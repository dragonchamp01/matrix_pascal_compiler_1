unit sqlparser;
{$mode objfpc}{$H+}
interface
uses System, Classes, SysUtils;
type
  TSQLStatementType = (stSelect, stInsert, stUpdate, stDelete, stCreateTable, stDropTable, stAlterTable, stCreateIndex, stDropIndex, stBegin, stCommit, stRollback, stUnknown);
  TSQLTokenType = (ttKeyword, ttIdentifier, ttNumber, ttString, ttOperator, ttSymbol, ttEOF);
  TSQLToken = record
    TokenType: TSQLTokenType;
    Value: string;
    Position: integer;
  end;
  TSQLStatement = class
  private
    FStmtType: TSQLStatementType;
    FRawSQL: string;
    FTables: TStrings;
  public
    constructor Create;
    destructor Destroy; override;
    property StmtType: TSQLStatementType read FStmtType;
    property RawSQL: string read FRawSQL;
    property Tables: TStrings read FTables;
  end;
  TSQLParser = class
  private
    FSQL: string;
    FPos: integer;
    FTokens: TList;
    procedure Tokenize;
    function NextToken: TSQLToken;
    function PeekToken: TSQLToken;
  public
    constructor Create(const ASQL: string);
    destructor Destroy; override;
    function Parse: TSQLStatement;
    function ParseSelect: TSQLStatement;
    function ParseInsert: TSQLStatement;
    function ParseUpdate: TSQLStatement;
    function ParseDelete: TSQLStatement;
    function ParseCreate: TSQLStatement;
    class function GetStatementType(const SQL: string): TSQLStatementType;
  end;
implementation
constructor TSQLStatement.Create;
begin FTables := TStringList.Create; end;
destructor TSQLStatement.Destroy;
begin FTables.Free; inherited; end;
constructor TSQLParser.Create(const ASQL: string);
begin FSQL := ASQL; FPos := 1; FTokens := TList.Create; end;
destructor TSQLParser.Destroy;
begin FTokens.Free; inherited; end;
procedure TSQLParser.Tokenize;
begin end;
function TSQLParser.NextToken: TSQLToken;
begin Result.TokenType := ttEOF; Result.Value := ''; Result.Position := FPos; end;
function TSQLParser.PeekToken: TSQLToken;
begin Result.TokenType := ttEOF; Result.Value := ''; Result.Position := FPos; end;
function TSQLParser.Parse: TSQLStatement;
begin Result := TSQLStatement.Create; end;
function TSQLParser.ParseSelect: TSQLStatement;
begin Result := TSQLStatement.Create; end;
function TSQLParser.ParseInsert: TSQLStatement;
begin Result := TSQLStatement.Create; end;
function TSQLParser.ParseUpdate: TSQLStatement;
begin Result := TSQLStatement.Create; end;
function TSQLParser.ParseDelete: TSQLStatement;
begin Result := TSQLStatement.Create; end;
function TSQLParser.ParseCreate: TSQLStatement;
begin Result := TSQLStatement.Create; end;
class function TSQLParser.GetStatementType(const SQL: string): TSQLStatementType;
begin
  if Pos('SELECT', UpperCase(SQL)) = 1 then Result := stSelect
  else if Pos('INSERT', UpperCase(SQL)) = 1 then Result := stInsert
  else if Pos('UPDATE', UpperCase(SQL)) = 1 then Result := stUpdate
  else if Pos('DELETE', UpperCase(SQL)) = 1 then Result := stDelete
  else Result := stUnknown;
end;
end.
