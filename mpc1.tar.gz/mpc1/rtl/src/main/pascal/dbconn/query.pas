unit query;
{$mode objfpc}{$H+}
interface
uses System, Classes, SysUtils, dbcore, sqlbuilder;
type
  TQueryState = (qsPrepared, qsExecuting, qsExecuted, qsClosed);
  TQuery = class
  private
    FDatabase: TDatabase;
    FSQL: string;
    FParams: TDBParams;
    FState: TQueryState;
    FBuilder: TSQLBuilder;
    FRows: TDBRows;
    FRowsAffected: int64;
    FLastError: string;
  public
    constructor Create(ADatabase: TDatabase);
    destructor Destroy; override;
    procedure SetSQL(const ASQL: string);
    procedure AddParam(const AName: string; AType: TParameterType; const AValue: string);
    procedure AddParamInteger(const AName: string; AValue: integer);
    procedure AddParamString(const AName: string; const AValue: string);
    procedure AddParamFloat(const AName: string; AValue: double);
    procedure AddParamBoolean(const AName: string; AValue: boolean);
    procedure AddParamDateTime(const AName: string; AValue: TDateTime);
    procedure AddParamBlob(const AName: string; const AValue: TBytes);
    procedure AddParamNull(const AName: string);
    procedure ClearParams;
    function Execute: boolean;
    function FetchAll: TDBRows;
    function RowsAffected: int64;
    function LastError: string;
    property Database: TDatabase read FDatabase;
    property SQL: string read FSQL;
    property State: TQueryState read FState;
    property Builder: TSQLBuilder read FBuilder;
  end;
implementation
constructor TQuery.Create(ADatabase: TDatabase);
begin FDatabase := ADatabase; FBuilder := TSQLBuilder.Create; FState := qsClosed; end;
destructor TQuery.Destroy;
begin FBuilder.Free; inherited; end;
procedure TQuery.SetSQL(const ASQL: string);
begin FSQL := ASQL; end;
procedure TQuery.AddParam(const AName: string; AType: TParameterType; const AValue: string);
var L: integer;
begin L := Length(FParams); SetLength(FParams, L + 1); FParams[L].Name := AName; FParams[L].ParamType := AType; FParams[L].Value := AValue; end;
procedure TQuery.AddParamInteger(const AName: string; AValue: integer);
begin AddParam(AName, ptInteger, AValue); end;
procedure TQuery.AddParamString(const AName: string; const AValue: string);
begin AddParam(AName, ptString, AValue); end;
procedure TQuery.AddParamFloat(const AName: string; AValue: double);
begin AddParam(AName, ptFloat, AValue); end;
procedure TQuery.AddParamBoolean(const AName: string; AValue: boolean);
begin AddParam(AName, ptBoolean, AValue); end;
procedure TQuery.AddParamDateTime(const AName: string; AValue: TDateTime);
begin AddParam(AName, ptDateTime, AValue); end;
procedure TQuery.AddParamBlob(const AName: string; const AValue: TBytes);
begin AddParam(AName, ptBlob, AValue); end;
procedure TQuery.AddParamNull(const AName: string);
begin AddParam(AName, ptNull, Null); end;
procedure TQuery.ClearParams;
begin SetLength(FParams, 0); end;
function TQuery.Execute: boolean;
begin FState := qsExecuted; Result := false; end;
function TQuery.FetchAll: TDBRows;
begin SetLength(Result, 0); end;
function TQuery.RowsAffected: int64;
begin Result := FRowsAffected; end;
function TQuery.LastError: string;
begin Result := FLastError; end;
end.
