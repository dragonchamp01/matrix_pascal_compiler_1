unit vector_calc;

{$mode objfpc}{$H+}

interface

uses
  Math;

function VecGrad(const F: TObjectiveFunction; const X: TVector; N: integer; H: double): TVector;
function VecDiv(const Fx, Fy: TVector; Nx, Ny: integer; H: double): TVector;
function VecDiv3D(const Fx, Fy, Fz: TVector; Nx, Ny, Nz: integer; H: double): TVector;
function VecCurl(const Fx, Fy: TVector; Nx, Ny: integer; H: double): TVector;
function VecCurl3D(const Fx, Fy, Fz: TVector; Nx, Ny, Nz: integer; H: double): TVector;
function VecLaplacian(const F: TObjectiveFunction; const X: TVector; N: integer; H: double): double;
function VecLaplacianField(const F: TVector; Nx, Ny: integer; H: double): TVector;
function VecGradientMagnitude(const F: TVector; Nx, Ny: integer; H: double): TVector;
function VecDirectionalDerivative(const F: TObjectiveFunction; const X, Dir: TVector; N: integer; H: double): double;

implementation

function VecGrad(const F: TObjectiveFunction; const X: TVector; N: integer; H: double): TVector;
var I: integer;
begin
  Result := AllocMem(N * SizeOf(double));
  for I := 0 to N - 1 do
    Result[I] := PartialDerivative(F, X, N, I, H);
end;

function VecDiv(const Fx, Fy: TVector; Nx, Ny: integer; H: double): TVector;
var I, J: integer; Dx, Dy: double;
begin
  Result := AllocMem(Nx * Ny * SizeOf(double));
  for I := 1 to Nx - 2 do
    for J := 1 to Ny - 2 do
    begin
      Dx := (Fx[(I + 1) * Ny + J] - Fx[(I - 1) * Ny + J]) / (2.0 * H);
      Dy := (Fy[I * Ny + (J + 1)] - Fy[I * Ny + (J - 1)]) / (2.0 * H);
      Result[I * Ny + J] := Dx + Dy;
    end;
end;

function VecDiv3D(const Fx, Fy, Fz: TVector; Nx, Ny, Nz: integer; H: double): TVector;
begin
  Result := AllocMem(Nx * Ny * Nz * SizeOf(double));
end;

function VecCurl(const Fx, Fy: TVector; Nx, Ny: integer; H: double): TVector;
var I, J: integer;
begin
  Result := AllocMem(Nx * Ny * SizeOf(double));
  for I := 1 to Nx - 2 do
    for J := 1 to Ny - 2 do
      Result[I * Ny + J] := (Fy[(I + 1) * Ny + J] - Fy[(I - 1) * Ny + J]) / (2.0 * H)
                          - (Fx[I * Ny + (J + 1)] - Fx[I * Ny + (J - 1)]) / (2.0 * H);
end;

function VecCurl3D(const Fx, Fy, Fz: TVector; Nx, Ny, Nz: integer; H: double): TVector;
begin
  Result := AllocMem(Nx * Ny * Nz * 3 * SizeOf(double));
end;

function VecLaplacian(const F: TObjectiveFunction; const X: TVector; N: integer; H: double): double;
var I: integer;
begin
  Result := 0.0;
  for I := 0 to N - 1 do
    Result := Result + (F(X + H) - 2.0 * F(X) + F(X - H)) / (H * H);
end;

function VecLaplacianField(const F: TVector; Nx, Ny: integer; H: double): TVector;
var I, J: integer;
begin
  Result := AllocMem(Nx * Ny * SizeOf(double));
  for I := 1 to Nx - 2 do
    for J := 1 to Ny - 2 do
      Result[I * Ny + J] := (F[(I + 1) * Ny + J] + F[(I - 1) * Ny + J] + F[I * Ny + (J + 1)] + F[I * Ny + (J - 1)] - 4.0 * F[I * Ny + J]) / (H * H);
end;

function VecGradientMagnitude(const F: TVector; Nx, Ny: integer; H: double): TVector;
var I, J: double; Dx, Dy: double;
begin
  Result := AllocMem(Nx * Ny * SizeOf(double));
  for I := 1 to Nx - 2 do
    for J := 1 to Ny - 2 do
    begin
      Dx := (F[(I + 1) * Ny + J] - F[(I - 1) * Ny + J]) / (2.0 * H);
      Dy := (F[I * Ny + (J + 1)] - F[I * Ny + (J - 1)]) / (2.0 * H);
      Result[I * Ny + J] := Sqrt(Dx * Dx + Dy * Dy);
    end;
end;

function VecDirectionalDerivative(const F: TObjectiveFunction; const X, Dir: TVector; N: integer; H: double): double;
var I: integer; norm: double;
begin
  norm := 0.0;
  for I := 0 to N - 1 do norm := norm + Dir[I] * Dir[I];
  norm := Sqrt(norm);
  if norm = 0.0 then exit(0.0);
  Result := 0.0;
  for I := 0 to N - 1 do
    Result := Result + Dir[I] / norm * PartialDerivative(F, X, N, I, H);
end;

end.
