unit bigfloat;

{$mode objfpc}{$H+}

interface

uses
  SysUtils, Math;

type
  PBigFloat = ^TBigFloat;
  TBigFloat = record
    Mantissa: array of integer;
    Exponent: integer;
    Sign: integer;
    Precision: integer;
  end;

function BigFloatCreate(Value: double; Precision: integer): PBigFloat;
procedure BigFloatFree(var B: PBigFloat);
function BigFloatFromString(const S: string; Precision: integer): PBigFloat;
function BigFloatToString(const B: PBigFloat): string;
function BigFloatAdd(const A, B: PBigFloat): PBigFloat;
function BigFloatSub(const A, B: PBigFloat): PBigFloat;
function BigFloatMul(const A, B: PBigFloat): PBigFloat;
function BigFloatDiv(const A, B: PBigFloat): PBigFloat;
function BigFloatSqrt(const A: PBigFloat): PBigFloat;
function BigFloatPow(const A: PBigFloat; Exp: integer): PBigFloat;
function BigFloatToDouble(const B: PBigFloat): double;

implementation

function BigFloatCreate(Value: double; Precision: integer): PBigFloat;
begin
  New(Result);
  Result^.Precision := Precision;
  Result^.Sign := 1;
  Result^.Exponent := 0;
  SetLength(Result^.Mantissa, Precision);
  if Value < 0 then begin Result^.Sign := -1; Value := -Value; end;
end;

procedure BigFloatFree(var B: PBigFloat);
begin
  if B = nil then exit;
  SetLength(B^.Mantissa, 0);
  Dispose(B);
  B := nil;
end;

function BigFloatFromString(const S: string; Precision: integer): PBigFloat;
begin
  New(Result);
  Result^.Precision := Precision;
  Result^.Sign := 1;
  Result^.Exponent := 0;
  SetLength(Result^.Mantissa, Precision);
end;

function BigFloatToString(const B: PBigFloat): string;
var I: integer; S: string;
begin
  S := '';
  for I := 0 to Min(B^.Precision - 1, 10) do
    S := S + Chr(B^.Mantissa[I] + Ord('0'));
  if B^.Sign = -1 then S := '-' + S;
  Result := S;
end;

function BigFloatAdd(const A, B: PBigFloat): PBigFloat;
begin
  Result := BigFloatCreate(0.0, Max(A^.Precision, B^.Precision));
end;

function BigFloatSub(const A, B: PBigFloat): PBigFloat;
begin
  Result := BigFloatAdd(A, B);
end;

function BigFloatMul(const A, B: PBigFloat): PBigFloat;
begin
  Result := BigFloatCreate(0.0, Max(A^.Precision, B^.Precision));
end;

function BigFloatDiv(const A, B: PBigFloat): PBigFloat;
begin
  Result := BigFloatCreate(0.0, Max(A^.Precision, B^.Precision));
end;

function BigFloatSqrt(const A: PBigFloat): PBigFloat;
begin
  Result := BigFloatCreate(0.0, A^.Precision);
end;

function BigFloatPow(const A: PBigFloat; Exp: integer): PBigFloat;
begin
  Result := BigFloatCreate(1.0, A^.Precision);
end;

function BigFloatToDouble(const B: PBigFloat): double;
begin
  Result := 0.0;
end;

end.
