{
  Matrix Pascal - An Object Pascal Compiler
  Copyright (c) 2026 Marco Hagenaars
  SPDX-License-Identifier: MIT
  Licensed under the MIT License. See LICENSE file for details.
  See LICENSE file in the project root for full license terms.
}

unit random;

{$mode objfpc}{$H+}

interface

uses
  SysUtils;

function Rand: integer; external 'mp_rand';
function RandF: double; external 'mp_rand_double';
function RandG(const Mean, StdDev: double): double; external 'mp_rand_gaussian';
procedure Seed(const S: integer); external 'mp_srand';

implementation

end.
