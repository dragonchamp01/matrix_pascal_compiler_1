unit quaternion_rot;

{$mode objfpc}{$H+}

interface

uses
  Math, Quaternion;

type
  TQuaternionRot = record
    Q: PQuaternion;
  end;

function QRotFromEuler(Yaw, Pitch, Roll: double): PQuaternion;
function QRotToEuler(const Q: PQuaternion): TVector;
function QRotBetweenVectors(const From, To_: TTVector3): PQuaternion;
function QRotLookAt(const Direction, Up: TTVector3): PQuaternion;
function QRotNlerp(const A, B: PQuaternion; T: double): PQuaternion;
function QRotRotor(const From, To_: TTVector3): PQuaternion;
function QRotIntegrate(const Q: PQuaternion; const AngularVel: TTVector3; Dt: double): PQuaternion;

implementation

function QRotFromEuler(Yaw, Pitch, Roll: double): PQuaternion;
var Cy, Sy, Cp, Sp, Cr, Sr: double;
begin
  Cy := Cos(Yaw / 2.0); Sy := Sin(Yaw / 2.0);
  Cp := Cos(Pitch / 2.0); Sp := Sin(Pitch / 2.0);
  Cr := Cos(Roll / 2.0); Sr := Sin(Roll / 2.0);
  Result := QuatCreate(
    Cr * Cp * Cy + Sr * Sp * Sy,
    Sr * Cp * Cy - Cr * Sp * Sy,
    Cr * Sp * Cy + Sr * Cp * Sy,
    Cr * Cp * Sy - Sr * Sp * Cy
  );
end;

function QRotToEuler(const Q: PQuaternion): TVector;
var SinPitch, Yaw, Pitch, Roll: double;
begin
  Result := AllocMem(3 * SizeOf(double));
  SinPitch := 2.0 * (Q^.W * Q^.Y - Q^.Z * Q^.X);
  if Abs(SinPitch) >= 1.0 then
  begin
    Pitch := Pi / 2.0 * Sign(SinPitch);
    Yaw := ArcTan2(2.0 * (Q^.W * Q^.Z - Q^.X * Q^.Y), 1.0 - 2.0 * (Q^.Y * Q^.Y + Q^.Z * Q^.Z));
    Roll := 0.0;
  end
  else
  begin
    Yaw := ArcTan2(2.0 * (Q^.W * Q^.Z + Q^.X * Q^.Y), 1.0 - 2.0 * (Q^.Y * Q^.Y + Q^.Z * Q^.Z));
    Pitch := ArcSin(SinPitch);
    Roll := ArcTan2(2.0 * (Q^.W * Q^.X + Q^.Y * Q^.Z), 1.0 - 2.0 * (Q^.X * Q^.X + Q^.Y * Q^.Y));
  end;
  Result[0] := Yaw; Result[1] := Pitch; Result[2] := Roll;
end;

function QRotBetweenVectors(const From, To_: TTVector3): PQuaternion;
var Dot: double; Axis: TTVector3;
begin
  Dot := From.X * To_.X + From.Y * To_.Y + From.Z * To_.Z;
  if Dot > 0.999999 then
    exit(QuatCreate(1.0, 0.0, 0.0, 0.0));
  if Dot < -0.999999 then
  begin
    Axis.X := 1.0; Axis.Y := 0.0; Axis.Z := 0.0;
    if (From.X * From.X) < 0.1 then
    begin Axis.X := 0.0; Axis.Y := 1.0; Axis.Z := 0.0; end;
    Result := QuatCreate(0.0, Axis.X, Axis.Y, Axis.Z);
    exit;
  end;
  Axis.X := From.Y * To_.Z - From.Z * To_.Y;
  Axis.Y := From.Z * To_.X - From.X * To_.Z;
  Axis.Z := From.X * To_.Y - From.Y * To_.X;
  Dot := Sqrt(2.0 * (1.0 + Dot));
  Result := QuatCreate(0.5 * Dot, 0.5 * Axis.X / Dot, 0.5 * Axis.Y / Dot, 0.5 * Axis.Z / Dot);
  Result := QuatNormalize(Result);
end;

function QRotLookAt(const Direction, Up: TTVector3): PQuaternion;
var Fwd, Right, UpDir: TTVector3;
begin
  Fwd := Direction;
  Right.X := Up.Y * Fwd.Z - Up.Z * Fwd.Y;
  Right.Y := Up.Z * Fwd.X - Up.X * Fwd.Z;
  Right.Z := Up.X * Fwd.Y - Up.Y * Fwd.X;
  UpDir.X := Fwd.Y * Right.Z - Fwd.Z * Right.Y;
  UpDir.Y := Fwd.Z * Right.X - Fwd.X * Right.Z;
  UpDir.Z := Fwd.X * Right.Y - Fwd.Y * Right.X;
  Result := QuatCreate(Sqrt(1.0 + Right.X + UpDir.Y + Fwd.Z) / 2.0, 0.0, 0.0, 0.0);
end;

function QRotNlerp(const A, B: PQuaternion; T: double): PQuaternion;
begin
  Result := QuatAdd(QuatMulS(A, 1.0 - T), QuatMulS(B, T));
  Result := QuatNormalize(Result);
end;

function QRotRotor(const From, To_: TTVector3): PQuaternion;
begin
  Result := QRotBetweenVectors(From, To_);
end;

function QRotIntegrate(const Q: PQuaternion; const AngularVel: TTVector3; Dt: double): PQuaternion;
var Half: double; Delta: PQuaternion;
begin
  Half := Dt * 0.5;
  Delta := QuatCreate(0.0, AngularVel.X * Half, AngularVel.Y * Half, AngularVel.Z * Half);
  Result := QuatAdd(Q, QuatMul(Delta, Q));
  Result := QuatNormalize(Result);
  QuatFree(Delta);
end;

end.
