unit fuzzy;

{$mode objfpc}{$H+}

interface

uses
  Math;

type
  PFuzzySet = ^TFuzzySet;
  TFuzzySet = record
    name: string;
    A, B, C, D: double;
    Kind: integer;
  end;

  PFuzzyRule = ^TFuzzyRule;
  TFuzzyRule = record
    Antecedent: array[0..9] of PFuzzySet;
    Consequent: array[0..9] of PFuzzySet;
    AntecedentCount: integer;
    ConsequentCount: integer;
  end;

  PFuzzySystem = ^TFuzzySystem;
  TFuzzySystem = record
    Sets: array[0..99] of PFuzzySet;
    Rules: array[0..99] of PFuzzyRule;
    SetCount: integer;
    RuleCount: integer;
  end;

function FuzzyTriangle(A, B, C, X: double): double;
function FuzzyTrapezoid(A, B, C, D, X: double): double;
function FuzzyGaussian(Mean, StdDev, X: double): double;
function FuzzyBell(A, B, C, X: double): double;
function FuzzyAnd(A, B: double): double;
function FuzzyOr(A, B: double): double;
function FuzzyNot(A: double): double;
function FuzzyDefuzzifyCenter(const Sets: array of PFuzzySet; const Values: array of double; Count: integer): double;
function FuzzyDefuzzifyBisector(const Sets: array of PFuzzySet; const Values: array of double; Count: integer): double;
function FuzzyDefuzzifyMax(const Sets: array of PFuzzySet; const Values: array of double; Count: integer): double;

implementation

function FuzzyTriangle(A, B, C, X: double): double;
begin
  if X <= A then Result := 0.0
  else if X <= B then Result := (X - A) / (B - A)
  else if X <= C then Result := (C - X) / (C - B)
  else Result := 0.0;
end;

function FuzzyTrapezoid(A, B, C, D, X: double): double;
begin
  if X <= A then Result := 0.0
  else if X <= B then Result := (X - A) / (B - A)
  else if X <= C then Result := 1.0
  else if X <= D then Result := (D - X) / (D - C)
  else Result := 0.0;
end;

function FuzzyGaussian(Mean, StdDev, X: double): double;
begin
  if StdDev = 0.0 then Result := 0.0
  else Result := Exp(-0.5 * ((X - Mean) / StdDev) * ((X - Mean) / StdDev));
end;

function FuzzyBell(A, B, C, X: double): double;
begin
  Result := 1.0 / (1.0 + Power(Abs((X - C) / A), 2.0 * B));
end;

function FuzzyAnd(A, B: double): double;
begin
  Result := Min(A, B);
end;

function FuzzyOr(A, B: double): double;
begin
  Result := Max(A, B);
end;

function FuzzyNot(A: double): double;
begin
  Result := 1.0 - A;
end;

function FuzzyDefuzzifyCenter(const Sets: array of PFuzzySet; const Values: array of double; Count: integer): double;
var I: double; Num, Den: double;
begin
  Num := 0.0; Den := 0.0;
  for I := 0 to Count - 1 do
  begin
    Num := Num + Values[I] * Values[I];
    Den := Den + Values[I];
  end;
  if Den = 0.0 then Result := 0.0 else Result := Num / Den;
end;

function FuzzyDefuzzifyBisector(const Sets: array of PFuzzySet; const Values: array of double; Count: integer): double;
begin
  Result := FuzzyDefuzzifyCenter(Sets, Values, Count);
end;

function FuzzyDefuzzifyMax(const Sets: array of PFuzzySet; const Values: array of double; Count: integer): double;
var I: integer; MaxVal, MaxIdx: double;
begin
  MaxVal := Values[0]; MaxIdx := 0;
  for I := 1 to Count - 1 do
    if Values[I] > MaxVal then begin MaxVal := Values[I]; MaxIdx := I; end;
  Result := MaxIdx;
end;

end.
