unit Math.Special;
{$mode objfpc}{$H+}
interface
uses System, Math;
type
  TSpecial = class
    class function Gamma(const X: double): double; static;
    class function LnGamma(const X: double): double; static;
    class function Beta(const X, Y: double): double; static;
    class function LnBeta(const X, Y: double): double; static;
    class function Erf(const X: double): double; static;
    class function Erfc(const X: double): double; static;
    class function Factorial(N: integer): double; static;
    class function Binomial(N, K: integer): double; static;
    class function Permutations(N, K: integer): double; static;
    class function BesselJ(N: integer; const X: double): double; static;
    class function BesselY(N: integer; const X: double): double; static;
    class function Legendre(N: integer; const X: double): double; static;
    class function Chebyshev(N: integer; const X: double): double; static;
    class function Zeta(const X: double): double; static;
  end;
implementation
end.
