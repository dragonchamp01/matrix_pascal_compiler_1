{
    Matrix Pascal - RTL Math Module
    AVX-512 Intrinsics Wrapper
    ═══════════════════════════════════════════════════════════
}

unit avx512;

interface

uses
  tensor_types;

function vadd512(a, b: PTensor): PTensor; external;
function vsub512(a, b: PTensor): PTensor; external;
function vmul512(a, b: PTensor): PTensor; external;
function vdiv512(a, b: PTensor): PTensor; external;
function vpow512(a, b: PTensor): PTensor; external;

implementation

end.
