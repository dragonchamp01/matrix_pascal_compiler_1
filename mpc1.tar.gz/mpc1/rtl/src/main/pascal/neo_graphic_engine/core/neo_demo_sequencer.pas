unit neo_demo_sequencer;

interface

uses
  sysutils, classes, neo_engine_state;

type
  TDemoScene = class
  private
    FDuration: single;
    FAction: procedure();
  public
    constructor Create(Duration: single; Action: procedure());
    property Duration: single read FDuration;
    procedure Execute;
  end;

  TNeoSequencer = class
  private
    FScenes: array of TDemoScene;
    FCurrentScene: integer;
    FElapsed: single;
  public
    constructor Create;
    procedure AddScene(Scene: TDemoScene);
    procedure Update(DeltaTime: single);
  end;

implementation

constructor TDemoScene.Create(Duration: single; Action: procedure());
begin
  inherited Create;
  FDuration := Duration;
  FAction := Action;
end;

procedure TDemoScene.Execute;
begin
  if Assigned(FAction) then FAction();
end;

constructor TNeoSequencer.Create;
begin
  inherited Create;
  FCurrentScene := 0;
  FElapsed := 0;
end;

procedure TNeoSequencer.AddScene(Scene: TDemoScene);
begin
  SetLength(FScenes, Length(FScenes) + 1);
  FScenes[High(FScenes)] := Scene;
end;

procedure TNeoSequencer.Update(DeltaTime: single);
begin
  if (FCurrentScene >= 0) and (FCurrentScene < Length(FScenes)) then
  begin
    FScenes[FCurrentScene].Execute;
    FElapsed := FElapsed + DeltaTime;
    if FElapsed > FScenes[FCurrentScene].Duration then
    begin
      FCurrentScene := FCurrentScene + 1;
      FElapsed := 0;
    end;
  end;
end;

end.
