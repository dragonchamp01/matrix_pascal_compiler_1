unit neo_asm;

interface

uses
  sysutils;

{ Highly optimized assembler routines for the Neo Graphic Engine }

procedure neo_clear_screen(Buffer: pointer; Width, Height: integer; Color: cardinal); cdecl; external;
procedure neo_put_pixel(Buffer: pointer; Width, Height, X, Y: integer; Color: cardinal); cdecl; external;
procedure neo_blit(Dest: pointer; Src: pointer; Width, Height, DestX, DestY, SrcX, SrcY, DestPitch, SrcPitch: integer); cdecl; external;
procedure neo_blit_alpha(Dest: pointer; Src: pointer; Width, Height, DestX, DestY, SrcX, SrcY, DestPitch, SrcPitch: integer; Alpha: byte); cdecl; external;
procedure neo_draw_line(Buffer: pointer; Width, Height, X1, Y1, X2, Y2: integer; Color: cardinal); cdecl; external;
procedure neo_xor_cipher(Data: pointer; Len: int64; Key: pointer; KeyLen: integer); cdecl; external;

implementation

end.
