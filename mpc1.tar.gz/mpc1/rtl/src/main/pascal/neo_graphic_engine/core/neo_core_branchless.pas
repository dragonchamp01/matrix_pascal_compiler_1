unit neo_core_branchless;

interface

uses
  sysutils, math;

type
  TNeoBranchless = class
  public
    class function Select(Cond: boolean; TrueVal, FalseVal: integer): integer;
    class function Step(Edge: single, X: single): single;
    class function Clamp(X, MinV, MaxV: single): single;
  end;

implementation

class function TNeoBranchless.Select(Cond: boolean; TrueVal, FalseVal: integer): integer;
begin
  // (Cond * TrueVal) + (!Cond * FalseVal)
  var mask := if Cond then -1 else 0;
  Result := (mask and TrueVal) or ((not mask) and FalseVal);
end;

class function TNeoBranchless.Step(Edge: single; X: single): single;
begin
  // Returns 1 if X >= Edge else 0
  Result := single((X >= Edge));
end;

class function TNeoBranchless.Clamp(X, MinV, MaxV: single): single;
begin
  Result := Max(MinV, Min(MaxV, X));
end;

end.
