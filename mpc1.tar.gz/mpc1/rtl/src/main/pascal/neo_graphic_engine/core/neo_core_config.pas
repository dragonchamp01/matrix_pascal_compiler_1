unit neo_core_config;

interface

uses
  sysutils, classes;

type
  TNeoConfig = class
  private
    FSettings: TDictionary<string, string>;
  public
    constructor Create;
    destructor Destroy; override;
    procedure Load(FileName: string);
    function GetString(Key: string; default: string): string;
    function GetInt(Key: string; default: integer): integer;
  end;

implementation

constructor TNeoConfig.Create;
begin
  inherited Create;
  FSettings := TDictionary<string, string>.Create;
end;

destructor TNeoConfig.Destroy;
begin
  FSettings.Free;
  inherited Destroy;
end;

procedure TNeoConfig.Load(FileName: string);
var
  list: TStringList;
  line, key, value: string;
begin
  if not FileExists(FileName) then exit;

  list := TStringList.Create;
  try
    list.LoadFromFile(FileName);
    for line in list do
    begin
      if (line = '') or (line[1] = '#') or (line[1] = ';') then continue;
      
      var pos := Pos('=', line);
      if pos > 0 then
      begin
        key := Trim(Copy(line, 1, pos - 1));
        value := Trim(Copy(line, pos + 1, Length(line) - pos));
        if key <> '' then
          FSettings.AddOrSetValue(key, value);
      end;
    end;
  finally
    list.Free;
  end;
end;


function TNeoConfig.GetString(Key: string; default: string): string;
begin
  if FSettings.ContainsKey(Key) then Result := FSettings[Key] else Result := default;
end;

function TNeoConfig.GetInt(Key: string; default: integer): integer;
begin
  if FSettings.ContainsKey(Key) then Result := StrToInt(FSettings[Key]) else Result := default;
end;

end.
