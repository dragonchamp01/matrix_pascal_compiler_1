unit neo_math_matrix_ext;

interface

uses
  neo_math_mat, neo_math_vec;

type
  TMatrixExt = class
  public
    class procedure LookAt(var Mat: TMat4; eye, center, up: TVec3);
    class procedure Perspective(var Mat: TMat4; fov, aspect, near, far: single);
  end;

implementation

class procedure TMatrixExt.LookAt(var Mat: TMat4; eye, center, up: TVec3);
begin
  Mat := TMat4.LookAt(eye, center, up);
end;

class procedure TMatrixExt.Perspective(var Mat: TMat4; fov, aspect, near, far: single);
begin
  Mat := TMat4.Perspective(fov, aspect, near, far);
end;

end.
