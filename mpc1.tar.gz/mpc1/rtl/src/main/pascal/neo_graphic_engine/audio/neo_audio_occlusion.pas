unit neo_audio_occlusion;

interface

uses
  sysutils, neo_audio_dsp;

type
   TNeoOcclusion = class
   private
     FFilter: TNeoLowPass;
   public
     constructor Create(SampleRate: integer);
     destructor Destroy; override;
     procedure SetOcclusion(Factor: single; SampleRate: single);
     procedure Process(var Sample: single; DeltaTime: single);
   end;

implementation

constructor TNeoOcclusion.Create(SampleRate: integer);
begin
   inherited Create;
   FFilter := TNeoLowPass.Create(SampleRate, 20000);
end;

destructor TNeoOcclusion.Destroy;
begin
   FFilter.Free;
   inherited Destroy;
end;

procedure TNeoOcclusion.SetOcclusion(Factor: single; SampleRate: single);
begin
   // Factor 1.0 = fully occluded (low cutoff), 0.0 = not occluded (high cutoff)
   var cutoff := 20000.0 * (1.0 - Factor * 0.95);
   FFilter.SetCutoff(SampleRate, Max(20, cutoff));
end;

procedure TNeoOcclusion.Process(var Sample: single; DeltaTime: single);
begin
   FFilter.Process(Sample, DeltaTime);
end;

end.
