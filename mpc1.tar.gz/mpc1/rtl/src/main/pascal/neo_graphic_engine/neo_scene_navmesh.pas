unit neo_scene_navmesh;

interface

uses
  sysutils, math, neo_math_vec, classes;

type
   TNavMesh = class
   private
     FGridSize: single;
     FWalkable: array of boolean;
     FWidth, FHeight: integer;
     function GetIndex(x, y: integer): integer;
   public
     constructor Create(W, H: integer; Spacing: single);
     destructor Destroy; override;
     function IsWalkable(Pos: TVec3): boolean;
     function FindPath(Start, end: TVec3): array of TVec3;
     procedure SetWalkable(X, Y: integer; Walkable: boolean);
   end;

implementation

constructor TNavMesh.Create(W, H: integer; Spacing: single);
begin
   inherited Create;
   FWidth := W;
   FHeight := H;
   FGridSize := Spacing;
   SetLength(FWalkable, W * H);
   for var i := 0 to W * H - 1 do FWalkable[i] := true;
end;

destructor TNavMesh.Destroy;
begin
   inherited Destroy;
end;

function TNavMesh.GetIndex(x, y: integer): integer;
begin
   Result := y * FWidth + x;
end;

procedure TNavMesh.SetWalkable(X, Y: integer; Walkable: boolean);
begin
   if (X >= 0) and (X < FWidth) and (Y >= 0) and (Y < FHeight) then
     FWalkable[GetIndex(X, Y)] := Walkable;
end;

function TNavMesh.IsWalkable(Pos: TVec3): boolean;
var
   gx, gy: integer;
begin
   gx := Round(Pos.X / FGridSize);
   gy := Round(Pos.Y / FGridSize);
   if (gx >= 0) and (gx < FWidth) and (gy >= 0) and (gy < FHeight) then
     Result := FWalkable[GetIndex(gx, gy)]
   else
     Result := false;
end;

function TNavMesh.FindPath(Start, end: TVec3): array of TVec3;
var
   startX, startY, endX, endY: integer;
   openSet: TList<integer>;
   closedSet: TDictionary<integer, integer>; // Index -> Parent Index
   gScore: TDictionary<integer, single>;
   fScore: TDictionary<integer, single>;
   curr: integer;
   nx, ny: integer;
   dx, dy: array of integer;
   h: single;
begin
   startX := Clamp(Round(Start.X / FGridSize), 0, FWidth - 1);
   startY := Clamp(Round(Start.Y / FGridSize), 0, FHeight - 1);
   endX := Clamp(Round(end.X / FGridSize), 0, FWidth - 1);
   endY := Clamp(Round(end.Y / FGridSize), 0, FHeight - 1);

   openSet := TList<integer>.Create;
   closedSet := TDictionary<integer, integer>.Create;
   gScore := TDictionary<integer, single>.Create;
   fScore := TDictionary<integer, single>.Create;
   
   try
     var startIdx := GetIndex(startX, startY);
     var endIdx := GetIndex(endX, endY);
     
     openSet.Add(startIdx);
     gScore.Add(startIdx, 0);
     h := (Abs(startX - endX) + Abs(startY - endY)) * FGridSize;
     fScore.Add(startIdx, h);
     
     while openSet.Count > 0 do
     begin
       // Get node in openSet with lowest fScore
       curr := openSet[0];
       var minF := fScore[curr];
       var minIdx := 0;
       for var i := 1 to openSet.Count - 1 do
       begin
         if fScore[openSet[i]] < minF then
         begin
           minF := fScore[openSet[i]];
           curr := openSet[i];
           minIdx := i;
         end;
       end;
       
       if curr = endIdx then
       begin
         // Reconstruct path
         var pathList := TList<TVec3>.Create;
         var temp := curr;
         while temp <> startIdx do
         begin
           var tx := temp mod FWidth;
           var ty := temp div FWidth;
           pathList.Add(TVec3.Create(tx * FGridSize, ty * FGridSize, 0));
           temp := closedSet[temp];
         end;
         pathList.Add(TVec3.Create(startX * FGridSize, startY * FGridSize, 0));
         
         // Reverse path
         SetLength(Result, pathList.Count);
         for var i := 0 to pathList.Count - 1 do
           Result[pathList.Count - 1 - i] := pathList[i];
         pathList.Free;
         exit;
       end;
       
       openSet.RemoveAt(minIdx);
       
       // Neighbors
       dx := [-1, 0, 1, 0, -1, 1, -1, 1];
       dy := [0, 1, 0, -1, -1, -1, 1, 1];
       
       for var i := 0 to 7 do
       begin
         nx := (curr mod FWidth) + dx[i];
         ny := (curr div FWidth) + dy[i];
         
         if (nx >= 0) and (nx < FWidth) and (ny >= 0) and (ny < FHeight) then
         begin
           var nIdx := GetIndex(nx, ny);
           if FWalkable[nIdx] and (not closedSet.ContainsKey(nIdx)) then
           begin
             var tentativeGScore := gScore[curr] + Sqrt((dx[i]*dx[i] + dy[i]*dy[i])*FGridSize*FGridSize);
             
             if (not gScore.ContainsKey(nIdx)) or (tentativeGScore < gScore[nIdx]) then
             begin
               closedSet.Add(nIdx, curr);
               gScore.Add(nIdx, tentativeGScore);
               h := (Abs(nx - endX) + Abs(ny - endY)) * FGridSize;
               fScore.Add(nIdx, tentativeGScore + h);
               
               if not openSet.contains(nIdx) then
                 openSet.Add(nIdx);
             end;
           end;
         end;
       end;
     end;
     
     SetLength(Result, 0); // No path found
   finally
     openSet.Free;
     closedSet.Free;
     gScore.Free;
     fScore.Free;
   end;
end;

end.
