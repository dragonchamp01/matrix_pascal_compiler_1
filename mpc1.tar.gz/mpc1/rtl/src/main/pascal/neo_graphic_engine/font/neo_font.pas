unit neo_font;

interface

uses
  sysutils, classes;

type
  TNeoFont = class
  private
    FData: array of byte;
    FWidth, FHeight: integer;
    FCharCount: integer;
  public
    constructor Create;
    destructor Destroy; override;
    procedure LoadFromFile(FileName: string);
    function GetCharBitmap(CharVal: byte; Row: integer): byte;
    property Width: integer read FWidth;
    property Height: integer read FHeight;
  end;

implementation

constructor TNeoFont.Create;
begin
  FWidth := 8;
  FHeight := 8;
  FCharCount := 256;
end;

destructor TNeoFont.Destroy;
begin
  inherited Destroy;
end;

procedure TNeoFont.LoadFromFile(FileName: string);
var
  F: TFileStream;
begin
  if not FileExists(FileName) then
    raise Exception.Create('Font file not found: ' + FileName);
    
  F := TFileStream.Create(FileName, fmOpenRead);
  try
    SetLength(FData, FCharCount * FHeight);
    F.read(FData[0], Length(FData));
  finally
    F.Free;
  end;
end;

function TNeoFont.GetCharBitmap(CharVal: byte; Row: integer): byte;
begin
  if (CharVal < FCharCount) and (Row < FHeight) then
    Result := FData[CharVal * FHeight + Row]
  else
    Result := 0;
end;

end.
