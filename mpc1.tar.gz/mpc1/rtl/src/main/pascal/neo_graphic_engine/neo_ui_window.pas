unit neo_ui_window;

interface

uses
  neo_ui_base, neo_ui_panel, neo_graphics, neo_input, sysutils;

type
  TWindowState = (wsNormal, wsMinimized, wsMaximized);

  TNeoWindow = class(TNeoPanel)
  private
    FTitle: string;
    FState: TWindowState;
    FIsDragging: boolean;
    FDragOffset: TVec2;
    FIsResizing: boolean;
    FResizeEdge: integer; // 0: bottom-right
    FTitleHeight: integer;
    FCloseClicked: boolean;
  protected
    procedure OnMouseDown(X, Y: integer); override;
    procedure OnMouseMove(X, Y: integer); override;
    procedure OnMouseUp; 
  public
    constructor Create(X, Y, W, H: integer; Title: string);
    destructor Destroy; override;
    procedure CloseWindow;
    function IsCloseRequested: boolean;
    procedure Render(Graphics: TNeoGraphics); override;
    procedure HandleInput(Input: TNeoInput); override;
    property Title: string read FTitle write FTitle;
    property State: TWindowState read FState write FState;
  end;

implementation

{ TNeoWindow }

constructor TNeoWindow.Create(X, Y, W, H: integer; Title: string);
begin
  inherited Create(X, Y, W, H);
  FTitle := Title;
  FState := wsNormal;
  FIsDragging := false;
  FIsResizing := false;
  FTitleHeight := 25;
  FCloseClicked := false;
  FBackgroundColor := $F0F0F0;
end;

destructor TNeoWindow.Destroy;
begin
  inherited Destroy;
end;

procedure TNeoWindow.CloseWindow;
begin
  FVisible := false;
end;

function TNeoWindow.IsCloseRequested: boolean;
begin
  Result := FCloseClicked;
end;

procedure TNeoWindow.OnMouseDown(X, Y: integer);
var
  relY: integer;
begin
  relY := Y - FY;
  if relY < FTitleHeight then
  begin
    // Dragging title bar
    FIsDragging := true;
    FDragOffset.X := X - FX;
    FDragOffset.Y := Y - FY;
  end
  else if (X > FX + FWidth - 10) and (Y > FY + FHeight - 10) then
  begin
    // Resizing from corner
    FIsResizing := true;
  end;
end;

procedure TNeoWindow.OnMouseMove(X, Y: integer);
begin
  if FIsDragging then
  begin
    FX := X - Round(FDragOffset.X);
    FY := Y - Round(FDragOffset.Y);
  end
  else if FIsResizing then
  begin
    FWidth := Max(100, X - FX);
    FHeight := Max(100, Y - FY);
  end;
end;

procedure TNeoWindow.OnMouseUp;
begin
  FIsDragging := false;
  FIsResizing := false;
end;

procedure TNeoWindow.Render(Graphics: TNeoGraphics);
var
  absX, absY: integer;
begin
  if not FVisible then exit;
  
  absX := FX;
  absY := FY;
  if Assigned(FParent) then
  begin
    absX := absX + FParent.FX;
    absY := absY + FParent.FY;
  end;
  
  // Window Body
  Graphics.FillRect(absX, absY, FWidth, FHeight, FBackgroundColor);
  Graphics.DrawRect(absX, absY, FWidth, FHeight, $000000, 1);
  
  // Title Bar
  Graphics.FillRect(absX, absY, FWidth, FTitleHeight, $000080);
  Graphics.DrawText(absX + 5, absY + 2, FTitle, $FFFFFF);
  
  // Close Button
  Graphics.FillRect(absX + FWidth - 20, absY + 2, 15, 15, $C0C0C0);
  Graphics.DrawText(absX + FWidth - 15, absY + 4, 'X', $000000);
  
  // Content
  for var i := 0 to Length(FChildren) - 1 do
    FChildren[i].Render(Graphics);
end;

procedure TNeoWindow.HandleInput(Input: TNeoInput);
var
  mx, my: integer;
begin
  if not FVisible or not FEnabled then exit;
  
  Input.GetMousePos(mx, my);
  
  if Input.IsMouseButtonUp(0) then OnMouseUp;
  
  if IsPointInside(mx, my) then
  begin
    // Close button check
    if (mx > FX + FWidth - 20) and (my > FY) and (my < FY + FTitleHeight) then
    begin
      FCloseClicked := true;
      exit;
    end;
    
    OnMouseMove(mx, my);
    if Input.IsMouseButtonDown(0) then
      OnMouseDown(mx, my);
  end;
  
  for var i := Length(FChildren) - 1 downto 0 do
    FChildren[i].HandleInput(Input);
end;

end.
