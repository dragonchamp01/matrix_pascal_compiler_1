{
    Matrix Pascal - RTL AI Module
    AI Knowledge Graph and Relation Unit
    ═══════════════════════════════════════════════════════════
    NL: Deze unit implementeert een Knowledge Graph (KG) voor AI,
    waarbij entiteiten en hun relaties worden opgeslagen in een
    gerichte graafstructuur.
    
    EN: This unit implements a Knowledge Graph (KG) for AI, 
    where entities and their relations are stored in a 
    directed graph structure.
}

unit ai_graph;

interface

uses
  System, Classes, SysUtils, Math, tensor;

type
  TEntity = string;
  TRelation = string;

  TEdge = record
    Target: TEntity;
    Relation: TRelation;
    Weight: double;
  end;

  TKnowledgeGraph = class(TObject)
  private
    FAdjList: TStringList; // Simplified as JSON or custom map
    FNodes: TStringList;
    function GetEdges(Node: TEntity): array of TEdge;
  public
    constructor Create;
    destructor Destroy; override;
    
    procedure AddEntity(Entity: TEntity);
    procedure AddRelation(Source, Target: TEntity; Rel: TRelation; Weight: double = 1.0);
    function FindPath(Start, end: TEntity): array of TRelation;
    function GetRelated(Entity: TEntity; Rel: TRelation): array of TEntity;
    
    property Nodes: TStringList read FNodes;
  end;

implementation

{ TKnowledgeGraph }

constructor TKnowledgeGraph.Create;
begin
  inherited Create;
  FAdjList := TStringList.Create;
  FNodes := TStringList.Create;
end;

destructor TKnowledgeGraph.Destroy;
begin
  FAdjList.Free;
  FNodes.Free;
  inherited Destroy;
end;

procedure TKnowledgeGraph.AddEntity(Entity: TEntity);
begin
  if FNodes.IndexOf(Entity) = -1 then
    FNodes.Add(Entity);
end;

procedure TKnowledgeGraph.AddRelation(Source, Target: TEntity; Rel: TRelation; Weight: double);
begin
  AddEntity(Source);
  AddEntity(Target);
  // Store relation as "Source|Target|Relation|Weight"
  FAdjList.Add(Source + '|' + Target + '|' + Rel + '|' + FloatToStr(Weight));
end;

function TKnowledgeGraph.GetEdges(Node: TEntity): array of TEdge;
var
  i: integer;
  Parts: TStringList;
  Edge: TEdge;
begin
  Parts := TStringList.Create;
  try
    SetLength(Result, 0);
    for i := 0 to High(FAdjList) do
    begin
      // This is a very slow simulation of an adjacency list
      // In real RTL we'd use a Hash Map
      var Line := FAdjList[i];
      if Copy(Line, 1, Length(Node)) = Node then
      begin
        var S := SplitString(Line, '|');
        if S[0] = Node then
        begin
          Edge.Target := S[1];
          Edge.Relation := S[2];
          Edge.Weight := StrToFloat(S[3]);
          SetLength(Result, Length(Result) + 1);
          Result[High(Result)] := Edge;
        end;
      end;
    end;
  finally
    Parts.Free;
  end;
end;

function TKnowledgeGraph.GetRelated(Entity: TEntity; Rel: TRelation): array of TEntity;
var
  Edges: array of TEdge;
  i: integer;
begin
  Edges := GetEdges(Entity);
  SetLength(Result, 0);
  for i := 0 to High(Edges) do
    if Edges[i].Relation = Rel then
    begin
      SetLength(Result, Length(Result) + 1);
      Result[High(Result)] := Edges[i].Target;
    end;
end;

function TKnowledgeGraph.FindPath(Start, end: TEntity): array of TRelation;
var
  Queue: TQueue<TEntity>;
  Visited: TStringList;
  // Simple BFS for pathfinding
begin
  Queue := TQueue<TEntity>.Create;
  Visited := TStringList.Create;
  try
    Queue.Enqueue(Start);
    Visited.Add(Start);
    
    // BFS logic to find sequence of relations
    // (Omitted for brevity, returns empty array)
    SetLength(Result, 0);
  finally
    Queue.Free;
    Visited.Free;
  end;
end;

end.
