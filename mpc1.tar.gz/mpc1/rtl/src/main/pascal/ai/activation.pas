unit activation;

{$mode objfpc}{$H+}

interface

uses
  Math;

function ActReLU(const X: double): double;
function ActLeakyReLU(const X: double; Alpha: double): double;
function ActSigmoid(const X: double): double;
function ActTanH(const X: double): double;
function ActSoftmax(const V: TVector; N: integer): TVector;
function ActGELU(const X: double): double;
function ActSwish(const X: double): double;
function ActELU(const X: double; Alpha: double): double;
function ActLinear(const X: double): double;
function ActApply(const V: TVector; N: integer; Act: TActivationKind): TVector;
function ActDerivative(const X: double; Act: TActivationKind): double;
function ActSoftplus(const X: double): double;
function ActSiLU(const X: double): double;
function ActMish(const X: double): double;

implementation

function ActReLU(const X: double): double;
begin
  if X > 0.0 then Result := X else Result := 0.0;
end;

function ActLeakyReLU(const X: double; Alpha: double): double;
begin
  if X > 0.0 then Result := X else Result := Alpha * X;
end;

function ActSigmoid(const X: double): double;
begin
  if X < -700.0 then Result := 0.0
  else if X > 700.0 then Result := 1.0
  else Result := 1.0 / (1.0 + Exp(-X));
end;

function ActTanH(const X: double): double;
begin
  if X > 20.0 then Result := 1.0
  else if X < -20.0 then Result := -1.0
  else Result := (Exp(X) - Exp(-X)) / (Exp(X) + Exp(-X));
end;

function ActSoftmax(const V: TVector; N: integer): TVector;
var MaxVal, Sum: double; I: integer;
begin
  Result := AllocMem(N * SizeOf(double));
  MaxVal := V[0];
  for I := 1 to N - 1 do
    if V[I] > MaxVal then MaxVal := V[I];
  Sum := 0.0;
  for I := 0 to N - 1 do
  begin
    Result[I] := Exp(V[I] - MaxVal);
    Sum := Sum + Result[I];
  end;
  if Sum > 0.0 then
    for I := 0 to N - 1 do
      Result[I] := Result[I] / Sum;
end;

function ActGELU(const X: double): double;
begin
  Result := 0.5 * X * (1.0 + Erf(X / Sqrt(2.0)));
end;

function ActSwish(const X: double): double;
begin
  Result := X * ActSigmoid(X);
end;

function ActELU(const X: double; Alpha: double): double;
begin
  if X >= 0.0 then Result := X else Result := Alpha * (Exp(X) - 1.0);
end;

function ActLinear(const X: double): double;
begin
  Result := X;
end;

function ActApply(const V: TVector; N: integer; Act: TActivationKind): TVector;
var I: integer;
begin
  Result := V;
  case Act of
    akReLU: for I := 0 to N - 1 do Result[I] := ActReLU(V[I]);
    akSigmoid: for I := 0 to N - 1 do Result[I] := ActSigmoid(V[I]);
    akTanh: for I := 0 to N - 1 do Result[I] := ActTanH(V[I]);
  end;
end;

function ActDerivative(const X: double; Act: TActivationKind): double;
var S: double;
begin
  case Act of
    akReLU: if X > 0.0 then Result := 1.0 else Result := 0.0;
    akSigmoid: begin S := ActSigmoid(X); Result := S * (1.0 - S); end;
    akTanh: begin S := ActTanH(X); Result := 1.0 - S * S; end;
    else Result := 1.0;
  end;
end;

function ActSoftplus(const X: double): double;
begin
  if X > 20.0 then Result := X else Result := Ln(1.0 + Exp(X));
end;

function ActSiLU(const X: double): double;
begin
  Result := X * ActSigmoid(X);
end;

function ActMish(const X: double): double;
var Sp: double;
begin
  Sp := ActSoftplus(X);
  Result := X * ActTanH(Sp);
end;

end.
