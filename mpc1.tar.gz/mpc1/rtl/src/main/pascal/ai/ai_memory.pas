{
    Matrix Pascal - RTL AI Module
    AI Knowledge Base and Semantic Memory Unit
    ═══════════════════════════════════════════════════════════
    NL: Deze unit implementeert een semantisch geheugen voor AI,
    waarbij concepten worden opgeslagen als vectoren (embeddings)
    in een hoog-dimensionale ruimte.
    
    EN: This unit implements a semantic memory for AI, 
    where concepts are stored as vectors (embeddings) 
    in a high-dimensional space.
}

unit ai_memory;

interface

uses
  System, Classes, SysUtils, Math, tensor;

type
  TConceptEmbedding = record
    ConceptName: string;
    Vec: PTensor;
    Confidence: double;
  end;

  TSemanticMemory = class(TObject)
  private
    FMemory: array of TConceptEmbedding;
    FVectorDim: integer;
    function CalculateCosineSimilarity(V1, V2: PTensor): double;
  public
    constructor Create(Dim: integer);
    destructor Destroy; override;
    
    procedure StoreConcept(AName: string; AVector: PTensor; Confidence: double = 1.0);
    function RetrieveClosest(Query: PTensor; TopN: integer = 1): array of TConceptEmbedding;
    function GetConceptVector(AName: string): PTensor;
    
    property Memory: array of TConceptEmbedding read FMemory;
  end;

implementation

{ TSemanticMemory }

constructor TSemanticMemory.Create(Dim: integer);
begin
  inherited Create;
  FVectorDim := Dim;
end;

destructor TSemanticMemory.Destroy;
begin
  // In real RTL, we'd free the vectors
  inherited Destroy;
end;

function TSemanticMemory.CalculateCosineSimilarity(V1, V2: PTensor);
var
  i: integer;
  Dot, Norm1, Norm2: double;
begin
  Dot := 0; Norm1 := 0; Norm2 := 0;
  for i := 0 to FVectorDim - 1 do
  begin
    Dot := Dot + (V1^[i] * V2^[i]);
    Norm1 := Norm1 + Sqr(V1^[i]);
    Norm2 := Norm2 + Sqr(V2^[i]);
  end;
  if (Norm1 = 0) or (Norm2 = 0) then exit(0.0);
  Result := Dot / (Sqrt(Norm1) * Sqrt(Norm2));
end;

procedure TSemanticMemory.StoreConcept(AName: string; AVector: PTensor; Confidence: double);
var
  CE: TConceptEmbedding;
begin
  if TensorSize(AVector) <> FVectorDim then
    raise Exception.Create('vector dimension mismatch');
    
  CE.ConceptName := AName;
  CE.Vec := AVector;
  CE.Confidence := Confidence;
  SetLength(FMemory, Length(FMemory) + 1);
  FMemory[High(FMemory)] := CE;
end;

function TSemanticMemory.RetrieveClosest(Query: PTensor; TopN: integer);
var
  i: integer;
  Sims: array of double;
  Indices: array of integer;
begin
  SetLength(Sims, Length(FMemory));
  SetLength(Indices, Length(FMemory));
  
  for i := 0 to High(FMemory) do
  begin
    Sims[i] := CalculateCosineSimilarity(Query, FMemory[i].Vec);
    Indices[i] := i;
  end;
  
  // Sort by similarity (descending)
  for i := 0 to High(Sims) - 1 do
    for var j := i + 1 to High(Sims) do
      if Sims[j] > Sims[i] then
      begin
        var TempS := Sims[i]; Sims[i] := Sims[j]; Sims[j] := TempS;
        var TempI := Indices[i]; Indices[i] := Indices[j]; Indices[j] := TempI;
      end;
      
  SetLength(Result, Min(TopN, Length(FMemory)));
  for i := 0 to High(Result) do
    Result[i] := FMemory[Indices[i]];
end;

function TSemanticMemory.GetConceptVector(AName: string): PTensor;
var
  i: integer;
begin
  for i := 0 to High(FMemory) do
    if FMemory[i].ConceptName = AName then
      exit(FMemory[i].vector);
  Result := nil;
end;

end.
