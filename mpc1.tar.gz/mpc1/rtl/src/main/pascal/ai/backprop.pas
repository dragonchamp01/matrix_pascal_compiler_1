unit backprop;

{$mode objfpc}{$H+}

interface

uses
  SysUtils, Math;

type
  PBackpropNet = ^TBackpropNet;
  TBackpropNet = record
    LayerCount: integer;
    LayerSizes: array[0..49] of integer;
    Weights: array[0..49] of PFloat64;
    Biases: array[0..49] of PFloat64;
    Z: array[0..49] of PFloat64;
    A: array[0..49] of PFloat64;
    Deltas: array[0..49] of PFloat64;
    GradW: array[0..49] of PFloat64;
    GradB: array[0..49] of PFloat64;
    LearningRate: double;
  end;

function BPCreate(const Sizes: array of integer): PBackpropNet;
procedure BPFree(var Net: PBackpropNet);
function BPForward(Net: PBackpropNet; const Input: TVector; InputSize: integer): TVector;
procedure BPBackward(Net: PBackpropNet; const Target: TVector; OutputSize: integer);
procedure BPUpdate(Net: PBackpropNet);
procedure BPTrain(Net: PBackpropNet; const Input, Target: TVector; InputSize, OutputSize: integer);

implementation

function BPCreate(const Sizes: array of integer): PBackpropNet;
var I: integer;
begin
  New(Result);
  Result^.LayerCount := Length(Sizes);
  Result^.LearningRate := 0.01;
  for I := 0 to Result^.LayerCount - 1 do
  begin
    Result^.LayerSizes[I] := Sizes[I];
    Result^.Z[I] := AllocMem(Sizes[I] * SizeOf(double));
    Result^.A[I] := AllocMem(Sizes[I] * SizeOf(double));
    Result^.Deltas[I] := AllocMem(Sizes[I] * SizeOf(double));
    if I > 0 then
    begin
      Result^.Weights[I] := AllocMem(Sizes[I - 1] * Sizes[I] * SizeOf(double));
      Result^.Biases[I] := AllocMem(Sizes[I] * SizeOf(double));
      Result^.GradW[I] := AllocMem(Sizes[I - 1] * Sizes[I] * SizeOf(double));
      Result^.GradB[I] := AllocMem(Sizes[I] * SizeOf(double));
    end;
  end;
end;

procedure BPFree(var Net: PBackpropNet);
var I: integer;
begin
  if Net = nil then exit;
  for I := 0 to Net^.LayerCount - 1 do
  begin
    FreeMem(Net^.Z[I]);
    FreeMem(Net^.A[I]);
    FreeMem(Net^.Deltas[I]);
    if I > 0 then
    begin
      FreeMem(Net^.Weights[I]);
      FreeMem(Net^.Biases[I]);
      FreeMem(Net^.GradW[I]);
      FreeMem(Net^.GradB[I]);
    end;
  end;
  Dispose(Net);
  Net := nil;
end;

function BPForward(Net: PBackpropNet; const Input: TVector; InputSize: integer): TVector;
var L, I, J: integer; Sum: double;
begin
  for I := 0 to InputSize - 1 do
    Net^.A[0][I] := Input[I];
  for L := 1 to Net^.LayerCount - 1 do
  begin
    for I := 0 to Net^.LayerSizes[L] - 1 do
    begin
      Sum := Net^.Biases[L][I];
      for J := 0 to Net^.LayerSizes[L - 1] - 1 do
        Sum := Sum + Net^.A[L - 1][J] * Net^.Weights[L][J * Net^.LayerSizes[L] + I];
      Net^.Z[L][I] := Sum;
      Net^.A[L][I] := 1.0 / (1.0 + Exp(-Sum));
    end;
  end;
  Result := Net^.A[Net^.LayerCount - 1];
end;

procedure BPBackward(Net: PBackpropNet; const Target: TVector; OutputSize: integer);
var L, I, J: integer; Error: double;
begin
  L := Net^.LayerCount - 1;
  for I := 0 to OutputSize - 1 do
    Net^.Deltas[L][I] := (Net^.A[L][I] - Target[I]) * Net^.A[L][I] * (1.0 - Net^.A[L][I]);
  for L := Net^.LayerCount - 2 downto 1 do
  begin
    for I := 0 to Net^.LayerSizes[L] - 1 do
    begin
      Error := 0.0;
      for J := 0 to Net^.LayerSizes[L + 1] - 1 do
        Error := Error + Net^.Deltas[L + 1][J] * Net^.Weights[L + 1][I * Net^.LayerSizes[L + 1] + J];
      Net^.Deltas[L][I] := Error * Net^.A[L][I] * (1.0 - Net^.A[L][I]);
    end;
  end;
end;

procedure BPUpdate(Net: PBackpropNet);
var L, I, J: integer; LR: double;
begin
  LR := Net^.LearningRate;
  for L := 1 to Net^.LayerCount - 1 do
  begin
    for I := 0 to Net^.LayerSizes[L - 1] - 1 do
      for J := 0 to Net^.LayerSizes[L] - 1 do
        Net^.Weights[L][I * Net^.LayerSizes[L] + J] := Net^.Weights[L][I * Net^.LayerSizes[L] + J] - LR * Net^.A[L - 1][I] * Net^.Deltas[L][J];
    for J := 0 to Net^.LayerSizes[L] - 1 do
      Net^.Biases[L][J] := Net^.Biases[L][J] - LR * Net^.Deltas[L][J];
  end;
end;

procedure BPTrain(Net: PBackpropNet; const Input, Target: TVector; InputSize, OutputSize: integer);
begin
  BPForward(Net, Input, InputSize);
  BPBackward(Net, Target, OutputSize);
  BPUpdate(Net);
end;

end.
