{
    Matrix Pascal - RTL AI Module
    Proximal Policy Optimization (PPO) for RL
    ═══════════════════════════════════════════════════════════
    NL: Deze unit implementeert एक gesimuleerde PPO-algoritme 
    voor Reinforcement Learning. PPO is een state-of-the-art 
    policy gradient methode die stabiele updates garandeert 
    door middel van clipping.
    
    EN: This unit implements a simulated PPO algorithm for 
    Reinforcement Learning. PPO is a state-of-the-art policy 
    gradient method that ensures stable updates via clipping.
}

unit ai_rl_ppo;

interface

uses
  System, Classes, SysUtils, Math, tensor, trainer, layers;

type
  TExperienceBuffer = record
    States: array of PTensor;
    Actions: array of integer;
    Rewards: array of double;
    LogProbs: array of double;
    Values: array of double;
  end;

  T PPOAgent = class(TObject)
  private
    FPolicyNet: TModel;
    FValueNet: TModel;
    FClipRange: double;
    FGamma: double;
    FLambda: double;
  public
    constructor Create(StateDim, ActionDim: integer);
    destructor Destroy; override;
    
    function GetAction(State: PTensor): integer;
    procedure Update(Buffer: TExperienceBuffer);
    function ComputeAdvantages(Buffer: TExperienceBuffer): array of double;
  end;

implementation

{ TPPOAgent }

constructor TPPOAgent.Create(StateDim, ActionDim: integer);
begin
  inherited Create;
  FClipRange := 0.2;
  FGamma := 0.99;
  FLambda := 0.95;
  
  // Actor Network
  FPolicyNet := TModel.Create(TBinaryCrossEntropyLoss.Create, TAdamOptimizer.Create(3e-4));
  FPolicyNet.AddLayer(TDenseLayer.Create(StateDim, 64));
  FPolicyNet.AddLayer(TReLULayer.Create);
  FPolicyNet.AddLayer(TDenseLayer.Create(64, ActionDim));
  FPolicyNet.AddLayer(TSoftmaxLayer.Create);
  
  // Critic Network
  FValueNet := TModel.Create(TMeanSquaredErrorLoss.Create, TAdamOptimizer.Create(1e-3));
  FValueNet.AddLayer(TDenseLayer.Create(StateDim, 64));
  FValueNet.AddLayer(TReLULayer.Create);
  FValueNet.AddLayer(TDenseLayer.Create(64, 1));
end;

destructor TPPOAgent.Destroy;
begin
  FPolicyNet.Free;
  FValueNet.Free;
  inherited Destroy;
end;

function TPPOAgent.GetAction(State: PTensor): integer;
var
  Probs: PTensor;
  i: integer;
  RandVal: double;
  Cumulative: double;
begin
  Probs := FPolicyNet.forward(State);
  RandVal := Random;
  Cumulative := 0;
  for i := 0 to TensorSize(Probs) - 1 do
  begin
    Cumulative := Cumulative + Probs^[i];
    if RandVal < Cumulative then exit(i);
  end;
  Result := TensorSize(Probs) - 1;
end;

function TPPOAgent.ComputeAdvantages(Buffer: TExperienceBuffer): array of double;
var
  i: integer;
  GAE: double;
  Delta: double;
begin
  SetLength(Result, Length(Buffer.States));
  GAE := 0;
  for i := High(Buffer.States) downto 0 do
  begin
    // Delta = reward + gamma * V(s') - V(s)
    Delta := Buffer.Rewards[i] + FGamma * Buffer.Values[i+1] - Buffer.Values[i];
    GAE := Delta + FGamma * FLambda * GAE;
    Result[i] := GAE;
  end;
end;

procedure TPPOAgent.Update(Buffer: TExperienceBuffer);
var
  i: integer;
  Advantages: array of double;
  Ratio: double;
  Surrogate1, Surrogate2: double;
  L_CLIP: double;
begin
  Advantages := ComputeAdvantages(Buffer);
  
  for i := 0 to High(Buffer.States) do
  begin
    // Ratio = pi_theta(a|s) / pi_theta_old(a|s)
    Ratio := FPolicyNet.forward(Buffer.States[i])^[Buffer.Actions[i]] / Buffer.LogProbs[i];
    
    Surrogate1 := Ratio * Advantages[i];
    Surrogate2 := Max(Min(Ratio, 1 + FClipRange), 1 - FClipRange) * Advantages[i];
    
    L_CLIP := Min(Surrogate1, Surrogate2);
    
    // Backprop L_CLIP
    FPolicyNet.Backward(TensorConstant(1, 1, L_CLIP));
    FPolicyNet.Step;
    
    // Update Critic (Value Network)
    FValueNet.Backward(TensorConstant(1, 1, Buffer.Rewards[i]));
    FValueNet.Step;
  end;
end;

end.
