unit regularizer;

{$mode objfpc}{$H+}

interface

uses
  Math;

type
  TRegularizerKind = (rkNone, rkL1, rkL2, rkElasticNet);

function RegL1Cost(const Weights: PFloat64; N: integer; Lambda: double): double;
function RegL2Cost(const Weights: PFloat64; N: integer; Lambda: double): double;
function RegElasticNetCost(const Weights: PFloat64; N: integer; Lambda1, Lambda2: double): double;
procedure RegL1Grad(const Weights: PFloat64; Grad: PFloat64; N: integer; Lambda: double);
procedure RegL2Grad(const Weights: PFloat64; Grad: PFloat64; N: integer; Lambda: double);
procedure RegElasticNetGrad(const Weights: PFloat64; Grad: PFloat64; N: integer; Lambda1, Lambda2: double);
function RegTotalCost(Weights: PFloat64; Grad: PFloat64; N: integer; Kind: TRegularizerKind; Lambda1, Lambda2: double): double;

implementation

function RegL1Cost(const Weights: PFloat64; N: integer; Lambda: double): double;
var I: integer;
begin
  Result := 0.0;
  for I := 0 to N - 1 do
    Result := Result + Abs(Weights[I]);
  Result := Result * Lambda;
end;

function RegL2Cost(const Weights: PFloat64; N: integer; Lambda: double): double;
var I: integer;
begin
  Result := 0.0;
  for I := 0 to N - 1 do
    Result := Result + Weights[I] * Weights[I];
  Result := Result * Lambda * 0.5;
end;

function RegElasticNetCost(const Weights: PFloat64; N: integer; Lambda1, Lambda2: double): double;
begin
  Result := RegL1Cost(Weights, N, Lambda1) + RegL2Cost(Weights, N, Lambda2);
end;

procedure RegL1Grad(const Weights: PFloat64; Grad: PFloat64; N: integer; Lambda: double);
var I: integer;
begin
  for I := 0 to N - 1 do
  begin
    if Weights[I] > 0.0 then Grad[I] := Grad[I] + Lambda
    else if Weights[I] < 0.0 then Grad[I] := Grad[I] - Lambda;
  end;
end;

procedure RegL2Grad(const Weights: PFloat64; Grad: PFloat64; N: integer; Lambda: double);
var I: integer;
begin
  for I := 0 to N - 1 do
    Grad[I] := Grad[I] + Lambda * Weights[I];
end;

procedure RegElasticNetGrad(const Weights: PFloat64; Grad: PFloat64; N: integer; Lambda1, Lambda2: double);
begin
  RegL1Grad(Weights, Grad, N, Lambda1);
  RegL2Grad(Weights, Grad, N, Lambda2);
end;

function RegTotalCost(Weights: PFloat64; Grad: PFloat64; N: integer; Kind: TRegularizerKind; Lambda1, Lambda2: double): double;
begin
  Result := 0.0;
  case Kind of
    rkL1: Result := RegL1Cost(Weights, N, Lambda1);
    rkL2: Result := RegL2Cost(Weights, N, Lambda2);
    rkElasticNet: Result := RegElasticNetCost(Weights, N, Lambda1, Lambda2);
  end;
end;

end.
