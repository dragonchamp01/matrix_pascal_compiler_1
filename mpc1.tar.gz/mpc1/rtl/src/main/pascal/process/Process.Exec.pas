unit Process.Exec;
{$mode objfpc}{$H+}
interface
uses System, Classes, SysUtils;
type
  TProcessExec = class
  private
    FCommand: string;
    FArguments: TStringList;
    FWorkingDir: string;
    FEnvironment: TStringList;
    FExitCode: integer;
    FProcessId: longword;
  public
    constructor Create;
    destructor Destroy; override;
    function Execute: boolean;
    function ExecuteAndCapture(out StdOut, StdErr: TStringList): boolean;
    function Start: boolean;
    function WaitForExit(Timeout: longword = Infinite): boolean;
    procedure Kill;
    property Command: string read FCommand write FCommand;
    property Arguments: TStringList read FArguments;
    property WorkingDir: string read FWorkingDir write FWorkingDir;
    property Environment: TStringList read FEnvironment;
    property ExitCode: integer read FExitCode;
    property ProcessId: longword read FProcessId;
  end;
implementation
end.
