unit RegEx.Replacer;
{$mode objfpc}{$H+}
interface
uses System, SysUtils;
type
  TReplacer = class
  private
    FPattern: pointer;
    FReplacement: string;
  public
    constructor Create(APattern: pointer; const AReplacement: string);
    function Replace(const Input: string): string;
    function ReplaceAll(const Input: string): string;
    function ReplaceCallback(const Input: string; Callback: function(const Match: string): string): string;
  end;
implementation
end.
