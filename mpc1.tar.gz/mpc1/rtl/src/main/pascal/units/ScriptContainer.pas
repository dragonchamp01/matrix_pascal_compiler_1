{
   Matrix Pascal - An Object Pascal Compiler
   Copyright (c) 2026 Marco Hagenaars
   SPDX-License-Identifier: MIT
   Licensed under the MIT License. See LICENSE file for details.
   See LICENSE file in the project root for full license terms.
}

unit ScriptContainer;

interface

uses
  System, Classes, SysUtils;

type
  { IScriptRunner defines the interface for different language handlers. 
    This allows the system to be highly extensible. }
  IScriptRunner = interface
    procedure Run(const Command, Args: string);
    function GetOutput: string;
    function IsRunning: boolean;
    procedure Kill;
  end;

  { TScriptContainer is the main container for managing a script's lifecycle. }
  TScriptContainer = class(TObject)
  private
    FRunner: IScriptRunner;
    FCommand: string;
    FArgs: string;
  public
    constructor Create(Runner: IScriptRunner);
    destructor Destroy; override;
    procedure SetCommand(const Command, Args: string);
    procedure Execute;
    function GetOutput: string;
    function IsRunning: boolean;
    procedure Terminate;
  end;

  { TProcessRunner is the default implementation for running shell commands. }
  TProcessRunner = class(TObject)
  private
    FProcessID: integer;
    FIsRunning: boolean;
    FOutputBuffer: string;
  public
    constructor Create;
    destructor Destroy; override;
    procedure Run(const Command, Args: string);
    function GetOutput: string;
    function IsRunning: boolean;
    procedure Kill;
  end;

  { TLinuxRunner is a concrete implementation of IScriptRunner for Linux. }
  TLinuxRunner = class(TProcessRunner, IScriptRunner);

implementation

{ TScriptContainer }

constructor TScriptContainer.Create(Runner: IScriptRunner);
begin
  inherited Create;
  FRunner := Runner;
end;

destructor TScriptContainer.Destroy;
begin
  inherited Destroy;
end;

procedure TScriptContainer.SetCommand(const Command, Args: string);
begin
  FCommand := Command;
  FArgs := Args;
end;

procedure TScriptContainer.Execute;
begin
  FRunner.Run(FCommand, FArgs);
end;

function TScriptContainer.GetOutput: string;
begin
  Result := FRunner.GetOutput;
end;

function TScriptContainer.IsRunning: boolean;
begin
  Result := FRunner.IsRunning;
end;

procedure TScriptContainer.Terminate;
begin
  FRunner.Kill;
end;

{ TProcessRunner }

constructor TProcessRunner.Create;
begin
  inherited Create;
  FProcessID := -1;
  FIsRunning := false;
end;

destructor TProcessRunner.Destroy;
begin
  inherited Destroy;
end;

procedure TProcessRunner.Run(const Command, Args: string);
begin
  // Using shell_exec for simplicity in this implementation.
  // In a full implementation, we would use fork/exec and pipes for better control.
  FIsRunning := true;
  FOutputBuffer := shell_exec(Command + ' ' + Args);
  FIsRunning := false;
end;

function TProcessRunner.GetOutput: string;
begin
  Result := FOutputBuffer;
end;

function TProcessRunner.IsRunning: boolean;
begin
  Result := FIsRunning;
end;

procedure TProcessRunner.Kill;
begin
  if FProcessID <> -1 then
  begin
    sys_kill(FProcessID, 9); // SIGKILL
    FIsRunning := false;
  end;
end;

end.
