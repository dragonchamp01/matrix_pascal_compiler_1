{
   Matrix Pascal - Build driver for matrix_pascal_crt_time.pas
   Used only by the RTL Makefile to compile the unit into an object file.
}

program matrix_pascal_crt_time_build_driver;

uses
  matrix_pascal_crt_time;

begin
end.
