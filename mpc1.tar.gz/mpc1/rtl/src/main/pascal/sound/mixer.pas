unit mixer;

interface

uses sound.audio_base;

type
  TMixerChannel = record
    Active: boolean;
    Buffer: TAudioBuffer;
    Volume: single;
    Pan: single;
    Loop: boolean;
  end;

  TMixer = class
  private
    FChannels: array of TMixerChannel;
    FMasterVolume: single;
    FSampleRate: integer;
  public
    constructor Create(AMaxChannels, ASampleRate: integer);
    function PlaySound(const ABuffer: TAudioBuffer; AVolume: single = 1.0;
      APan: single = 0.0; ALoop: boolean = false): integer;
    procedure StopChannel(AChannel: integer);
    procedure SetChannelVolume(AChannel: integer; AVolume: single);
    procedure SetChannelPan(AChannel: integer; APan: single);
    function Mix(AOutBuffer: pointer; AFrames: integer): integer;
    property MasterVolume: single read FMasterVolume write FMasterVolume;
  end;

implementation

constructor TMixer.Create(AMaxChannels, ASampleRate: integer);
begin
  SetLength(FChannels, AMaxChannels);
  FMasterVolume := 1.0;
  FSampleRate := ASampleRate;
end;

function TMixer.PlaySound(const ABuffer: TAudioBuffer; AVolume: single = 1.0;
  APan: single = 0.0; ALoop: boolean = false): integer;
var
  i: integer;
begin
  Result := -1;
  for i := 0 to High(FChannels) do
  begin
    if not FChannels[i].Active then
    begin
      FChannels[i].Active := true;
      FChannels[i].Buffer := ABuffer;
      FChannels[i].Volume := AVolume;
      FChannels[i].Pan := APan;
      FChannels[i].Loop := ALoop;
      Result := i;
      break;
    end;
  end;
end;

procedure TMixer.StopChannel(AChannel: integer);
begin
  if (AChannel >= 0) and (AChannel < Length(FChannels)) then
    FChannels[AChannel].Active := false;
end;

procedure TMixer.SetChannelVolume(AChannel: integer; AVolume: single);
begin
  if (AChannel >= 0) and (AChannel < Length(FChannels)) then
    FChannels[AChannel].Volume := AVolume;
end;

procedure TMixer.SetChannelPan(AChannel: integer; APan: single);
begin
  if (AChannel >= 0) and (AChannel < Length(FChannels)) then
    FChannels[AChannel].Pan := APan;
end;

function TMixer.Mix(AOutBuffer: pointer; AFrames: integer): integer;
begin
  Result := 0;
end;

end.
