{
    Matrix Pascal - RTL AI Brain Module
    Easy Weight Decay (L2)
    ═══════════════════════════════════════════════════════════
    NL: Eenvoudige implementatie van L2 regularisatie.
    
    EN: Simple implementation of L2 regularization.
}

unit brain_easy_decay;

interface

uses
  System, Classes, SysUtils, tensor_unit;

type
  TEasyDecay = class(TObject)
  public
    procedure Apply(W: PTensor; Lambda: double);
  end;

implementation

procedure TEasyDecay.Apply(W: PTensor; Lambda: double);
var
  i: integer;
begin
  for i := 0 to TensorSize(W) - 1 do
    W^[i] := W^[i] * (1.0 - Lambda);
end;

end.
