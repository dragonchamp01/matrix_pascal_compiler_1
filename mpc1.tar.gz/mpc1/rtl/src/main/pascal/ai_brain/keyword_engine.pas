{
   Matrix Pascal - RTL AI Brain Module
   Keyword Engine: Keyword and event grouping system
   ════════════════════════════════════════════════════════════════
   Nederlands: De Keyword Engine groepeert trefwoorden en
   gebeurtenissen in categorieën. Het herkent patronen in
   gebruikersinvoer, extraheert betekenisvolle termen, en
   organiseert ze in een hiërarchie. Dit stelt de AI Brain in
   staat om verbanden te leggen tussen verschillende concepten.

   English: The Keyword Engine groups keywords and events into
   categories. It recognizes patterns in user input, extracts
   meaningful terms, and organizes them into a hierarchy. This
   enables the AI Brain to establish relationships between
   different concepts.

   Gebruik / Usage:
     KE := TKeywordEngine.Create;
     KE.AddKeyword('machine learning', 'AI');
     KE.AddKeyword('neurale netwerken', 'AI');
     KE.AddEvent('Gebruiker opent app', 'events');
     Grouped := KE.GetKeywordsByGroup('AI');

   Copyright (c) 2026 Marco Hagenaars
   SPDX-License-Identifier: MIT
}

unit keyword_engine;

interface

uses
  System, Classes, SysUtils;

type
  { █████████████████████████████████████████████████████████████
    TKeywordEngine — Trefwoord- en gebeurtenisgroepering
                     Keyword and event grouping
    █████████████████████████████████████████████████████████████
    NL: Organiseert trefwoorden en gebeurtenissen in groepen.
    Herkent synoniemen, extraheert keywords uit tekst, en
    genereert rapporten per categorie.

    EN: Organizes keywords and events into groups. Recognizes
    synonyms, extracts keywords from text, and generates reports
    per category. }
  TKeywordEngine = class
  private
    FKeywords: TStringList;       { keyword=group }
    FEvents: TStringList;         { event=group }
    FSynonymMap: TStringList;     { synonym=keyword }
    FStopWords: TStringList;

    function NormalizeWord(const word: string): string;
    function IsStopWord(const word: string): boolean;
  public
    constructor Create;
    destructor Destroy; override;

    { ─── Trefwoorden beheer / Keyword management ─── }
    procedure AddKeyword(const Keyword, Group: string);
    procedure RemoveKeyword(const Keyword: string);
    function GetKeywordsByGroup(const Group: string): TStringList;
    function GetAllGroups: TStringList;
    function FindKeyword(const text: string): TStringList;     { Vindt keywords in tekst }
    function ExtractKeywords(const text: string): TStringList; { Extraheer alle termen }

    { ─── Synoniemen / Synonyms ─── }
    procedure AddSynonym(const Synonym, MainKeyword: string);
    function ResolveSynonym(const word: string): string;

    { ─── Gebeurtenissen / Events ─── }
    procedure AddEvent(const Event, Group: string);
    function GetEventsByGroup(const Group: string): TStringList;
    function GetRecentEvents(Count: integer): TStringList;

    { ─── Groepering / Grouping ─── }
    function GroupText(const text: string): string;
    function GetGroupSummary: TStringList;
    function Classify(const text: string): string;             { Classificeer tekst in groep }

    { ─── Configuratie / Configuration ─── }
    procedure AddStopWord(const word: string);
    property Keywords: TStringList read FKeywords;
  end;

implementation

{ TKeywordEngine }

constructor TKeywordEngine.Create;
begin
  inherited Create;

  FKeywords := TStringList.Create;
  FEvents := TStringList.Create;
  FSynonymMap := TStringList.Create;
  FStopWords := TStringList.Create;

  { Standaard stopwoorden Nederlands / Default Dutch stop words }
  FStopWords.Add('de'); FStopWords.Add('het'); FStopWords.Add('een');
  FStopWords.Add('en'); FStopWords.Add('van'); FStopWords.Add('in');
  FStopWords.Add('op'); FStopWords.Add('met'); FStopWords.Add('voor');
  FStopWords.Add('aan'); FStopWords.Add('dat'); FStopWords.Add('die');
  FStopWords.Add('is'); FStopWords.Add('was'); FStopWords.Add('zijn');
  FStopWords.Add('wordt'); FStopWords.Add('heeft'); FStopWords.Add('dit');

  { Standaard stopwoorden Engels / Default English stop words }
  FStopWords.Add('the'); FStopWords.Add('a'); FStopWords.Add('an');
  FStopWords.Add('and'); FStopWords.Add('or'); FStopWords.Add('but');
  FStopWords.Add('in'); FStopWords.Add('on'); FStopWords.Add('at');
  FStopWords.Add('to'); FStopWords.Add('for'); FStopWords.Add('of');
  FStopWords.Add('is'); FStopWords.Add('are'); FStopWords.Add('was');
end;

destructor TKeywordEngine.Destroy;
begin
  FKeywords.Free;
  FEvents.Free;
  FSynonymMap.Free;
  FStopWords.Free;
  inherited Destroy;
end;

{ NL: Normaliseer een woord (lowercase, verwijder leestekens). }
{ EN: Normalize a word (lowercase, remove punctuation). }
function TKeywordEngine.NormalizeWord(const word: string): string;
var
  I: integer;
begin
  Result := LowerCase(word);
  for I := Length(Result) downto 1 do
    if not (Result[I] in ['a'..'z', '0'..'9', '-', '_']) then
      Delete(Result, I, 1);
end;

{ NL: Controleer of een woord een stopwoord is. }
{ EN: Check if a word is a stop word. }
function TKeywordEngine.IsStopWord(const word: string): boolean;
begin
  Result := FStopWords.IndexOf(NormalizeWord(word)) >= 0;
end;

{ NL: Voeg een trefwoord toe aan een groep. }
{ EN: Add a keyword to a group. }
procedure TKeywordEngine.AddKeyword(const Keyword, Group: string);
begin
  FKeywords.Values[NormalizeWord(Keyword)] := Group;
end;

procedure TKeywordEngine.RemoveKeyword(const Keyword: string);
begin
  FKeywords.Delete(FKeywords.IndexOfName(NormalizeWord(Keyword)));
end;

{ NL: Haal alle trefwoorden in een groep op. }
{ EN: Get all keywords in a group. }
function TKeywordEngine.GetKeywordsByGroup(const Group: string): TStringList;
var
  I: integer;
begin
  Result := TStringList.Create;
  for I := 0 to FKeywords.Count - 1 do
    if FKeywords.ValueFromIndex[I] = Group then
      Result.Add(FKeywords.Names[I]);
end;

{ NL: Haal alle groepen op. }
{ EN: Get all groups. }
function TKeywordEngine.GetAllGroups: TStringList;
var
  I: integer;
begin
  Result := TStringList.Create;
  for I := 0 to FKeywords.Count - 1 do
    if Result.IndexOf(FKeywords.ValueFromIndex[I]) < 0 then
      Result.Add(FKeywords.ValueFromIndex[I]);
end;

{ NL: Vind bekende trefwoorden in een tekst. Retourneert lijst
      van "keyword=group". }
{ EN: Find known keywords in a text. Returns list of "keyword=group". }
function TKeywordEngine.FindKeyword(const text: string): TStringList;
var
  I: integer;
  LowerText: string;
begin
  Result := TStringList.Create;
  LowerText := LowerCase(text);

  for I := 0 to FKeywords.Count - 1 do
    if Pos(FKeywords.Names[I], LowerText) > 0 then
      Result.Add(FKeywords.Names[I] + '=' + FKeywords.ValueFromIndex[I]);
end;

{ NL: Extraheer alle betekenisvolle termen uit een tekst (geen stopwoorden). }
{ EN: Extract all meaningful terms from text (no stop words). }
function TKeywordEngine.ExtractKeywords(const text: string): TStringList;
var
  Words: TStringList;
  I: integer;
  word: string;
begin
  Result := TStringList.Create;
  Words := TStringList.Create;
  Words.Delimiter := ' ';
  Words.DelimitedText := text;

  for I := 0 to Words.Count - 1 do
  begin
    word := NormalizeWord(Words[I]);
    if (word <> '') and not IsStopWord(word) then
      if Result.IndexOf(word) < 0 then
        Result.Add(word);
  end;

  Words.Free;
end;

{ NL: Voeg een synoniem toe. }
{ EN: Add a synonym. }
procedure TKeywordEngine.AddSynonym(const Synonym, MainKeyword: string);
begin
  FSynonymMap.Values[NormalizeWord(Synonym)] := NormalizeWord(MainKeyword);
end;

{ NL: Vind het hoofdtrefwoord voor een synoniem. }
{ EN: Find the main keyword for a synonym. }
function TKeywordEngine.ResolveSynonym(const word: string): string;
var
  Normalized: string;
begin
  Normalized := NormalizeWord(word);
  if FSynonymMap.IndexOfName(Normalized) >= 0 then
    Result := FSynonymMap.Values[Normalized]
  else
    Result := Normalized;
end;

{ NL: Voeg een gebeurtenis toe aan een groep. }
{ EN: Add an event to a group. }
procedure TKeywordEngine.AddEvent(const Event, Group: string);
begin
  FEvents.Add(DateTimeToStr(Now) + '|' + Event + '=' + Group);
end;

{ NL: Haal gebeurtenissen in een groep op. }
{ EN: Get events in a group. }
function TKeywordEngine.GetEventsByGroup(const Group: string): TStringList;
var
  I: integer;
begin
  Result := TStringList.Create;
  for I := 0 to FEvents.Count - 1 do
    if FEvents.ValueFromIndex[I] = Group then
      Result.Add(FEvents.Names[I]);
end;

{ NL: Haal de meest recente gebeurtenissen op. }
{ EN: Get the most recent events. }
function TKeywordEngine.GetRecentEvents(Count: integer): TStringList;
var
  I, StartIdx: integer;
begin
  Result := TStringList.Create;
  StartIdx := FEvents.Count - Count;
  if StartIdx < 0 then StartIdx := 0;

  for I := StartIdx to FEvents.Count - 1 do
    Result.Add(FEvents[I]);
end;

{ NL: Extraheer de dominante groep uit een tekst. }
{ EN: Extract the dominant group from a text. }
function TKeywordEngine.GroupText(const text: string): string;
var
  Found: TStringList;
  I: integer;
  GroupCount: TStringList;
  GroupName: string;
  MaxCount, Idx: integer;
begin
  Found := FindKeyword(text);
  GroupCount := TStringList.Create;

  for I := 0 to Found.Count - 1 do
  begin
    GroupName := Found.ValueFromIndex[I];
    Idx := GroupCount.IndexOfName(GroupName);
    if Idx >= 0 then
      GroupCount.ValueFromIndex[Idx] := IntToStr(StrToInt(GroupCount.ValueFromIndex[Idx]) + 1)
    else
      GroupCount.Add(GroupName + '=1');
  end;

  if GroupCount.Count > 0 then
  begin
    MaxCount := 0;
    Result := '';
    for I := 0 to GroupCount.Count - 1 do
      if StrToInt(GroupCount.ValueFromIndex[I]) > MaxCount then
      begin
        MaxCount := StrToInt(GroupCount.ValueFromIndex[I]);
        Result := GroupCount.Names[I];
      end;
  end
  else
    Result := 'unknown';

  Found.Free;
  GroupCount.Free;
end;

{ NL: Genereer een samenvatting van alle groepen en hun keywords. }
{ EN: Generate a summary of all groups and their keywords. }
function TKeywordEngine.GetGroupSummary: TStringList;
var
  Groups: TStringList;
  I, J: integer;
  Keywords: TStringList;
begin
  Result := TStringList.Create;
  Groups := GetAllGroups;

  for I := 0 to Groups.Count - 1 do
  begin
    Result.Add('■ ' + Groups[I] + ':');
    Keywords := GetKeywordsByGroup(Groups[I]);
    for J := 0 to Keywords.Count - 1 do
      Result.Add('    - ' + Keywords[J]);
    Keywords.Free;
  end;

  Groups.Free;
end;

{ NL: Classificeer een tekst in een bekende groep. }
{ EN: Classify a text into a known group. }
function TKeywordEngine.Classify(const text: string): string;
begin
  Result := GroupText(text);
  if Result = 'unknown' then
    Result := 'unclassified';
end;

procedure TKeywordEngine.AddStopWord(const word: string);
begin
  FStopWords.Add(NormalizeWord(word));
end;

end.
