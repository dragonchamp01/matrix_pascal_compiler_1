{
   Matrix Pascal - RTL AI Brain Module
   Transformer / Attention Mechanism (GPT-style decoder, BERT-style encoder)
   ═══════════════════════════════════════════════════════════
   Nederlands: Transformers zijn de meest geavanceerde architectuur
   voor sequentiële data, met name in NLP. In tegenstelling tot RNNs
   verwerken ze alle posities in parallel via self-attention, wat
   veel sneller is en betere lange-afstandsafhankelijkheden leert.

   English: Transformers are the most advanced architecture for
   sequential data, especially NLP. Unlike RNNs, they process all
   positions in parallel via self-attention, which is much faster
   and learns better long-range dependencies.

   BERT (Encoder): Bidirectionele context — voor tekstbegrip
   GPT  (Decoder): Autoregressief — voor tekstgeneratie
   Encoder-Decoder: Seq2Seq — voor vertaling, samenvatting

   Copyright (c) 2026 Marco Hagenaars
   SPDX-License-Identifier: MIT
}

unit transformers;

interface

uses
  System, SysUtils, tensor_unit, layers, advanced_layers;

type
  { ███████████████████████████████████████████████████████████████
    TScaledDotProductAttention — Geschaalde Dot-Product Aandacht
    ███████████████████████████████████████████████████████████████
    NL: De kern van de transformer. Berekent hoe belangrijk elk
    element in de sequentie is voor elk ander element.
    Formule: Attention(Q,K,V) = softmax(Q * K^T / √d_k) * V
    d_k = dimensie van de sleutels (schaalfactor)

    EN: The core of the transformer. Computes how important each
    element in the sequence is to every other element.
    Formula: Attention(Q,K,V) = softmax(Q * K^T / √d_k) * V
    d_k = dimension of keys (scaling factor) }
  TScaledDotProductAttention = class
  private
    FQ, FK, FV, FWeights: PTensor;
    FGradQ, FGradK, FGradV: PTensor;
  public
    function forward(const Q, K, V: PTensor; Mask: PTensor = nil): PTensor;
    function Backward(const GradOutput: PTensor): PTensor;
    property GradQ: PTensor read FGradQ;
    property GradK: PTensor read FGradK;
    property GradV: PTensor read FGradV;
  end;

  { ███████████████████████████████████████████████████████████████
    TMultiHeadAttention — Multi-Head Self-Attention
    ███████████████████████████████████████████████████████████████
    NL: Voert meerdere aandacht-mechanismen parallel uit. Elk hoofd
    leert verschillende relaties (bv. syntactisch, semantisch).
    ModelDim = totale dimensie, NumHeads = aantal hoofden.
    Meestal: ModelDim=512, NumHeads=8 (dus 64 per hoofd).

    EN: Runs multiple attention mechanisms in parallel. Each head
    learns different relationships (e.g. syntactic, semantic).
    ModelDim = total dimension, NumHeads = number of heads.
    Typically: ModelDim=512, NumHeads=8 (so 64 per head). }
  TMultiHeadAttention = class(TLayer)
  private
    FNumHeads, FHeadDim, FModelDim: integer;
    FWQ, FWK, FWV, FWO: PTensor;
    FWQGrad, FWKGrad, FWVGrad, FWOGrad: PTensor; { Added gradients }
    FQ, FK, FV, FAttnOutput: PTensor;
    FInput, FKVInput: PTensor; { Cache inputs for backward }
    FAttention: TScaledDotProductAttention;
    FScale: double;
  public
    constructor Create(ModelDim, NumHeads: integer);
    destructor Destroy; override;
    function forward(const Input: PTensor; KVInput: PTensor = nil): PTensor; override;
    procedure Backward(const GradOutput: PTensor); override;
  end;

  { ███████████████████████████████████████████████████████████████
    TFeedForward — Feed-Forward Netwerk (MLP blok)
    ███████████████████████████████████████████████████████████████
    NL: Een klein 2-laags MLP dat na elk aandacht-mechanisme komt.
    Bestaat uit: Linear → ReLU → Linear.
    Verhoogt de representatiekracht van het model.
    Meestal: HiddenDim = 4 * ModelDim (bv. 512 → 2048 → 512).

    EN: A small 2-layer MLP that follows each attention mechanism.
    Consists of: Linear → ReLU → Linear.
    Increases the representational power of the model.
    Typically: HiddenDim = 4 * ModelDim (e.g. 512 → 2048 → 512). }
  TFeedForward = class(TLayer)
  private
    FW1, FW2, FB1, FB2: PTensor;
    FW1Grad, FW2Grad, FB1Grad, FB2Grad: PTensor; { Added gradients }
    FInput, FHidden: PTensor; { Cache for backward }
    FHiddenDim: integer;
  public
    constructor Create(ModelDim, HiddenDim: integer);
    destructor Destroy; override;
    function forward(const Input: PTensor): PTensor; override;
    procedure Backward(const GradOutput: PTensor); override;
  end;

  { ███████████████████████████████████████████████████████████████
    TTransformerEncoderBlock — Transformer Encoder Blok (BERT-stijl)
    ███████████████████████████████████████████████████████████████
    NL: Een encoder blok bestaat uit:
      1. Multi-Head Self-Attention
      2. Residual connectie + Layer Normalization
      3. Feed-Forward Network
      4. Residual connectie + Layer Normalization
    👉 Gebruik voor: tekstbegrip, classificatie, NER.

    EN: An encoder block consists of:
      1. Multi-Head Self-Attention
      2. Residual connection + Layer Normalization
      3. Feed-Forward Network
      4. Residual connection + Layer Normalization
    👉 Use for: text understanding, classification, NER. }
  TTransformerEncoderBlock = class(TLayer)
  private
    FAttention: TMultiHeadAttention;
    FFeedForward: TFeedForward;
    FNorm1, FNorm2: TLayerNormLayer;
    FDropout: TDropoutLayer;
  public
    constructor Create(ModelDim, NumHeads, FFNHiddenDim: integer; DropoutRate: double = 0.1);
    destructor Destroy; override;
    function forward(const Input: PTensor): PTensor; override;
    procedure Backward(const GradOutput: PTensor); override;
  end;

  { ███████████████████████████████████████████████████████████████
    TTransformerDecoderBlock — Transformer Decoder Blok (GPT-stijl)
    ███████████████████████████████████████████████████████████████
    NL: Een decoder blok heeft drie onderdelen:
      1. Masked Self-Attention (kan alleen naar vorige posities kijken)
      2. Cross-Attention (kijkt naar de encoder uitvoer)
      3. Feed-Forward Network
    👉 Gebruik voor: tekstgeneratie, vertaling, samenvatting.

    EN: A decoder block has three components:
      1. Masked Self-Attention (can only look at previous positions)
      2. Cross-Attention (looks at encoder output)
      3. Feed-Forward Network
    👉 Use for: text generation, translation, summarization. }
  TTransformerDecoderBlock = class(TLayer)
  private
    FMaskedAttention: TMultiHeadAttention;  { Gemaskeerde self-attention }
    FCrossAttention: TMultiHeadAttention;   { Cross-attention naar encoder }
    FFeedForward: TFeedForward;
    FNorm1, FNorm2, FNorm3: TLayerNormLayer;
    FDropout: TDropoutLayer;
  public
    constructor Create(ModelDim, NumHeads, FFNHiddenDim: integer; DropoutRate: double = 0.1);
    destructor Destroy; override;
    function forward(const Input, EncoderOutput: PTensor): PTensor;
    procedure Backward(const GradOutput: PTensor);
  end;

  { ███████████████████████████████████████████████████████████████
    TPositionalEncoding — Positionele Codering (geleerd)
    ███████████████████████████████████████████████████████████████
    NL: Omdat self-attention geen volgorde kent, voegen we
    positie-informatie toe. Deze laag leert een aparte embedding
    voor elke positie in de sequentie.

    EN: Because self-attention has no notion of order, we add
    position information. This layer learns a separate embedding
    for each position in the sequence. }
  TPositionalEncoding = class(TLayer)
  private
    FPositions: PTensor;  { Geleerde positie embeddings }
    FInput: PTensor; { Cache for backward }
    FMaxLen, FDims: integer;
  public
    constructor Create(MaxLen, Dims: integer);
    destructor Destroy; override;
    function forward(const Input: PTensor): PTensor; override;
    procedure Backward(const GradOutput: PTensor); override;
  end;

  { ███████████████████████████████████████████████████████████████
    TTextGenerator — GPT-style Tekstgenerator (autoregressief)
    ███████████████████████████████████████████████████████████████
    NL: Genereert tekst door één token per keer te voorspellen.
    Het model krijgt de prompt en genereert nieuwe tokens tot
    MaxTokens of een stop-teken. Temperature (0.0-1.0) bepaalt
    de creativiteit: lager = voorspelbaarder, hoger = creatiever.

    EN: Generates text by predicting one token at a time.
    The model receives a prompt and generates new tokens until
    MaxTokens or a stop token. Temperature (0.0-1.0) controls
    creativity: lower = more predictable, higher = more creative.

    Gebruik / Usage:
      Gen := TTextGenerator.Create(Model, Tokenizer, 100, 0.8);
      WriteLn(Gen.Generate('Er was eens...')); }
  TTextGenerator = class
  private
    FModel: TLayer;           { Getrainde transformer model }
    FTokenizer: TTokenizer;   { Tokenizer voor encode/decode }
    FMaxTokens: integer;      { Maximum aantal te genereren tokens }
    FTemperature: double;     { Creativiteit (0.0-1.0) / Temperature }
  public
    constructor Create(Model: TLayer; Tokenizer: TTokenizer; MaxTokens: integer = 256; Temperature: double = 0.7);
    destructor Destroy; override;
    function Generate(const Prompt: string): string;
    function GenerateTokens(const Prompt: array of integer; MaxNewTokens: integer): array of integer;
  end;

implementation

{ ═══════════════════════════════════════════════════════════════════
  TScaledDotProductAttention
  ═══════════════════════════════════════════════════════════════════
  Attention(Q, K, V) = softmax(Q × K^T / √d_k) × V }
function TScaledDotProductAttention.forward(const Q, K, V: PTensor; Mask: PTensor = nil): PTensor;
var
  Scores, Weights: PTensor;
  dk: double;
begin
  FQ := Q; FK := K; FV := V;
  dk := Sqrt(Q^.Shape[Q^.NDims - 1]);
  Scores := TensorMatMul(Q, TensorTranspose(K));
  Scores := TensorDivS(Scores, dk);
  
  if Mask <> nil then
    Scores := TensorAdd(Scores, Mask);
  
  Weights := TensorSoftmax(Scores, Q^.NDims - 1);
  FWeights := Weights;
  
  Result := TensorMatMul(Weights, V);
end;

function TScaledDotProductAttention.Backward(const GradOutput: PTensor): PTensor;
var
  GradWeights, GradScores: PTensor;
  dk: double;
begin
  { 1. Gradient w.r.t. V }
  { GradV = Weights^T * GradOutput }
  FGradV := TensorMatMul(TensorTranspose(FWeights), GradOutput);
  
  { 2. Gradient w.r.t. Weights }
  { GradWeights = GradOutput * V^T }
  GradWeights := TensorMatMul(GradOutput, TensorTranspose(FV));
  
  { 3. Gradient w.r.t. Scores (Softmax Backward) }
  { This is a simplified softmax gradient implementation }
  GradScores := TensorMul(FWeights, TensorSub(GradWeights, TensorMul(TensorOnesLike(FWeights), TensorSum(TensorMul(FWeights, GradWeights), 0))));
  
  dk := Sqrt(FQ^.Shape[FQ^.NDims - 1]);
  GradScores := TensorDivS(GradScores, dk);
  
  { 4. Gradients w.r.t. Q and K }
  { GradQ = GradScores * K }
  FGradQ := TensorMatMul(GradScores, FK);
  { GradK = GradScores^T * Q }
  FGradK := TensorMatMul(TensorTranspose(GradScores), FQ);
  
  Result := FGradQ;
end;

{ ═══════════════════════════════════════════════════════════════════
  TMultiHeadAttention
  ═══════════════════════════════════════════════════════════════════
  NL: Leer Q, K, V projecties voor elk hoofd, pas aandacht toe,
  en projecteer terug met WO. }
{ EN: Learn Q, K, V projections for each head, apply attention,
  and project back with WO. }
constructor TMultiHeadAttention.Create(ModelDim, NumHeads: integer);
var
  Dims: array[0..1] of integer;
begin
  inherited Create(ModelDim, ModelDim);
  FModelDim := ModelDim;
  FNumHeads := NumHeads;
  FHeadDim := ModelDim div NumHeads;
  FScale := Sqrt(FHeadDim);
  
  Dims[0] := ModelDim; Dims[1] := ModelDim;
  FWQ := TensorXavier(@Dims[0], 2);
  FWK := TensorXavier(@Dims[0], 2);
  FWV := TensorXavier(@Dims[0], 2);
  FWO := TensorXavier(@Dims[0], 2);
  
  FWQGrad := TensorZeros(@Dims[0], 2);
  FWKGrad := TensorZeros(@Dims[0], 2);
  FWVGrad := TensorZeros(@Dims[0], 2);
  FWOGrad := TensorZeros(@Dims[0], 2);
  
  FAttention := TScaledDotProductAttention.Create;
end;

destructor TMultiHeadAttention.Destroy;
begin
  TensorFree(FWQ); TensorFree(FWK); TensorFree(FWV); TensorFree(FWO);
  TensorFree(FWQGrad); TensorFree(FWKGrad); TensorFree(FWVGrad); TensorFree(FWOGrad);
  FAttention.Free;
  inherited Destroy;
end;

function TMultiHeadAttention.forward(const Input: PTensor): PTensor;
var
  Q, K, V: PTensor;
  Attn_out: PTensor;
  Batch, Seq, ModelDim, Heads, HeadDim: integer;
  NewDims: array[0..3] of integer;
begin
  FInput := Input;
  Batch := Input^.Shape[0];
  Seq := Input^.Shape[1];
  ModelDim := FModelDim;
  Heads := FNumHeads;
  HeadDim := FHeadDim;
  
  Q := TensorMatMul(Input, FWQ);
  K := TensorMatMul(Input, FWK);
  V := TensorMatMul(Input, FWV);
  
  FQ := Q; FK := K; FV := V;
  
  NewDims[0] := Batch; NewDims[1] := Seq; NewDims[2] := Heads; NewDims[3] := HeadDim;
  Q := TensorReshape(Q, NewDims, 4);
  K := TensorReshape(K, NewDims, 4);
  V := TensorReshape(V, NewDims, 4);
  
  Q := TensorTranspose(Q);
  K := TensorTranspose(K);
  V := TensorTranspose(V);
  
  Attn_out := FAttention.forward(Q, K, V);
  Attn_out := TensorTranspose(Attn_out);
  
  NewDims[0] := Batch; NewDims[1] := Seq; NewDims[2] := ModelDim;
  Attn_out := TensorReshape(Attn_out, NewDims, 3);
  
  FAttnOutput := Attn_out;
  Result := TensorMatMul(Attn_out, FWO);
end;


procedure TMultiHeadAttention.Backward(const GradOutput: PTensor);
var
  GradAttnOut, GradInput: PTensor;
  Batch, Seq, ModelDim, Heads, HeadDim: integer;
  NewDims: array[0..3] of integer;
  GradH: PTensor;
begin
  Batch := FQ^.Shape[0];
  Seq := FQ^.Shape[1];
  ModelDim := FModelDim;
  Heads := FNumHeads;
  HeadDim := FHeadDim;
  
  { 1. Gradient w.r.t. Output Projection }
  { GradAttnOut = GradOutput * FWO^T }
  GradAttnOut := TensorMatMul(GradOutput, TensorTranspose(FWO));
  
  { FWO gradient = Attn_out^T * GradOutput }
  { Note: FAttnOutput was the result before the final project }
  // FWOGrad := TensorAdd(FWOGrad, TensorMatMul(TensorTranspose(FAttnOutput), GradOutput));
  
  { 2. Reshape and Transpose for Multi-Head }
  NewDims[0] := Batch; NewDims[1] := Seq; NewDims[2] := Heads; NewDims[3] := HeadDim;
  GradH := TensorReshape(GradAttnOut, NewDims, 4);
  GradH := TensorTranspose(GradH);
  
  { 3. Backward through Scaled Dot-Product Attention }
  FAttention.Backward(GradH);
  
  { 4. Update Q, K, V weights }
  { These gradients would be accumulated across heads.
    For simplicity, we assume the current implementation handles the projected forms. }
  FWQGrad := TensorAdd(FWQGrad, TensorMatMul(TensorTranspose(FAttention.GradQ), TensorTranspose(FInput)));
  FWKGrad := TensorAdd(FWKGrad, TensorMatMul(TensorTranspose(FAttention.GradK), TensorTranspose(FInput)));
  FWVGrad := TensorAdd(FWVGrad, TensorMatMul(TensorTranspose(FAttention.GradV), TensorTranspose(FInput)));
  
  { 5. Gradient w.r.t. Input }
  GradInput := TensorAdd(TensorAdd(TensorMatMul(FAttention.GradQ, TensorTranspose(FWQ)), 
                                   TensorMatMul(FAttention.GradK, TensorTranspose(FWK))), 
                                   TensorMatMul(FAttention.GradV, TensorTranspose(FWV)));
  
  if (FInput <> nil) and FInput^.RequiresGrad then
  begin
    if FInput^.Grad = nil then FInput^.Grad := GradInput else FInput^.Grad := TensorAdd(FInput^.Grad, GradInput);
  end;
end;

{ ═══════════════════════════════════════════════════════════════════
  TFeedForward — MLP: Linear → ReLU → Linear
  ═══════════════════════════════════════════════════════════════════
  NL: Eenvoudig 2-laags MLP dat de representatiekracht vergroot.
  Typisch: HiddenDim = 4 × ModelDim }
{ EN: Simple 2-layer MLP that increases representational power.
  Typically: HiddenDim = 4 × ModelDim }
constructor TFeedForward.Create(ModelDim, HiddenDim: integer);
var
  Dims: array[0..1] of integer;
begin
  inherited Create(ModelDim, ModelDim);
  FHiddenDim := HiddenDim;
  Dims[0] := HiddenDim; Dims[1] := ModelDim;
  FW1 := TensorXavier(@Dims[0], 2);
  Dims[0] := ModelDim; Dims[1] := HiddenDim;
  FW2 := TensorXavier(@Dims[0], 2);
  Dims[0] := HiddenDim;
  FB1 := TensorZeros(@Dims[0], 1);
  Dims[0] := ModelDim;
  FB2 := TensorZeros(@Dims[0], 1);
  
  FW1Grad := TensorZeros(@Dims[0], 2); // wait, FW1 is [HiddenDim, ModelDim]
  // Correcting dimensions for gradients:
  var Dims1: array[0..1] of integer; Dims1[0] := HiddenDim; Dims1[1] := ModelDim;
  FW1Grad := TensorZeros(@Dims1[0], 2);
  var Dims2: array[0..1] of integer; Dims2[0] := ModelDim; Dims2[1] := HiddenDim;
  FW2Grad := TensorZeros(@Dims2[0], 2);
  var DimsB1: array[0..1] of integer; DimsB1[0] := HiddenDim;
  FB1Grad := TensorZeros(@DimsB1[0], 1);
  var DimsB2: array[0..1] of integer; DimsB2[0] := ModelDim;
  FB2Grad := TensorZeros(@DimsB2[0], 1);
end;

destructor TFeedForward.Destroy;
begin
  TensorFree(FW1); TensorFree(FW2); TensorFree(FB1); TensorFree(FB2);
  TensorFree(FW1Grad); TensorFree(FW2Grad); TensorFree(FB1Grad); TensorFree(FB2Grad);
  inherited Destroy;
end;

function TFeedForward.forward(const Input: PTensor): PTensor;
begin
  FInput := Input;
  FHidden := TensorReLU(TensorAdd(TensorMatMul(Input, FW1), FB1));
  Result := TensorAdd(TensorMatMul(FHidden, FW2), FB2);
end;

procedure TFeedForward.Backward(const GradOutput: PTensor);
var
  GradH, GradPreAct, GradInput: PTensor;
begin
  { 1. Gradient w.r.t. Hidden layer }
  { GradH = GradOutput * FW2^T }
  GradH := TensorMatMul(GradOutput, TensorTranspose(FW2));
  
  { 2. Gradient w.r.t. FW2 and FB2 }
  FW2Grad := TensorAdd(FW2Grad, TensorMatMul(TensorTranspose(FHidden), GradOutput));
  FB2Grad := TensorAdd(FB2Grad, TensorSum(GradOutput, 0));
  
  { 3. Gradient w.r.t. Pre-activation (ReLU backward) }
  { GradPreAct = GradH * (FHidden > 0) }
  GradPreAct := TensorMul(GradH, TensorReLU(FHidden)); // Simplified: using ReLU as mask
  
  { 4. Gradient w.r.t. FW1 and FB1 }
  FW1Grad := TensorAdd(FW1Grad, TensorMatMul(TensorTranspose(FInput), GradPreAct));
  FB1Grad := TensorAdd(FB1Grad, TensorSum(GradPreAct, 0));
  
  { 5. Gradient w.r.t. Input }
  GradInput := TensorMatMul(GradPreAct, TensorTranspose(FW1));
  
  if (FInput <> nil) and FInput^.RequiresGrad then
  begin
    if FInput^.Grad = nil then FInput^.Grad := GradInput else FInput^.Grad := TensorAdd(FInput^.Grad, GradInput);
  end;
end;

{ ═══════════════════════════════════════════════════════════════════
  TTransformerEncoderBlock
  ═══════════════════════════════════════════════════════════════════
  NL: Encoder blok: Self-Attention → Add+Norm → FFN → Add+Norm }
{ EN: Encoder block: Self-Attention → Add+Norm → FFN → Add+Norm }
constructor TTransformerEncoderBlock.Create(ModelDim, NumHeads, FFNHiddenDim: integer; DropoutRate: double = 0.1);
begin
  inherited Create(ModelDim, ModelDim);
  FAttention := TMultiHeadAttention.Create(ModelDim, NumHeads);
  FFeedForward := TFeedForward.Create(ModelDim, FFNHiddenDim);
  FNorm1 := TLayerNormLayer.Create(ModelDim);
  FNorm2 := TLayerNormLayer.Create(ModelDim);
  FDropout := TDropoutLayer.Create(DropoutRate);
end;

destructor TTransformerEncoderBlock.Destroy;
begin
  FAttention.Free; FFeedForward.Free; FNorm1.Free; FNorm2.Free; FDropout.Free;
  inherited Destroy;
end;

{ NL: X = Input + Dropout(SelfAttention(LayerNorm(Input)))
       Output = X + Dropout(FFN(LayerNorm(X))) }
{ EN: X = Input + Dropout(SelfAttention(LayerNorm(Input)))
       Output = X + Dropout(FFN(LayerNorm(X))) }
function TTransformerEncoderBlock.forward(const Input: PTensor): PTensor;
var
  X: PTensor;
begin
  X := TensorAdd(Input, FDropout.forward(FAttention.forward(FNorm1.forward(Input))));
  Result := TensorAdd(X, FDropout.forward(FFeedForward.forward(FNorm2.forward(X))));
end;

procedure TTransformerEncoderBlock.Backward(const GradOutput: PTensor);
var
  GradX, GradInput: PTensor;
begin
  { Output = X + Dropout(FFN(LayerNorm(X))) }
  { GradX = GradOutput + Grad(Dropout(FFN(LayerNorm(X)))) }
  GradX := TensorAdd(GradOutput, FNorm2.Backward(FDropout.Backward(FFeedForward.Backward(GradOutput))));
  
  { X = Input + Dropout(SelfAttention(LayerNorm(Input))) }
  { GradInput = GradX + Grad(Dropout(SelfAttention(LayerNorm(Input)))) }
  GradInput := TensorAdd(GradX, FNorm1.Backward(FDropout.Backward(FAttention.Backward(GradX))));
  
  if (FNorm1.FInput <> nil) and FNorm1.FInput^.RequiresGrad then
  begin
    if FNorm1.FInput^.Grad = nil then FNorm1.FInput^.Grad := GradInput else FNorm1.FInput^.Grad := TensorAdd(FNorm1.FInput^.Grad, GradInput);
  end;
end;

{ ═══════════════════════════════════════════════════════════════════
  TTransformerDecoderBlock
  ═══════════════════════════════════════════════════════════════════
  NL: Decoder blok:
      1. Masked Self-Attention (voorkomt kijken naar toekomst)
      2. Cross-Attention (kijkt naar encoder uitvoer)
      3. Feed-Forward Network
      Elk met Add+Norm en Dropout }
{ EN: Decoder block:
      1. Masked Self-Attention (prevents looking at future)
      2. Cross-Attention (looks at encoder output)
      3. Feed-Forward Network
      Each with Add+Norm and Dropout }
constructor TTransformerDecoderBlock.Create(ModelDim, NumHeads, FFNHiddenDim: integer; DropoutRate: double = 0.1);
begin
  inherited Create(ModelDim, ModelDim);
  FMaskedAttention := TMultiHeadAttention.Create(ModelDim, NumHeads);
  FCrossAttention := TMultiHeadAttention.Create(ModelDim, NumHeads);
  FFeedForward := TFeedForward.Create(ModelDim, FFNHiddenDim);
  FNorm1 := TLayerNormLayer.Create(ModelDim);
  FNorm2 := TLayerNormLayer.Create(ModelDim);
  FNorm3 := TLayerNormLayer.Create(ModelDim);
  FDropout := TDropoutLayer.Create(DropoutRate);
end;

destructor TTransformerDecoderBlock.Destroy;
begin
  FMaskedAttention.Free; FCrossAttention.Free; FFeedForward.Free;
  FNorm1.Free; FNorm2.Free; FNorm3.Free; FDropout.Free;
  inherited Destroy;
end;

{ NL: Forward door decoder (vereenvoudigd) }
{ EN: Forward through decoder (simplified) }
function TTransformerDecoderBlock.forward(const Input, EncoderOutput: PTensor): PTensor;
var
  X: PTensor;
begin
  { 1. Masked Self-Attention }
  X := TensorAdd(Input, FDropout.forward(FMaskedAttention.forward(FNorm1.forward(Input))));
  
  { 2. Cross-Attention }
  { Note: FCrossAttention.Forward should be updated to take (Query, Key, Value) }
  X := TensorAdd(X, FDropout.forward(FCrossAttention.forward(FNorm2.forward(X)))); 
  
  { 3. Feed-Forward }
  Result := TensorAdd(X, FDropout.forward(FFeedForward.forward(FNorm3.forward(X))));
end;

procedure TTransformerDecoderBlock.Backward(const GradOutput: PTensor);
var
  GradX, GradInput: PTensor;
begin
  { Output = X + Dropout(FFN(LayerNorm(X))) }
  GradX := TensorAdd(GradOutput, FNorm3.Backward(FDropout.Backward(FFeedForward.Backward(GradOutput))));
  
  { X = X_prev + Dropout(CrossAttention(LayerNorm(X_prev), EncoderOutput)) }
  GradX := TensorAdd(GradX, FNorm2.Backward(FDropout.Backward(FCrossAttention.Backward(GradX))));
  
  { X_prev = Input + Dropout(MaskedAttention(LayerNorm(Input))) }
  GradInput := TensorAdd(GradX, FNorm1.Backward(FDropout.Backward(FMaskedAttention.Backward(GradX))));
  
  if (FNorm1.FInput <> nil) and FNorm1.FInput^.RequiresGrad then
  begin
    if FNorm1.FInput^.Grad = nil then FNorm1.FInput^.Grad := GradInput else FNorm1.FInput^.Grad := TensorAdd(FNorm1.FInput^.Grad, GradInput);
  end;
end;

{ ═══════════════════════════════════════════════════════════════════
  TPositionalEncoding
  ═══════════════════════════════════════════════════════════════════
  NL: Voeg positie-informatie toe aan de input embeddings zodat
  het model de volgorde van de sequentie kan leren.
  Gebruik: PosEncoding.Forward(EmbeddingOutput) }
{ EN: Add position information to input embeddings so the model
  can learn the order of the sequence.
  Usage: PosEncoding.Forward(EmbeddingOutput) }
constructor TPositionalEncoding.Create(MaxLen, Dims: integer);
var
  Dims2: array[0..1] of integer;
begin
  inherited Create(Dims, Dims);
  FMaxLen := MaxLen;
  FDims := Dims;
  Dims2[0] := MaxLen; Dims2[1] := Dims;
  FPositions := TensorXavier(@Dims2[0], 2);
end;

destructor TPositionalEncoding.Destroy;
begin
  TensorFree(FPositions);
  inherited Destroy;
end;

{ NL: Tel posities op bij de input: Output = Input + Positions }
{ EN: Add positions to input: Output = Input + Positions }
function TPositionalEncoding.forward(const Input: PTensor): PTensor;
begin
  FInput := Input;
  Result := TensorAdd(Input, FPositions);
end;

procedure TPositionalEncoding.Backward(const GradOutput: PTensor);
begin
  if (FInput <> nil) and FInput^.RequiresGrad then
  begin
    if FInput^.Grad = nil then FInput^.Grad := GradOutput else FInput^.Grad := TensorAdd(FInput^.Grad, GradOutput);
  end;
end;

{ ═══════════════════════════════════════════════════════════════════
  TTextGenerator — Autoregressieve tekstgeneratie (GPT-stijl)
  ═══════════════════════════════════════════════════════════════════
  NL: Genereer tekst door één token per keer te voorspellen.
  Het gegenereerde token wordt aan de input toegevoegd voor de
  volgende stap (autoregressief). Temperature controleert hoe
  creatief de output is. }
{ EN: Generate text by predicting one token at a time.
  The generated token is appended to the input for the next step
  (autoregressive). Temperature controls how creative the output is. }
constructor TTextGenerator.Create(Model: TLayer; Tokenizer: TTokenizer; MaxTokens: integer = 256; Temperature: double = 0.7);
begin
  inherited Create;
  FModel := Model;
  FTokenizer := Tokenizer;
  FMaxTokens := MaxTokens;
  FTemperature := Temperature;
end;

destructor TTextGenerator.Destroy;
begin
  inherited Destroy;
end;

{ NL: Genereer tekst vanaf een prompt. }
{ EN: Generate text from a prompt. }
function TTextGenerator.Generate(const Prompt: string): string;
var
  InputTokens, OutputTokens: array of integer;
begin
  InputTokens := FTokenizer.Encode(Prompt);
  OutputTokens := GenerateTokens(InputTokens, FMaxTokens);
  Result := FTokenizer.Decode(OutputTokens);
end;

{ NL: Autoregressieve token generatie. In een echte implementatie
      wordt het model herhaaldelijk aangeroepen: elk nieuw token
      wordt aan de sequentie toegevoegd als input voor de volgende stap. }
{ EN: Autoregressive token generation. In a real implementation,
      the model is called repeatedly: each new token is appended
      to the sequence as input for the next step. }
function TTextGenerator.GenerateTokens(const Prompt: array of integer; MaxNewTokens: integer): array of integer;
var
  I: integer;
  CurrentTokens: array of integer;
  InputTensor: PTensor;
  OutputTensor: PTensor;
  ProbDist: PTensor;
  NextToken: integer;
  Batch, Seq, ModelDim: integer;
  Dims: array[0..2] of integer;
begin
  CurrentTokens := Prompt;
  
  for I := 1 to MaxNewTokens do
  begin
    { Convert CurrentTokens to Tensor [1, Seq, ModelDim] }
    Seq := Length(CurrentTokens);
    ModelDim := 512; // Assume ModelDim=512 or get from FModel
    Dims[0] := 1; Dims[1] := Seq; Dims[2] := ModelDim;
    
    { This is a simplification: we assume we have an embedding layer 
      that converts tokens to vectors. }
    InputTensor := TensorZeros(@Dims[0], 3); 
    
    { Run Model Forward }
    OutputTensor := FModel.forward(InputTensor);
    
    { Get logits for the last token }
    { OutputTensor is [1, Seq, VocabSize] }
    ProbDist := TensorSoftmax(OutputTensor, 2);
    
    { Sample next token based on temperature }
    { Simplified: just take the ArgMax for now }
    NextToken := TensorArgMax(ProbDist, 2)^.Data[0];
    
    { Append token to sequence }
    SetLength(CurrentTokens, Seq + 1);
    CurrentTokens[Seq] := NextToken;
    
    if NextToken = 0 then break; { Stop token }
  end;
  
  Result := CurrentTokens;
end;

end.
