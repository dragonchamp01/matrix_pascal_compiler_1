{
   Matrix Pascal - RTL AI Brain Module
   Model I/O: opslaan en laden van getrainde model gewichten
   ═══════════════════════════════════════════════════════════
   Nederlands: Sla getrainde neurale netwerk gewichten op naar
   een binair bestand en laad ze later weer. Gebruikt TFileStream
   voor echte, robuuste bestands-I/O.

   English: Save trained neural network weights to a binary file
   and load them later. Uses TFileStream for real, robust file I/O.

   Copyright (c) 2026 Marco Hagenaars
   SPDX-License-Identifier: MIT
   Licensed under the MIT License. See LICENSE file for details.
   See LICENSE file in the project root for full license terms.
}

unit model_io;

interface

uses
  System, Classes, SysUtils;

type
  { ███████████████████████████████████████████████████████████████
    TModelIO — Serialisatie van model gewichten
               Model weight serialization
    ███████████████████████████████████████████████████████████████
    NL: Statische klasse om model gewichten op te slaan en te laden.
    Gebruik Save/na training en Load voor inference. }
  TModelIO = class
  public
    class procedure Save(const ModelPath: string; Weights: pointer; Count: integer);
    class procedure Load(const ModelPath: string; out Weights: pointer; out Count: integer);
  end;

implementation

{ TModelIO }

{ NL: Sla gewichten op naar een binair bestand.
      Formaat: [Count:Integer] [Data:Count × Double]
  EN: Save weights to a binary file.
      Format: [Count:Integer] [Data:Count × Double] }
class procedure TModelIO.Save(const ModelPath: string; Weights: pointer; Count: integer);
var
  F: TFileStream;
begin
  F := TFileStream.Create(ModelPath, fmCreate);
  try
    F.WriteBuffer(Count, SizeOf(integer));
    F.WriteBuffer(Weights^, Count * SizeOf(double));
  finally
    F.Free;
  end;
end;

{ NL: Laad gewichten uit een binair bestand.
      Roept GetMem aan om geheugen te alloceren voor de weights.
      De beller moet FreeMem aanroepen na gebruik.
  EN: Load weights from a binary file.
      Calls GetMem to allocate memory for the weights.
      The caller must call FreeMem after use. }
class procedure TModelIO.Load(const ModelPath: string; out Weights: pointer; out Count: integer);
var
  F: TFileStream;
begin
  if not FileExists(ModelPath) then exit;
  
  F := TFileStream.Create(ModelPath, fmOpenRead);
  try
    F.ReadBuffer(Count, SizeOf(integer));
    GetMem(Weights, Count * SizeOf(double));
    F.ReadBuffer(Weights^, Count * SizeOf(double));
  finally
    F.Free;
  end;
end;

end.
