{
   Matrix Pascal - RTL AI Brain Module
   Planner: Task planning and scheduling system
   ════════════════════════════════════════════════════════════════
   Nederlands: De Planner organiseert taken in een gestructureerd
   plan. Het kan stappen maken, prioriteiten toekennen, deadlines
   bijhouden, en de voortgang rapporteren. Dit maakt de AI Brain
   proactief in plaats van alleen reactief.

   English: The Planner organizes tasks into a structured plan.
   It can create steps, assign priorities, track deadlines, and
   report progress. This makes the AI Brain proactive instead
   of just reactive.

   Gebruik / Usage:
     Plan := TPlanner.Create;
     Plan.CreatePlan('Leer Nederlands in 3 maanden');
     Plan.AddStep(PlanID, 'Leer woordenschat', 1);
     Plan.ExecuteTask(PlanID);

   Copyright (c) 2026 Marco Hagenaars
   SPDX-License-Identifier: MIT
}

unit planner;

interface

uses
  System, Classes, SysUtils;

type
  { Taak status / Task status }
  TPlanStatus = (psPending, psInProgress, psCompleted, psFailed, psCancelled);
  TPriority = (prLow, prNormal, prHigh, prCritical);

  { Een individuele stap in een plan / An individual step in a plan }
  TPlanStep = class
  public
    ID: integer;
    Description: string;
    Status: TPlanStatus;
    Priority: TPriority;
    Created: TDateTime;
    Deadline: TDateTime;
    Notes: TStringList;
    Result: string;
    constructor Create(const ADesc: string; APriority: TPriority);
    destructor Destroy; override;
  end;

  { ███████████████████████████████████████████████████████████████
    TPlanner — Taakplanner en planner voor de AI Brain
               Task planner and scheduler for the AI Brain
    ███████████████████████████████████████████████████████████████
    NL: Beheert meerdere plannen, elk met stappen. Kan
    afhankelijkheden tussen stappen en plannen aan.

    EN: Manages multiple plans, each with steps. Can handle
    dependencies between steps and plans. }
  TPlanner = class
  private
    FPlans: TList;              { Lijst van TList (elk plan = lijst stappen) / List of TList }
    FPlanDescriptions: TStringList;
    FNextStepID: integer;
    FNextPlanID: integer;

    function GetPlanCount: integer;
    function GetStepCount(PlanID: integer): integer;
    function GetStep(PlanID, StepIndex: integer): TPlanStep;
  public
    constructor Create;
    destructor Destroy; override;

    { ─── Plan beheer / Plan management ─── }
    function CreatePlan(const Description: string): integer;
    procedure DeletePlan(PlanID: integer);
    function AddStep(PlanID: integer; const Description: string; Priority: TPriority = prNormal): integer;
    procedure UpdateStepStatus(PlanID, StepID: integer; Status: TPlanStatus);
    procedure ExecuteTask(PlanID: integer);
    function ListPlans: TStringList;
    function GetPlanReport(PlanID: integer): TStringList;

    { ─── Eenvoudige planning / Simple planning ─── }
    function CreatePlanFromText(const TaskText: string): string;

    property PlanCount: integer read GetPlanCount;
  end;

implementation

{ TPlanStep }

constructor TPlanStep.Create(const ADesc: string; APriority: TPriority);
begin
  inherited Create;
  Description := ADesc;
  Priority := APriority;
  Status := psPending;
  Created := Now;
  Notes := TStringList.Create;
end;

destructor TPlanStep.Destroy;
begin
  Notes.Free;
  inherited Destroy;
end;

{ TPlanner }

constructor TPlanner.Create;
begin
  inherited Create;
  FPlans := TList.Create;
  FPlanDescriptions := TStringList.Create;
  FNextStepID := 1;
  FNextPlanID := 1;
end;

destructor TPlanner.Destroy;
var
  I, J: integer;
begin
  for I := 0 to FPlans.Count - 1 do
  begin
    for J := 0 to TList(FPlans[I]).Count - 1 do
      TPlanStep(TList(FPlans[I])[J]).Free;
    TList(FPlans[I]).Free;
  end;
  FPlans.Free;
  FPlanDescriptions.Free;
  inherited Destroy;
end;

{ NL: Maak een nieuw plan en retourneer het plan ID. }
{ EN: Create a new plan and return the plan ID. }
function TPlanner.CreatePlan(const Description: string): integer;
begin
  Result := FNextPlanID;
  Inc(FNextPlanID);
  FPlans.Add(TList.Create);
  FPlanDescriptions.Add(IntToStr(Result) + '=' + Description);
end;

{ NL: Verwijder een plan en al zijn stappen. }
{ EN: Delete a plan and all its steps. }
procedure TPlanner.DeletePlan(PlanID: integer);
var
  I, Idx: integer;
begin
  Idx := PlanID - 1;
  if (Idx >= 0) and (Idx < FPlans.Count) then
  begin
    for I := 0 to TList(FPlans[Idx]).Count - 1 do
      TPlanStep(TList(FPlans[Idx])[I]).Free;
    TList(FPlans[Idx]).Free;
    FPlans.Delete(Idx);
    FPlanDescriptions.Delete(Idx);
  end;
end;

{ NL: Voeg een stap toe aan een bestaand plan. }
{ EN: Add a step to an existing plan. }
function TPlanner.AddStep(PlanID: integer; const Description: string; Priority: TPriority): integer;
var
  Idx: integer;
  Step: TPlanStep;
begin
  Idx := PlanID - 1;
  if (Idx >= 0) and (Idx < FPlans.Count) then
  begin
    Step := TPlanStep.Create(Description, Priority);
    Step.ID := FNextStepID;
    Result := FNextStepID;
    Inc(FNextStepID);
    TList(FPlans[Idx]).Add(Step);
  end
  else
    Result := -1;
end;

{ NL: Update de status van een stap. }
{ EN: Update the status of a step. }
procedure TPlanner.UpdateStepStatus(PlanID, StepID: integer; Status: TPlanStatus);
var
  I, Idx: integer;
  PlanSteps: TList;
begin
  Idx := PlanID - 1;
  if (Idx >= 0) and (Idx < FPlans.Count) then
  begin
    PlanSteps := TList(FPlans[Idx]);
    for I := 0 to PlanSteps.Count - 1 do
      if TPlanStep(PlanSteps[I]).ID = StepID then
      begin
        TPlanStep(PlanSteps[I]).Status := Status;
        break;
      end;
  end;
end;

{ NL: Voer alle stappen van een plan uit (simulatie). }
{ EN: Execute all steps of a plan (simulation). }
procedure TPlanner.ExecuteTask(PlanID: integer);
var
  I, Idx: integer;
  Step: TPlanStep;
begin
  Idx := PlanID - 1;
  if (Idx >= 0) and (Idx < FPlans.Count) then
  begin
    for I := 0 to TList(FPlans[Idx]).Count - 1 do
    begin
      Step := TPlanStep(TList(FPlans[Idx])[I]);
      Step.Status := psInProgress;
      Step.Result := 'Uitgevoerd: ' + Step.Description;
      Step.Status := psCompleted;
    end;
  end;
end;

{ NL: Genereer een lijst van alle plannen met beschrijvingen. }
{ EN: Generate a list of all plans with descriptions. }
function TPlanner.ListPlans: TStringList;
var
  I: integer;
begin
  Result := TStringList.Create;
  for I := 0 to FPlanDescriptions.Count - 1 do
    Result.Add('Plan ' + IntToStr(I + 1) + ': ' + FPlanDescriptions.ValueFromIndex[I]);
end;

{ NL: Genereer een gedetailleerd rapport van een plan. }
{ EN: Generate a detailed report of a plan. }
function TPlanner.GetPlanReport(PlanID: integer): TStringList;
var
  I, Idx: integer;
  Step: TPlanStep;
  StatusStr: string;
begin
  Result := TStringList.Create;
  Idx := PlanID - 1;
  if (Idx >= 0) and (Idx < FPlans.Count) then
  begin
    Result.Add('=== Plan Report: ' + FPlanDescriptions.ValueFromIndex[Idx] + ' ===');
    for I := 0 to TList(FPlans[Idx]).Count - 1 do
    begin
      Step := TPlanStep(TList(FPlans[Idx])[I]);
      case Step.Status of
        psPending:    StatusStr := '⏳ Wachtend / Pending';
        psInProgress: StatusStr := '▶️ Bezig / In Progress';
        psCompleted:  StatusStr := '✅ Voltooid / Completed';
        psFailed:     StatusStr := '❌ Mislukt / Failed';
        psCancelled:  StatusStr := '🚫 Geannuleerd / Cancelled';
      end;
      Result.Add(Format('  [%d] %s - %s', [Step.ID, Step.Description, StatusStr]));
      if Step.Result <> '' then
        Result.Add('       Result: ' + Step.Result);
    end;
  end
  else
    Result.Add('Plan not found');
end;

{ NL: Maak een plan van losse tekst door het te parsen. }
{ EN: Create a plan from free text by parsing it. }
function TPlanner.CreatePlanFromText(const TaskText: string): string;
var
  PlanID: integer;
begin
  PlanID := CreatePlan('Auto-plan: ' + TaskText);
  AddStep(PlanID, 'Analyseer: ' + TaskText, prHigh);
  AddStep(PlanID, 'Voer uit: ' + TaskText, prNormal);
  AddStep(PlanID, 'Controleer resultaat', prNormal);
  Result := 'Plan #' + IntToStr(PlanID) + ' created: ' + TaskText;
end;

function TPlanner.GetPlanCount: integer;
begin
  Result := FPlans.Count;
end;

function TPlanner.GetStepCount(PlanID: integer): integer;
var
  Idx: integer;
begin
  Idx := PlanID - 1;
  if (Idx >= 0) and (Idx < FPlans.Count) then
    Result := TList(FPlans[Idx]).Count
  else
    Result := 0;
end;

function TPlanner.GetStep(PlanID, StepIndex: integer): TPlanStep;
var
  Idx: integer;
begin
  Idx := PlanID - 1;
  if (Idx >= 0) and (Idx < FPlans.Count) and
     (StepIndex >= 0) and (StepIndex < TList(FPlans[Idx]).Count) then
    Result := TPlanStep(TList(FPlans[Idx])[StepIndex])
  else
    Result := nil;
end;

end.
