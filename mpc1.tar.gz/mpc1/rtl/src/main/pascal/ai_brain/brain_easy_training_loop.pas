{
    Matrix Pascal - RTL AI Brain Module
    Easy Training Loop Wrapper
    ═══════════════════════════════════════════════════════════
    NL: Een eenvoudige wrapper voor het trainen van een netwerk.
    
    EN: A simple wrapper for training a network.
}

unit brain_easy_training_loop;

interface

uses
  System, Classes, SysUtils, brain_core, trainer, tensor_unit;

type
  TEasyTrainer = class(TObject)
  public
    procedure QuickTrain(Net: TBrainNetwork; X, Y: array of PTensor; Epochs: integer);
  end;

implementation

procedure TEasyTrainer.QuickTrain(Net: TBrainNetwork; X, Y: array of PTensor; Epochs: integer);
var
  T: TModelTrainer;
  DS: TDataset;
begin
  DS := TDataset.Create;
  for var i := 0 to High(X) do DS.AddSample(X[i], Y[i]);
  
  T := TModelTrainer.Create(TModel(Net), TTrainingConfig.Create);
  try
    T.Fit(DS);
  finally
    T.Free;
    DS.Free;
  end;
end;

end.
