{
   Matrix Pascal - Zero-Copy Stream I/O & Async File Operations
   ════════════════════════════════════════════════════════════════
   Memory-mapped files, zero-copy buffers, buffer pool, async I/O,
   scatter/gather I/O

   Nederlands: Zero-copy stream I/O: memory-mapped bestanden,
   zero-copy buffers, buffer pool, async I/O, scatter/gather I/O.

   English: Zero-copy stream I/O: memory-mapped files, zero-copy
   buffers, buffer pool, async I/O, scatter/gather I/O.

   Copyright (c) 2026 Marco Hagenaars
}
unit zerocopy;

{$mode objfpc}{$H+}
{$includelib c}
{$includelib rt}

interface

uses System, Classes, SysUtils, Math;

type
  EZerocopyError = class(Exception);

  { █████████████████████████████████████████████████████████████
    TMMapFile — Memory-mapped file (mmap) / Geheugen-gemapt bestand }
  TMMapFile = class
  private
    FFileName: string;
    FData: pointer;
    FSize: int64;
    FMapped: boolean;
    FHandle: integer;
  public
    constructor Create(const FileName: string);
    destructor Destroy; override;
    function Map: boolean;
    procedure Unmap;
    property Data: pointer read FData;
    property Size: int64 read FSize;
    property Mapped: boolean read FMapped;
    property FileName: string read FFileName;
  end;

  { █████████████████████████████████████████████████████████████
    TZeroBuffer — Reference-counted zero-copy buffer / Referentie-getelde buffer }
  TZeroBuffer = class
  private
    FData: pointer;
    FSize: integer;
    FOwned: boolean;
    FRefCount: PInteger;
  public
    constructor Create(ASize: integer);
    constructor CreateFrom(const AData; ASize: integer; AOwned: boolean = true);
    destructor Destroy; override;
    procedure AddRef;
    procedure ReleaseRef;
    function Slice(AOffset, ACount: integer): TZeroBuffer;
    function DataPtr: pointer;
    function GetSize: integer;
    function GetRefCount: integer;
  end;

  { █████████████████████████████████████████████████████████████
    TBufferPool — Reusable buffer pool / Herbruikbare buffer pool }
  TBufferPool = class
  private
    FBuffers: array of TZeroBuffer;
    FBufferSizes: array of integer;
    FCount: integer;
    FMaxBuffers: integer;
    FAvailable: array of boolean;
  public
    constructor Create(AMaxBuffers: integer = 64);
    destructor Destroy; override;
    function Acquire(MinSize: integer): TZeroBuffer;
    procedure Release(Buf: TZeroBuffer);
    procedure Clear;
  end;

  { Async file operation types }
  TAsyncFileOp = (afoRead, afoWrite);
  TAsyncFileStatus = (afsPending, afsCompleted, afsFailed);

  { █████████████████████████████████████████████████████████████
    TAsyncResult — Result of an async operation / Async resultaat }
  TAsyncResult = class
  private
    FStatus: TAsyncFileStatus;
    FBytesTransferred: int64;
    FErrorCode: integer;
    FUserData: pointer;
    FAioBuf: pointer;
  public
    constructor Create;
    destructor Destroy; override;
    function Wait(TimeoutMS: integer = -1): boolean;
    function IsCompleted: boolean;
    property Status: TAsyncFileStatus read FStatus;
    property BytesTransferred: int64 read FBytesTransferred;
    property ErrorCode: integer read FErrorCode;
    property UserData: pointer read FUserData write FUserData;
  end;

  { █████████████████████████████████████████████████████████████
    TAsyncFile — Async file I/O / Async bestand I/O }
  TAsyncFile = class
  private
    FHandle: integer;
    FFileName: string;
    FOpen: boolean;
  public
    constructor Create(const AFileName: string; readonly: boolean = false);
    destructor Destroy; override;
    function read(Buffer: TZeroBuffer; AOffset: int64; ACount: integer): TAsyncResult;
    function write(Buffer: TZeroBuffer; AOffset: int64; ACount: integer): TAsyncResult;
    function Flush: boolean;
    procedure Close;
    property FileName: string read FFileName;
    property IsOpen: boolean read FOpen;
  end;

  { Scatter/gather I/O vector }
  TIOVec = record
    Base: pointer;
    Len: integer;
  end;

  { Read into multiple buffers }
  function ReadV(Handle: integer; const IOV: array of TIOVec; Count: integer): int64;
  { Write from multiple buffers }
  function WriteV(Handle: integer; const IOV: array of TIOVec; Count: integer): int64;

implementation

uses
  BaseUnix;

{ POSIX functions via BaseUnix }

function _open(const Path: pchar; Flags, Mode: integer): integer;
begin
  Result := fpOpen(Path, Flags, Mode);
end;

function _close(Fd: integer): integer;
begin
  Result := fpClose(Fd);
end;

function _read(Fd: integer; Buf: pointer; Count: integer): int64;
begin
  Result := fpRead(Fd, Buf, Count);
end;

function _write(Fd: integer; Buf: pointer; Count: integer): int64;
begin
  Result := fpWrite(Fd, Buf, Count);
end;

function _lseek(Fd: integer; offset: int64; Whence: integer): int64;
begin
  Result := fpLSeek(Fd, offset, Whence);
end;

function _fsync(Fd: integer): integer;
begin
  Result := fpFsync(Fd);
end;

function _mmap(addr: pointer; Length: int64; Prot, Flags, Fd, offset: integer): pointer;
begin
  Result := fpMmap(addr, Length, Prot, Flags, Fd, offset);
end;

function _munmap(addr: pointer; Length: int64): integer;
begin
  Result := fpMUnmap(addr, Length);
end;

function _readv(Fd: integer; const Iov: pointer; Iovcnt: integer): int64; external name 'readv';
function _writev(Fd: integer; const Iov: pointer; Iovcnt: integer): int64; external name 'writev';

const
  O_RDONLY = 0;
  O_WRONLY = 1;
  O_RDWR = 2;
  O_CREAT = 64;
  O_TRUNC = 512;
  S_IRUSR = 256;
  S_IWUSR = 128;
  PROT_READ = 1;
  PROT_WRITE = 2;
  MAP_PRIVATE = 2;
  MAP_SHARED = 1;
  SEEK_SET = 0;
  SEEK_CUR = 1;
  SEEK_END = 2;

type
  aiocb = record
    aio_fildes: integer;
    aio_buf: pointer;
    aio_nbytes: integer;
    aio_offset: int64;
    aio_reqprio: integer;
    aio_sigevent: pointer;
    aio_lio_opcode: integer;
  end;

function _aio_read(var Aiocbp: aiocb): integer; external name 'aio_read';
function _aio_write(var Aiocbp: aiocb): integer; external name 'aio_write';
function _aio_error(var Aiocbp: aiocb): integer; external name 'aio_error';
function _aio_return(var Aiocbp: aiocb): int64; external name 'aio_return';
function _aio_suspend(const List: pointer; NItems: integer; Timeout: pointer): integer; external name 'aio_suspend';

{ TMMapFile }

constructor TMMapFile.Create(const FileName: string);
begin
  inherited Create;
  FFileName := FileName;
  FData := nil;
  FSize := 0;
  FMapped := false;
  FHandle := -1;
end;

destructor TMMapFile.Destroy;
begin
  Unmap;
  inherited;
end;

function TMMapFile.Map: boolean;
begin
  if FMapped then exit(true);
  FHandle := _open(pchar(FFileName), O_RDONLY, 0);
  if FHandle < 0 then exit(false);
  FSize := _lseek(FHandle, 0, SEEK_END);
  if FSize <= 0 then
  begin
    _close(FHandle);
    FHandle := -1;
    exit(false);
  end;
  FData := _mmap(nil, FSize, PROT_READ, MAP_PRIVATE, FHandle, 0);
  if FData = pointer(-1) then
  begin
    FData := nil;
    _close(FHandle);
    FHandle := -1;
    exit(false);
  end;
  FMapped := true;
  Result := true;
end;

procedure TMMapFile.Unmap;
begin
  if FMapped then
  begin
    _munmap(FData, FSize);
    FData := nil;
    FMapped := false;
  end;
  if FHandle >= 0 then
  begin
    _close(FHandle);
    FHandle := -1;
  end;
end;

{ TZeroBuffer }

constructor TZeroBuffer.Create(ASize: integer);
begin
  inherited Create;
  FSize := ASize;
  if ASize > 0 then
    GetMem(FData, ASize)
  else
    FData := nil;
  FOwned := true;
  New(FRefCount);
  FRefCount^ := 1;
end;

constructor TZeroBuffer.CreateFrom(const AData; ASize: integer; AOwned: boolean);
begin
  inherited Create;
  FData := @AData;
  FSize := ASize;
  FOwned := AOwned;
  New(FRefCount);
  FRefCount^ := 1;
end;

destructor TZeroBuffer.Destroy;
begin
  if FOwned and (FData <> nil) then
    FreeMem(FData);
  if FRefCount <> nil then
  begin
    Dispose(FRefCount);
    FRefCount := nil;
  end;
  inherited;
end;

procedure TZeroBuffer.AddRef;
begin
  if FRefCount <> nil then
    Inc(FRefCount^);
end;

procedure TZeroBuffer.ReleaseRef;
begin
  if (FRefCount <> nil) and (FRefCount^ > 0) then
  begin
    Dec(FRefCount^);
    if FRefCount^ = 0 then
      Free;
  end;
end;

function TZeroBuffer.Slice(AOffset, ACount: integer): TZeroBuffer;
begin
  if (AOffset < 0) or (AOffset + ACount > FSize) then
    raise EZerocopyError.Create('Slice out of bounds');
  Result := TZeroBuffer.Create;
  Result.FData := pointer(PByte(FData) + AOffset);
  Result.FSize := ACount;
  Result.FOwned := false;
  Result.FRefCount := FRefCount;
  AddRef;
end;

function TZeroBuffer.DataPtr: pointer;
begin
  Result := FData;
end;

function TZeroBuffer.GetSize: integer;
begin
  Result := FSize;
end;

function TZeroBuffer.GetRefCount: integer;
begin
  if FRefCount <> nil then
    Result := FRefCount^
  else
    Result := 0;
end;

{ TBufferPool }

constructor TBufferPool.Create(AMaxBuffers: integer);
begin
  inherited Create;
  FMaxBuffers := AMaxBuffers;
  FCount := 0;
  SetLength(FBuffers, AMaxBuffers);
  SetLength(FBufferSizes, AMaxBuffers);
  SetLength(FAvailable, AMaxBuffers);
end;

destructor TBufferPool.Destroy;
begin
  Clear;
  inherited;
end;

function TBufferPool.Acquire(MinSize: integer): TZeroBuffer;
var
  I, Best: integer;
begin
  Best := -1;
  for I := 0 to FCount - 1 do
    if FAvailable[I] and (FBufferSizes[I] >= MinSize) then
      if (Best < 0) or (FBufferSizes[I] < FBufferSizes[Best]) then
        Best := I;
  if Best >= 0 then
  begin
    FAvailable[Best] := false;
    Result := FBuffers[Best];
  end
  else
  begin
    if FCount < FMaxBuffers then
    begin
      Result := TZeroBuffer.Create(MinSize);
      FBuffers[FCount] := Result;
      FBufferSizes[FCount] := MinSize;
      FAvailable[FCount] := false;
      Inc(FCount);
    end
    else
      Result := TZeroBuffer.Create(MinSize);
  end;
end;

procedure TBufferPool.Release(Buf: TZeroBuffer);
var
  I: integer;
begin
  for I := 0 to FCount - 1 do
    if FBuffers[I] = Buf then
    begin
      FAvailable[I] := true;
      exit;
    end;
  Buf.Free;
end;

procedure TBufferPool.Clear;
var
  I: integer;
begin
  for I := 0 to FCount - 1 do
    if not FAvailable[I] then
      FBuffers[I].Free;
  FCount := 0;
  SetLength(FBuffers, 0);
  SetLength(FBufferSizes, 0);
  SetLength(FAvailable, 0);
end;

{ TAsyncResult }

constructor TAsyncResult.Create;
begin
  inherited Create;
  FStatus := afsPending;
  FBytesTransferred := 0;
  FErrorCode := 0;
  FUserData := nil;
  FAioBuf := AllocMem(SizeOf(aiocb));
end;

destructor TAsyncResult.Destroy;
begin
  if FAioBuf <> nil then FreeMem(FAioBuf);
  inherited;
end;

function TAsyncResult.Wait(TimeoutMS: integer = -1): boolean;
var
  Ts: int64;
  Ret: integer;
begin
  if FStatus <> afsPending then
    exit(FStatus = afsCompleted);
  if FAioBuf = nil then exit(false);
  if TimeoutMS < 0 then
    Ret := _aio_suspend(FAioBuf, 1, nil)
  else
  begin
    Ts := TimeoutMS * 1000000;
    Ret := _aio_suspend(FAioBuf, 1, @Ts);
  end;
  if Ret = 0 then
  begin
    if _aio_error(Paiocb(FAioBuf)^) = 0 then
    begin
      FStatus := afsCompleted;
      FBytesTransferred := _aio_return(Paiocb(FAioBuf)^);
      Result := true;
    end
    else
    begin
      FStatus := afsFailed;
      FErrorCode := _aio_error(Paiocb(FAioBuf)^);
      Result := false;
    end;
  end
  else
  begin
    FStatus := afsFailed;
    FErrorCode := Ret;
    Result := false;
  end;
end;

function TAsyncResult.IsCompleted: boolean;
var
  Err: integer;
begin
  if FStatus <> afsPending then
    exit(FStatus = afsCompleted);
  if FAioBuf = nil then exit(false);
  Err := _aio_error(Paiocb(FAioBuf)^);
  if Err = 0 then
  begin
    FStatus := afsCompleted;
    FBytesTransferred := _aio_return(Paiocb(FAioBuf)^);
    Result := true;
  end
  else if Err = 1 then
    Result := false
  else
  begin
    FStatus := afsFailed;
    FErrorCode := Err;
    Result := false;
  end;
end;

{ TAsyncFile }

constructor TAsyncFile.Create(const AFileName: string; readonly: boolean);
var
  Flags: integer;
begin
  inherited Create;
  FFileName := AFileName;
  if readonly then
    Flags := O_RDONLY
  else
    Flags := O_RDWR or O_CREAT or O_TRUNC;
  FHandle := _open(pchar(AFileName), Flags, S_IRUSR or S_IWUSR);
  FOpen := FHandle >= 0;
  if not FOpen then
    raise EZerocopyError.Create('Failed to open file: ' + AFileName);
end;

destructor TAsyncFile.Destroy;
begin
  Close;
  inherited;
end;

function TAsyncFile.read(Buffer: TZeroBuffer; AOffset: int64; ACount: integer): TAsyncResult;
var
  AiocbPtr: Paiocb;
begin
  if not FOpen then
    raise EZerocopyError.Create('file not open');
  Result := TAsyncResult.Create;
  AiocbPtr := Result.FAioBuf;
  AiocbPtr.aio_fildes := FHandle;
  AiocbPtr.aio_buf := Buffer.DataPtr;
  AiocbPtr.aio_nbytes := ACount;
  AiocbPtr.aio_offset := AOffset;
  AiocbPtr.aio_reqprio := 0;
  if _aio_read(AiocbPtr^) < 0 then
  begin
    Result.FStatus := afsFailed;
    Result.FErrorCode := -1;
  end;
end;

function TAsyncFile.write(Buffer: TZeroBuffer; AOffset: int64; ACount: integer): TAsyncResult;
var
  AiocbPtr: Paiocb;
begin
  if not FOpen then
    raise EZerocopyError.Create('file not open');
  Result := TAsyncResult.Create;
  AiocbPtr := Result.FAioBuf;
  AiocbPtr.aio_fildes := FHandle;
  AiocbPtr.aio_buf := Buffer.DataPtr;
  AiocbPtr.aio_nbytes := ACount;
  AiocbPtr.aio_offset := AOffset;
  AiocbPtr.aio_reqprio := 0;
  if _aio_write(AiocbPtr^) < 0 then
  begin
    Result.FStatus := afsFailed;
    Result.FErrorCode := -1;
  end;
end;

function TAsyncFile.Flush: boolean;
begin
  if not FOpen then exit(false);
  Result := _fsync(FHandle) = 0;
end;

procedure TAsyncFile.Close;
begin
  if FOpen then
  begin
    Flush;
    _close(FHandle);
    FOpen := false;
    FHandle := -1;
  end;
end;

{ Scatter/gather I/O }

function ReadV(Handle: integer; const IOV: array of TIOVec; Count: integer): int64;
begin
  Result := _readv(Handle, @IOV[0], Count);
  if Result < 0 then
    raise EZerocopyError.Create('readv failed');
end;

function WriteV(Handle: integer; const IOV: array of TIOVec; Count: integer): int64;
begin
  Result := _writev(Handle, @IOV[0], Count);
  if Result < 0 then
    raise EZerocopyError.Create('writev failed');
end;

end.
