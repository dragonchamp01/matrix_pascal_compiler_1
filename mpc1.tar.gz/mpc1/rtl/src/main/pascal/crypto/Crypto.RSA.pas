unit Crypto.RSA;
{$mode objfpc}{$H+}
interface
uses System, SysUtils;
type
  TRSAKeyPair = record
    PublicKey: TBytes;
    PrivateKey: TBytes;
  end;
  TRSAKeySize = (rs1024, rs2048, rs4096);
  TRSA = class
  private
    FPublicKey: TBytes;
    FPrivateKey: TBytes;
    FKeySize: TRSAKeySize;
  public
    constructor Create(AKeySize: TRSAKeySize = rs2048);
    class function GenerateKeyPair(AKeySize: TRSAKeySize): TRSAKeyPair; static;
    function Encrypt(const Data: TBytes): TBytes;
    function Decrypt(const Data: TBytes): TBytes;
    function Sign(const Data: TBytes): TBytes;
    function Verify(const Data, Signature: TBytes): boolean;
    procedure LoadPublicKey(const Key: TBytes);
    procedure LoadPrivateKey(const Key: TBytes);
    property KeySize: TRSAKeySize read FKeySize;
  end;
implementation
end.
