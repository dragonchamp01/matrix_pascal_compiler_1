{
   Matrix Pascal - Audio: AO Unit
   ════════════════════════════════════════════════════════════════
   Audio output abstraction layer

   Copyright (c) 2026 Marco Hagenaars
}
unit ao;

{$mode objfpc}{$H+}

interface

uses System, Classes, SysUtils;

type
  TAudioDriver = (
    adNone,
    adALSA,
    adPulseAudio,
    adOSS,
    adWaveOut,
    adDirectSound,
    adCoreAudio,
    adFile
  );

  TAudioSampleFormat = (
    asfU8,
    asfS16_LE,
    asfS16_BE,
    asfS24_LE,
    asfS24_BE,
    asfS32_LE,
    asfS32_BE,
    asfFloat32_LE,
    asfFloat32_BE
  );

  TAODeviceInfo = record
    Name: string;
    Driver: TAudioDriver;
    MaxChannels: integer;
    PreferredSampleRate: integer;
    DefaultFormat: TAudioSampleFormat;
  end;

  TAOCallback = procedure(Buffer: pointer; BufferSize: integer; UserData: pointer);

  TAOStream = class
  private
    FDevice: TAODeviceInfo;
    FSampleRate: integer;
    FNumChannels: integer;
    FSampleFormat: TAudioSampleFormat;
    FActive: boolean;
  public
    constructor Create;
    destructor Destroy; override;
    function Open(Device: integer = 0): boolean;
    function Close: boolean;
    function Play(Buffer: pointer; Size: integer): integer;
    function Wait: boolean;
    property SampleRate: integer read FSampleRate write FSampleRate;
    property NumChannels: integer read FNumChannels write FNumChannels;
    property Active: boolean read FActive;
  end;

  TAO = class
  private
    class var FDrivers: TList;
  public
    class constructor Create;
    class destructor Destroy;
    class function Initialize: boolean;
    class function Shutdown: boolean;
    class function DefaultDriver: TAudioDriver;
    class function OpenLive(Driver: TAudioDriver; SampleRate, Channels: integer;
                            Format: TAudioSampleFormat;
                            Callback: TAOCallback; UserData: pointer): TAOStream;
    class procedure EnumerateDrivers;
  end;

implementation

constructor TAOStream.Create;
begin
  inherited Create;
  FSampleRate := 44100;
  FNumChannels := 2;
  FSampleFormat := asfS16_LE;
  FActive := false;
end;

destructor TAOStream.Destroy;
begin
  Close;
  inherited Destroy;
end;

function TAOStream.Open(Device: integer): boolean;
begin
  Result := false;
end;

function TAOStream.Close: boolean;
begin
  FActive := false;
  Result := true;
end;

function TAOStream.Play(Buffer: pointer; Size: integer): integer;
begin
  Result := 0;
end;

function TAOStream.Wait: boolean;
begin
  Result := true;
end;

class constructor TAO.Create;
begin
  FDrivers := TList.Create;
end;

class destructor TAO.Destroy;
begin
  FDrivers.Free;
end;

class function TAO.Initialize: boolean;
begin
  Result := true;
end;

class function TAO.Shutdown: boolean;
begin
  Result := true;
end;

class function TAO.DefaultDriver: TAudioDriver;
begin
  Result := adNone;
end;

class function TAO.OpenLive(Driver: TAudioDriver; SampleRate, Channels: integer;
                            Format: TAudioSampleFormat;
                            Callback: TAOCallback; UserData: pointer): TAOStream;
begin
  Result := nil;
end;

class procedure TAO.EnumerateDrivers;
begin

end;

end.
