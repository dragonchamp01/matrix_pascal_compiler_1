unit JSON.Reader;
{$mode objfpc}{$H+}
interface
uses System, Classes, SysUtils;
type
  TJSONTokenKind = (jtNull, jtTrue, jtFalse, jtNumber, jtString, jtArrayStart, jtArrayEnd, jtObjectStart, jtObjectEnd, jtComma, jtColon);
  TJSONToken = record
    Kind: TJSONTokenKind;
    Value: string;
  end;
  TJSONReader = class
  private
    FStream: TStream;
    FToken: TJSONToken;
  public
    constructor Create(AStream: TStream);
    function read: boolean;
    function Skip: boolean;
    property Token: TJSONToken read FToken;
  end;
implementation
end.
