{
  Matrix Pascal - An Object Pascal Compiler
  Copyright (c) 2026 Marco Hagenaars
  SPDX-License-Identifier: MIT
  Licensed under the MIT License. See LICENSE file for details.
  See LICENSE file in the project root for full license terms.
}

{
  Matrix Pascal RTL — Low-level SQLite3 bindings (port of sqlite3_wrapper.c)
  Thin Pascal wrappers around the SQLite3 C API for compiler-generated code.
}

unit sqlite3_low;

{$mode objfpc}{$H+}
{$includelib sqlite3}

interface

uses
  ctypes;

type
  sqlite3 = pointer;
  sqlite3_stmt = pointer;
  sqlite3_callback = function(arg: pointer; argc: integer; argv: PPChar; colNames: PPChar): integer; cdecl;
  sqlite3_destructor = procedure(ptr: pointer); cdecl;

{ Connection }
function _SQLite3_Open(filename: pchar; var db: pointer): integer; cdecl; external 'sqlite3' name 'sqlite3_open';
function _SQLite3_Close(db: pointer): integer; cdecl; external 'sqlite3' name 'sqlite3_close';
function _SQLite3_ErrCode(db: pointer): integer; cdecl; external 'sqlite3' name 'sqlite3_errcode';
function _SQLite3_ErrMsg(db: pointer): pchar; cdecl; external 'sqlite3' name 'sqlite3_errmsg';

{ Execution }
function _SQLite3_Exec(db: pointer; sql: pchar; callback: sqlite3_callback; arg: pointer; errmsg: PPChar): integer; cdecl; external 'sqlite3' name 'sqlite3_exec';
function _SQLite3_Exec_NoCallback(db: pointer; sql: pchar; errmsg: PPChar): integer; cdecl;

{ Prepared statements }
function _SQLite3_Prepare(db: pointer; sql: pchar; sqlLen: integer; var stmt: pointer; var tail: pchar): integer; cdecl; external 'sqlite3' name 'sqlite3_prepare_v2';
function _SQLite3_Step(stmt: pointer): integer; cdecl; external 'sqlite3' name 'sqlite3_step';
function _SQLite3_Finalize(stmt: pointer): integer; cdecl; external 'sqlite3' name 'sqlite3_finalize';
function _SQLite3_Reset(stmt: pointer): integer; cdecl; external 'sqlite3' name 'sqlite3_reset';
function _SQLite3_ClearBindings(stmt: pointer): integer; cdecl; external 'sqlite3' name 'sqlite3_clear_bindings';

{ Column access }
function _SQLite3_ColumnCount(stmt: pointer): integer; cdecl; external 'sqlite3' name 'sqlite3_column_count';
function _SQLite3_ColumnType(stmt: pointer; col: integer): integer; cdecl; external 'sqlite3' name 'sqlite3_column_type';
function _SQLite3_ColumnText(stmt: pointer; col: integer): pchar; cdecl; external 'sqlite3' name 'sqlite3_column_text';
function _SQLite3_ColumnInt(stmt: pointer; col: integer): integer; cdecl; external 'sqlite3' name 'sqlite3_column_int';
function _SQLite3_ColumnInt64(stmt: pointer; col: integer): int64; cdecl; external 'sqlite3' name 'sqlite3_column_int64';
function _SQLite3_ColumnDouble(stmt: pointer; col: integer): double; cdecl; external 'sqlite3' name 'sqlite3_column_double';
function _SQLite3_ColumnName(stmt: pointer; col: integer): pchar; cdecl; external 'sqlite3' name 'sqlite3_column_name';
function _SQLite3_ColumnDeclType(stmt: pointer; col: integer): pchar; cdecl; external 'sqlite3' name 'sqlite3_column_decltype';
function _SQLite3_ColumnBytes(stmt: pointer; col: integer): integer; cdecl; external 'sqlite3' name 'sqlite3_column_bytes';

{ Binding parameters }
function _SQLite3_BindInt(stmt: pointer; idx: integer; val: integer): integer; cdecl; external 'sqlite3' name 'sqlite3_bind_int';
function _SQLite3_BindInt64(stmt: pointer; idx: integer; val: int64): integer; cdecl; external 'sqlite3' name 'sqlite3_bind_int64';
function _SQLite3_BindDouble(stmt: pointer; idx: integer; val: double): integer; cdecl; external 'sqlite3' name 'sqlite3_bind_double';
function _SQLite3_BindText(stmt: pointer; idx: integer; val: pchar; len: integer; destructor: sqlite3_destructor): integer; cdecl; external 'sqlite3' name 'sqlite3_bind_text';
function _SQLite3_BindNull(stmt: pointer; idx: integer): integer; cdecl; external 'sqlite3' name 'sqlite3_bind_null';

{ Misc }
function _SQLite3_LastInsertRowid(db: pointer): int64; cdecl; external 'sqlite3' name 'sqlite3_last_insert_rowid';
function _SQLite3_Changes(db: pointer): integer; cdecl; external 'sqlite3' name 'sqlite3_changes';
function _SQLite3_TotalChanges(db: pointer): integer; cdecl; external 'sqlite3' name 'sqlite3_total_changes';
function _SQLite3_LibVersion: pchar; cdecl; external 'sqlite3' name 'sqlite3_libversion';
function _SQLite3_LibVersionNumber: integer; cdecl; external 'sqlite3' name 'sqlite3_libversion_number';

implementation

function _SQLite3_Exec_NoCallback(db: pointer; sql: pchar; errmsg: PPChar): integer; cdecl;
begin
  Result := _SQLite3_Exec(db, sql, nil, nil, errmsg);
end;

end.