{
   Matrix Pascal - Statistics Unit
   ════════════════════════════════════════════════════════════════
   Descriptive statistics, probability distributions,
   hypothesis testing, regression, random sampling

   Nederlands: Beschrijvende statistiek, kansverdelingen,
   hypothesetoetsen, regressie, random sampling.

   English: Descriptive statistics, probability distributions,
   hypothesis testing, regression, random sampling.

   Copyright (c) 2026 Marco Hagenaars
}
unit statistics;

interface

uses System, Classes, SysUtils, math;

type
  { █████████████████████████████████████████████████████████████
    TStatistics — Beschrijvende statistiek }
  TStatistics = class
  public
    { Centrale tendens / Central tendency }
    class function Mean(const Data: array of double): double;
    class function Median(const Data: array of double): double;
    class function Mode(const Data: array of double): TArray<double>;
    class function GeometricMean(const Data: array of double): double;
    class function HarmonicMean(const Data: array of double): double;
    class function TrimmedMean(const Data: array of double; TrimPercent: double): double;

    { Spreiding / Dispersion }
    class function Variance(const Data: array of double; Population: boolean = false): double;
    class function StdDev(const Data: array of double; Population: boolean = false): double;
    class function Range(const Data: array of double): double;
    class function IQR(const Data: array of double): double;
    class function MAD(const Data: array of double): double;  { Mean absolute deviation }
    class function CV(const Data: array of double): double;   { Coefficient of variation }

    { Positie / Position }
    class function Min(const Data: array of double): double;
    class function Max(const Data: array of double): double;
    class function Percentile(const Data: array of double; P: double): double;
    class function Quartile1(const Data: array of double): double;
    class function Quartile3(const Data: array of double): double;

    { Vorm / Shape }
    class function Skewness(const Data: array of double): double;
    class function Kurtosis(const Data: array of double): double;

    { Correlatie / Correlation }
    class function Covariance(const X, Y: array of double): double;
    class function Correlation(const X, Y: array of double): double;
    class function SpearmanRank(const X, Y: array of double): double;

    { Regressie / Regression }
    class function LinearRegression(const X, Y: array of double; out Slope, Intercept, R2: double): boolean;
    class function PolynomialRegression(const X, Y: array of double; Degree: integer;
      out Coefficients: TArray<double>): boolean;
  end;

  { █████████████████████████████████████████████████████████████
    TDistribution — Kansverdelingen }
  TDistribution = class
  public
    { Normaal / Normal }
    class function NormalPDF(X, Mean, StdDev: double): double;
    class function NormalCDF(X, Mean, StdDev: double): double;
    class function NormalInv(P, Mean, StdDev: double): double;

    { Uniform }
    class function UniformPDF(X, A, B: double): double;
    class function UniformCDF(X, A, B: double): double;

    { Student's t }
    class function TPDF(X: double; DF: integer): double;
    class function TCDF(X: double; DF: integer): double;
    class function TInv(P: double; DF: integer): double;

    { Chi-kwadraat / Chi-square }
    class function ChiSquarePDF(X: double; DF: integer): double;
    class function ChiSquareCDF(X: double; DF: integer): double;
    class function ChiSquareInv(P: double; DF: integer): double;

    { F-verdeling / F-distribution }
    class function FPDF(X: double; DF1, DF2: integer): double;
    class function FCDF(X: double; DF1, DF2: integer): double;

    { Binomiaal / Binomial }
    class function BinomialPMF(K, N: integer; P: double): double;
    class function BinomialCDF(K, N: integer; P: double): double;

    { Poisson }
    class function PoissonPMF(K: integer; Lambda: double): double;
    class function PoissonCDF(K: integer; Lambda: double): double;

    { Exponentieel / Exponential }
    class function ExponentialPDF(X, Rate: double): double;
    class function ExponentialCDF(X, Rate: double): double;

    { Beta }
    class function BetaPDF(X, Alpha, Beta: double): double;
  end;

  { █████████████████████████████████████████████████████████████
    THypothesisTest — Hypothesetoetsen }
  THypothesisTest = class
  public
    { T-test }
    class function OneSampleT(const Data: array of double; Mu: double;
      out TStat, PValue: double; Alpha: double = 0.05): boolean;
    class function TwoSampleT(const X, Y: array of double;
      out TStat, PValue: double; Alpha: double = 0.05): boolean;
    class function PairedT(const X, Y: array of double;
      out TStat, PValue: double; Alpha: double = 0.05): boolean;

    { Z-test }
    class function ZTest(const Data: array of double; Mu, Sigma: double;
      out ZStat, PValue: double): boolean;

    { Chi-kwadraat / Chi-square }
    class function ChiSquareTest(const Observed, Expected: array of double;
      out Chi2, PValue: double; Alpha: double = 0.05): boolean;

    { ANOVA }
    class function OneWayANOVA(const Groups: array of TArray<double>;
      out FStat, PValue: double): boolean;

    { Mann-Whitney U }
    class function MannWhitneyU(const X, Y: array of double;
      out UStat, PValue: double): boolean;

    { Kolmogorov-Smirnov }
    class function KSTest(const Data: array of double; Dist: string;
      out DStat, PValue: double): boolean;
  end;

  { █████████████████████████████████████████████████████████████
    TRandomSampling — Random sampling methods }
  TRandomSampling = class
  public
    class function Sample(const Population: array of double; SampleSize: integer): TArray<double>;
    class function Bootstrap(const Data: array of double; NSamples: integer;
      StatFunc: TFunc<TArray<double>, double>): TArray<double>;
    class function StratifiedSample(const Population: array of double;
      const Strata: array of integer; SampleSize: integer): TArray<double>;
    class function SystematicSample(const Population: array of double;
      SampleSize: integer): TArray<double>;
  end;

implementation

{ Utility functions }

function SortCopy(const Data: array of double): TArray<double>;
var
  I: integer;
begin
  SetLength(Result, Length(Data));
  for I := 0 to Length(Data) - 1 do Result[I] := Data[I];
  // Simple bubble sort - replace with quicksort in production
  for I := 0 to Length(Result) - 2 do
    for var J := I + 1 to Length(Result) - 1 do
      if Result[I] > Result[J] then
      begin
        var T := Result[I]; Result[I] := Result[J]; Result[J] := T;
      end;
end;

function SumArray(const Data: array of double): double;
var
  I: integer;
begin
  Result := 0;
  for I := 0 to Length(Data) - 1 do Result := Result + Data[I];
end;

function Fact(N: integer): double;
var
  I: integer;
begin
  Result := 1;
  for I := 2 to N do Result := Result * I;
end;

function Binom(N, K: integer): double;
begin
  if (K < 0) or (K > N) then exit(0);
  Result := Fact(N) / (Fact(K) * Fact(N - K));
end;

{ TStatistics }

class function TStatistics.Mean(const Data: array of double): double;
begin
  if Length(Data) = 0 then exit(0);
  Result := SumArray(Data) / Length(Data);
end;

class function TStatistics.Median(const Data: array of double): double;
var
  Sorted: TArray<double>;
  N: integer;
begin
  N := Length(Data);
  if N = 0 then exit(0);
  Sorted := SortCopy(Data);
  if N mod 2 = 1 then
    Result := Sorted[N div 2]
  else
    Result := (Sorted[N div 2 - 1] + Sorted[N div 2]) / 2;
end;

class function TStatistics.Mode(const Data: array of double): TArray<double>;
var
  Counts: THashMap;
  I: integer;
  MaxCount: integer;
  Key: string;
  Val: string;
begin
  Result := [];
  if Length(Data) = 0 then exit;
  Counts := THashMap.Create;
  try
    MaxCount := 0;
    for I := 0 to Length(Data) - 1 do
    begin
      Key := FloatToStr(Data[I]);
      if Counts.contains(Key) then
        Counts.Put(Key, IntToStr(StrToInt(Counts.GetDef(Key, '0')) + 1))
      else
        Counts.Put(Key, '1');
    end;
    for I := 0 to Counts.Count - 1 do
    begin
      Val := Counts.GetDef(Key, '0');
      if StrToInt(Val) > MaxCount then MaxCount := StrToInt(Val);
    end;
    SetLength(Result, 0);
    for I := 0 to Counts.Count - 1 do
      if StrToInt(Counts.GetDef(Key, '0')) = MaxCount then
      begin
        SetLength(Result, Length(Result) + 1);
        Result[Length(Result) - 1] := StrToFloat(Key);
      end;
  finally
    Counts.Free;
  end;
end;

class function TStatistics.GeometricMean(const Data: array of double): double;
var
  I: integer;
  P: double;
begin
  if Length(Data) = 0 then exit(0);
  P := 1;
  for I := 0 to Length(Data) - 1 do P := P * Data[I];
  Result := Power(P, 1 / Length(Data));
end;

class function TStatistics.HarmonicMean(const Data: array of double): double;
var
  I: integer;
  S: double;
begin
  if Length(Data) = 0 then exit(0);
  S := 0;
  for I := 0 to Length(Data) - 1 do
    if Data[I] <> 0 then S := S + 1 / Data[I];
  if S = 0 then exit(0);
  Result := Length(Data) / S;
end;

class function TStatistics.TrimmedMean(const Data: array of double; TrimPercent: double): double;
var
  Sorted: TArray<double>;
  N, TrimCount: integer;
  Sum: double;
  I: integer;
begin
  N := Length(Data);
  TrimCount := Round(N * TrimPercent / 100);
  if TrimCount * 2 >= N then exit(0);
  Sorted := SortCopy(Data);
  Sum := 0;
  for I := TrimCount to N - TrimCount - 1 do Sum := Sum + Sorted[I];
  Result := Sum / (N - 2 * TrimCount);
end;

class function TStatistics.Variance(const Data: array of double; Population: boolean = false): double;
var
  M: double;
  I: integer;
  N: integer;
begin
  N := Length(Data);
  if N < 2 then exit(0);
  M := Mean(Data);
  Result := 0;
  for I := 0 to N - 1 do Result := Result + Sqr(Data[I] - M);
  if Population then
    Result := Result / N
  else
    Result := Result / (N - 1);
end;

class function TStatistics.StdDev(const Data: array of double; Population: boolean = false): double;
begin
  Result := Sqrt(Variance(Data, Population));
end;

class function TStatistics.Range(const Data: array of double): double;
begin
  if Length(Data) = 0 then exit(0);
  Result := Max(Data) - Min(Data);
end;

class function TStatistics.IQR(const Data: array of double): double;
begin
  Result := Quartile3(Data) - Quartile1(Data);
end;

class function TStatistics.MAD(const Data: array of double): double;
var
  M: double;
  I: integer;
begin
  M := Median(Data);
  Result := 0;
  for I := 0 to Length(Data) - 1 do Result := Result + Abs(Data[I] - M);
  Result := Result / Length(Data);
end;

class function TStatistics.CV(const Data: array of double): double;
begin
  Result := StdDev(Data, false) / Mean(Data);
end;

class function TStatistics.Min(const Data: array of double): double;
var
  I: integer;
begin
  if Length(Data) = 0 then exit(0);
  Result := Data[0];
  for I := 1 to Length(Data) - 1 do
    if Data[I] < Result then Result := Data[I];
end;

class function TStatistics.Max(const Data: array of double): double;
var
  I: integer;
begin
  if Length(Data) = 0 then exit(0);
  Result := Data[0];
  for I := 1 to Length(Data) - 1 do
    if Data[I] > Result then Result := Data[I];
end;

class function TStatistics.Percentile(const Data: array of double; P: double): double;
var
  Sorted: TArray<double>;
  N: integer;
  Idx: double;
begin
  N := Length(Data);
  if N = 0 then exit(0);
  Sorted := SortCopy(Data);
  Idx := (P / 100) * (N - 1);
  if Idx = Trunc(Idx) then
    Result := Sorted[Trunc(Idx)]
  else
    Result := Sorted[Trunc(Idx)] + (Idx - Trunc(Idx)) * (Sorted[Trunc(Idx) + 1] - Sorted[Trunc(Idx)]);
end;

class function TStatistics.Quartile1(const Data: array of double): double;
begin
  Result := Percentile(Data, 25);
end;

class function TStatistics.Quartile3(const Data: array of double): double;
begin
  Result := Percentile(Data, 75);
end;

class function TStatistics.Skewness(const Data: array of double): double;
var
  M, S: double;
  I: integer;
  N: double;
begin
  N := Length(Data);
  if N < 3 then exit(0);
  M := Mean(Data);
  S := StdDev(Data, true);
  if S = 0 then exit(0);
  Result := 0;
  for I := 0 to Length(Data) - 1 do Result := Result + Power((Data[I] - M) / S, 3);
  Result := Result * N / ((N - 1) * (N - 2));
end;

class function TStatistics.Kurtosis(const Data: array of double): double;
var
  M, S: double;
  I: integer;
  N: double;
begin
  N := Length(Data);
  if N < 4 then exit(0);
  M := Mean(Data);
  S := StdDev(Data, true);
  if S = 0 then exit(0);
  Result := 0;
  for I := 0 to Length(Data) - 1 do Result := Result + Power((Data[I] - M) / S, 4);
  Result := Result * N * (N + 1) / ((N - 1) * (N - 2) * (N - 3));
  Result := Result - 3 * Sqr(N - 1) / ((N - 2) * (N - 3));
end;

class function TStatistics.Covariance(const X, Y: array of double): double;
var
  MX, MY: double;
  I: integer;
begin
  if (Length(X) <> Length(Y)) or (Length(X) < 2) then exit(0);
  MX := Mean(X);
  MY := Mean(Y);
  Result := 0;
  for I := 0 to Length(X) - 1 do Result := Result + (X[I] - MX) * (Y[I] - MY);
  Result := Result / (Length(X) - 1);
end;

class function TStatistics.Correlation(const X, Y: array of double): double;
var
  SX, SY: double;
begin
  SX := StdDev(X, false);
  SY := StdDev(Y, false);
  if (SX = 0) or (SY = 0) then exit(0);
  Result := Covariance(X, Y) / (SX * SY);
end;

class function TStatistics.SpearmanRank(const X, Y: array of double): double;
var
  RX, RY: TArray<double>;
  I, J: integer;
  D2: double;
begin
  if Length(X) <> Length(Y) then exit(0);
  SetLength(RX, Length(X));
  SetLength(RY, Length(Y));
  for I := 0 to Length(X) - 1 do
  begin
    RX[I] := 1; RY[I] := 1;
    for J := 0 to Length(X) - 1 do
    begin
      if X[J] < X[I] then RX[I] := RX[I] + 1;
      if Y[J] < Y[I] then RY[I] := RY[I] + 1;
    end;
  end;
  D2 := 0;
  for I := 0 to Length(X) - 1 do D2 := D2 + Sqr(RX[I] - RY[I]);
  Result := 1 - 6 * D2 / (Length(X) * (Sqr(Length(X)) - 1));
end;

class function TStatistics.LinearRegression(const X, Y: array of double;
  out Slope, Intercept, R2: double): boolean;
var
  SXX, SXY, MX, MY: double;
  I: integer;
begin
  if Length(X) <> Length(Y) then exit(false);
  if Length(X) < 2 then exit(false);
  MX := Mean(X);
  MY := Mean(Y);
  SXX := 0; SXY := 0;
  for I := 0 to Length(X) - 1 do
  begin
    SXX := SXX + Sqr(X[I] - MX);
    SXY := SXY + (X[I] - MX) * (Y[I] - MY);
  end;
  if SXX = 0 then exit(false);
  Slope := SXY / SXX;
  Intercept := MY - Slope * MX;
  R2 := Sqr(Correlation(X, Y));
  Result := true;
end;

class function TStatistics.PolynomialRegression(const X, Y: array of double;
  Degree: integer; out Coefficients: TArray<double>): boolean;
begin
  { In productie: gebruik normale vergelijking (X^T X)^{-1} X^T Y }
  SetLength(Coefficients, Degree + 1);
  Coefficients[0] := Mean(Y);
  if Degree >= 1 then Coefficients[1] := Correlation(X, Y) * StdDev(Y, false) / StdDev(X, false);
  for var I := 2 to Degree do Coefficients[I] := 0;
  Result := true;
end;

{ TDistribution }

class function TDistribution.NormalPDF(X, Mean, StdDev: double): double;
begin
  if StdDev <= 0 then exit(0);
  Result := Exp(-0.5 * Sqr((X - Mean) / StdDev)) / (StdDev * Sqrt(2 * Pi));
end;

class function TDistribution.NormalCDF(X, Mean, StdDev: double): double;
begin
  Result := 0.5 * (1 + Erf((X - Mean) / (StdDev * Sqrt(2))));
end;

class function TDistribution.NormalInv(P, Mean, StdDev: double): double;
var
  T: double;
begin
  if (P <= 0) or (P >= 1) then exit(0);
  T := Sqrt(-2 * Ln(1 - P));
  Result := Mean + StdDev * (T - (2.515517 + 0.802853 * T + 0.010328 * T * T) /
    (1 + 1.432788 * T + 0.189269 * T * T + 0.001308 * T * T * T));
end;

class function TDistribution.UniformPDF(X, A, B: double): double;
begin
  if (X >= A) and (X <= B) then Result := 1 / (B - A)
  else Result := 0;
end;

class function TDistribution.UniformCDF(X, A, B: double): double;
begin
  if X < A then Result := 0
  else if X > B then Result := 1
  else Result := (X - A) / (B - A);
end;

class function TDistribution.TPDF(X: double; DF: integer): double;
begin
  Result := Math.Gamma((DF + 1) / 2) / (Sqrt(DF * Pi) * Math.Gamma(DF / 2)) *
    Power(1 + X * X / DF, -(DF + 1) / 2);
end;

class function TDistribution.TCDF(X: double; DF: integer): double;
begin
  { Vereenvoudigde benadering }
  Result := NormalCDF(X, 0, 1);
end;

class function TDistribution.TInv(P: double; DF: integer): double;
begin
  Result := NormalInv(P, 0, 1);
end;

class function TDistribution.ChiSquarePDF(X: double; DF: integer): double;
begin
  if X <= 0 then exit(0);
  Result := Power(X, DF / 2 - 1) * Exp(-X / 2) /
    (Power(2, DF / 2) * Math.Gamma(DF / 2));
end;

class function TDistribution.ChiSquareCDF(X: double; DF: integer): double;
begin
  { Vereenvoudigde benadering }
  if X <= 0 then exit(0);
  Result := 1 - Exp(-X / 2);
  for var I := 1 to DF div 2 - 1 do
    Result := Result - Power(X / 2, I) * Exp(-X / 2) / Fact(I);
end;

class function TDistribution.ChiSquareInv(P: double; DF: integer): double;
begin
  Result := 2 * DF * (1 - 2 / (9 * DF) + NormalInv(P, 0, 1) * Sqrt(2 / (9 * DF)));
end;

class function TDistribution.FPDF(X: double; DF1, DF2: integer): double;
begin
  if X <= 0 then exit(0);
  Result := Sqrt(Power(DF1 * X, DF1) * Power(DF2, DF2) / Power(DF1 * X + DF2, DF1 + DF2)) /
    (X * Math.Beta(DF1 / 2, DF2 / 2));
end;

class function TDistribution.FCDF(X: double; DF1, DF2: integer): double;
begin
  Result := NormalCDF(X, 1, Sqrt(2 / DF1 + 2 / DF2));
end;

class function TDistribution.BinomialPMF(K, N: integer; P: double): double;
begin
  if (K < 0) or (K > N) then exit(0);
  Result := Binom(N, K) * Power(P, K) * Power(1 - P, N - K);
end;

class function TDistribution.BinomialCDF(K, N: integer; P: double): double;
begin
  Result := 0;
  for var I := 0 to K do Result := Result + BinomialPMF(I, N, P);
end;

class function TDistribution.PoissonPMF(K: integer; Lambda: double): double;
begin
  if K < 0 then exit(0);
  Result := Exp(-Lambda) * Power(Lambda, K) / Fact(K);
end;

class function TDistribution.PoissonCDF(K: integer; Lambda: double): double;
begin
  Result := 0;
  for var I := 0 to K do Result := Result + PoissonPMF(I, Lambda);
end;

class function TDistribution.ExponentialPDF(X, Rate: double): double;
begin
  if X < 0 then exit(0);
  Result := Rate * Exp(-Rate * X);
end;

class function TDistribution.ExponentialCDF(X, Rate: double): double;
begin
  if X < 0 then Result := 0
  else Result := 1 - Exp(-Rate * X);
end;

class function TDistribution.BetaPDF(X, Alpha, Beta: double): double;
begin
  if (X <= 0) or (X >= 1) then exit(0);
  Result := Power(X, Alpha - 1) * Power(1 - X, Beta - 1) / Math.Beta(Alpha, Beta);
end;

{ THypothesisTest }

class function THypothesisTest.OneSampleT(const Data: array of double; Mu: double;
  out TStat, PValue: double; Alpha: double = 0.05): boolean;
var
  M, S, SE: double;
  N: integer;
begin
  N := Length(Data);
  if N < 2 then exit(false);
  M := TStatistics.Mean(Data);
  S := TStatistics.StdDev(Data, false);
  SE := S / Sqrt(N);
  if SE = 0 then exit(false);
  TStat := (M - Mu) / SE;
  PValue := 2 * (1 - TDistribution.TCDF(Abs(TStat), N - 1));
  Result := PValue < Alpha;
end;

class function THypothesisTest.TwoSampleT(const X, Y: array of double;
  out TStat, PValue: double; Alpha: double = 0.05): boolean;
var
  M1, M2, S1, S2, SE: double;
  N1, N2, DF: integer;
begin
  N1 := Length(X); N2 := Length(Y);
  if (N1 < 2) or (N2 < 2) then exit(false);
  M1 := TStatistics.Mean(X); M2 := TStatistics.Mean(Y);
  S1 := TStatistics.Variance(X, false); S2 := TStatistics.Variance(Y, false);
  SE := Sqrt(S1 / N1 + S2 / N2);
  if SE = 0 then exit(false);
  TStat := (M1 - M2) / SE;
  DF := Round(Sqr(S1 / N1 + S2 / N2) / (Sqr(S1 / N1) / (N1 - 1) + Sqr(S2 / N2) / (N2 - 1)));
  PValue := 2 * (1 - TDistribution.TCDF(Abs(TStat), DF));
  Result := PValue < Alpha;
end;

class function THypothesisTest.PairedT(const X, Y: array of double;
  out TStat, PValue: double; Alpha: double = 0.05): boolean;
var
  Diffs: TArray<double>;
  I: integer;
begin
  if Length(X) <> Length(Y) then exit(false);
  SetLength(Diffs, Length(X));
  for I := 0 to Length(X) - 1 do Diffs[I] := X[I] - Y[I];
  Result := OneSampleT(Diffs, 0, TStat, PValue, Alpha);
end;

class function THypothesisTest.ZTest(const Data: array of double; Mu, Sigma: double;
  out ZStat, PValue: double): boolean;
var
  M, SE: double;
begin
  if Length(Data) < 1 then exit(false);
  M := TStatistics.Mean(Data);
  SE := Sigma / Sqrt(Length(Data));
  if SE = 0 then exit(false);
  ZStat := (M - Mu) / SE;
  PValue := 2 * (1 - TDistribution.NormalCDF(Abs(ZStat), 0, 1));
  Result := true;
end;

class function THypothesisTest.ChiSquareTest(const Observed, Expected: array of double;
  out Chi2, PValue: double; Alpha: double = 0.05): boolean;
var
  I: integer;
begin
  if Length(Observed) <> Length(Expected) then exit(false);
  Chi2 := 0;
  for I := 0 to Length(Observed) - 1 do
    if Expected[I] > 0 then
      Chi2 := Chi2 + Sqr(Observed[I] - Expected[I]) / Expected[I];
  PValue := 1 - TDistribution.ChiSquareCDF(Chi2, Length(Observed) - 1);
  Result := PValue < Alpha;
end;

class function THypothesisTest.OneWayANOVA(const Groups: array of TArray<double>;
  out FStat, PValue: double): boolean;
var
  AllMeans: TArray<double>;
  GrandMean, SSB, SSW: double;
  I, J, K, N, DF1, DF2: integer;
begin
  K := Length(Groups);
  if K < 2 then exit(false);
  SetLength(AllMeans, K);
  N := 0;
  GrandMean := 0;
  for I := 0 to K - 1 do
  begin
    AllMeans[I] := TStatistics.Mean(Groups[I]);
    GrandMean := GrandMean + AllMeans[I] * Length(Groups[I]);
    N := N + Length(Groups[I]);
  end;
  GrandMean := GrandMean / N;
  SSB := 0; SSW := 0;
  for I := 0 to K - 1 do
  begin
    SSB := SSB + Length(Groups[I]) * Sqr(AllMeans[I] - GrandMean);
    for J := 0 to Length(Groups[I]) - 1 do
      SSW := SSW + Sqr(Groups[I][J] - AllMeans[I]);
  end;
  DF1 := K - 1;
  DF2 := N - K;
  if (DF1 <= 0) or (DF2 <= 0) then exit(false);
  FStat := (SSB / DF1) / (SSW / DF2);
  PValue := 1 - TDistribution.FCDF(FStat, DF1, DF2);
  Result := true;
end;

class function THypothesisTest.MannWhitneyU(const X, Y: array of double;
  out UStat, PValue: double): boolean;
var
  Combined: TArray<double>;
  Ranks: TArray<double>;
  I, J, N1, N2: integer;
  R1: double;
begin
  N1 := Length(X); N2 := Length(Y);
  SetLength(Combined, N1 + N2);
  for I := 0 to N1 - 1 do Combined[I] := X[I];
  for I := 0 to N2 - 1 do Combined[N1 + I] := Y[I];
  SetLength(Ranks, N1 + N2);
  for I := 0 to N1 + N2 - 1 do
  begin
    Ranks[I] := 1;
    for J := 0 to N1 + N2 - 1 do
      if Combined[J] < Combined[I] then Ranks[I] := Ranks[I] + 1;
  end;
  R1 := 0;
  for I := 0 to N1 - 1 do R1 := R1 + Ranks[I];
  UStat := N1 * N2 + N1 * (N1 + 1) / 2 - R1;
  PValue := 2 * TDistribution.NormalCDF(-Abs(UStat - N1 * N2 / 2) / Sqrt(N1 * N2 * (N1 + N2 + 1) / 12), 0, 1);
  Result := true;
end;

class function THypothesisTest.KSTest(const Data: array of double; Dist: string;
  out DStat, PValue: double): boolean;
var
  Sorted: TArray<double>;
  I, N: integer;
  DPlus, DMinus, D: double;
  ECDF, CCDF: double;
begin
  N := Length(Data);
  if N < 2 then exit(false);
  Sorted := SortCopy(Data);
  DPlus := 0; DMinus := 0;
  for I := 0 to N - 1 do
  begin
    ECDF := (I + 1) / N;
    CCDF := TDistribution.NormalCDF(Sorted[I], TStatistics.Mean(Data), TStatistics.StdDev(Data, true));
    D := Abs(ECDF - CCDF);
    if D > DPlus then DPlus := D;
    D := Abs(CCDF - (I) / N);
    if D > DMinus then DMinus := D;
  end;
  DStat := Max(DPlus, DMinus);
  PValue := 2 * Exp(-2 * Sqr(DStat) * N);
  Result := true;
end;

{ TRandomSampling }

class function TRandomSampling.Sample(const Population: array of double; SampleSize: integer): TArray<double>;
var
  Idx: TArray<integer>;
  I, J, R: integer;
begin
  if SampleSize > Length(Population) then SampleSize := Length(Population);
  SetLength(Idx, Length(Population));
  for I := 0 to Length(Population) - 1 do Idx[I] := I;
  for I := 0 to SampleSize - 1 do
  begin
    R := Random(Length(Population) - I) + I;
    J := Idx[I]; Idx[I] := Idx[R]; Idx[R] := J;
  end;
  SetLength(Result, SampleSize);
  for I := 0 to SampleSize - 1 do Result[I] := Population[Idx[I]];
end;

class function TRandomSampling.Bootstrap(const Data: array of double; NSamples: integer;
  StatFunc: TFunc<TArray<double>, double>): TArray<double>;
var
  Sample: TArray<double>;
  I, J: integer;
  N: integer;
begin
  N := Length(Data);
  SetLength(Result, NSamples);
  SetLength(Sample, N);
  for I := 0 to NSamples - 1 do
  begin
    for J := 0 to N - 1 do
      Sample[J] := Data[Random(N)];
    Result[I] := StatFunc(Sample);
  end;
end;

class function TRandomSampling.StratifiedSample(const Population: array of double;
  const Strata: array of integer; SampleSize: integer): TArray<double>;
begin
  { In productie: sample per stratum proportioneel }
  Result := Sample(Population, SampleSize);
end;

class function TRandomSampling.SystematicSample(const Population: array of double;
  SampleSize: integer): TArray<double>;
var
  K, I: integer;
begin
  if SampleSize >= Length(Population) then exit(Sample(Population, SampleSize));
  K := Length(Population) div SampleSize;
  SetLength(Result, SampleSize);
  for I := 0 to SampleSize - 1 do
    Result[I] := Population[I * K + Random(K)];
end;

end.
