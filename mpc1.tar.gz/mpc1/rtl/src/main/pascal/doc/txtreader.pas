unit txtreader;
{$mode objfpc}{$H+}
interface
uses System, Classes, SysUtils;
type
  TTextEncoding = (teUnknown, teUTF8, teUTF16BE, teUTF16LE, teLatin1, teWindows1252, teASCII, teShiftJIS);
  TEncodingDetection = (edAuto, edForceUTF8, edForceLatin1, edForceASCII);
  TTxtReader = class
  private
    FFileName: string;
    FLines: TStringList;
    FEncoding: TTextEncoding;
    FEncodingDetection: TEncodingDetection;
    FBOMFound: boolean;
    FTotalLines: integer;
  public
    constructor Create;
    destructor Destroy; override;
    procedure LoadFromFile(const AFileName: string);
    procedure LoadFromStream(AStream: TStream);
    function ReadAll: string;
    function ReadLine(LineNum: integer): string;
    function ReadLines(StartLine, Count: integer): TStrings;
    function DetectEncoding: TTextEncoding;
    function GetBOMSize: integer;
    class function ConvertEncoding(const S: string; FromEnc, ToEnc: TTextEncoding): string;
    property Lines: TStringList read FLines;
    property Encoding: TTextEncoding read FEncoding;
    property BOMFound: boolean read FBOMFound;
    property TotalLines: integer read FTotalLines;
    property EncodingDetection: TEncodingDetection read FEncodingDetection write FEncodingDetection;
  end;
implementation
constructor TTxtReader.Create;
begin FLines := TStringList.Create; FEncodingDetection := edAuto; FBOMFound := false; end;
destructor TTxtReader.Destroy;
begin FLines.Free; inherited; end;
procedure TTxtReader.LoadFromFile(const AFileName: string);
begin FFileName := AFileName; end;
procedure TTxtReader.LoadFromStream(AStream: TStream);
begin end;
function TTxtReader.ReadAll: string;
var I: integer;
begin
  Result := '';
  for I := 0 to FLines.Count - 1 do
  begin
    if I > 0 then Result := Result + sLineBreak;
    Result := Result + FLines[I];
  end;
end;
function TTxtReader.ReadLine(LineNum: integer): string;
begin if (LineNum >= 0) and (LineNum < FLines.Count) then Result := FLines[LineNum] else Result := ''; end;
function TTxtReader.ReadLines(StartLine, Count: integer): TStrings;
begin Result := TStringList.Create; end;
function TTxtReader.DetectEncoding: TTextEncoding;
begin Result := teUTF8; end;
function TTxtReader.GetBOMSize: integer;
begin Result := 0; end;
class function TTxtReader.ConvertEncoding(const S: string; FromEnc, ToEnc: TTextEncoding): string;
begin Result := S; end;
end.
