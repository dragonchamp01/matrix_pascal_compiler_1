unit markdown2html;
{$mode objfpc}{$H+}
interface
uses System, Classes, SysUtils, markdown;
type
  TMarkdown2HtmlOptions = record
    EnableTables: boolean;
    EnableStrikethrough: boolean;
    EnableTasklists: boolean;
    EnableAutoLinks: boolean;
    HeaderIDs: boolean;
    CodeHighlight: boolean;
  end;
  TMarkdown2Html = class
  private
    FParser: TMarkdownParser;
    FOptions: TMarkdown2HtmlOptions;
  public
    constructor Create;
    destructor Destroy; override;
    function Convert(const Markdown: string): string;
    function ConvertFile(const FileName: string): string;
    function ConvertDocument(Doc: TMarkdownDocument): string;
    class function RenderHTML(const Markdown: string): string;
    property Options: TMarkdown2HtmlOptions read FOptions write FOptions;
  end;
implementation
constructor TMarkdown2Html.Create;
begin FParser := TMarkdownParser.Create;
  FOptions.EnableTables := true; FOptions.EnableStrikethrough := true;
  FOptions.EnableTasklists := true; FOptions.EnableAutoLinks := true;
  FOptions.HeaderIDs := false; FOptions.CodeHighlight := false;
end;
destructor TMarkdown2Html.Destroy;
begin FParser.Free; inherited; end;
function TMarkdown2Html.Convert(const Markdown: string): string;
begin Result := ''; end;
function TMarkdown2Html.ConvertFile(const FileName: string): string;
begin Result := ''; end;
function TMarkdown2Html.ConvertDocument(Doc: TMarkdownDocument): string;
begin Result := ''; end;
class function TMarkdown2Html.RenderHTML(const Markdown: string): string;
begin Result := '<p>' + Markdown + '</p>'; end;
end.
