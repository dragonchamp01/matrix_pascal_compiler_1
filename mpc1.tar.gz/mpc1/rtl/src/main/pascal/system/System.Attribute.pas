unit System.attribute;
{$mode objfpc}{$H+}
interface
uses System;
type
  TAttribute = class
  private
    FName: string;
  public
    constructor Create(const AName: string);
    property name: string read FName;
  end;
  TAttributeClass = class of TAttribute;
  TObsoleteAttribute = class(TAttribute)
  private
    FMessage: string;
  public
    constructor Create(const AMessage: string = '');
    property message: string read FMessage;
  end;
  TSuppressWarningAttribute = class(TAttribute);
  TDllImportAttribute = class(TAttribute);
implementation
end.
