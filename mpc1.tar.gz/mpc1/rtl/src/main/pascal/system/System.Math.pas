unit System.Math;
{$mode objfpc}{$H+}
interface
uses System;
const
  Pi = 3.14159265358979323846;
  E = 2.71828182845904523536;
  Infinity = 1.0 / 0.0;
  NaN = 0.0 / 0.0;
function Abs(const X: double): double;
function Sqrt(const X: double): double;
function Power(const Base, Exp: double): double;
function Exp(const X: double): double;
function Ln(const X: double): double;
function Log10(const X: double): double;
function LogN(const Base, X: double): double;
function Min(const A, B: double): double;
function Max(const A, B: double): double;
function Sign(const X: double): integer;
function Ceil(const X: double): integer;
function Floor(const X: double): integer;
function Round(const X: double): int64;
function Trunc(const X: double): int64;
function Frac(const X: double): double;
function Int(const X: double): double;
implementation
end.
