unit System.Threading;
{$mode objfpc}{$H+}
interface
uses System, Classes, SysUtils;
type
  TThreadState = (tsRunning, tsSuspended, tsTerminated);
  TThreadProc = procedure(Data: pointer);
  TThread = class
  private
    FState: TThreadState;
    FProc: TThreadProc;
    FData: pointer;
    FHandle: pointer;
  public
    constructor Create(AProc: TThreadProc; AData: pointer = nil);
    destructor Destroy; override;
    procedure Start;
    procedure suspend;
    procedure resume;
    procedure Terminate;
    procedure Join;
    property State: TThreadState read FState;
  end;
  function GetCurrentThreadId: longword;
  function GetProcessorCount: integer;
  procedure Sleep(Milliseconds: longword);
  procedure Yield;
implementation
end.
