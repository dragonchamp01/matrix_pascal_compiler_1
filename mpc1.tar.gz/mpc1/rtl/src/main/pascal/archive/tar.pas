{
   Matrix Pascal - Archive: Tar Unit
   ════════════════════════════════════════════════════════════════
   POSIX tar archive creation and extraction

   Copyright (c) 2026 Marco Hagenaars
}
unit tar;

{$mode objfpc}{$H+}

interface

uses System, Classes, SysUtils;

const
  TAR_BLOCK_SIZE = 512;
  TAR_MAGIC = 'ustar';
  TAR_MAGIC_XHD = 'ustar ';

type
  TTarTypeFlag = (
    tarNormal,    { Ordinary file }
    tarHardLink,  { Hard link }
    tarSymLink,   { Symbolic link }
    tarCharDev,   { Character device }
    tarBlockDev,  { Block device }
    tarDirectory, { Directory }
    tarFIFO,      { FIFO/named pipe }
    tarContig     { Contiguous file }
  );

  TTarHeader = packed record
    name: array[0..99] of char;
    Mode: array[0..7] of char;
    UID: array[0..7] of char;
    GID: array[0..7] of char;
    Size: array[0..11] of char;
    MTime: array[0..11] of char;
    Chksum: array[0..7] of char;
    TypeFlag: char;
    LinkName: array[0..99] of char;
    Magic: array[0..5] of char;
    Version: array[0..1] of char;
    Uname: array[0..31] of char;
    Gname: array[0..31] of char;
    DevMajor: array[0..7] of char;
    DevMinor: array[0..7] of char;
    Prefix: array[0..154] of char;
    Padding: array[0..11] of byte;
  end;

  TTarEntry = class
  private
    FHeader: TTarHeader;
    FData: TBytes;
  public
    constructor Create;
    property Header: TTarHeader read FHeader;
    property Data: TBytes read FData write FData;
    function FileName: string;
    function FileSize: int64;
    function IsDirectory: boolean;
    function IsFile: boolean;
    function IsSymLink: boolean;
  end;

  TTarArchive = class
  private
    FEntries: TList;
    function ReadHeader(Stream: TStream; var Header: TTarHeader): boolean;
    function Checksum(const Header: TTarHeader): integer;
  public
    constructor Create;
    destructor Destroy; override;
    procedure Clear;
    procedure AddEntry(Entry: TTarEntry);
    procedure LoadFromFile(const FileName: string);
    procedure LoadFromStream(Stream: TStream);
    procedure SaveToFile(const FileName: string);
    procedure SaveToStream(Stream: TStream);
    procedure AddFile(const FileName, ArcName: string);
    procedure ExtractTo(const OutputDir: string);
    function EntryCount: integer;
    function GetEntry(index: integer): TTarEntry;
    function FindEntry(const name: string): TTarEntry;
  end;

function OctalToInt(const S: string): int64;
function IntToOctal(Value: int64; Len: integer): string;

implementation

function OctalToInt(const S: string): int64;
var
  I: integer;
begin
  Result := 0;
  for I := 1 to Length(S) do
  begin
    if (S[I] >= '0') and (S[I] <= '7') then
      Result := (Result shl 3) + (Ord(S[I]) - Ord('0'))
    else
      break;
  end;
end;

function IntToOctal(Value: int64; Len: integer): string;
var
  I: integer;
begin
  SetLength(Result, Len);
  for I := Len downto 1 do
  begin
    Result[I] := Chr(Ord('0') + (Value and 7));
    Value := Value shr 3;
  end;
end;

constructor TTarEntry.Create;
begin
  inherited Create;
  FillChar(FHeader, SizeOf(FHeader), 0);
end;

function TTarEntry.FileName: string;
begin
  Result := string(FHeader.name);
end;

function TTarEntry.FileSize: int64;
begin
  Result := OctalToInt(string(FHeader.Size));
end;

function TTarEntry.IsDirectory: boolean;
begin
  Result := FHeader.TypeFlag = '5';
end;

function TTarEntry.IsFile: boolean;
begin
  Result := (FHeader.TypeFlag = '0') or (FHeader.TypeFlag = #0);
end;

function TTarEntry.IsSymLink: boolean;
begin
  Result := FHeader.TypeFlag = '2';
end;

constructor TTarArchive.Create;
begin
  inherited Create;
  FEntries := TList.Create;
end;

destructor TTarArchive.Destroy;
begin
  Clear;
  FEntries.Free;
  inherited Destroy;
end;

procedure TTarArchive.Clear;
var
  I: integer;
begin
  for I := 0 to FEntries.Count - 1 do
    TTarEntry(FEntries[I]).Free;
  FEntries.Clear;
end;

procedure TTarArchive.AddEntry(Entry: TTarEntry);
begin
  FEntries.Add(Entry);
end;

function TTarArchive.Checksum(const Header: TTarHeader): integer;
var
  I: integer;
  P: PByte;
begin
  Result := 0;
  P := PByte(@Header);
  for I := 0 to SizeOf(TTarHeader) - 1 do
    Result := Result + P[I];
  for I := 148 to 155 do
    Result := Result - P[I] + Ord(' ');
end;

function TTarArchive.ReadHeader(Stream: TStream; var Header: TTarHeader): boolean;
var
  BytesRead: integer;
begin
  BytesRead := Stream.read(Header, SizeOf(TTarHeader));
  Result := BytesRead = SizeOf(TTarHeader);
  if Result then
    Result := (Header.Magic[0] = 'u') and (Header.Magic[1] = 's');
end;

procedure TTarArchive.LoadFromFile(const FileName: string);
var
  Stream: TFileStream;
begin
  Stream := TFileStream.Create(FileName, fmOpenRead or fmShareDenyWrite);
  try
    LoadFromStream(Stream);
  finally
    Stream.Free;
  end;
end;

procedure TTarArchive.LoadFromStream(Stream: TStream);
var
  Header: TTarHeader;
  Entry: TTarEntry;
  DataSize: int64;
  PadSize: int64;
begin
  Clear;
  while ReadHeader(Stream, Header) do
  begin
    DataSize := OctalToInt(string(Header.Size));
    if DataSize = 0 then
      continue;
    Entry := TTarEntry.Create;
    Entry.FHeader := Header;
    SetLength(Entry.FData, DataSize);
    Stream.read(Entry.FData[0], DataSize);
    FEntries.Add(Entry);
    PadSize := (TAR_BLOCK_SIZE - (DataSize mod TAR_BLOCK_SIZE)) mod TAR_BLOCK_SIZE;
    if PadSize > 0 then
      Stream.Seek(PadSize, soFromCurrent);
  end;
end;

procedure TTarArchive.SaveToFile(const FileName: string);
var
  Stream: TFileStream;
begin
  Stream := TFileStream.Create(FileName, fmCreate);
  try
    SaveToStream(Stream);
  finally
    Stream.Free;
  end;
end;

procedure TTarArchive.SaveToStream(Stream: TStream);
var
  I: integer;
  Entry: TTarEntry;
  DataSize: int64;
  PadSize: int64;
  ZeroBlock: array[0..TAR_BLOCK_SIZE - 1] of byte;
begin
  for I := 0 to FEntries.Count - 1 do
  begin
    Entry := TTarEntry(FEntries[I]);
    Stream.write(Entry.FHeader, SizeOf(TTarHeader));
    DataSize := Length(Entry.FData);
    if DataSize > 0 then
      Stream.write(Entry.FData[0], DataSize);
    PadSize := (TAR_BLOCK_SIZE - (DataSize mod TAR_BLOCK_SIZE)) mod TAR_BLOCK_SIZE;
    if PadSize > 0 then
      Stream.write(ZeroBlock, PadSize);
  end;
  FillChar(ZeroBlock, SizeOf(ZeroBlock), 0);
  Stream.write(ZeroBlock, SizeOf(ZeroBlock));
  Stream.write(ZeroBlock, SizeOf(ZeroBlock));
end;

procedure TTarArchive.AddFile(const FileName, ArcName: string);
var
  Entry: TTarEntry;
  FileStream: TFileStream;
  Header: TTarHeader;
  S: string;
begin
  Entry := TTarEntry.Create;
  try
    FileStream := TFileStream.Create(FileName, fmOpenRead or fmShareDenyWrite);
    try
      SetLength(Entry.FData, FileStream.Size);
      FileStream.read(Entry.FData[0], FileStream.Size);
    finally
      FileStream.Free;
    end;
    FillChar(Header, SizeOf(Header), 0);
    S := ArcName;
    if Length(S) > 99 then SetLength(S, 99);
    Move(S[1], Header.name, Length(S));
    S := '0000644';
    Move(S[1], Header.Mode, 8);
    S := IntToOctal(Length(Entry.FData), 11);
    Move(S[1], Header.Size, 11);
    Header.TypeFlag := '0';
    S := TAR_MAGIC;
    Move(S[1], Header.Magic, 5);
    Entry.FHeader := Header;
    FEntries.Add(Entry);
  except
    Entry.Free;
    raise;
  end;
end;

procedure TTarArchive.ExtractTo(const OutputDir: string);
var
  I: integer;
  Entry: TTarEntry;
  OutPath: string;
  OutStream: TFileStream;
begin
  for I := 0 to FEntries.Count - 1 do
  begin
    Entry := TTarEntry(FEntries[I]);
    OutPath := IncludeTrailingPathDelimiter(OutputDir) + Entry.FileName;
    if Entry.IsDirectory then
      ForceDirectories(OutPath)
    else
    begin
      ForceDirectories(ExtractFilePath(OutPath));
      OutStream := TFileStream.Create(OutPath, fmCreate);
      try
        OutStream.write(Entry.FData[0], Length(Entry.FData));
      finally
        OutStream.Free;
      end;
    end;
  end;
end;

function TTarArchive.EntryCount: integer;
begin
  Result := FEntries.Count;
end;

function TTarArchive.GetEntry(index: integer): TTarEntry;
begin
  Result := TTarEntry(FEntries[index]);
end;

function TTarArchive.FindEntry(const name: string): TTarEntry;
var
  I: integer;
begin
  Result := nil;
  for I := 0 to FEntries.Count - 1 do
  begin
    if TTarEntry(FEntries[I]).FileName = name then
    begin
      Result := TTarEntry(FEntries[I]);
      exit;
    end;
  end;
end;

end.
