{
   Matrix Pascal - Encoding: Hex Unit
   ════════════════════════════════════════════════════════════════
   Hexadecimal encoding/decoding utilities

   Copyright (c) 2026 Marco Hagenaars
}
unit hex;

{$mode objfpc}{$H+}

interface

uses System, Classes, SysUtils;

type
  THexCase = (hcLower, hcUpper);
  THexEncoding = (heDefault, heWithSpaces, heWithColons);

  THex = class
  public
    class function Encode(const Data: TBytes; HexCase: THexCase = hcLower): string; static;
    class function Decode(const S: string): TBytes; static;
    class function EncodeString(const S: string; HexCase: THexCase = hcLower): string; static;
    class function DecodeString(const S: string): string; static;
    class function EncodeWithDelimiter(const Data: TBytes; Delimiter: char; HexCase: THexCase = hcLower): string; static;
    class function IsValidHex(const S: string): boolean; static;
    class function ByteToHex(B: byte; HexCase: THexCase = hcLower): string; static;
    class function HexToByte(const S: string): byte; static;
    class function IntToHex(Value: int64; Digits: integer; HexCase: THexCase = hcLower): string; static;
    class function Dump(const Data: TBytes; BytesPerLine: integer = 16): TStringList; static;
  end;

implementation

class function THex.ByteToHex(B: byte; HexCase: THexCase): string;
const
  HexChars: array[0..15] of char = '0123456789abcdef';
  HexCharsUpper: array[0..15] of char = '0123456789ABCDEF';
var
  Table: array[0..15] of char;
begin
  if HexCase = hcUpper then
    Table := HexCharsUpper
  else
    Table := HexChars;
  Result := Table[B shr 4] + Table[B and $0F];
end;

class function THex.HexToByte(const S: string): byte;

  function Nibble(C: char): byte;
  begin
    if (C >= '0') and (C <= '9') then Result := Ord(C) - Ord('0')
    else if (C >= 'A') and (C <= 'F') then Result := Ord(C) - Ord('A') + 10
    else if (C >= 'a') and (C <= 'f') then Result := Ord(C) - Ord('a') + 10
    else Result := 0;
  end;

begin
  if Length(S) >= 2 then
    Result := (Nibble(S[1]) shl 4) or Nibble(S[2])
  else if Length(S) = 1 then
    Result := Nibble(S[1])
  else
    Result := 0;
end;

class function THex.Encode(const Data: TBytes; HexCase: THexCase): string;
var
  I: integer;
begin
  SetLength(Result, Length(Data) * 2);
  for I := 0 to Length(Data) - 1 do
  begin
    Result[I * 2 + 1] := ByteToHex(Data[I], HexCase)[1];
    Result[I * 2 + 2] := ByteToHex(Data[I], HexCase)[2];
  end;
end;

class function THex.Decode(const S: string): TBytes;
var
  I, J: integer;
  Clean: string;
begin
  Clean := '';
  for I := 1 to Length(S) do
    if S[I] in ['0'..'9', 'A'..'F', 'a'..'f'] then
      Clean := Clean + S[I];
  SetLength(Result, Length(Clean) div 2);
  J := 0;
  I := 1;
  while I + 1 <= Length(Clean) do
  begin
    Result[J] := HexToByte(Copy(Clean, I, 2));
    Inc(I, 2);
    Inc(J);
  end;
end;

class function THex.EncodeString(const S: string; HexCase: THexCase): string;
begin
  Result := Encode(BytesOf(S), HexCase);
end;

class function THex.DecodeString(const S: string): string;
begin
  Result := StringOf(Decode(S));
end;

class function THex.EncodeWithDelimiter(const Data: TBytes; Delimiter: char; HexCase: THexCase): string;
var
  I: integer;
begin
  if Length(Data) = 0 then exit('');
  Result := ByteToHex(Data[0], HexCase);
  for I := 1 to Length(Data) - 1 do
    Result := Result + Delimiter + ByteToHex(Data[I], HexCase);
end;

class function THex.IsValidHex(const S: string): boolean;
var
  I: integer;
begin
  if S = '' then exit(false);
  for I := 1 to Length(S) do
    if not (S[I] in ['0'..'9', 'A'..'F', 'a'..'f', ' ', ':']) then
      exit(false);
  Result := true;
end;

class function THex.IntToHex(Value: int64; Digits: integer; HexCase: THexCase): string;
begin
  Result := System.IntToHex(Value, Digits);
  if HexCase = hcLower then
    Result := LowerCase(Result);
end;

class function THex.Dump(const Data: TBytes; BytesPerLine: integer): TStringList;
var
  I, J: integer;
  AddrStr, HexStr, AscStr: string;
begin
  Result := TStringList.Create;
  I := 0;
  while I < Length(Data) do
  begin
    AddrStr := System.IntToHex(I, 8) + ': ';
    HexStr := '';
    AscStr := '';
    for J := 0 to BytesPerLine - 1 do
    begin
      if I + J < Length(Data) then
      begin
        HexStr := HexStr + ByteToHex(Data[I + J], hcLower) + ' ';
        if (Data[I + J] >= 32) and (Data[I + J] < 127) then
          AscStr := AscStr + Chr(Data[I + J])
        else
          AscStr := AscStr + '.';
      end
      else
        HexStr := HexStr + '   ';
    end;
    Result.Add(AddrStr + HexStr + ' ' + AscStr);
    Inc(I, BytesPerLine);
  end;
end;

end.
