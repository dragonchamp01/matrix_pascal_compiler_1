unit Graphics.Canvas;
{$mode objfpc}{$H+}
interface
uses System, Classes, Graphics.Color;
type
  TCanvas = class
  private
    FHandle: pointer;
    FPenColor: TColor;
    FBrushColor: TColor;
    FPenWidth: integer;
  public
    constructor Create;
    destructor Destroy; override;
    procedure DrawLine(X1, Y1, X2, Y2: integer);
    procedure DrawRectangle(X1, Y1, X2, Y2: integer);
    procedure FillRectangle(X1, Y1, X2, Y2: integer);
    procedure DrawEllipse(X1, Y1, X2, Y2: integer);
    procedure FillEllipse(X1, Y1, X2, Y2: integer);
    procedure DrawText(X, Y: integer; const text: string);
    procedure DrawPixel(X, Y: integer);
    procedure DrawPolygon(const Points: array of TPoint);
    procedure FillPolygon(const Points: array of TPoint);
    procedure Clear(Color: TColor);
    property PenColor: TColor read FPenColor write FPenColor;
    property BrushColor: TColor read FBrushColor write FBrushColor;
    property PenWidth: integer read FPenWidth write FPenWidth;
  end;
implementation
end.
