unit camera_dev;

interface

uses graphics.image;

type
  TCameraDevice = class
  private
    FDeviceIndex: integer;
    FWidth, FHeight: integer;
    FFPS: integer;
    FActive: boolean;
  public
    constructor Create(ADeviceIndex: integer);
    function Open(AWidth, AHeight: integer; AFPS: integer = 30): boolean;
    procedure Close;
    function CaptureFrame(var Img: TImage): boolean;
    function StartStream: boolean;
    function StopStream: boolean;
    property Width: integer read FWidth;
    property Height: integer read FHeight;
    property FPS: integer read FFPS;
    property Active: boolean read FActive;
  end;

implementation

constructor TCameraDevice.Create(ADeviceIndex: integer);
begin
  FDeviceIndex := ADeviceIndex;
  FActive := false;
end;

function TCameraDevice.Open(AWidth, AHeight: integer; AFPS: integer = 30): boolean;
begin
  FWidth := AWidth;
  FHeight := AHeight;
  FFPS := AFPS;
  Result := false;
end;

procedure TCameraDevice.Close;
begin
  FActive := false;
end;

function TCameraDevice.CaptureFrame(var Img: TImage): boolean;
begin
  Result := false;
end;

function TCameraDevice.StartStream: boolean;
begin
  FActive := true;
  Result := false;
end;

function TCameraDevice.StopStream: boolean;
begin
  FActive := false;
  Result := false;
end;

end.
