unit IO.Bluetooth;
{$mode objfpc}{$H+}
interface
uses System, Classes, SysUtils;
type
  TBluetoothDevice = class
  private
    FName: string;
    FAddress: string;
    FPaired: boolean;
    FConnected: boolean;
  public
    constructor Create(const AName, AAddress: string);
    function Pair: boolean;
    function Unpair: boolean;
    function Connect: boolean;
    procedure Disconnect;
    function SendData(const Data: TBytes): boolean;
    function ReceiveData(out Data: TBytes; Timeout: integer = 5000): boolean;
    property Name: string read FName;
    property Address: string read FAddress;
    property Paired: boolean read FPaired;
    property Connected: boolean read FConnected;
  end;
  TBluetoothManager = class
    class function GetAdapterName: string;
    class function DiscoverDevices(Timeout: integer = 10000): TList;
    class function GetPairedDevices: TList;
  end;
implementation
end.
