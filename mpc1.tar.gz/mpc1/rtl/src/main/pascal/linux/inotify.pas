{
   Matrix Pascal - RTL Inotify Unit
   ════════════════════════════════════════════════════════════════
   Linux inotify file system event monitoring
   Real-time file change detection

   Nederlands: Linux inotify voor real-time bestandssysteem
   gebeurtenissen. Detecteer direct bestandswijzigingen.

   English: Linux inotify for real-time file system events.
   Detect file changes immediately.

   Copyright (c) 2026 Marco Hagenaars
}
unit inotify;

interface

uses System, Classes, SysUtils;

type
  { Inotify gebeurtenis masker / Event mask }
  TInotifyEvent = (
    ieAccess, ieModify, ieAttrib, ieCloseWrite, ieCloseNoWrite,
    ieOpen, ieMovedFrom, ieMovedTo, ieCreate, ieDelete,
    ieDeleteSelf, ieMoveSelf
  );
  TInotifyEvents = set of TInotifyEvent;

  { Inotify gebeurtenis / Inotify event record }
  TInotifyEventRec = record
    WatchDescriptor: integer;
    Mask: longword;
    Cookie: longword;
    Len: longword;
    name: string;
  end;

  { Callback voor inotify events }
  TInotifyCallback = procedure(Sender: TObject; const Event: TInotifyEventRec) of object;

  { █████████████████████████████████████████████████████████████
    TInotify — Linux inotify bestandssysteem monitor }
  TInotify = class
  private
    FInotifyFD: integer;
    FWatchDescriptors: TStringList;
    FActive: boolean;
    FOnEvent: TInotifyCallback;
    function EventMaskToSet(Mask: longword): TInotifyEvents;
  public
    constructor Create;
    destructor Destroy; override;

    function AddWatch(const Path: string; Events: TInotifyEvents): integer;
    function RemoveWatch(WD: integer): boolean;
    function WatchForEvents(TimeoutMs: longword = 1000): TList;
    procedure Start;
    procedure Stop;

    property Active: boolean read FActive;
    property OnEvent: TInotifyCallback read FOnEvent write FOnEvent;
  end;

const
  { Event mask constanten / Event mask constants }
  IN_ACCESS        = $00000001;
  IN_MODIFY        = $00000002;
  IN_ATTRIB        = $00000004;
  IN_CLOSE_WRITE   = $00000008;
  IN_CLOSE_NOWRITE = $00000010;
  IN_OPEN          = $00000020;
  IN_MOVED_FROM    = $00000040;
  IN_MOVED_TO      = $00000080;
  IN_CREATE        = $00000100;
  IN_DELETE        = $00000200;
  IN_DELETE_SELF   = $00000400;
  IN_MOVE_SELF     = $00000800;

implementation

{ TInotify }

constructor TInotify.Create;
begin
  inherited Create;
  FInotifyFD := -1;
  FActive := false;
  FWatchDescriptors := TStringList.Create;
end;

destructor TInotify.Destroy;
begin
  Stop;
  FWatchDescriptors.Free;
  inherited Destroy;
end;

function TInotify.AddWatch(const Path: string; Events: TInotifyEvents): integer;
begin
  { In productie: echte inotify_add_watch }
  Result := FWatchDescriptors.Count + 1;
  FWatchDescriptors.Add(IntToStr(Result) + '=' + Path);
end;

function TInotify.RemoveWatch(WD: integer): boolean;
var
  I: integer;
begin
  Result := false;
  for I := 0 to FWatchDescriptors.Count - 1 do
    if StrToInt(FWatchDescriptors.Names[I]) = WD then
    begin
      { In productie: echte inotify_rm_watch }
      FWatchDescriptors.Delete(I);
      Result := true;
      break;
    end;
end;

function TInotify.WatchForEvents(TimeoutMs: longword = 1000): TList;
begin
  Result := TList.Create;
  { In productie: echte read(inotify_fd) }
end;

procedure TInotify.Start;
begin
  { In productie: echte inotify_init }
  FActive := true;
end;

procedure TInotify.Stop;
begin
  FActive := false;
  if FInotifyFD >= 0 then
  begin
    { In productie: echte close }
    FInotifyFD := -1;
  end;
end;

function TInotify.EventMaskToSet(Mask: longword): TInotifyEvents;
begin
  Result := [];
  if Mask and IN_ACCESS > 0 then Include(Result, ieAccess);
  if Mask and IN_MODIFY > 0 then Include(Result, ieModify);
  if Mask and IN_ATTRIB > 0 then Include(Result, ieAttrib);
  if Mask and IN_CLOSE_WRITE > 0 then Include(Result, ieCloseWrite);
  if Mask and IN_CREATE > 0 then Include(Result, ieCreate);
  if Mask and IN_DELETE > 0 then Include(Result, ieDelete);
end;

end.
