unit apparmor;

{ objfpc}{+}

interface

uses
  SysUtils,
  ctypes,
  dl;

{ TODO: Add Apparmor bindings and wrapper functions }

implementation

{ TODO: Implement Apparmor unit functionality }

end.
