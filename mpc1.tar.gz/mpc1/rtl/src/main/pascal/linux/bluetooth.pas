unit bluetooth;

{ objfpc}{+}

interface

uses
  SysUtils,
  ctypes,
  dl;

{ TODO: Add Bluetooth bindings and wrapper functions }

implementation

{ TODO: Implement Bluetooth unit functionality }

end.
