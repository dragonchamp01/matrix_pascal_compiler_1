unit websocket;
{$mode objfpc}{$H+}
interface
uses System, Classes, SysUtils, sockets;
type
  TWebSocketOpcode = (wsContinuation, wsText, wsBinary, wsClose, wsPing, wsPong);
  TWebSocketState = (wsConnecting, wsOpen, wsClosing, wsClosed);
  TWebSocketMessage = record
    Opcode: TWebSocketOpcode;
    Payload: TBytes;
    Masked: boolean;
  end;
  TWebSocketEvent = procedure(Sender: TObject; const Msg: TWebSocketMessage) of object;
  TWebSocketErrorEvent = procedure(Sender: TObject; const ErrorMsg: string) of object;
  TWebSocket = class
  private
    FState: TWebSocketState;
    FSocket: TSocket;
    FHost: string;
    FPort: word;
    FPath: string;
    FTimeout: integer;
    FOnMessage: TWebSocketEvent;
    FOnError: TWebSocketErrorEvent;
    FOnOpen: TNotifyEvent;
    FOnClose: TNotifyEvent;
  public
    constructor Create;
    destructor Destroy; override;
    procedure Connect(const AHost: string; APort: word; const APath: string = '/');
    procedure Disconnect;
    procedure Send(const Data: TBytes; Opcode: TWebSocketOpcode = wsBinary);
    procedure SendString(const text: string);
    procedure SendPing;
    procedure SendPong;
    procedure Poll;
    property State: TWebSocketState read FState;
    property Timeout: integer read FTimeout write FTimeout;
    property OnMessage: TWebSocketEvent read FOnMessage write FOnMessage;
    property OnError: TWebSocketErrorEvent read FOnError write FOnError;
    property OnOpen: TNotifyEvent read FOnOpen write FOnOpen;
    property OnClose: TNotifyEvent read FOnClose write FOnClose;
  end;
  TWebSocketServer = class
  private
    FPort: word;
    FServerSocket: TTcpServer;
    FClients: TList;
    FActive: boolean;
  public
    constructor Create(APort: word);
    destructor Destroy; override;
    procedure Start;
    procedure Stop;
    procedure Broadcast(const Data: TBytes);
    procedure BroadcastString(const text: string);
    property Active: boolean read FActive;
  end;
implementation
constructor TWebSocket.Create;
begin FState := wsClosed; FTimeout := 30000; end;
destructor TWebSocket.Destroy;
begin Disconnect; inherited; end;
procedure TWebSocket.Connect(const AHost: string; APort: word; const APath: string);
begin FHost := AHost; FPort := APort; FPath := APath; end;
procedure TWebSocket.Disconnect;
begin FState := wsClosed; end;
procedure TWebSocket.Send(const Data: TBytes; Opcode: TWebSocketOpcode);
begin end;
procedure TWebSocket.SendString(const text: string);
begin end;
procedure TWebSocket.SendPing;
begin end;
procedure TWebSocket.SendPong;
begin end;
procedure TWebSocket.Poll;
begin end;
constructor TWebSocketServer.Create(APort: word);
begin FPort := APort; FClients := TList.Create; end;
destructor TWebSocketServer.Destroy;
begin Stop; FClients.Free; inherited; end;
procedure TWebSocketServer.Start;
begin FActive := true; end;
procedure TWebSocketServer.Stop;
begin FActive := false; end;
procedure TWebSocketServer.Broadcast(const Data: TBytes);
begin end;
procedure TWebSocketServer.BroadcastString(const text: string);
begin end;
end.
