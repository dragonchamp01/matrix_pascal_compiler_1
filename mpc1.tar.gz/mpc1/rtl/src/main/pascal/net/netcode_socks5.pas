unit netcode_socks5;

{$mode objfpc}{$H+}

interface

uses
  SysUtils;

function socks5_connect(proxy_host, target_host: string; proxy_port, target_port: integer): integer;

implementation

uses
  BaseUnix, netdb;

type
  TInetSockAddr = packed record
    sin_family: word;
    sin_port: word;
    sin_addr: cardinal;
    sin_zero: array[0..7] of byte;
  end;

function htons(v: word): word; inline;
begin
  Result := ((v shr 8) and $FF) or ((v and $FF) shl 8);
end;

function socks5_connect(proxy_host, target_host: string; proxy_port, target_port: integer): integer;
var
  Fd: integer;
  Entry: THostEntry;
  Sa: TInetSockAddr;
  Req, Resp: array[0..255] of byte;
  N, ReqLen: integer;
  TargetLen: word;
begin
  if ResolveHost(proxy_host, Entry) < 0 then
    exit(-1);

  Fd := fpSocket(AF_INET, SOCK_STREAM, 0);
  if Fd < 0 then
    exit(-1);

  FillChar(Sa, SizeOf(Sa), 0);
  Sa.sin_family := AF_INET;
  Sa.sin_port := htons(proxy_port);
  Sa.sin_addr.S_addr := Entry.addr;

  if fpConnect(Fd, @Sa, SizeOf(Sa)) < 0 then
  begin
    fpClose(Fd);
    exit(-1);
  end;

  Req[0] := $05;
  Req[1] := $01;
  Req[2] := $00;
  if fpSend(Fd, @Req, 3, 0) <> 3 then
  begin
    fpClose(Fd);
    exit(-1);
  end;

  if (fpRecv(Fd, @Resp, 2, 0) <> 2) or (Resp[0] <> $05) or (Resp[1] <> $00) then
  begin
    fpClose(Fd);
    exit(-1);
  end;

  Req[0] := $05;
  Req[1] := $01;
  Req[2] := $00;
  Req[3] := $03;
  TargetLen := Length(target_host);
  Req[4] := byte(TargetLen);
  Move(target_host[1], Req[5], TargetLen);
  ReqLen := 5 + TargetLen;
  PWord(@Req[ReqLen])^ := htons(target_port);
  Inc(ReqLen, 2);

  if fpSend(Fd, @Req, ReqLen, 0) <> ReqLen then
  begin
    fpClose(Fd);
    exit(-1);
  end;

  N := fpRecv(Fd, @Resp, 10, 0);
  if (N < 10) or (Resp[1] <> 0) then
  begin
    fpClose(Fd);
    exit(-1);
  end;

  Result := Fd;
end;

end.
