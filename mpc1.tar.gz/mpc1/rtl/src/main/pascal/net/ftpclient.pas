unit ftpclient;
{$mode objfpc}{$H+}
interface
uses System, Classes, SysUtils, sockets, ssockets;
type
  TFTPTransferType = (ftASCII, ftBinary);
  TFTPClient = class
  private
    FHost: string;
    FPort: word;
    FUsername: string;
    FPassword: string;
    FControlSock: TTcpClient;
    FPassive: boolean;
    FTransferType: TFTPTransferType;
    FTimeout: integer;
  public
    constructor Create;
    destructor Destroy; override;
    procedure Connect(const AHost: string; APort: word = 21);
    procedure Login(const AUsername, APassword: string);
    procedure Disconnect;
    procedure ChangeDir(const ADir: string);
    function CurrentDir: string;
    procedure MakeDir(const ADir: string);
    procedure RemoveDir(const ADir: string);
    procedure DeleteFile(const AFileName: string);
    procedure Rename(const AFrom, ATo: string);
    function List(const ADir: string = ''): TStrings;
    procedure Download(const RemoteFile, LocalFile: string);
    procedure Upload(const LocalFile, RemoteFile: string);
    procedure SetPassive(Value: boolean);
    property TransferType: TFTPTransferType read FTransferType write FTransferType;
    property Timeout: integer read FTimeout write FTimeout;
  end;
implementation
constructor TFTPClient.Create;
begin
  FPort := 21;
  FPassive := true;
  FTransferType := ftBinary;
  FTimeout := 30000;
end;
destructor TFTPClient.Destroy;
begin
  Disconnect;
  inherited;
end;
procedure TFTPClient.Connect(const AHost: string; APort: word);
begin
  FHost := AHost; FPort := APort;
end;
procedure TFTPClient.Login(const AUsername, APassword: string);
begin
  FUsername := AUsername; FPassword := APassword;
end;
procedure TFTPClient.Disconnect;
begin end;
procedure TFTPClient.ChangeDir(const ADir: string);
begin end;
function TFTPClient.CurrentDir: string;
begin Result := '/'; end;
procedure TFTPClient.MakeDir(const ADir: string);
begin end;
procedure TFTPClient.RemoveDir(const ADir: string);
begin end;
procedure TFTPClient.DeleteFile(const AFileName: string);
begin end;
procedure TFTPClient.Rename(const AFrom, ATo: string);
begin end;
function TFTPClient.List(const ADir: string): TStrings;
begin Result := TStringList.Create; end;
procedure TFTPClient.Download(const RemoteFile, LocalFile: string);
begin end;
procedure TFTPClient.Upload(const LocalFile, RemoteFile: string);
begin end;
procedure TFTPClient.SetPassive(Value: boolean);
begin FPassive := Value; end;
end.
