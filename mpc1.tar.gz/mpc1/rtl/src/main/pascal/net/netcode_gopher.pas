unit netcode_gopher;

{$mode objfpc}{$H+}

interface

uses
  SysUtils;

function gopher_get(host, selector: string; port: integer = 70): string;

implementation

uses
  sockets;

function gopher_get(host, selector: string; port: integer = 70): string;
var
  Client: TTcpClient;
  Request: string;
  Buf: array[0..4095] of byte;
  N: integer;
begin
  Result := '';
  try
    Client := TTcpClient.Create(host, port);
  except
    exit;
  end;
  try
    Request := selector + #13#10;
    if Client.Send(Request[1], Length(Request)) <> Length(Request) then
      exit;

    Result := '';
    repeat
      N := Client.Recv(Buf, SizeOf(Buf));
      if N > 0 then
      begin
        SetLength(Result, Length(Result) + N);
        Move(Buf, Result[Length(Result) - N + 1], N);
      end;
    until N <= 0;
  finally
    Client.Close;
    Client.Free;
  end;
end;

end.
