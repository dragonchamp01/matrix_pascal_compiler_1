{
   Matrix Pascal - URI Unit
   ════════════════════════════════════════════════════════════════
   URI/URL parsing, construction, and manipulation

   Nederlands: URI/URL parsing, constructie en manipulatie.

   English: URI/URL parsing, construction, and manipulation.

   Copyright (c) 2026 Marco Hagenaars
}
unit uri;

interface

uses System, Classes, SysUtils;

type
  { █████████████████████████████████████████████████████████████
    TURI — URI parser en builder }
  TURI = class
  private
    FScheme: string;
    FUser: string;
    FPassword: string;
    FHost: string;
    FPort: integer;
    FPath: string;
    FQuery: string;
    FFragment: string;
    FOriginal: string;
    FValid: boolean;

    procedure Parse(const S: string);
  public
    constructor Create(const URIStr: string);
    function ToString: string;
    function IsValid: boolean;

    property Scheme: string read FScheme;
    property User: string read FUser;
    property Password: string read FPassword;
    property Host: string read FHost;
    property Port: integer read FPort;
    property Path: string read FPath;
    property Query: string read FQuery;
    property Fragment: string read FFragment;

    class function Encode(const S: string): string;
    class function Decode(const S: string): string;
    class function ParseQuery(const Query: string): THashMap;
  end;

implementation

constructor TURI.Create(const URIStr: string);
begin
  inherited Create;
  FOriginal := URIStr;
  Parse(URIStr);
end;

procedure TURI.Parse(const S: string);
var
  Remainder: string;
  P: integer;
  PortStr: string;
begin
  FValid := false;
  if S = '' then exit;

  { Scheme }
  P := Pos('://', S);
  if P > 0 then
  begin
    FScheme := Copy(S, 1, P - 1);
    Remainder := Copy(S, P + 3, Length(S));
  end
  else
  begin
    FScheme := '';
    Remainder := S;
  end;

  { Fragment }
  P := Pos('#', Remainder);
  if P > 0 then
  begin
    FFragment := Copy(Remainder, P + 1, Length(Remainder));
    Remainder := Copy(Remainder, 1, P - 1);
  end;

  { Query }
  P := Pos('?', Remainder);
  if P > 0 then
  begin
    FQuery := Copy(Remainder, P + 1, Length(Remainder));
    Remainder := Copy(Remainder, 1, P - 1);
  end;

  { Auth @ Host:Port / Path }
  P := Pos('@', Remainder);
  if P > 0 then
  begin
    FUser := Copy(Remainder, 1, P - 1);
    Remainder := Copy(Remainder, P + 1, Length(Remainder));
    P := Pos(':', FUser);
    if P > 0 then
    begin
      FPassword := Copy(FUser, P + 1, Length(FUser));
      FUser := Copy(FUser, 1, P - 1);
    end;
  end;

  { Path }
  P := Pos('/', Remainder);
  if P > 0 then
  begin
    FPath := Copy(Remainder, P, Length(Remainder));
    Remainder := Copy(Remainder, 1, P - 1);
  end
  else
  begin
    FPath := '/';
  end;

  { Host:Port }
  P := Pos(':', Remainder);
  if P > 0 then
  begin
    FHost := Copy(Remainder, 1, P - 1);
    PortStr := Copy(Remainder, P + 1, Length(Remainder));
    FPort := StrToIntDef(PortStr, 0);
  end
  else
  begin
    FHost := Remainder;
    FPort := 0;
  end;

  if FScheme = '' then FScheme := 'http';
  if FPort = 0 then
  begin
    if FScheme = 'https' then FPort := 443
    else if FScheme = 'http' then FPort := 80
    else if FScheme = 'ftp' then FPort := 21
    else if FScheme = 'ssh' then FPort := 22;
  end;

  FValid := FHost <> '';
end;

function TURI.ToString: string;
begin
  Result := '';
  if FScheme <> '' then Result := FScheme + '://';
  if FUser <> '' then
  begin
    Result := Result + FUser;
    if FPassword <> '' then Result := Result + ':' + FPassword;
    Result := Result + '@';
  end;
  Result := Result + FHost;
  if (FPort > 0) and not ((FScheme = 'http') and (FPort = 80)) and
     not ((FScheme = 'https') and (FPort = 443)) then
    Result := Result + ':' + IntToStr(FPort);
  Result := Result + FPath;
  if FQuery <> '' then Result := Result + '?' + FQuery;
  if FFragment <> '' then Result := Result + '#' + FFragment;
end;

function TURI.IsValid: boolean;
begin
  Result := FValid;
end;

class function TURI.Encode(const S: string): string;
var
  I: integer;
  C: char;
begin
  Result := '';
  for I := 1 to Length(S) do
  begin
    C := S[I];
    if (C in ['A'..'Z', 'a'..'z', '0'..'9', '-', '_', '.', '~']) then
      Result := Result + C
    else
      Result := Result + '%' + IntToHex(Ord(C), 2);
  end;
end;

class function TURI.Decode(const S: string): string;
var
  I: integer;
begin
  Result := '';
  I := 1;
  while I <= Length(S) do
  begin
    if (S[I] = '%') and (I + 2 <= Length(S)) then
    begin
      Result := Result + Chr(StrToInt('$' + Copy(S, I + 1, 2)));
      Inc(I, 3);
    end
    else
    begin
      Result := Result + S[I];
      Inc(I);
    end;
  end;
end;

class function TURI.ParseQuery(const Query: string): THashMap;
var
  Parts: TStringList;
  I, P: integer;
  Key, Val: string;
begin
  Result := THashMap.Create;
  Parts := TStringList.Create;
  try
    Parts.Delimiter := '&';
    Parts.DelimitedText := Query;
    for I := 0 to Parts.Count - 1 do
    begin
      P := Pos('=', Parts[I]);
      if P > 0 then
      begin
        Key := Decode(Copy(Parts[I], 1, P - 1));
        Val := Decode(Copy(Parts[I], P + 1, Length(Parts[I])));
        Result.Put(Key, Val);
      end;
    end;
  finally
    Parts.Free;
  end;
end;

end.
