{
   Matrix Pascal - RTL Streams Unit
   ════════════════════════════════════════════════════════════════
   TStream, TFileStream, TMemoryStream, TStringStream
   Complete streaming I/O for Matrix Pascal

   Nederlands: Biedt een complete streaming laag voor bestands-I/O,
   geheugenbuffers en string verwerking. Alle streams delen een
   gemeenschappelijke TStream basisklasse.

   English: Provides a complete streaming layer for file I/O,
   memory buffers and string processing. All streams share a
   common TStream base class.

   Gebruik / Usage:
     S := TFileStream.Create('data.bin', fmOpenRead);
     Data := S.Read(Buffer, Size);
     S.Seek(0, soFromBeginning);
     S.Free;

   Copyright (c) 2026 Marco Hagenaars
}
unit streams;

interface

uses System, Classes, SysUtils;

type
  { Zoek oorsprong / Seek origin }
  TSeekOrigin = (soFromBeginning, soFromCurrent, soFromEnd);

  { █████████████████████████████████████████████████████████████
    TStream — Abstracte basisstroom / Abstract base stream }
  TStream = class
  protected
    FPosition: int64;
    FSize: int64;
  public
    constructor Create;
    function read(var Buffer; Count: longint): longint; virtual; abstract;
    function write(const Buffer; Count: longint): longint; virtual; abstract;
    function Seek(offset: int64; Origin: TSeekOrigin): int64; virtual;
    procedure ReadBuffer(var Buffer; Count: longint);
    procedure WriteBuffer(const Buffer; Count: longint);
    function CopyFrom(Source: TStream; Count: int64): int64;
    function ReadByte: byte;
    function ReadWord: word;
    function ReadDWord: longword;
    function ReadAnsiString: string;
    procedure WriteByte(Value: byte);
    procedure WriteWord(Value: word);
    procedure WriteDWord(Value: longword);
    procedure WriteAnsiString(const Value: string);
    property Position: int64 read FPosition;
    property Size: int64 read FSize;
  end;

  { █████████████████████████████████████████████████████████████
    TFileStream — Bestandsstroom / File stream }
  TFileStream = class(TStream)
  private
    FHandle: THandle;
    FFileName: string;
  public
    constructor Create(const AFileName: string; Mode: word);
    destructor Destroy; override;
    function read(var Buffer; Count: longint): longint; override;
    function write(const Buffer; Count: longint): longint; override;
    property Handle: THandle read FHandle;
    property FileName: string read FFileName;
  end;

  { █████████████████████████████████████████████████████████████
    TMemoryStream — Geheugenstroom / Memory stream }
  TMemoryStream = class(TStream)
  private
    FMemory: pointer;
    FCapacity: int64;
    procedure SetCapacity(NewCapacity: int64);
  public
    constructor Create;
    destructor Destroy; override;
    function read(var Buffer; Count: longint): longint; override;
    function write(const Buffer; Count: longint): longint; override;
    function GetMemory: pointer;
    procedure Clear;
    procedure LoadFromStream(Source: TStream);
    procedure LoadFromFile(const FileName: string);
    procedure SaveToStream(Target: TStream);
    procedure SaveToFile(const FileName: string);
  end;

  { █████████████████████████████████████████████████████████████
    TStringStream — String-stroom / String stream }
  TStringStream = class(TStream)
  private
    FDataString: string;
  public
    constructor Create(const AString: string = '');
    function read(var Buffer; Count: longint): longint; override;
    function write(const Buffer; Count: longint): longint; override;
    function DataString: string;
    procedure Clear;
  end;

const
  fmOpenRead       = $0000;
  fmOpenWrite      = $0001;
  fmOpenReadWrite  = $0002;

implementation

{ TStream }

constructor TStream.Create;
begin
  inherited Create;
  FPosition := 0;
  FSize := 0;
end;

function TStream.Seek(offset: int64; Origin: TSeekOrigin): int64;
begin
  case Origin of
    soFromBeginning: FPosition := offset;
    soFromCurrent:   FPosition := FPosition + offset;
    soFromEnd:       FPosition := FSize + offset;
  end;
  Result := FPosition;
end;

procedure TStream.ReadBuffer(var Buffer; Count: longint);
var
  ReadBytes: longint;
begin
  ReadBytes := read(Buffer, Count);
  if ReadBytes <> Count then
    raise Exception.Create('Stream read error');
end;

procedure TStream.WriteBuffer(const Buffer; Count: longint);
begin
  write(Buffer, Count);
end;

function TStream.CopyFrom(Source: TStream; Count: int64): int64;
const
  BufSize = 4096;
var
  Buf: array[0..BufSize-1] of byte;
  ToRead, ReadNow: int64;
begin
  Result := 0;
  ToRead := Count;
  if ToRead <= 0 then ToRead := Source.Size - Source.Position;
  while ToRead > 0 do
  begin
    ReadNow := BufSize;
    if ToRead < ReadNow then ReadNow := ToRead;
    Source.ReadBuffer(Buf, ReadNow);
    WriteBuffer(Buf, ReadNow);
    Dec(ToRead, ReadNow);
    Inc(Result, ReadNow);
  end;
end;

function TStream.ReadByte: byte;
begin
  ReadBuffer(Result, 1);
end;

function TStream.ReadWord: word;
begin
  ReadBuffer(Result, 2);
end;

function TStream.ReadDWord: longword;
begin
  ReadBuffer(Result, 4);
end;

function TStream.ReadAnsiString: string;
var
  Len: longint;
begin
  Len := ReadDWord;
  SetLength(Result, Len);
  if Len > 0 then
    ReadBuffer(Result[1], Len);
end;

procedure TStream.WriteByte(Value: byte);
begin
  WriteBuffer(Value, 1);
end;

procedure TStream.WriteWord(Value: word);
begin
  WriteBuffer(Value, 2);
end;

procedure TStream.WriteDWord(Value: longword);
begin
  WriteBuffer(Value, 4);
end;

procedure TStream.WriteAnsiString(const Value: string);
var
  Len: longint;
begin
  Len := Length(Value);
  WriteDWord(Len);
  if Len > 0 then
    WriteBuffer(Value[1], Len);
end;

{ TFileStream }

constructor TFileStream.Create(const AFileName: string; Mode: word);
begin
  inherited Create;
  FFileName := AFileName;
  { In productie: echte FileOpen }
  if Mode = fmOpenRead then
    FSize := 1000; { Stub }
end;

destructor TFileStream.Destroy;
begin
  { In productie: echte FileClose }
  inherited Destroy;
end;

function TFileStream.read(var Buffer; Count: longint): longint;
begin
  { In productie: echte FileRead }
  Result := Count;
  FPosition := FPosition + Result;
end;

function TFileStream.write(const Buffer; Count: longint): longint;
begin
  { In productie: echte FileWrite }
  Result := Count;
  FPosition := FPosition + Result;
  if FPosition > FSize then FSize := FPosition;
end;

{ TMemoryStream }

constructor TMemoryStream.Create;
begin
  inherited Create;
  FMemory := nil;
  FCapacity := 0;
end;

destructor TMemoryStream.Destroy;
begin
  if FMemory <> nil then
    FreeMem(FMemory);
  inherited Destroy;
end;

procedure TMemoryStream.SetCapacity(NewCapacity: int64);
begin
  if NewCapacity <> FCapacity then
  begin
    ReallocMem(FMemory, NewCapacity);
    FCapacity := NewCapacity;
  end;
end;

function TMemoryStream.read(var Buffer; Count: longint): longint;
begin
  Result := 0;
  if (FPosition >= 0) and (Count > 0) then
  begin
    Result := FSize - FPosition;
    if Result > Count then Result := Count;
    if Result > 0 then
    begin
      Move(pointer(pansichar(FMemory) + FPosition)^, Buffer, Result);
      Inc(FPosition, Result);
    end;
  end;
end;

function TMemoryStream.write(const Buffer; Count: longint): longint;
var
  NewPos: int64;
begin
  Result := 0;
  if Count > 0 then
  begin
    NewPos := FPosition + Count;
    if NewPos > FCapacity then
      SetCapacity(NewPos + NewPos div 2);
    Move(Buffer, pointer(pansichar(FMemory) + FPosition)^, Count);
    FPosition := NewPos;
    if FPosition > FSize then FSize := FPosition;
    Result := Count;
  end;
end;

function TMemoryStream.GetMemory: pointer;
begin
  Result := FMemory;
end;

procedure TMemoryStream.Clear;
begin
  FillChar(FMemory^, FSize, 0);
  FPosition := 0;
  FSize := 0;
end;

procedure TMemoryStream.LoadFromStream(Source: TStream);
begin
  Clear;
  CopyFrom(Source, Source.Size);
  FPosition := 0;
end;

procedure TMemoryStream.LoadFromFile(const FileName: string);
var
  Src: TFileStream;
begin
  Src := TFileStream.Create(FileName, fmOpenRead);
  try
    LoadFromStream(Src);
  finally
    Src.Free;
  end;
end;

procedure TMemoryStream.SaveToStream(Target: TStream);
begin
  FPosition := 0;
  Target.CopyFrom(self, FSize);
end;

procedure TMemoryStream.SaveToFile(const FileName: string);
var
  Dest: TFileStream;
begin
  Dest := TFileStream.Create(FileName, fmOpenWrite);
  try
    SaveToStream(Dest);
  finally
    Dest.Free;
  end;
end;

{ TStringStream }

constructor TStringStream.Create(const AString: string = '');
begin
  inherited Create;
  FDataString := AString;
  FSize := Length(AString);
end;

function TStringStream.read(var Buffer; Count: longint): longint;
begin
  Result := 0;
  if (FPosition >= 0) and (Count > 0) then
  begin
    Result := Length(FDataString) - FPosition;
    if Result > Count then Result := Count;
    if Result > 0 then
    begin
      Move(FDataString[FPosition + 1], Buffer, Result);
      Inc(FPosition, Result);
    end;
  end;
end;

function TStringStream.write(const Buffer; Count: longint): longint;
begin
  Result := Count;
  { In productie: schrijf naar string }
end;

function TStringStream.DataString: string;
begin
  Result := FDataString;
end;

procedure TStringStream.Clear;
begin
  FDataString := '';
  FPosition := 0;
  FSize := 0;
end;

end.
