unit service;

interface

uses SysUtils;

type
  TServiceState = (ssStopped, ssRunning, ssPaused, ssStarting, ssStopping);

  TService = class
  private
    FName: string;
    FDisplayName: string;
    FState: TServiceState;
  public
    constructor Create(const AName, ADisplayName: string);
    function Start: boolean;
    function Stop: boolean;
    function Pause: boolean;
    function resume: boolean;
    function Install: boolean;
    function Uninstall: boolean;
    property name: string read FName;
    property DisplayName: string read FDisplayName;
    property State: TServiceState read FState;
  end;

implementation

constructor TService.Create(const AName, ADisplayName: string);
begin
  FName := AName;
  FDisplayName := ADisplayName;
  FState := ssStopped;
end;

function TService.Start: boolean;
begin
  Result := false;
end;

function TService.Stop: boolean;
begin
  Result := false;
end;

function TService.Pause: boolean;
begin
  Result := false;
end;

function TService.resume: boolean;
begin
  Result := false;
end;

function TService.Install: boolean;
begin
  Result := false;
end;

function TService.Uninstall: boolean;
begin
  Result := false;
end;

end.
