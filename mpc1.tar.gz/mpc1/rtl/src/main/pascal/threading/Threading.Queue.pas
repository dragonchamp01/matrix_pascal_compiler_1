unit Threading.Queue;
{$mode objfpc}{$H+}
interface
uses System, Classes, SysUtils, Threading.Lock;
type
  TThreadSafeQueue<T> = class
  private
    FQueue: TQueue;
    FLock: TLock;
  public
    constructor Create;
    destructor Destroy; override;
    procedure Enqueue(const Item: T);
    function Dequeue(out Item: T): boolean;
    function TryDequeue(out Item: T; Timeout: longword = 0): boolean;
    function Count: integer;
    procedure Clear;
  end;
implementation
end.
