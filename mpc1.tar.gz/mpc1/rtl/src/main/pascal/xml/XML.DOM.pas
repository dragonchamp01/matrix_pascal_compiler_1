unit XML.DOM;
{$mode objfpc}{$H+}
interface
uses System, Classes, SysUtils;
type
  TXMLNodeType = (ntElement, ntAttribute, ntText, ntCDATA, ntComment, ntPI, ntDocument);
  TXMLNode = class
  private
    FNodeType: TXMLNodeType;
    FNodeName: string;
    FNodeValue: string;
    FParent: TXMLNode;
    FChildNodes: TList;
    FAttributes: TStringList;
  public
    constructor Create(ANodeType: TXMLNodeType; const AName: string);
    destructor Destroy; override;
    procedure AddChild(Child: TXMLNode);
    procedure InsertBefore(Child, RefChild: TXMLNode);
    procedure RemoveChild(Child: TXMLNode);
    function AppendChild(const TagName: string): TXMLNode;
    procedure SetAttribute(const name, Value: string);
    function GetAttribute(const name: string): string;
    function HasAttribute(const name: string): boolean;
    function HasChildNodes: boolean;
    property NodeType: TXMLNodeType read FNodeType;
    property NodeName: string read FNodeName write FNodeName;
    property NodeValue: string read FNodeValue write FNodeValue;
    property ParentNode: TXMLNode read FParent;
    property ChildNodes: TList read FChildNodes;
    property Attributes: TStringList read FAttributes;
  end;
  TXMLDocument = class(TXMLNode)
  private
    FVersion: string;
    FEncoding: string;
  public
    constructor Create(const ARootName: string);
    function XML: string;
    procedure LoadFromFile(const FileName: string);
    procedure SaveToFile(const FileName: string);
    procedure LoadFromString(const XMLStr: string);
    function FindElement(const TagName: string): TXMLNode;
    function FindElements(const TagName: string): TList;
    property Version: string read FVersion write FVersion;
    property Encoding: string read FEncoding write FEncoding;
  end;
implementation
end.
