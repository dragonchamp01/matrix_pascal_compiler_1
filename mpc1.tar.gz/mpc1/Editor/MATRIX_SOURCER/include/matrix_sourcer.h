#ifndef MATRIX_SOURCER_H
#define MATRIX_SOURCER_H

#include <cstdint>
#include <cstddef>
#include <string>
#include <vector>
#include <map>

struct ElfParseResult;

#define MATRIX_SOURCER_VERSION "1.0.0"
#define MATRIX_SOURCER_NAME "Matrix Sourcer"
#define MAX_PASSES 18
#define MAX_INSTR_LEN 16
#define DEFAULT_BASE_ADDRESS 0x00400000

enum class ArchMode {
    MODE_16,
    MODE_32,
    MODE_64
};

enum class OutputFormat {
    NASM,
    RAW,
    JSON,
    C_OUTPUT,
    PAS_OUTPUT
};

enum class ColorTheme {
    VCOMM,
    MONOCHROME,
    RGB
};

struct DisasmConfig {
    ArchMode arch_mode;
    OutputFormat output_format;
    ColorTheme color_theme;
    int passes;
    uint64_t base_address;
    uint64_t entry_point;
    bool show_hex;
    bool show_offsets;
    bool show_bytes;
    bool show_comments;
    bool show_labels;
    bool resolve_calls;
    bool resolve_jumps;
    bool binutils_syntax;
    std::string input_file;
    std::string output_file;
    std::string symbol_file;
    std::string section_name;
    bool quiet;
    bool final_pass_only;
    bool decompile_body;
    bool ai_annotations;
    bool export_cfg;
};

struct DisasmResult {
    uint64_t address;
    uint8_t bytes[MAX_INSTR_LEN];
    size_t byte_count;
    std::string mnemonic;
    std::string operands;
    std::string raw_string;
    bool is_branch;
    bool is_call;
    bool is_jump;
    bool is_return;
    uint64_t target_address;
};

struct PassResult {
    int pass_number;
    std::vector<DisasmResult> instructions;
    std::map<uint64_t, std::string> labels;
    std::map<uint64_t, uint64_t> branch_targets;
    size_t instruction_count;
};

class MatrixSourcer {
public:
    MatrixSourcer();
    ~MatrixSourcer();

    int run(int argc, char* argv[]);
    int disassemble(const DisasmConfig& config);
    int disassemble(const DisasmConfig& config,
                    const std::vector<uint8_t>& binary_data,
                    const ElfParseResult* elf_result);

private:
    DisasmConfig config;
};

#endif