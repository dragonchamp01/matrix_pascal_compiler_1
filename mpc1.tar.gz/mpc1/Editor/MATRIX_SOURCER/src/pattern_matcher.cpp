#include "pattern_matcher.h"
#include <sstream>
#include <algorithm>

PatternMatcher::PatternMatcher() {
}

PatternMatcher::~PatternMatcher() {
}

std::vector<MatchedPattern> PatternMatcher::match(
    const std::vector<DisasmResult>& instructions,
    uint64_t base_addr
) {
    all_matches.clear();

    auto prologue_matches = match_function_prologue(instructions, base_addr);
    auto if_matches = match_if_else(instructions, base_addr);
    auto for_matches = match_for_loop(instructions, base_addr);
    auto while_matches = match_while_loop(instructions, base_addr);
    auto switch_matches = match_switch_statement(instructions, base_addr);
    auto call_matches = match_function_call(instructions, base_addr);
    auto var_matches = match_local_variable_access(instructions, base_addr);

    std::vector<MatchedPattern> all_results;
    for (const auto& m : prologue_matches) all_results.push_back(m);
    for (const auto& m : if_matches) all_results.push_back(m);
    for (const auto& m : for_matches) all_results.push_back(m);
    for (const auto& m : while_matches) all_results.push_back(m);
    for (const auto& m : switch_matches) all_results.push_back(m);
    for (const auto& m : call_matches) all_results.push_back(m);
    for (const auto& m : var_matches) all_results.push_back(m);

    return all_results;
}

std::vector<MatchedPattern> PatternMatcher::match_function_prologue(
    const std::vector<DisasmResult>& instructions,
    uint64_t base_addr
) {
    std::vector<MatchedPattern> results;

    for (size_t i = 0; i + 2 < instructions.size(); i++) {
        const auto& instr1 = instructions[i];
        const auto& instr2 = instructions[i + 1];
        const auto& instr3 = instructions[i + 2];

        if (instr1.mnemonic == "push" && instr1.operands.find("rbp") != std::string::npos &&
            instr2.mnemonic == "mov" && instr2.operands.find("rbp") != std::string::npos &&
            instr2.operands.find("rsp") != std::string::npos &&
            instr3.mnemonic == "sub") {

            PatternMatch match;
            match.pattern_name = "function_prologue";
            match.start_addr = instr1.address;
            match.end_addr = instr3.address + instr3.byte_count;
            match.confidence = 0.95f;
            match.description = "Function prologue detected: push rbp; mov rbp, rsp; sub rsp, N";

            std::ostringstream oss;
            oss << "sub rsp, " << instr3.operands;
            match.bindings["stack_size"] = instr3.operands;

            MatchedPattern mp;
            mp.match = match;
            mp.instructions.push_back(instr1);
            mp.instructions.push_back(instr2);
            mp.instructions.push_back(instr3);
            results.push_back(mp);
        }
    }

    return results;
}

std::vector<MatchedPattern> PatternMatcher::match_if_else(
    const std::vector<DisasmResult>& instructions,
    uint64_t base_addr
) {
    std::vector<MatchedPattern> results;

    for (size_t i = 0; i + 1 < instructions.size(); i++) {
        const auto& cmp_instr = instructions[i];
        const auto& jcc_instr = instructions[i + 1];

        if (cmp_instr.mnemonic == "cmp" &&
            (jcc_instr.mnemonic.find("j") == 0 && jcc_instr.mnemonic != "jmp")) {

            PatternMatch match;
            match.pattern_name = "if_else";
            match.start_addr = cmp_instr.address;
            match.end_addr = jcc_instr.address + jcc_instr.byte_count;
            match.confidence = 0.85f;
            match.description = "Conditional branch detected after comparison";
            match.bindings["condition"] = cmp_instr.operands;
            match.bindings["target"] = jcc_instr.operands;
            match.bindings["jcc_type"] = jcc_instr.mnemonic;

            MatchedPattern mp;
            mp.match = match;
            mp.instructions.push_back(cmp_instr);
            mp.instructions.push_back(jcc_instr);
            results.push_back(mp);
        }
    }

    return results;
}

std::vector<MatchedPattern> PatternMatcher::match_for_loop(
    const std::vector<DisasmResult>& instructions,
    uint64_t base_addr
) {
    std::vector<MatchedPattern> results;

    for (size_t i = 0; i + 4 < instructions.size(); i++) {
        const auto& mov_instr = instructions[i];
        const auto& cmp_instr = instructions[i + 1];
        const auto& jcc_instr = instructions[i + 2];
        const auto& inc_instr = instructions[i + 3];

        if (mov_instr.mnemonic == "mov" &&
            cmp_instr.mnemonic == "cmp" &&
            (jcc_instr.mnemonic.find("j") == 0) &&
            inc_instr.mnemonic == "inc") {

            PatternMatch match;
            match.pattern_name = "for_loop";
            match.start_addr = mov_instr.address;
            match.end_addr = inc_instr.address + inc_instr.byte_count;
            match.confidence = 0.8f;
            match.description = "For loop pattern detected";
            match.bindings["counter_init"] = mov_instr.operands;
            match.bindings["limit"] = cmp_instr.operands;
            match.bindings["jcc_type"] = jcc_instr.mnemonic;

            MatchedPattern mp;
            mp.match = match;
            mp.instructions.push_back(mov_instr);
            mp.instructions.push_back(cmp_instr);
            mp.instructions.push_back(jcc_instr);
            mp.instructions.push_back(inc_instr);
            results.push_back(mp);
        }
    }

    return results;
}

std::vector<MatchedPattern> PatternMatcher::match_while_loop(
    const std::vector<DisasmResult>& instructions,
    uint64_t base_addr
) {
    std::vector<MatchedPattern> results;

    for (size_t i = 0; i + 2 < instructions.size(); i++) {
        const auto& cmp_instr = instructions[i];
        const auto& jcc_instr = instructions[i + 1];
        const auto& jmp_instr = instructions[i + 2];

        if (cmp_instr.mnemonic == "cmp" &&
            (jcc_instr.mnemonic.find("j") == 0) &&
            jmp_instr.mnemonic == "jmp") {

            PatternMatch match;
            match.pattern_name = "while_loop";
            match.start_addr = cmp_instr.address;
            match.end_addr = jmp_instr.address + jmp_instr.byte_count;
            match.confidence = 0.8f;
            match.description = "While loop pattern detected";
            match.bindings["condition"] = cmp_instr.operands;
            match.bindings["jcc_type"] = jcc_instr.mnemonic;

            MatchedPattern mp;
            mp.match = match;
            mp.instructions.push_back(cmp_instr);
            mp.instructions.push_back(jcc_instr);
            mp.instructions.push_back(jmp_instr);
            results.push_back(mp);
        }
    }

    return results;
}

std::vector<MatchedPattern> PatternMatcher::match_switch_statement(
    const std::vector<DisasmResult>& instructions,
    uint64_t base_addr
) {
    std::vector<MatchedPattern> results;

    for (size_t i = 0; i < instructions.size(); i++) {
        const auto& instr = instructions[i];

        if (instr.mnemonic == "jmp" &&
            instr.operands.find("[") != std::string::npos &&
            instr.operands.find("*") != std::string::npos) {

            PatternMatch match;
            match.pattern_name = "switch_statement";
            match.start_addr = instr.address;
            match.end_addr = instr.address + instr.byte_count;
            match.confidence = 0.9f;
            match.description = "Switch statement with jump table detected";
            match.bindings["table"] = instr.operands;

            MatchedPattern mp;
            mp.match = match;
            mp.instructions.push_back(instr);
            results.push_back(mp);
        }
    }

    return results;
}

std::vector<MatchedPattern> PatternMatcher::match_function_call(
    const std::vector<DisasmResult>& instructions,
    uint64_t base_addr
) {
    std::vector<MatchedPattern> results;

    for (const auto& instr : instructions) {
        if (instr.mnemonic == "call") {
            PatternMatch match;
            match.pattern_name = "function_call";
            match.start_addr = instr.address;
            match.end_addr = instr.address + instr.byte_count;
            match.confidence = 0.95f;
            match.description = "Function call detected";
            match.bindings["target"] = instr.operands;

            MatchedPattern mp;
            mp.match = match;
            mp.instructions.push_back(instr);
            results.push_back(mp);
        }
    }

    return results;
}

std::vector<MatchedPattern> PatternMatcher::match_local_variable_access(
    const std::vector<DisasmResult>& instructions,
    uint64_t base_addr
) {
    std::vector<MatchedPattern> results;

    for (const auto& instr : instructions) {
        if (instr.operands.find("[rbp") != std::string::npos ||
            instr.operands.find("[rbp-") != std::string::npos ||
            instr.operands.find("[rbp+") != std::string::npos) {

            PatternMatch match;
            match.pattern_name = "local_variable_access";
            match.start_addr = instr.address;
            match.end_addr = instr.address + instr.byte_count;
            match.confidence = 0.85f;
            match.description = "Local variable access via stack frame";
            match.bindings["access"] = instr.operands;

            MatchedPattern mp;
            mp.match = match;
            mp.instructions.push_back(instr);
            results.push_back(mp);
        }
    }

    return results;
}

bool PatternMatcher::match_sequence(
    const std::vector<DisasmResult>& instructions,
    size_t start_idx,
    const std::vector<std::string>& pattern,
    std::map<std::string, std::string>& bindings
) {
    if (start_idx + pattern.size() > instructions.size()) {
        return false;
    }

    for (size_t i = 0; i < pattern.size(); i++) {
        const auto& instr = instructions[start_idx + i];
        if (instr.mnemonic != pattern[i]) {
            return false;
        }
    }

    return true;
}

std::string PatternMatcher::normalize_mnemonic(const std::string& mnemonic) {
    return mnemonic;
}

std::string PatternMatcher::normalize_operands(const std::string& operands) {
    return operands;
}
