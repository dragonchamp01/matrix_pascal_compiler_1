#include "mainwindow.h"
#include "editorwidget.h"
#include "workspace.h"
#include "debugger.h"
#include "outputwidget.h"
#include "projectpropertiesdialog.h"
#include "gitmanager.h"
#include "finddialog.h"
#include "lspclient.h"
#include "codeeditor.h"
#include "diagnosticsview.h"
#include "snippetsmanager.h"
#include "snippetsview.h"
#include "classview.h"
#include "watchview.h"
#include "memoryview.h"
#include "disassemblyview.h"
#include "callstackview.h"
#include "threadsview.h"
#include "attachdialog.h"
#include "remotedebugdialog.h"
#include "buildmatrix.h"
#include "buildmatrixdialog.h"
#include "buildengine.h"
#include "buildloganalyzer.h"
#include "externaltoolsdialog.h"
#include "packagingbuilder.h"
#include "packagingdialog.h"
#include "profiler.h"
#include "usageview.h"
#include <QMenuBar>
#include <QUrl>
#include <QJsonValue>
#include <QJsonArray>
#include <QJsonDocument>
#include <QComboBox>
#include <QToolBar>
#include <QDockWidget>
#include <QSettings>
#include <QFileDialog>
#include <QMdiSubWindow>
#include <QMessageBox>
#include <QInputDialog>
#include <QProcess>
#include <QKeySequence>
#include <QDir>
#include "cfgparser.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent), m_mdiArea(new QMdiArea(this)) {

    setCentralWidget(m_mdiArea);
    m_mdiArea->setViewMode(QMdiArea::TabbedView);
    m_mdiArea->setTabsClosable(true);

    m_workspace = new WorkspaceWidget(this);
    m_debugger = new DebuggerWidget(this);
    m_output = new OutputWidget(this);
    m_lspClient = new LspClient(this);
    m_diagnosticsView = new DiagnosticsView(this);
    m_snippetsManager = new SnippetsManager(this);
    m_snippetsView = new SnippetsView(m_snippetsManager, this);
    m_classView = new ClassView(this);
    m_watchView = new WatchView(this);
    m_memoryView = new MemoryView(this);
    m_disassemblyView = new DisassemblyView(this);
    m_callStackView = new CallStackView(this);
    m_threadsView = new ThreadsView(this);
    m_buildEngine = new BuildEngine(this);
    m_buildLogAnalyzer = new BuildLogAnalyzer(this);
    m_profiler = new ProfilerWidget(this);
    m_usageView = new UsageView(this);

    connect(m_output, &OutputWidget::textAppended, this, [this](const QString &text, const QString &channel){
        if (channel == "Build") {
            m_buildLogAnalyzer->addText(text);
        }
    });
    connect(m_buildLogAnalyzer, &BuildLogAnalyzer::entryActivated, this, [this](const QString &file, int line){
        QString resolved = file;
        if (!QFileInfo(resolved).isAbsolute()) {
            resolved = QDir::current().absoluteFilePath(resolved);
        }
        openDocument(resolved);
        QMdiSubWindow *sub = m_mdiArea->activeSubWindow();
        if (sub) {
            CodeEditor *editor = qobject_cast<CodeEditor*>(sub->widget());
            if (editor) {
                QTextCursor cursor = editor->textCursor();
                cursor.movePosition(QTextCursor::Start);
                cursor.movePosition(QTextCursor::Down, QTextCursor::MoveAnchor, line - 1);
                editor->setTextCursor(cursor);
            }
        }
    });

    connect(m_usageView, &UsageView::entryActivated, this, [this](const QString &file, int line, int col){
        openDocument(file);
        QMdiSubWindow *sub = m_mdiArea->activeSubWindow();
        if (sub) {
            CodeEditor *editor = qobject_cast<CodeEditor*>(sub->widget());
            if (editor) {
                QTextCursor cursor = editor->textCursor();
                cursor.movePosition(QTextCursor::Start);
                cursor.movePosition(QTextCursor::Down, QTextCursor::MoveAnchor, line);
                cursor.movePosition(QTextCursor::Right, QTextCursor::MoveAnchor, col);
                editor->setTextCursor(cursor);
            }
        }
    });

    connect(m_lspClient, &LspClient::responseReceived, this, &MainWindow::handleLspResponse);

    connect(m_buildEngine, &BuildEngine::outputLine, this, [this](const QString &line){
        m_output->appendOutput(line, "Build");
    });
    connect(m_buildEngine, &BuildEngine::targetStarted, this, [this](const QString &name){
        m_output->appendOutput("Target " + name + ":", "Build");
    });
    connect(m_buildEngine, &BuildEngine::buildFinished, this, [this](bool ok){
        m_output->appendOutput(ok ? "Build engine finished OK." : "Build engine FAILED.", "Build");
    });

    connect(m_workspace, &WorkspaceWidget::fileSelected, this, &MainWindow::openDocument);
    connect(m_lspClient, &LspClient::responseReceived, this, &MainWindow::handleLspResponse);
    connect(m_snippetsView, &SnippetsView::snippetSelected, this, &MainWindow::insertSnippet);
    connect(m_debugger, &DebuggerWidget::outputReceived, this, [this](const QString &text){
        m_output->appendOutput(text, "Debug");
    });

    createDockWidgets();
    createMenuBar();
    createToolBars();
    detectCompilers();
    applyDeveloperTheme();
}

MainWindow::~MainWindow() {}

void MainWindow::createDockWidgets() {
    QDockWidget *wDock = new QDockWidget("Workspace", this);
    wDock->setWidget(m_workspace);
    addDockWidget(Qt::LeftDockWidgetArea, wDock);

    m_debuggerDock = new QDockWidget("Debugger", this);
    m_debuggerDock->setWidget(m_debugger);
    addDockWidget(Qt::BottomDockWidgetArea, m_debuggerDock);

    QDockWidget *oDock = new QDockWidget("Output", this);
    oDock->setWidget(m_output);
    addDockWidget(Qt::BottomDockWidgetArea, oDock);

    QDockWidget *diagDock = new QDockWidget("Diagnostics", this);
    diagDock->setWidget(m_diagnosticsView);
    addDockWidget(Qt::BottomDockWidgetArea, diagDock);

    QDockWidget *snippetDock = new QDockWidget("Snippets", this);
    snippetDock->setWidget(m_snippetsView);
    addDockWidget(Qt::RightDockWidgetArea, snippetDock);

    QDockWidget *classDock = new QDockWidget("Class View", this);
    classDock->setWidget(m_classView);
    addDockWidget(Qt::RightDockWidgetArea, classDock);

    QDockWidget *watchDock = new QDockWidget("Watch", this);
    watchDock->setWidget(m_watchView);
    addDockWidget(Qt::BottomDockWidgetArea, watchDock);

    QDockWidget *memoryDock = new QDockWidget("Memory", this);
    memoryDock->setWidget(m_memoryView);
    addDockWidget(Qt::BottomDockWidgetArea, memoryDock);

    QDockWidget *disassemblyDock = new QDockWidget("Disassembly", this);
    disassemblyDock->setWidget(m_disassemblyView);
    addDockWidget(Qt::BottomDockWidgetArea, disassemblyDock);

    QDockWidget *callStackDock = new QDockWidget("Call Stack", this);
    callStackDock->setWidget(m_callStackView);
    addDockWidget(Qt::BottomDockWidgetArea, callStackDock);

    QDockWidget *threadsDock = new QDockWidget("Threads", this);
    threadsDock->setWidget(m_threadsView);
    addDockWidget(Qt::BottomDockWidgetArea, threadsDock);

    QDockWidget *buildIssuesDock = new QDockWidget("Build Issues", this);
    buildIssuesDock->setWidget(m_buildLogAnalyzer);
    addDockWidget(Qt::BottomDockWidgetArea, buildIssuesDock);

    QDockWidget *profilerDock = new QDockWidget("Profiler", this);
    profilerDock->setWidget(m_profiler);
    addDockWidget(Qt::BottomDockWidgetArea, profilerDock);

    QDockWidget *refDock = new QDockWidget("References", this);
    refDock->setWidget(m_usageView);
    addDockWidget(Qt::BottomDockWidgetArea, refDock);
    
    connect(m_callStackView, &CallStackView::frameSelected, this, [this](const QString &file, int line){
        openDocument(file);
        // Move cursor to line
        QMdiSubWindow *sub = m_mdiArea->activeSubWindow();
        if (sub) {
            CodeEditor *editor = qobject_cast<CodeEditor*>(sub->widget());
            if (editor) {
                QTextCursor cursor = editor->textCursor();
                cursor.movePosition(QTextCursor::Start);
                cursor.movePosition(QTextCursor::Down, QTextCursor::MoveAnchor, line);
                editor->setTextCursor(cursor);
            }
        }
    });

    connect(m_debugger, &DebuggerWidget::threadsUpdated, m_threadsView, &ThreadsView::updateThreads);
    connect(m_threadsView, &ThreadsView::threadSelected, m_debugger, &DebuggerWidget::selectThread);
}

void MainWindow::createMenuBar() {
    QMenu *fileMenu = menuBar()->addMenu("&File");
    fileMenu->addAction("&New", this, &MainWindow::newFile);
    fileMenu->addAction("&Open", this, &MainWindow::openFile);
    fileMenu->addAction("Find in Files", [this](){
        FindDialog dlg(this);
        connect(&dlg, &FindDialog::findRequested, [this](const QString &text){
            m_output->appendOutput("Searching for: " + text, "Search");
        });
        dlg.exec();
    });
    
    QMenu *recentMenu = fileMenu->addMenu("Recent Projects");
    QSettings settings("MatrixStudio", "MatrixStudio");
    QStringList recentProjects = settings.value("recentProjects").toStringList();
    for (const QString &path : recentProjects) {
        recentMenu->addAction(path, [this, path](){ openDocument(path); });
    }

    fileMenu->addAction("&Save", this, &MainWindow::saveDocument);
    fileMenu->addSeparator();
    fileMenu->addAction("E&xit", this, &MainWindow::close);

    QMenu *buildMenu = menuBar()->addMenu("&Build");
    buildMenu->addAction("&Build", this, &MainWindow::buildProject);
    buildMenu->addAction("&Rebuild", this, [this](){
        QMdiSubWindow *sub = m_mdiArea->activeSubWindow();
        if (!sub) return;
        CodeEditor *editor = qobject_cast<CodeEditor*>(sub->widget());
        QString filePath = editor ? editor->filePath() : sub->windowTitle();
        if (filePath.isEmpty()) return;
        QFile probe(filePath);
        if (probe.open(QIODevice::ReadOnly | QIODevice::Text)) {
            const QByteArray first = probe.read(200).trimmed();
        if (first.startsWith('<')) {
            m_buildLogAnalyzer->clear();
            QString error;
            if (!m_buildEngine->load(filePath, &error)) {
                    m_output->appendOutput("Build engine load failed: " + error, "Build");
                    return;
                }
                const QString target = m_buildEngine->hasTarget("Build") ? "Build"
                    : m_buildEngine->targetNames().isEmpty() ? QString()
                    : m_buildEngine->targetNames().first();
                if (target.isEmpty()) return;
                m_output->appendOutput(QString("Build engine (rebuild): %1 [%2]")
                    .arg(QFileInfo(filePath).fileName()).arg(target), "Build");
                m_buildEngine->rebuildTarget(target);
                return;
            }
        }
        const QString platform = m_platformCombo ? m_platformCombo->currentText() : "x64";
        const QString configuration = m_configCombo ? m_configCombo->currentText() : "Debug";
        buildFile(filePath, platform, configuration);
    });
    buildMenu->addAction("Build &Matrix...", this, &MainWindow::buildMatrix);
    buildMenu->addAction("Run &XML Build File...", this, [this](){
        QString path = QFileDialog::getOpenFileName(this, "Open XML Build File", QString(),
            "Build Files (*.build *.xml *.proj);;All Files (*)");
        if (!path.isEmpty()) buildWithEngine(path);
    });
    buildMenu->addSeparator();
    buildMenu->addAction("&Create Package...", this, &MainWindow::createPackage);
    buildMenu->addAction("C&lean", this, &MainWindow::cleanProject);
    buildMenu->addAction("Clean &All", this, &MainWindow::cleanAll);

    QMenu *debugMenu = menuBar()->addMenu("&Debug");
    debugMenu->addAction("&Run", this, &MainWindow::runProject);
    debugMenu->addAction("Step &Into", m_debugger, &DebuggerWidget::stepInto);
    debugMenu->addAction("Step &Over", m_debugger, &DebuggerWidget::stepOver);
    debugMenu->addAction("Step &Out", m_debugger, &DebuggerWidget::stepOut);
    debugMenu->addAction("&Continue", m_debugger, &DebuggerWidget::continueExecution);

    QAction *runToCursorAct = debugMenu->addAction("Run to &Cursor");
    runToCursorAct->setShortcut(QKeySequence("Ctrl+F10"));
    connect(runToCursorAct, &QAction::triggered, this, [this](){
        QMdiSubWindow *sub = m_mdiArea->activeSubWindow();
        if (sub) {
            CodeEditor *editor = qobject_cast<CodeEditor*>(sub->widget());
            if (editor) {
                m_debugger->runToCursor(editor->filePath(), editor->textCursor().blockNumber() + 1);
            }
        }
    });

    debugMenu->addSeparator();
    debugMenu->addAction("Profile Active &File...", this, &MainWindow::startProfiling);

    QAction *toggleBpAct = debugMenu->addAction("Toggle &Breakpoint");
    toggleBpAct->setShortcut(QKeySequence("F9"));
    connect(toggleBpAct, &QAction::triggered, this, [this](){
        QMdiSubWindow *sub = m_mdiArea->activeSubWindow();
        if (sub) {
            CodeEditor *editor = qobject_cast<CodeEditor*>(sub->widget());
            if (editor) {
                int line = editor->textCursor().blockNumber() + 1;
                editor->toggleBreakpoint(line);
                if (editor->breakpoints().contains(line)) {
                    m_debugger->addBreakpoint(editor->filePath(), line);
                } else {
                    m_debugger->removeBreakpointAt(editor->filePath(), line);
                }
            }
        }
    });

    QAction *clearBpsAct = debugMenu->addAction("Clear &All Breakpoints");
    connect(clearBpsAct, &QAction::triggered, m_debugger, &DebuggerWidget::clearBreakpoints);

    debugMenu->addSeparator();
    debugMenu->addAction("&Attach to Process...", this, [this](){
        AttachProcessDialog dlg(this);
        if (dlg.exec() == QDialog::Accepted) {
            m_debugger->attach(dlg.selectedPid());
        }
    });
    debugMenu->addAction("&Detach", m_debugger, &DebuggerWidget::detach);

    debugMenu->addSeparator();
    debugMenu->addAction("&Remote Debug...", this, [this](){
        RemoteDebugDialog dlg(this);
        if (dlg.exec() == QDialog::Accepted) {
            m_debugger->startRemoteSession(dlg.username(), dlg.targetHost(), dlg.port(),
                                           dlg.localProgram(), dlg.remoteProgram(),
                                           dlg.launchGdbserver());
        }
    });

    QMenu *gitMenu = menuBar()->addMenu("&Git");
    GitManager *git = new GitManager(this);
    gitMenu->addAction("Status", [git](){ git->runCommand({"status"}); });
    gitMenu->addAction("Pull", [git](){ git->runCommand({"pull"}); });
    gitMenu->addAction("Push", [git](){ git->runCommand({"push"}); });
    connect(git, &GitManager::outputReceived, this, [this](const QString &text){
        m_output->appendOutput(text, "Build");
    });

    QMenu *viewMenu = menuBar()->addMenu("&View");
    viewMenu->addAction("Toggle Debugger", [this](){
        m_debuggerDock->setVisible(!m_debuggerDock->isVisible());
    });

    m_toolsMenu = menuBar()->addMenu("&Tools");
    populateToolsMenu();
}

void MainWindow::populateToolsMenu() {
    m_toolsMenu->clear();
    m_toolsMenu->addAction("External &Tools...", this, [this](){
        ExternalToolsDialog dlg(this);
        if (dlg.exec() == QDialog::Accepted) {
            saveExternalTools(dlg.tools());
            populateToolsMenu();
        }
    });
    const QList<ExternalTool> tools = loadExternalTools();
    if (tools.isEmpty()) return;
    m_toolsMenu->addSeparator();
    for (const ExternalTool &tool : tools) {
        m_toolsMenu->addAction(tool.title, this, [this, tool](){
            runExternalTool(tool);
        });
    }
}

void MainWindow::runExternalTool(const ExternalTool &tool) {
    if (tool.command.isEmpty()) return;

    QString args = tool.arguments;
    if (tool.promptArgs) {
        bool ok;
        args = QInputDialog::getText(this, tool.title, "Arguments:", QLineEdit::Normal, args, &ok);
        if (!ok) return;
    }

    QString workingDir = tool.workingDir;
    if (workingDir.isEmpty()) {
        QMdiSubWindow *sub = m_mdiArea->activeSubWindow();
        if (sub) {
            CodeEditor *editor = qobject_cast<CodeEditor*>(sub->widget());
            if (editor && !editor->filePath().isEmpty()) {
                workingDir = QFileInfo(editor->filePath()).absolutePath();
            }
        }
    }
    if (workingDir.isEmpty()) workingDir = QDir::currentPath();

    m_output->appendOutput(QString("Running %1: %2 %3").arg(tool.title, tool.command, args), "Build");

    QProcess *proc = new QProcess(this);
    proc->setWorkingDirectory(workingDir);
    connect(proc, &QProcess::readyReadStandardOutput, this, [this, proc](){
        m_output->appendOutput(QString::fromUtf8(proc->readAllStandardOutput()), "Build");
    });
    connect(proc, &QProcess::readyReadStandardError, this, [this, proc](){
        m_output->appendOutput("Error: " + QString::fromUtf8(proc->readAllStandardError()), "Build");
    });
    connect(proc, QOverload<int, QProcess::ExitStatus>::of(&QProcess::finished), this,
        [this, proc](int exitCode, QProcess::ExitStatus){
            m_output->appendOutput(QString("  %1 finished (%2)").arg(proc->program()).arg(exitCode), "Build");
            proc->deleteLater();
        });
    proc->start(tool.command, args.split(' ', Qt::SkipEmptyParts));
}

void MainWindow::createToolBars() {
    QToolBar *debugToolBar = addToolBar("Debug");
    m_configCombo = new QComboBox();
    m_configCombo->addItems({"Debug", "Release"});
    m_platformCombo = new QComboBox();
    m_platformCombo->addItems({"x86", "x64"});
    debugToolBar->addWidget(m_configCombo);
    debugToolBar->addWidget(m_platformCombo);
    debugToolBar->addAction("Run", this, &MainWindow::runProject);
    debugToolBar->addAction("Step Into", m_debugger, &DebuggerWidget::stepInto);
    debugToolBar->addAction("Step Over", m_debugger, &DebuggerWidget::stepOver);
    debugToolBar->addAction("Step Out", m_debugger, &DebuggerWidget::stepOut);
    debugToolBar->addAction("Continue", m_debugger, &DebuggerWidget::continueExecution);
}

void MainWindow::detectCompilers() {
    CfgParser parser;
    QStringList compilers = {"gcc", "nasm", "mpc1"};
    for (const QString &c : compilers) {
        QProcess proc;
        proc.start("which", {c});
        if (proc.waitForFinished() && proc.exitCode() == 0) {
            parser.set("Compilers", c, QString::fromUtf8(proc.readAllStandardOutput()).trimmed());
        } else {
            parser.set("Compilers", c, "Not Found");
        }
    }
    QString cfgPath = QDir::homePath() + "/.config/matrix-studio.dev.cfg";
    parser.save(cfgPath);
}

bool MainWindow::openDocument(const QString &filePath) {
    QFile file(filePath);
    if (!file.open(QIODevice::ReadOnly | QIODevice::Text)) return false;
    
    CodeEditor *editor = new CodeEditor();
    EditorWidget::setupEditor(editor, filePath);
    editor->setFilePath(filePath);
    editor->setPlainText(file.readAll());
    file.close();

    QMdiSubWindow *subWindow = m_mdiArea->addSubWindow(editor);
    subWindow->setWindowTitle(QFileInfo(filePath).fileName());
    subWindow->show();

    connect(editor, &CodeEditor::goToDefinitionRequested, this, [this, filePath](int line, int column){
        m_lspClient->requestDefinition(QUrl::fromLocalFile(filePath).toString(), line, column);
    });

    connect(editor, &CodeEditor::signatureHelpRequested, this, [this, filePath](int line, int column){
        m_lspClient->requestSignatureHelp(QUrl::fromLocalFile(filePath).toString(), line, column);
    });

    connect(editor, &CodeEditor::renameRequested, this, [this, filePath](int line, int column){
        bool ok;
        QString newName = QInputDialog::getText(this, "Rename Symbol", "New name:", QLineEdit::Normal, "", &ok);
        if (ok && !newName.isEmpty()) {
            m_lspClient->requestRename(QUrl::fromLocalFile(filePath).toString(), line, column, newName);
        }
    });

    connect(editor, &CodeEditor::runToCursorRequested, this, [this, filePath](int line){
        m_debugger->runToCursor(filePath, line);
    });

    connect(editor, &CodeEditor::findReferencesRequested, this, [this, filePath](int line, int column){
        m_lspClient->requestReferences(QUrl::fromLocalFile(filePath).toString(), line, column);
    });

    connect(editor, &CodeEditor::toggleBreakpointRequested, this, [this, editor, filePath](int line){
        if (editor->breakpoints().contains(line)) {
            m_debugger->removeBreakpointAt(filePath, line);
        } else {
            m_debugger->addBreakpoint(filePath, line);
        }
    });

    // Start LSP if not running
    if (filePath.endsWith(".c")) {
        m_lspClient->start("clangd", {});
    }
    return true;
}

void MainWindow::newFile() {
    CodeEditor *editor = new CodeEditor();
    EditorWidget::setupEditor(editor, "Untitled");
    QMdiSubWindow *subWindow = m_mdiArea->addSubWindow(editor);
    subWindow->setWindowTitle("Untitled");
    subWindow->show();
    subWindow->setFocus();
}

void MainWindow::openFile() {
    QString path = QFileDialog::getOpenFileName(this, "Open File");
    if (!path.isEmpty()) {
        openDocument(path);
        QSettings settings("MatrixStudio", "MatrixStudio");
        QStringList recent = settings.value("recentProjects").toStringList();
        recent.removeAll(path);
        recent.prepend(path);
        while (recent.size() > 10) recent.removeLast();
        settings.setValue("recentProjects", recent);
    }
}

void MainWindow::saveDocument() {
    QMdiSubWindow *sub = m_mdiArea->activeSubWindow();
    if (sub) {
        // Implementation for save
    }
}

void MainWindow::closeDocument() {
    m_mdiArea->closeActiveSubWindow();
}

bool MainWindow::buildFile(const QString &filePath, const QString &platform, const QString &configuration) {
    if (filePath.isEmpty()) return false;
    m_buildLogAnalyzer->clear();
    QFileInfo fi(filePath);
    const QString ext = fi.suffix().toLower();

    CfgParser parser;
    QString cfgPath = QDir::homePath() + "/.config/matrix-studio.dev.cfg";
    parser.load(cfgPath);
    parser.setSection("Compilers");

    QString compiler;
    if (ext == "c") {
        compiler = parser.get("Compilers", "gcc", "gcc").toString();
    } else if (ext == "pas") {
        compiler = parser.get("Compilers", "mpc1", "mpc1").toString();
    } else if (ext == "asm") {
        compiler = parser.get("Compilers", "nasm", "nasm").toString();
    } else {
        m_output->appendOutput("Unsupported file type for build: " + fi.fileName(), "Build");
        return false;
    }

    if (compiler == "Not Found") {
        m_output->appendOutput("Compiler not found: " + compiler, "Build");
        return false;
    }

    const QString outDir = BuildMatrix::outputDirectory(platform, configuration);
    QDir().mkpath(outDir);
    const QString outPath = outDir + "/" + BuildMatrix::outputName(filePath, platform);
    const QStringList args = BuildMatrix::compilerArgs(compiler, platform, filePath, outPath);

    m_output->appendOutput(QString("Building %1 [%2]...").arg(fi.fileName())
                               .arg(BuildMatrix::label(platform, configuration)), "Build");
    m_output->appendOutput(QString("  %1 %2").arg(compiler, args.join(" ")), "Build");

    QProcess *proc = new QProcess(this);
    connect(proc, &QProcess::readyReadStandardOutput, this, [this, proc](){
        m_output->appendOutput(QString::fromUtf8(proc->readAllStandardOutput()), "Build");
    });
    connect(proc, &QProcess::readyReadStandardError, this, [this, proc](){
        m_output->appendOutput("Error: " + QString::fromUtf8(proc->readAllStandardError()), "Build");
    });
    connect(proc, QOverload<int, QProcess::ExitStatus>::of(&QProcess::finished), this,
        [this, proc, outPath](int exitCode, QProcess::ExitStatus){
            m_output->appendOutput(exitCode == 0
                ? QString("  -> %1 [OK]").arg(outPath)
                : QString("  -> build failed (%1)").arg(exitCode), "Build");
            proc->deleteLater();
        });
    proc->start(compiler, args);
    return true;
}

void MainWindow::buildProject() {
    QMdiSubWindow *sub = m_mdiArea->activeSubWindow();
    if (!sub) return;

    CodeEditor *editor = qobject_cast<CodeEditor*>(sub->widget());
    QString filePath = editor ? editor->filePath() : sub->windowTitle();
    if (filePath.isEmpty()) return;

    QFile probe(filePath);
    if (probe.open(QIODevice::ReadOnly | QIODevice::Text)) {
        const QByteArray first = probe.read(200).trimmed();
        if (first.startsWith('<')) {
            buildWithEngine(filePath);
            return;
        }
    }

    const QString platform = m_platformCombo ? m_platformCombo->currentText() : "x64";
    const QString configuration = m_configCombo ? m_configCombo->currentText() : "Debug";
    buildFile(filePath, platform, configuration);
}

void MainWindow::buildWithEngine(const QString &filePath) {
    m_buildLogAnalyzer->clear();
    QString error;
    if (!m_buildEngine->load(filePath, &error)) {
        m_output->appendOutput("Build engine load failed: " + error, "Build");
        return;
    }
    QString target = m_buildEngine->hasTarget("Build") ? "Build"
                    : m_buildEngine->targetNames().isEmpty() ? QString()
                    : m_buildEngine->targetNames().first();
    if (target.isEmpty()) {
        m_output->appendOutput("No build targets defined in " + QFileInfo(filePath).fileName(), "Build");
        return;
    }
    m_output->appendOutput(QString("Build engine: %1 [%2]").arg(QFileInfo(filePath).fileName()).arg(target), "Build");
    m_buildEngine->runTarget(target);
}

void MainWindow::buildMatrix() {
    QMdiSubWindow *sub = m_mdiArea->activeSubWindow();
    if (!sub) return;

    CodeEditor *editor = qobject_cast<CodeEditor*>(sub->widget());
    QString filePath = editor ? editor->filePath() : sub->windowTitle();
    if (filePath.isEmpty()) return;

    BuildMatrixDialog dlg(this);
    if (dlg.exec() != QDialog::Accepted) return;

    m_buildLogAnalyzer->clear();
    const QList<BuildTarget> targets = dlg.selectedTargets();
    for (const BuildTarget &t : targets) {
        buildFile(filePath, t.platform, t.configuration);
    }
}

void MainWindow::createPackage() {
    QString buildDir = "build/x64/Release";
    QMdiSubWindow *sub = m_mdiArea->activeSubWindow();
    CodeEditor *editor = sub ? qobject_cast<CodeEditor*>(sub->widget()) : nullptr;
    QString baseName = editor ? QFileInfo(editor->filePath()).completeBaseName() : QString("MyApp");
    if (editor && !editor->filePath().isEmpty()) {
        buildDir = QFileInfo(editor->filePath()).absolutePath() + "/build/x64/Release";
    }

    PackagingDialog dlg(buildDir, this);
    dlg.setWindowTitle("Create Package");
    if (dlg.exec() != QDialog::Accepted) return;

    QString name = dlg.packageName();
    if (name.isEmpty()) name = baseName;

    QString error;
    m_output->appendOutput(QString("Packaging %1...").arg(name), "Build");
    if (PackagingBuilder::makePackage(name, dlg.version(), dlg.buildDir(),
                                      dlg.outDir(), dlg.makeTar(), dlg.makeRun(), &error)) {
        m_output->appendOutput("Package created in " + dlg.outDir(), "Build");
    } else {
        m_output->appendOutput("Packaging failed: " + error, "Build");
    }
}

static QString runSync(QProcess &proc) {
    QString out;
    proc.start();
    proc.waitForStarted();
    while (proc.waitForReadyRead(30000)) {
        out += QString::fromUtf8(proc.readAllStandardOutput());
        out += QString::fromUtf8(proc.readAllStandardError());
    }
    proc.waitForFinished(30000);
    out += QString::fromUtf8(proc.readAllStandardOutput());
    out += QString::fromUtf8(proc.readAllStandardError());
    return out;
}

void MainWindow::startProfiling() {
    QMdiSubWindow *sub = m_mdiArea->activeSubWindow();
    if (!sub) return;
    CodeEditor *editor = qobject_cast<CodeEditor*>(sub->widget());
    if (!editor) return;
    const QString filePath = editor->filePath();
    if (filePath.isEmpty()) return;

    QFileInfo fi(filePath);
    const QString ext = fi.suffix().toLower();
    const QString base = fi.completeBaseName();
    const QString srcDir = fi.absolutePath();
    const QString profileDir = srcDir + "/profile";
    QDir().mkpath(profileDir);
    const QString outPath = profileDir + "/" + base + ".out";

    m_buildLogAnalyzer->clear();
    m_profiler->clear();
    m_output->appendOutput(QString("Profiling %1...").arg(fi.fileName()), "Build");

    CfgParser parser;
    QString cfgPath = QDir::homePath() + "/.config/matrix-studio.dev.cfg";
    parser.load(cfgPath);
    parser.setSection("Compilers");
    QString compiler = parser.get("Compilers", "gcc", "gcc").toString();
    const QString platform = m_platformCombo ? m_platformCombo->currentText() : "x64";

    QProcess compile;
    QString compileLine;
    if (ext == "c") {
        const QString bits = (platform == "x86") ? "-m32" : "-m64";
        compileLine = QString("%1 -g -pg %2 \"%3\" -o \"%4\"").arg(compiler, bits, filePath, outPath);
    } else if (ext == "asm") {
        const QString nasm = parser.get("Compilers", "nasm", "nasm").toString();
        const QString fmt = (platform == "x86") ? "elf32" : "elf64";
        const QString obj = profileDir + "/" + base + ".o";
        compileLine = QString("%1 -g -f %2 \"%3\" -o \"%4\" && %5 -no-pie -pg \"%4\" -o \"%6\"")
                          .arg(nasm, fmt, filePath, obj, compiler, outPath);
    } else if (ext == "pas") {
        compileLine = QString("%1 \"%2\" -o \"%3\"").arg(compiler, filePath, outPath);
    } else {
        m_output->appendOutput("Profiling not supported for: " + fi.fileName(), "Build");
        return;
    }

    m_output->appendOutput("  " + compileLine, "Build");
    QProcess shell;
    shell.setProgram("/bin/sh");
    shell.setArguments({"-c", compileLine});
    const QString compileOut = runSync(shell);
    if (!compileOut.trimmed().isEmpty()) m_output->appendOutput(compileOut, "Build");
    if (shell.exitCode() != 0) {
        m_output->appendOutput("  -> profile build failed", "Build");
        return;
    }

    QProcess run;
    run.setWorkingDirectory(profileDir);
    run.setProgram(outPath);
    m_output->appendOutput(QString("  running %1 ...").arg(outPath), "Build");
    const QString runOut = runSync(run);
    if (!runOut.trimmed().isEmpty()) m_output->appendOutput(runOut, "Build");
    m_output->appendOutput(QString("  program finished (%1)").arg(run.exitCode()), "Build");

    QProcess gprof;
    gprof.setWorkingDirectory(profileDir);
    gprof.setProgram("gprof");
    gprof.setArguments({base + ".out", "gmon.out"});
    const QString profileText = runSync(gprof);

    const QList<ProfileEntry> entries = parseGprofFlatProfile(profileText);
    if (entries.isEmpty()) {
        m_output->appendOutput("  no profile data (was the program executed?)", "Build");
        return;
    }
    m_profiler->setProfile(entries);
    m_output->appendOutput(QString("  %1 functions profiled").arg(entries.size()), "Build");
}

void MainWindow::cleanProject() {
    QMdiSubWindow *sub = m_mdiArea->activeSubWindow();
    if (!sub) return;
    CodeEditor *editor = qobject_cast<CodeEditor*>(sub->widget());
    if (!editor) return;
    QString filePath = editor->filePath();
    if (filePath.isEmpty()) return;

    const QString platform = m_platformCombo ? m_platformCombo->currentText() : "x64";
    const QString configuration = m_configCombo ? m_configCombo->currentText() : "Debug";
    const QString outDir = BuildMatrix::outputDirectory(platform, configuration);
    QDir(outDir).removeRecursively();
    m_output->appendOutput(QString("Cleaned: %1").arg(outDir), "Build");
}

void MainWindow::cleanAll() {
    QDir("build").removeRecursively();
    m_output->appendOutput("Cleaned build directory.", "Build");
}

void MainWindow::runProject() {
    QMdiSubWindow *sub = m_mdiArea->activeSubWindow();
    if (!sub) return;

    CodeEditor *editor = qobject_cast<CodeEditor*>(sub->widget());
    if (!editor) return;
    QString fileName = editor->filePath();
    if (fileName.isEmpty()) fileName = sub->windowTitle();

    QString program;
    if (fileName.endsWith(".c") || fileName.endsWith(".pas")) {
        program = fileName.left(fileName.lastIndexOf('.')) + ".out";
    } else if (fileName.endsWith(".asm")) {
        program = fileName.left(fileName.lastIndexOf('.')) + ".o";
    }
    if (program.isEmpty()) {
        m_output->appendOutput("No debug session started: unsupported file type.", "Debug");
        return;
    }
    m_output->appendOutput("Starting debug session: " + program, "Debug");
    if (!m_debugger->start(program)) {
        m_output->appendOutput("Failed to start debugger (gdb not found?).", "Debug");
        return;
    }
    const QList<QMdiSubWindow *> subs = m_mdiArea->subWindowList();
    for (QMdiSubWindow *s : subs) {
        CodeEditor *e = qobject_cast<CodeEditor*>(s->widget());
        if (!e) continue;
        const QSet<int> bps = e->breakpoints();
        for (int line : bps) {
            m_debugger->addBreakpoint(e->filePath(), line);
        }
    }
}

void MainWindow::insertSnippet(const QString &content) {
    QMdiSubWindow *sub = m_mdiArea->activeSubWindow();
    if (sub) {
        CodeEditor *editor = qobject_cast<CodeEditor*>(sub->widget());
        if (editor) {
            editor->textCursor().insertText(content);
        }
    }
}

void MainWindow::handleLspResponse(const QJsonObject &response, const QString &method) {
    if (method == "textDocument/references") {
        m_usageView->clear();
        QJsonArray result = response["result"].toArray();
        QList<UsageEntry> refs;
        for (const QJsonValue &v : result) {
            QJsonObject loc = v.toObject();
            UsageEntry e;
            e.file = QUrl(loc["uri"].toString()).toLocalFile();
            QJsonObject start = loc["range"].toObject()["start"].toObject();
            e.line = start["line"].toInt();
            e.column = start["character"].toInt();
            refs.append(e);
        }
        m_usageView->setUsages(refs);
        return;
    }

    if (response.contains("method") && response["method"] == "textDocument/publishDiagnostics") {
        m_diagnosticsView->clearDiagnostics();
        QJsonObject params = response["params"].toObject();
        QString uri = params["uri"].toString();
        QJsonArray diagnostics = params["diagnostics"].toArray();
        for (const QJsonValue &diag : diagnostics) {
            QJsonObject d = diag.toObject();
            m_diagnosticsView->addDiagnostic(uri, d["range"].toObject()["start"].toObject()["line"].toInt(), d["message"].toString());
        }
        return;
    }

    QJsonValue result = response.value("result");

    // Signature Help
    if (result.isObject() && result.toObject().contains("signatures")) {
        m_output->appendOutput("Signature: " + QJsonDocument(result.toObject()).toJson(), "Debug");
        return;
    }

    // Definition handling
    QString uri;
    int line = 0, col = 0;
    
    if (result.isArray()) {
        QJsonObject loc = result.toArray().first().toObject();
        uri = loc["uri"].toString();
        QJsonObject start = loc["range"].toObject()["start"].toObject();
        line = start["line"].toInt();
        col = start["character"].toInt();
    } else if (result.isObject()) {
        QJsonObject loc = result.toObject();
        uri = loc["uri"].toString();
        QJsonObject start = loc["range"].toObject()["start"].toObject();
        line = start["line"].toInt();
        col = start["character"].toInt();
    }
    
    if (!uri.isEmpty()) {
        openDocument(QUrl(uri).toLocalFile());
        QMdiSubWindow *sub = m_mdiArea->activeSubWindow();
        if (sub) {
            CodeEditor *editor = qobject_cast<CodeEditor*>(sub->widget());
            if (editor) {
                QTextCursor cursor = editor->textCursor();
                cursor.movePosition(QTextCursor::Start);
                cursor.movePosition(QTextCursor::Down, QTextCursor::MoveAnchor, line);
                cursor.movePosition(QTextCursor::Right, QTextCursor::MoveAnchor, col);
                editor->setTextCursor(cursor);
            }
        }
    }
}

void MainWindow::applyDeveloperTheme() {
    // Borland Turbo Pascal style: Dark Blue background
    setStyleSheet("QMainWindow { background-color: #0000aa; }"
                  "QMdiArea { background-color: #0000aa; }"
                  "QDockWidget { background-color: #0000aa; color: #aaaaaa; }"
                  "QPlainTextEdit { background-color: #0000aa; color: #aaaaaa; }");
}
