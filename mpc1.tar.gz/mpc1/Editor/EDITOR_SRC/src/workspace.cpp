#include "workspace.h"
#include "solution.h"
#include "project.h"
#include "projectpropertiesdialog.h"
#include <QTreeWidgetItem>
#include <QDir>
#include <QFileInfo>
#include <QVBoxLayout>
#include <QPushButton>
#include <QHBoxLayout>
#include <QFileDialog>
#include <QMessageBox>
#include <QInputDialog>
#include <QMenu>
#include <QAction>

WorkspaceWidget::WorkspaceWidget(QWidget *parent)
    : QWidget(parent), m_tree(new QTreeWidget(this)) {

    m_tree->setHeaderHidden(true);
    m_tree->setIndentation(20);
    m_tree->setAnimated(true);
    m_tree->setSelectionMode(QAbstractItemView::SingleSelection);
    m_tree->setDragEnabled(true);
    m_tree->setAcceptDrops(true);
    m_tree->setDropIndicatorShown(true);
    m_tree->setDefaultDropAction(Qt::MoveAction);

    m_fileTypes[".pas"] = "Matrix Pascal";
    m_fileTypes[".c"] = "C Source";
    m_fileTypes[".asm"] = "NASM Assembly";
    m_fileTypes[".mak"] = "Makefile";
    m_fileTypes[".cfg"] = "Config";

    QVBoxLayout *layout = new QVBoxLayout(this);
    layout->setContentsMargins(2, 2, 2, 2);
    layout->setSpacing(2);

    QHBoxLayout *btnLayout = new QHBoxLayout();
    QPushButton *openBtn = new QPushButton("Open", this);
    QPushButton *addBtn = new QPushButton("Add", this);
    QPushButton *newBtn = new QPushButton("New Project", this);
    QPushButton *newFileBtn = new QPushButton("New File", this);
    QPushButton *refreshBtn = new QPushButton("Refresh", this);
    btnLayout->addWidget(openBtn);
    btnLayout->addWidget(addBtn);
    btnLayout->addWidget(newBtn);
    btnLayout->addWidget(newFileBtn);
    btnLayout->addWidget(refreshBtn);
    btnLayout->addStretch();

    layout->addLayout(btnLayout);
    layout->addWidget(m_tree);

    connect(openBtn, &QPushButton::clicked, this, &WorkspaceWidget::openProject);
    connect(addBtn, &QPushButton::clicked, this, &WorkspaceWidget::addProject);
    connect(newBtn, &QPushButton::clicked, this, &WorkspaceWidget::createProjectFromTemplate);
    connect(newFileBtn, &QPushButton::clicked, this, &WorkspaceWidget::createNewFile);
    connect(refreshBtn, &QPushButton::clicked, this, &WorkspaceWidget::rebuildTree);
    m_tree->setContextMenuPolicy(Qt::CustomContextMenu);
    connect(m_tree, &QTreeWidget::customContextMenuRequested, this, [this](const QPoint &pos) {
        QTreeWidgetItem *item = m_tree->itemAt(pos);
        if (!item) return;

        QVariant data = item->data(0, Qt::UserRole);
        if (!data.isValid() || !data.toString().startsWith("/")) return;
        QString filePath = data.toString();

        QMenu menu(this);
        QAction *renameAction = menu.addAction("Rename");
        QAction *deleteAction = menu.addAction("Delete");
        QAction *propsAction = menu.addAction("Properties");

        QAction *selectedAction = menu.exec(m_tree->mapToGlobal(pos));
        if (selectedAction == renameAction) {
            bool ok;
            QString newName = QInputDialog::getText(this, "Rename", "New name:", QLineEdit::Normal, QFileInfo(filePath).fileName(), &ok);
            if (ok && !newName.isEmpty()) {
                QFile::rename(filePath, QFileInfo(filePath).absolutePath() + "/" + newName);
                populateTree();
            }
        } else if (selectedAction == deleteAction) {
            if (QMessageBox::question(this, "Delete", "Are you sure you want to delete " + QFileInfo(filePath).fileName() + "?") == QMessageBox::Yes) {
                QFile::remove(filePath);
                populateTree();
            }
        } else if (selectedAction == propsAction) {
            ProjectPropertiesDialog dlg(this);
            // In a real implementation, we'd load the project file here
            dlg.exec();
        }
    });

    connect(m_tree, &QTreeWidget::itemClicked, this, [this](QTreeWidgetItem *item, int col) {
        Q_UNUSED(col)
        QVariant data = item->data(0, Qt::UserRole);
        if (data.isValid() && data.toString().startsWith("/")) {
            emit fileSelected(data.toString());
        }
    });
}

WorkspaceWidget::~WorkspaceWidget() {
}

void WorkspaceWidget::createProjectFromTemplate() {
    QStringList templates = QDir("../templates").entryList(QDir::Dirs | QDir::NoDotAndDotDot);
    bool ok;
    QString templateName = QInputDialog::getItem(this, "New Project", "Select template:", templates, 0, false, &ok);
    if (!ok || templateName.isEmpty()) return;

    QString targetDir = QFileDialog::getExistingDirectory(this, "Select Project Location");
    if (targetDir.isEmpty()) return;

    QDir sourceDir("../templates/" + templateName);
    QDir destDir(targetDir);
    
    for (const QFileInfo &info : sourceDir.entryInfoList(QDir::Files)) {
        QFile::copy(info.absoluteFilePath(), destDir.absoluteFilePath(info.fileName()));
    }
    
    setProjectRoot(targetDir);
}

void WorkspaceWidget::createNewFile() {
    if (m_projectRoots.isEmpty()) return;

    // Default to the first project root
    QString root = m_projectRoots.first();
    bool ok;
    QString fileName = QInputDialog::getText(this, "New File", "Filename:", QLineEdit::Normal, "", &ok);
    if (!ok || fileName.isEmpty()) return;

    QFile file(root + "/" + fileName);
    if (file.open(QIODevice::WriteOnly)) {
        file.close();
        populateTree();
    }
}

// Rest of the methods (openProject, closeProject, etc.) remain largely the same or are slightly updated...
bool WorkspaceWidget::loadConfig(const QString &cfgPath) { /* ... existing implementation ... */ return true; }
bool WorkspaceWidget::saveConfig(const QString &cfgPath) { Q_UNUSED(cfgPath); return true; }

void WorkspaceWidget::setProjectRoot(const QString &rootPath) {
    m_projectRoots.clear();
    m_projectRoots.append(rootPath);
    populateTree();
    emit projectOpened(rootPath);
}

void WorkspaceWidget::addProjectRoot(const QString &rootPath) {
    if (!m_projectRoots.contains(rootPath)) {
        m_projectRoots.append(rootPath);
        populateTree();
        emit projectOpened(rootPath);
    }
}

QStringList WorkspaceWidget::projectRoots() const { return m_projectRoots; }

QStringList WorkspaceWidget::sourceFiles() const {
    QStringList files;
    for (int i = 0; i < m_tree->topLevelItemCount(); ++i)
        collectFilePaths(m_tree->topLevelItem(i), files);
    return files;
}

QStringList WorkspaceWidget::makefiles() const {
    QStringList files;
    for (int i = 0; i < m_tree->topLevelItemCount(); ++i)
        collectMakefiles(m_tree->topLevelItem(i), files);
    return files;
}

void WorkspaceWidget::refresh() { populateTree(); }

void WorkspaceWidget::openProject() {
    QString file = QFileDialog::getOpenFileName(this, "Open Project", m_projectRoots.isEmpty() ? "" : m_projectRoots.first(), "Project Files (*.proj)");
    if (!file.isEmpty()) setProjectRoot(file);
}

void WorkspaceWidget::addProject() {
    QString file = QFileDialog::getOpenFileName(this, "Add Project", m_projectRoots.isEmpty() ? "" : m_projectRoots.first(), "Project Files (*.proj)");
    if (!file.isEmpty()) addProjectRoot(file);
}

void WorkspaceWidget::closeProject() {
    m_projectRoots.clear();
    m_tree->clear();
    emit projectClosed();
}
void WorkspaceWidget::addFile(const QString &filePath) { Q_UNUSED(filePath) }
void WorkspaceWidget::removeFile(const QString &filePath) { Q_UNUSED(filePath) }
void WorkspaceWidget::rebuildTree() { populateTree(); }

#include "project.h"

// ... inside WorkspaceWidget::populateTree()
void WorkspaceWidget::populateTree() {
    m_tree->clear();
    for (const QString &rootPath : m_projectRoots) {
        if (rootPath.endsWith(".proj")) { // Assuming .proj for project files
            Project proj;
            if (proj.load(rootPath)) {
                QTreeWidgetItem *rootItem = new QTreeWidgetItem(m_tree, {proj.name});
                rootItem->setData(0, Qt::UserRole, rootPath);
                for (const QString &file : proj.files) {
                    QTreeWidgetItem *fileItem = new QTreeWidgetItem(rootItem, {QFileInfo(file).fileName()});
                    fileItem->setData(0, Qt::UserRole, file);
                }
            }
        } else { // fallback to directory
            QDir rootDir(rootPath);
            QTreeWidgetItem *rootItem = new QTreeWidgetItem(m_tree, {rootDir.dirName()});
            rootItem->setData(0, Qt::UserRole, rootPath);
            scanDirectory(rootPath, rootItem);
        }
    }
    m_tree->expandAll();
}
void WorkspaceWidget::scanDirectory(const QString &dirPath, QTreeWidgetItem *parent) { QDir dir(dirPath); QFileInfoList entries = dir.entryInfoList(QDir::Dirs | QDir::Files | QDir::NoDotAndDotDot); for (const QFileInfo &info : entries) { if (info.isDir()) { QTreeWidgetItem *dirItem = new QTreeWidgetItem(parent, {info.fileName()}); dirItem->setData(0, Qt::UserRole, info.absoluteFilePath()); scanDirectory(info.absoluteFilePath(), dirItem); } else if (info.isFile()) { QString suffix = info.suffix().toLower(); if (m_fileTypes.contains("." + suffix) || suffix == "mak") { QTreeWidgetItem *fileItem = new QTreeWidgetItem(parent, {info.fileName()}); fileItem->setData(0, Qt::UserRole, info.absoluteFilePath()); } } } }
void WorkspaceWidget::collectFilePaths(QTreeWidgetItem *item, QStringList &files) const { QVariant data = item->data(0, Qt::UserRole); if (data.isValid() && data.toString().startsWith("/") && QFileInfo(data.toString()).isFile()) files.append(data.toString()); for (int i = 0; i < item->childCount(); ++i) collectFilePaths(item->child(i), files); }
void WorkspaceWidget::collectMakefiles(QTreeWidgetItem *item, QStringList &files) const { QVariant data = item->data(0, Qt::UserRole); if (data.isValid() && data.toString().endsWith(".mak")) files.append(data.toString()); for (int i = 0; i < item->childCount(); ++i) collectMakefiles(item->child(i), files); }
QString WorkspaceWidget::iconForFile(const QString &filePath) const { QString suffix = QFileInfo(filePath).suffix().toLower(); if (suffix == "pas") return "pascal"; if (suffix == "c") return "c"; if (suffix == "asm") return "asm"; if (suffix == "mak") return "makefile"; return "generic"; }
