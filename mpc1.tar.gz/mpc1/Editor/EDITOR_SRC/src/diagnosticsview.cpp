#include "diagnosticsview.h"

DiagnosticsView::DiagnosticsView(QWidget *parent) : QTreeWidget(parent) {
    setHeaderLabels({"File", "Line", "Message"});
}

void DiagnosticsView::addDiagnostic(const QString &file, int line, const QString &message) {
    new QTreeWidgetItem(this, {file, QString::number(line + 1), message});
}

void DiagnosticsView::clearDiagnostics() {
    clear();
}
