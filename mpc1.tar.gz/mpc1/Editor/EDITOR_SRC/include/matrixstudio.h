#ifndef MATRIXSTUDIO_H
#define MATRIXSTUDIO_H

#include <QApplication>

class MatrixStudio : public QApplication {
public:
    MatrixStudio(int &argc, char **argv) : QApplication(argc, argv) {}
};

#endif
