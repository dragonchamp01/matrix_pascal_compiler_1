#ifndef SYNTAXHIGHLIGHTER_H
#define SYNTAXHIGHLIGHTER_H

#include <QSyntaxHighlighter>
#include <QTextCharFormat>
#include <QRegularExpression>

class QTextDocument;

class SyntaxHighlighter : public QSyntaxHighlighter {
    Q_OBJECT

public:
    enum Language { Pascal, C, Nasm };

    explicit SyntaxHighlighter(QTextDocument *parent = nullptr);
    ~SyntaxHighlighter();

    void setLanguage(Language lang);
    Language language() const;

protected:
    void highlightBlock(const QString &text) override;

private:
    struct HighlightRule {
        QRegularExpression pattern;
        QTextCharFormat format;
    };

    Language m_language;
    QVector<HighlightRule> m_rules;

    QTextCharFormat m_keywordFormat;
    QTextCharFormat m_stringFormat;
    QTextCharFormat m_numberFormat;
    QTextCharFormat m_commentFormat;
    QTextCharFormat m_operatorFormat;
    QTextCharFormat m_identifierFormat;
    QTextCharFormat m_asmDirectiveFormat;
    QTextCharFormat m_registerFormat;
    QTextCharFormat m_preprocessorFormat;

    void setupPascalRules();
    void setupCRules();
    void setupNasmRules();
    void initFormats();

    void highlightPascalBlockComments(const QString &text);
    void highlightPascalStringLiterals(const QString &text);
    void highlightCBlockComments(const QString &text);
    void highlightCStringLiterals(const QString &text);
    void highlightNasmComments(const QString &text);
};

#endif
