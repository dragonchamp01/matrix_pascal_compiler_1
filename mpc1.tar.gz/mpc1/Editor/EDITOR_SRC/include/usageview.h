#ifndef USAGEVIEW_H
#define USAGEVIEW_H

#include <QWidget>
#include <QList>
#include <QString>
#include <QVariant>

struct UsageEntry {
    QString file;
    int line;
    int column;
};
Q_DECLARE_METATYPE(UsageEntry)

class QTableWidget;

class UsageView : public QWidget {
    Q_OBJECT
public:
    explicit UsageView(QWidget *parent = nullptr);
    void setUsages(const QList<UsageEntry> &usages);
    void clear();

signals:
    void entryActivated(const QString &file, int line, int column);

private:
    QTableWidget *m_table;
};

#endif

