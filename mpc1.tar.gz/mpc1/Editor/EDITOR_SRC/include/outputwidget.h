#ifndef OUTPUTWIDGET_H
#define OUTPUTWIDGET_H

#include <QWidget>
#include <QPlainTextEdit>
#include <QMap>
#include <QSet>

class QComboBox;

class OutputWidget : public QWidget {
    Q_OBJECT

public:
    explicit OutputWidget(QWidget *parent = nullptr);
    void appendOutput(const QString &text);
    void appendOutput(const QString &text, const QString &channel);
    void clearOutput();
    void clearOutput(const QString &channel);
    void setChannel(const QString &channel);

signals:
    void textAppended(const QString &text, const QString &channel);

private:
    QPlainTextEdit *m_outputDisplay;
    QComboBox *m_channelCombo;
    QMap<QString, QString> m_channelBuffer;
    QSet<QString> m_channels;
    QString m_currentChannel;

    void showChannel(const QString &channel);
};

#endif
