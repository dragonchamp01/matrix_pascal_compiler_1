#ifndef GITMANAGER_H
#define GITMANAGER_H

#include <QObject>
#include <QProcess>
#include <QString>

class GitManager : public QObject {
    Q_OBJECT
public:
    explicit GitManager(QObject *parent = nullptr);
    void runCommand(const QStringList &args);

signals:
    void outputReceived(const QString &output);

private:
    QProcess m_process;
};

#endif
