# Matrix Pascal Language Manual

**Author:** marco hagenaars grim reaper neo

Welcome to the official documentation for Matrix Pascal, a high-performance compiler targeting scientific computing and AI/ML.

## Sections

### Keywords
- [Keywords Index](keywords/index.htm)

### Types
- [Types Index](types/index.htm)

### Operators
- [Operators Index](operators/index.htm)

### Examples
- [Examples Index](examples/index.htm)

### Specifications
- [Language Specification](specs/language-spec.htm)
- [Compiler Architecture](specs/compiler-arch.htm)
- [RTL Architecture](specs/rtl-arch.htm)
