# Neo Graphic Engine — Unit Reference

## Overview

The Neo Graphic Engine is a **software-rendered retro 3D engine** for demo scene productions,
written in Matrix Pascal with hand-optimized x86-64 assembly. Runs on Linux framebuffer (`/dev/fb0`).

## Core Subdirectory (`core/`)

| Unit | Description |
|------|-------------|
| `neo_core` | Base engine core — framebuffer init, mmap `/dev/fb0`, double-buffering, Z-buffer |
| `neo_asm` | External ASM routine declarations (`cdecl; external`) |
| `neo_asm_impl` | x86-64 inline ASM implementations (clear_screen, put_pixel, blit, alpha, line, XOR cipher) |
| `neo_interrupts` | 60 FPS frame timer (busy-wait) |
| `neo_interrupts_impl` | SIGALRM signal handler via rt_sigaction syscall (hardware-level interrupt) |
| `neo_core_branchless` | Branchless integer select, clamp, step |
| `neo_core_job_system` | Job queue with critical section synchronization |
| `neo_core_scripting` | Script execution stub |
| `neo_math_vec` | TVec2, TVec3, TVec4 vector math (add, sub, dot, cross, normalize, lerp) |
| `neo_math_mat` | TMat4 4x4 matrix (identity, multiply, translate, rotate, scale, perspective, ortho, lookAt) |
| `neo_math_quat` | TQuaternion (normalize, multiply, slerp, rotation matrix) |
| `neo_math_fast` | Fast inverse sqrt (Quake III), fast sin/cos, fast pow/log2 |
| `neo_math_trig_fast` | Bhaskara/Taylor fast trig approximations |
| `neo_math_noise` | 3D Perlin noise with permutation table |
| `neo_math_spline` | Bezier + Catmull-Rom spline evaluation |
| `neo_demo_sequencer` | Timed demo scene sequencer |

## Graphics Subdirectory (`graphics/`)

| Unit | Description |
|------|-------------|
| `neo_graphics` | Core 2D/3D graphics — clear, pixels, lines, rects, tri fill, text, scrollers, plasma, starfield, copper bars, tunnel, fire, 3D cube, rotozoom, CRT filter, bloom |
| `neo_render_graph` | Render pass pipeline (init → execute → shutdown) |
| `neo_render_path` | Render path (precompiled .o) |
| `neo_render_pbr` | PBR rendering (precompiled .o) |
| `neo_render_raymarch_elite` | Elite raymarcher (precompiled .o) |

## Audio Subdirectory (`audio/`)

| Unit | Description |
|------|-------------|
| `neo_audio` | WAV playback via ALSA |
| `neo_audio_core` | Audio mixer and sample management |
| `neo_audio_wav` | WAV file loader/decoder |
| `neo_audio_mp3` | MP3 streaming |
| `neo_audio_dsp` | DSP effects (reverb, compressor, EQ, limiter, delay, chorus, flanger, phaser, distortion, wah-wah, vocoder, spatial) |
| `neo_audio_fm` | FM synthesis with multiple operators |
| `neo_audio_fft` | FFT audio spectrum analysis |
| `neo_audio_mixer` | Multi-channel audio mixing |
| `neo_audio_synth` | Waveform synthesis (sine, saw, square, triangle, noise) |

## Effects Subdirectory (`effects/`)

| Unit | Description |
|------|-------------|
| `neo_particles_core` | Particle emitter base |
| `neo_particles_emitter` | Particle emission patterns |
| `neo_particles_collision` | Particle collision detection |
| `neo_particles_fluid` | Fluid particle simulation |
| `neo_particles_boids` | Boids flocking algorithm |
| `neo_particles_attractor` | Particle attractor forces |
| `neo_particles_instanced` | Instanced particle rendering |
| `neo_effect_fire` | Fire/combustion simulation |
| `neo_effect_smoke` | Volumetric smoke |
| `neo_effect_sky` | Sky/atmosphere rendering |
| Additional effects: | plasma, tunnel, rotozoom, starfield, copper bars, mandelbrot, matrix rain, lightning, water ripple, morphing, metaballs, blobs, lens flare, glow, shockwave, heat shimmer, DOF, parallax, bump mapping, normal mapping, environment mapping, glass, ice, snow, rain, cloud, fog, explosion, trail, beam, aura, vortex |

## Font Subdirectory (`font/`)

| Unit | Description |
|------|-------------|
| `neo_font` | Base font system |
| `neo_font_loader` | .FNT bitmap font loading |
| `neo_font_sdf` | Signed-distance field font rendering |
| `neo_font_3d` | 3D text rendering |
| `neo_font_neon` | Neon glow text style |
| `neo_font_gothic` | Gothic text style |
| `neo_scroller` | Sine-wave text scroller |

## Physics Subdirectory (`physics/`)

| Unit | Description |
|------|-------------|
| `neo_physics_core` | Newtonian physics (drag, Euler integration) |
| `neo_physics_rigid` | Rigid body dynamics (angular velocity, quaternion) |
| `neo_physics_collision` | Collision detection (AABB, sphere, OBB, ray, mesh, capsule, terrain, compound) |
| `neo_physics_constraint` | Constraints (joints, springs, hinges, ragdoll) |
| `neo_phys_cloth` | Cloth simulation |
| `neo_phys_fluid_sph` | SPH fluid simulation |
| `neo_phys_softbody` | Softbody physics |
| `neo_phys_destruction` | Destruction/shattering |

## Packer Subdirectory (`packer/`)

| Unit | Description |
|------|-------------|
| `neo_pak` | PAK archive system (ZLib compression + XOR encryption) |
| `neo_pak_writer` | PAK archive creation |
| `neo_pak_reader` | PAK archive reading/extraction |

## VR Subdirectory (`vr/`)

Precompiled `.mpi` interfaces (no `.pas` source):

| Unit | Description |
|------|-------------|
| `neo_vr_core` | 3D object loading and VR projection |
| Others: | Frustum culling, shadow mapping, PBR lighting, BVH, IK solver, skinning |

## Root-Level Units

| Unit | Description |
|------|-------------|
| `neo_engine` | Facade engine class — owns all subsystems (graphics, input, audio, timer, profiler, events, render) |
| `neo_3d` | Simple software 3D mesh renderer (transform, project, flat shade) |
| `neo_anim_controller` | Animation state machine (play, crossfade clips) |
| `neo_anim_core` | Bone hierarchy and skeleton transforms |
| `neo_anim_ik` | CCD inverse kinematics solver |
| `neo_anim_keyframe` | Keyframe animation clips (position lerp, rotation slerp) |
| `neo_anim_skinning` | GPU-style vertex skinning (4 bone weights) |
| `neo_engine_asset_loader` | Dictionary-based asset cache |
| `neo_engine_config_loader` | Config key-value store |
| `neo_engine_memory` | Stack allocator (frame pool + global pool) |
| `neo_engine_state` | Engine state machine + global context (delta time) |
| `neo_engine_sync` | Audio-master timing sync |
| `neo_event_bus` | Publish-subscribe event bus |
| `neo_event_system` | Event dispatcher (immediate + queue) |
| `neo_geom_procedural` | Procedural geometry (box, torus, sphere, terrain) |
| `neo_image` | JPEG image loader + blitter |
| `neo_input` | Input state array (keyboard/mouse) |
| `neo_input_gesture` | Gesture recognizer (click, drag, swipe, pinch) |
| `neo_input_mapping` | Action-to-key binding system |
| `neo_input_midi` | MIDI event interface |
| `neo_palette` | Color palette with gradient generation |
| `neo_postprocess` | Post-processing (CRT, bloom, color grading) |
| `neo_proc_automata` | Conway's Game of Life cellular automaton |
| `neo_proc_city` | Procedural city generator (skyline) |
| `neo_proc_erosion` | Thermal + hydraulic terrain erosion |
| `neo_proc_lsystem` | L-system string generator + turtle renderer |
| `neo_proc_perlin_worley` | Perlin + Worley combined noise |
| `neo_raycaster` | Wolfenstein-style raycaster |
| `neo_resource_cache` | Resource cache with PAK backing |
| `neo_resource_manager` | Resource manager |
| `neo_scene_daynight` | Sun direction cycling |
| `neo_scene_graph` | Scene graph with transform hierarchy |
| `neo_scene_lod_manager` | Distance-based LOD assignment |
| `neo_scene_navmesh` | A* pathfinding on grid |
| `neo_scene_occlusion` | Occlusion query |
| `neo_scene_spatial_hash` | 3D spatial hash grid |
| `neo_scene` | Scene manager with timeline |
| `neo_sprite` | Sprite class (image + alpha blit) |
| `neo_tex_synthesis` | Seamless noise + tiled pattern generation |
| `neo_texture_proc` | Procedural textures (Perlin, Voronoi, checkerboard, gradient) |

## UI Toolkit Units

| Unit | Description |
|------|-------------|
| `neo_ui_base` | Base UI element (parent/child, events, rendering) |
| `neo_ui_animation` | Lerp-based UI animation |
| `neo_ui_canvas` | Drawing canvas (Bresenham, circles, Bezier, text) |
| `neo_ui_canvas_api` | Canvas API (gradient, rounded rect, arc) |
| `neo_ui_button` | Clickable button (hover/pressed) |
| `neo_ui_checkbox` | Checkbox toggle |
| `neo_ui_dialog` | Modal dialog (OK/Cancel) |
| `neo_ui_dropdown` | Dropdown list |
| `neo_ui_grid` | Data grid view |
| `neo_ui_list` | Scrollable list with selection |
| `neo_ui_menu` | Menu with items and submenus |
| `neo_ui_panel` | Container (absolute/vertical/horizontal) |
| `neo_ui_scrollview` | Scrollable viewport |
| `neo_ui_slider` | Draggable slider |
| `neo_ui_tab` | Tab control |
| `neo_ui_textbox` | Text input with keyboard |
| `neo_ui_theme` | Theme color manager |
| `neo_ui_tooltip` | Tooltip popup |
| `neo_ui_tree` | Tree view |
| `neo_ui_tween` | Value tween (linear interpolation) |
| `neo_ui_window` | Draggable/resizable window |

## ASM Routines

| Routine | Purpose |
|---------|---------|
| `neo_clear_screen` | Fill framebuffer with color (`rep stosq`) |
| `neo_put_pixel` | Plot single pixel |
| `neo_blit` | Copy rectangle (`movdqa`/`movdqu`) |
| `neo_blit_alpha` | Alpha-blend rectangle (`pavgb`, `paddb`) |
| `neo_draw_line` | Bresenham line drawing |
| `neo_xor_cipher` | XOR data encryption |

All routines use `assembler64` Intel syntax via `{ $ASMMODE INTEL }`.

## Summary by Implementation Status

| Module | Status |
|--------|--------|
| Core (framebuffer, ASM) | ~90% complete |
| Math library | ~95% complete |
| Graphics 2D | ~80% complete |
| Graphics 3D | ~30% complete |
| Animation | ~60% complete |
| UI Toolkit | ~50% complete |
| Audio | ~40% complete |
| Physics | ~50% complete |
| Procedural Gen | ~60% complete |
| Packer | ~80% complete |
| Post-processing | ~70% complete |
| Event System | ~80% complete |
| Resource Management | ~60% complete |

## See Also

- [Demo Scene Guide (HTML)](docs/demo-scene/index.htm)
- [Neo Engine Units Index](neo_engine_units.md)
- [Project Specifications](project_specs.md)
