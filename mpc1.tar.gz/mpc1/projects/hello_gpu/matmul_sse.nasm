; Matrix Pascal — SSE-optimized 4x4 matmul kernel
; Computes C[0..3] += A[0..3] * B[0..3] (4x4 block)
; Arguments: rdi = A, rsi = B, rcx = C
section .text
global matmul_block_4x4
matmul_block_4x4:
    push rbx
    xor rbx, rbx
    mov rax, rdi
    mov rdx, rsi
    mov rdi, rcx
.loop_i:
    mov rsi, rdx
    xor r8, r8
.loop_j:
    movupd xmm0, [rax + rbx*8]
    movupd xmm2, [rsi + r8*8]
    mulpd xmm0, xmm2
    movupd xmm1, [rax + rbx*8 + 16]
    movupd xmm3, [rsi + r8*8 + 16]
    mulpd xmm1, xmm3
    haddpd xmm0, xmm1
    movupd xmm4, [rdi + r8*8]
    addpd xmm4, xmm0
    movupd [rdi + r8*8], xmm4
    add r8, 4
    cmp r8, 16
    jl .loop_j
    inc rbx
    cmp rbx, 4
    jl .loop_i
    pop rbx
    ret
