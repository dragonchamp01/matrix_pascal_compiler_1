unit train_data;
interface
uses System, Classes, SysUtils, Math;
type
  TSample = record Inputs, Outputs: array of double; end;
  TDataset = class
  private
    FSamples: array of TSample;
    FSampleCount: integer;
    FInputSize, FOutputSize: integer;
  public
    constructor Create(InputSize, OutputSize: integer);
    procedure AddSample(const Inputs, Outputs: array of double);
    function GetSample(Idx: integer): TSample;
    function Count: integer;
    procedure Shuffle;
    function InputSize: integer;
    function OutputSize: integer;
  end;
implementation
constructor TDataset.Create(InputSize, OutputSize: integer);
begin
  inherited Create;
  FInputSize := InputSize; FOutputSize := OutputSize;
end;
procedure TDataset.AddSample(const Inputs, Outputs: array of double);
var I: integer;
begin
  Inc(FSampleCount); SetLength(FSamples, FSampleCount);
  SetLength(FSamples[FSampleCount-1].Inputs, FInputSize);
  SetLength(FSamples[FSampleCount-1].Outputs, FOutputSize);
  for I := 0 to FInputSize - 1 do FSamples[FSampleCount-1].Inputs[I] := Inputs[I];
  for I := 0 to FOutputSize - 1 do FSamples[FSampleCount-1].Outputs[I] := Outputs[I];
end;
function TDataset.GetSample(Idx: integer): TSample;
begin Result := FSamples[Idx]; end;
function TDataset.Count: integer;
begin Result := FSampleCount; end;
procedure TDataset.Shuffle;
var I, J: integer; Tmp: TSample;
begin
  for I := FSampleCount - 1 downto 1 do
  begin
    J := Random(I + 1);
    Tmp := FSamples[I]; FSamples[I] := FSamples[J]; FSamples[J] := Tmp;
  end;
end;
function TDataset.InputSize: integer;
begin Result := FInputSize; end;
function TDataset.OutputSize: integer;
begin Result := FOutputSize; end;
end.
