program http_auth_bearer;

{$APPTYPE CONSOLE}

type
  THttpAuthBearer = class
  private
    FHost: string;
    FPort: integer;
  public
    constructor Create(AHost: string; APort: integer);
    function Connect: boolean;
    function Send(const Data: string): boolean;
    function Receive: string;
    procedure Disconnect;
  end;

constructor THttpAuthBearer.Create(AHost: string; APort: integer);
begin
  FHost := AHost;
  FPort := APort;
end;

function THttpAuthBearer.Connect: boolean;
begin
  WriteLn('Connecting to ', FHost, ':', FPort);
  Result := true;
end;

function THttpAuthBearer.Send(const Data: string): boolean;
begin
  WriteLn('Sending: ', Data);
  Result := true;
end;

function THttpAuthBearer.Receive: string;
begin
  Result := 'Response from ' + FHost;
end;

procedure THttpAuthBearer.Disconnect;
begin
  WriteLn('Disconnected from ', FHost);
end;

var
  Client: THttpAuthBearer;
begin
  Client := THttpAuthBearer.Create('localhost', 8080);
  WriteLn('http_auth_bearer example');
  if Client.Connect then
  begin
    Client.Send('Hello');
    WriteLn('Received: ', Client.Receive);
    Client.Disconnect;
  end;
  WriteLn('http_auth_bearer complete.');
end.
