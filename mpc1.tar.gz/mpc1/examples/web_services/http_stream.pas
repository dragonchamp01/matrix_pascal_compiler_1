program http_stream;

{$APPTYPE CONSOLE}

type
  THttpStream = class
  private
    FHost: string;
    FPort: integer;
  public
    constructor Create(AHost: string; APort: integer);
    function Connect: boolean;
    function Send(const Data: string): boolean;
    function Receive: string;
    procedure Disconnect;
  end;

constructor THttpStream.Create(AHost: string; APort: integer);
begin
  FHost := AHost;
  FPort := APort;
end;

function THttpStream.Connect: boolean;
begin
  WriteLn('Connecting to ', FHost, ':', FPort);
  Result := true;
end;

function THttpStream.Send(const Data: string): boolean;
begin
  WriteLn('Sending: ', Data);
  Result := true;
end;

function THttpStream.Receive: string;
begin
  Result := 'Response from ' + FHost;
end;

procedure THttpStream.Disconnect;
begin
  WriteLn('Disconnected from ', FHost);
end;

var
  Client: THttpStream;
begin
  Client := THttpStream.Create('localhost', 8080);
  WriteLn('http_stream example');
  if Client.Connect then
  begin
    Client.Send('Hello');
    WriteLn('Received: ', Client.Receive);
    Client.Disconnect;
  end;
  WriteLn('http_stream complete.');
end.
