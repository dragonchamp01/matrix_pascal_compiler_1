program Tutorial3;

uses Xorg;

var
  display: PDisplay;
  window: PWindow;
  screen: integer;
  root: integer;
  white_pixel: uint32;
  black_pixel: uint32;
  event: PXEvent;
  key_event: PXKeyEvent;

begin
  display := XOpenDisplay(nil);
  if display = nil then
  begin
    WriteLn('Error: Cannot open X display.');
    exit;
  end;

  screen := XDefaultScreen(display);
  root := XDefaultRootWindow(display);
  white_pixel := XDefaultWhitePixel(display, screen);
  black_pixel := XDefaultBlackPixel(display, screen);

  window := XCreateSimpleWindow(display, root, 100, 100, 400, 300, 1, black_pixel, white_pixel);
  // Select KeyPress events
  XSelectInput(display, window, KeyPressMask);
  XMapWindow(display, window);

  WriteLn('Window created. Press any key to exit...');

  // Event loop
  while True do
  begin
    XNextEvent(display, event);
    if event.type = KeyPress then
    begin
      key_event := PXKeyEvent(event.data); // This is a bit dangerous without proper union handling, but works for demo
      // Note: in real Pascal, we'd use a better way to handle the union.
      // Here we just cast the pointer.
      WriteLn('Key pressed!');
      break;
    end;
  end;

  XDestroyWindow(display, window);
  XCloseDisplay(display);
  WriteLn('Done.');
end.
