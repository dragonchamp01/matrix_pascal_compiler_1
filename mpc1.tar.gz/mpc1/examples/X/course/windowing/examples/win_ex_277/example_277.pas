program Example_277;

uses Windowing;

begin
  Initialize;
  
  var win := CreateWindow('Example 277');
  ShowWindow(win);
  
  MessageBox('Example 277', 'Hello from Windowing API!');
  
  CloseWindow(win);
  Terminate;
end.