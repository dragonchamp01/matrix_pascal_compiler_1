program Example_235;

uses Windowing;

begin
  Initialize;
  
  var win := CreateWindow('Example 235');
  ShowWindow(win);
  
  MessageBox('Example 235', 'Hello from Windowing API!');
  
  CloseWindow(win);
  Terminate;
end.