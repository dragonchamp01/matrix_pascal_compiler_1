program Example_064;

uses Windowing;

begin
  Initialize;
  
  var win := CreateWindow('Example 064');
  ShowWindow(win);
  
  MessageBox('Example 064', 'Hello from Windowing API!');
  
  CloseWindow(win);
  Terminate;
end.