program Example_143;

uses Windowing;

begin
  Initialize;
  
  var win := CreateWindow('Example 143');
  ShowWindow(win);
  
  MessageBox('Example 143', 'Hello from Windowing API!');
  
  CloseWindow(win);
  Terminate;
end.