program Example_300;

uses Windowing;

begin
  Initialize;
  
  var win := CreateWindow('Example 300');
  ShowWindow(win);
  
  MessageBox('Example 300', 'Hello from Windowing API!');
  
  CloseWindow(win);
  Terminate;
end.