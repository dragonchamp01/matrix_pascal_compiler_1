program Example_185;

uses Windowing;

begin
  Initialize;
  
  var win := CreateWindow('Example 185');
  ShowWindow(win);
  
  MessageBox('Example 185', 'Hello from Windowing API!');
  
  CloseWindow(win);
  Terminate;
end.