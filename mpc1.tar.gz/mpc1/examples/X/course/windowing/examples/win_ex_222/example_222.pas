program Example_222;

uses Windowing;

begin
  Initialize;
  
  var win := CreateWindow('Example 222');
  ShowWindow(win);
  
  MessageBox('Example 222', 'Hello from Windowing API!');
  
  CloseWindow(win);
  Terminate;
end.