program Example_263;

uses Windowing;

begin
  Initialize;
  
  var win := CreateWindow('Example 263');
  ShowWindow(win);
  
  MessageBox('Example 263', 'Hello from Windowing API!');
  
  CloseWindow(win);
  Terminate;
end.