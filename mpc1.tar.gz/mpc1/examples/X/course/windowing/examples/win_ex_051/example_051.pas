program Example_051;

uses Windowing;

begin
  Initialize;
  
  var win := CreateWindow('Example 051');
  ShowWindow(win);
  
  MessageBox('Example 051', 'Hello from Windowing API!');
  
  CloseWindow(win);
  Terminate;
end.