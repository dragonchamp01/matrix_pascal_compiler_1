program Example_128;

uses Windowing;

begin
  Initialize;
  
  var win := CreateWindow('Example 128');
  ShowWindow(win);
  
  MessageBox('Example 128', 'Hello from Windowing API!');
  
  CloseWindow(win);
  Terminate;
end.