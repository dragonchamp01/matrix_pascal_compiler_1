program Example_250;

uses Windowing;

begin
  Initialize;
  
  var win := CreateWindow('Example 250');
  ShowWindow(win);
  
  MessageBox('Example 250', 'Hello from Windowing API!');
  
  CloseWindow(win);
  Terminate;
end.