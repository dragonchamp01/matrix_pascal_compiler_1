program Example_036;

uses Windowing;

begin
  Initialize;
  
  var win := CreateWindow('Example 036');
  ShowWindow(win);
  
  MessageBox('Example 036', 'Hello from Windowing API!');
  
  CloseWindow(win);
  Terminate;
end.