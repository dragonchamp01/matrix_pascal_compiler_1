program Example_292;

uses Windowing;

begin
  Initialize;
  
  var win := CreateWindow('Example 292');
  ShowWindow(win);
  
  MessageBox('Example 292', 'Hello from Windowing API!');
  
  CloseWindow(win);
  Terminate;
end.