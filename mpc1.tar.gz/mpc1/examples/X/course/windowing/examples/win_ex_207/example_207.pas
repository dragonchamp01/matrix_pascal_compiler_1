program Example_207;

uses Windowing;

begin
  Initialize;
  
  var win := CreateWindow('Example 207');
  ShowWindow(win);
  
  MessageBox('Example 207', 'Hello from Windowing API!');
  
  CloseWindow(win);
  Terminate;
end.