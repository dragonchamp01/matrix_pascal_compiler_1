program Example_198;

uses Windowing;

begin
  Initialize;
  
  var win := CreateWindow('Example 198');
  ShowWindow(win);
  
  MessageBox('Example 198', 'Hello from Windowing API!');
  
  CloseWindow(win);
  Terminate;
end.