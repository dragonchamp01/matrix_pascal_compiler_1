program Example_101;

uses Windowing;

begin
  Initialize;
  
  var win := CreateWindow('Example 101');
  ShowWindow(win);
  
  MessageBox('Example 101', 'Hello from Windowing API!');
  
  CloseWindow(win);
  Terminate;
end.