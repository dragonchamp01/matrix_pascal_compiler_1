program Example_093;

uses Windowing;

begin
  Initialize;
  
  var win := CreateWindow('Example 093');
  ShowWindow(win);
  
  MessageBox('Example 093', 'Hello from Windowing API!');
  
  CloseWindow(win);
  Terminate;
end.