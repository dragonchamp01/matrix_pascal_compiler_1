program Example_171;

uses Windowing;

begin
  Initialize;
  
  var win := CreateWindow('Example 171');
  ShowWindow(win);
  
  MessageBox('Example 171', 'Hello from Windowing API!');
  
  CloseWindow(win);
  Terminate;
end.