program Example_008;

uses Windowing;

begin
  Initialize;
  
  var win := CreateWindow('Example 008');
  ShowWindow(win);
  
  MessageBox('Example 008', 'Hello from Windowing API!');
  
  CloseWindow(win);
  Terminate;
end.