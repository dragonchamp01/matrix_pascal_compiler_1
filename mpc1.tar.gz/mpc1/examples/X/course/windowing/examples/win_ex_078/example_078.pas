program Example_078;

uses Windowing;

begin
  Initialize;
  
  var win := CreateWindow('Example 078');
  ShowWindow(win);
  
  MessageBox('Example 078', 'Hello from Windowing API!');
  
  CloseWindow(win);
  Terminate;
end.