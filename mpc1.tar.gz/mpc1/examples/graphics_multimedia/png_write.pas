program png_write;

{$APPTYPE CONSOLE}

type
  TPngWrite = class
  private
    FWidth: integer;
    FHeight: integer;
  public
    constructor Create(AWidth, AHeight: integer);
    procedure Render;
    procedure Process;
    function GetInfo: string;
  end;

constructor TPngWrite.Create(AWidth, AHeight: integer);
begin
  FWidth := AWidth;
  FHeight := AHeight;
end;

procedure TPngWrite.Render;
begin
  WriteLn('Rendering at ', FWidth, 'x', FHeight);
end;

procedure TPngWrite.Process;
begin
  WriteLn('Processing graphics data');
end;

function TPngWrite.GetInfo: string;
begin
  Result := 'Graphics object ' + IntToStr(FWidth) + 'x' + IntToStr(FHeight);
end;

var
  Obj: TPngWrite;
begin
  Obj := TPngWrite.Create(640, 480);
  WriteLn('png_write example');
  WriteLn(Obj.GetInfo);
  Obj.Render;
  Obj.Process;
  WriteLn('png_write complete.');
end.
