program particle_fire;

{$APPTYPE CONSOLE}

type
  TParticleFire = class
  private
    FWidth: integer;
    FHeight: integer;
  public
    constructor Create(AWidth, AHeight: integer);
    procedure Render;
    procedure Process;
    function GetInfo: string;
  end;

constructor TParticleFire.Create(AWidth, AHeight: integer);
begin
  FWidth := AWidth;
  FHeight := AHeight;
end;

procedure TParticleFire.Render;
begin
  WriteLn('Rendering at ', FWidth, 'x', FHeight);
end;

procedure TParticleFire.Process;
begin
  WriteLn('Processing graphics data');
end;

function TParticleFire.GetInfo: string;
begin
  Result := 'Graphics object ' + IntToStr(FWidth) + 'x' + IntToStr(FHeight);
end;

var
  Obj: TParticleFire;
begin
  Obj := TParticleFire.Create(640, 480);
  WriteLn('particle_fire example');
  WriteLn(Obj.GetInfo);
  Obj.Render;
  Obj.Process;
  WriteLn('particle_fire complete.');
end.
