program demo_gi_11;
uses sysutils, neo_engine, neo_graphics, neo_render_gi;
var Engine: TNeoEngineFacade; GI: TNeoGIManager;
procedure OnFrame(Time: single); begin GI.GetInterpolatedLight(TVec3(0,0,0)); end;
begin Engine := TNeoEngineFacade.Create; Engine.Init(800, 600, 'GI Demo 11'); GI := TNeoGIManager.Create; Engine.SetFrameCallback(@OnFrame); Engine.Run; end.