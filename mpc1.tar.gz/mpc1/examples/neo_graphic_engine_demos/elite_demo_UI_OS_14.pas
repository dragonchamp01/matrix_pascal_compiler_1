program demo_ui_os_14;
uses sysutils, neo_engine, neo_graphics, neo_ui_window, neo_ui_tab, neo_ui_tree;

var 
  Engine: TNeoEngineFacade;
  Win: TNeoWindow;
  Tabs: TNeoTabControl;

procedure OnFrame(Time: single);
begin
  Engine.Graphics.Clear($D0D0D0);
  Win.Render(Engine.Graphics);
end;

begin
  Engine := TNeoEngineFacade.Create;
  Engine.Init(1024, 768, 'NeoOS 14');
  Win := TNeoWindow.Create(50, 50, 600, 400, 'System Manager');
  Tabs := TNeoTabControl.Create(10, 10, 580, 380);
  Win.AddChild(Tabs);
  Engine.SetFrameCallback(@OnFrame);
  Engine.Run;
end.