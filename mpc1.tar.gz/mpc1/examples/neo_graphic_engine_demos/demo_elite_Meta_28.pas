program demo_meta_28;
uses sysutils, neo_engine, neo_graphics, neo_render_metaballs;
var Engine: TNeoEngineFacade; Meta: TNeoMetaballRenderer;
procedure OnFrame(Time: single); begin Meta.Render(Engine.Graphics); end;
begin Engine := TNeoEngineFacade.Create; Engine.Init(800, 600, 'Metaball Demo 28'); Meta := TNeoMetaballRenderer.Create; Engine.SetFrameCallback(@OnFrame); Engine.Run; end.