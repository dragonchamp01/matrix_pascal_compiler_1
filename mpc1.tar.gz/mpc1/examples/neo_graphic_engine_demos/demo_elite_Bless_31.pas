program demo_bless_31;
uses sysutils, neo_engine, neo_graphics, neo_core_branchless;
var Engine: TNeoEngineFacade;
procedure OnFrame(Time: single); begin TNeoBranchless.Select(true, 1, 0); end;
begin Engine := TNeoEngineFacade.Create; Engine.Init(800, 600, 'Branchless Demo 31'); Engine.SetFrameCallback(@OnFrame); Engine.Run; end.