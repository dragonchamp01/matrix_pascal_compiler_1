program demo_phys_strings_7;
uses sysutils, neo_engine, neo_graphics, neo_audio_physical, neo_phys_verlet;

var 
  Engine: TNeoEngineFacade;
  Phys: TNeoPhysicalSynth;
  Cloth: TNeoCloth;

procedure OnFrame(Time: single);
begin
  Engine.Graphics.Clear($000000);
  Cloth.Update(0.016);
  Cloth.Render(Engine.Graphics);
end;

begin
  Engine := TNeoEngineFacade.Create;
  Engine.Init(800, 600, 'string Theory 7');
  Phys := TNeoPhysicalSynth.Create(440);
  Cloth := TNeoCloth.Create(20, 20);
  Engine.SetFrameCallback(@OnFrame);
  Engine.Run;
end.