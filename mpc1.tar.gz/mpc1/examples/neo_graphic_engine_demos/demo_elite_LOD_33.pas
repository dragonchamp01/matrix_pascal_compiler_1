program demo_lod_33;
uses sysutils, neo_engine, neo_graphics, neo_render_lod;
var Engine: TNeoEngineFacade; LOD: TNeoLODGroup;
procedure OnFrame(Time: single); begin LOD.GetMeshForDistance(10.0); end;
begin Engine := TNeoEngineFacade.Create; Engine.Init(800, 600, 'LOD Demo 33'); LOD := TNeoLODGroup.Create; Engine.SetFrameCallback(@OnFrame); Engine.Run; end.