program demo_pctex_17;
uses sysutils, neo_engine, neo_graphics, neo_render_pc_tex;
var Engine: TNeoEngineFacade; Tex: TNeoTextureMapper;
procedure OnFrame(Time: single); begin Tex.SamplePerspectiveCorrect(nil, 0.5, 0.5, 1.0); end;
begin Engine := TNeoEngineFacade.Create; Engine.Init(800, 600, 'PC Tex 17'); Engine.SetFrameCallback(@OnFrame); Engine.Run; end.