program neo_demo_ui_14;
uses sysutils, neo_engine, neo_graphics, neo_ui_window;
var Engine: TNeoEngineFacade; Win: TNeoWindow;
procedure OnFrame(Time: single); begin Win.Render(Engine.Graphics); end;
begin Engine := TNeoEngineFacade.Create; Engine.Init(800, 600, 'UI Demo 14'); Win := TNeoWindow.Create(100, 100, 400, 300, 'Test'); Engine.SetFrameCallback(@OnFrame); Engine.Run; end.