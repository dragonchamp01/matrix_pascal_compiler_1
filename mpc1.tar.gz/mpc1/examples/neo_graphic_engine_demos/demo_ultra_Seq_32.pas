program demo_seq_32;
uses sysutils, neo_engine, neo_graphics, neo_demo_sequencer;
var Engine: TNeoEngineFacade; Seq: TNeoSequencer;
procedure OnFrame(Time: single); begin Seq.Update(0.016); end;
begin Engine := TNeoEngineFacade.Create; Engine.Init(800, 600, 'Sequencer 32'); Seq := TNeoSequencer.Create; Engine.SetFrameCallback(@OnFrame); Engine.Run; end.