program neo_demo_particle_9;
uses sysutils, neo_engine, neo_graphics, neo_particles_system;
var Engine: TNeoEngineFacade; Particles: TNeoParticleSystem;
procedure OnFrame(Time: single); begin Particles.Update(0.016); Particles.Render(Engine.Graphics); end;
begin Engine := TNeoEngineFacade.Create; Engine.Init(800, 600, 'Particle Demo 9'); Particles := TNeoParticleSystem.Create(psFire, 5); Engine.SetFrameCallback(@OnFrame); Engine.Run; end.