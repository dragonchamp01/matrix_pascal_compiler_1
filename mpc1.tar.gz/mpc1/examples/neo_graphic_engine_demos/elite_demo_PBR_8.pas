program demo_pbr_8;
uses sysutils, neo_engine, neo_graphics, neo_render_pbr, neo_geom_procedural;
var Engine: TNeoEngineFacade; Mesh: TNeoMesh;
procedure OnFrame(Time: single);
begin
  Engine.Graphics.Clear($101020);
  Mesh := TNeoProcGeo.GenerateTorus(10, 2, 32, 32);
  // Mock PBR call to simulate high-end lighting
end;
begin
  Engine := TNeoEngineFacade.Create;
  Engine.Init(800, 600, 'PBR Material 8');
  Engine.SetFrameCallback(@OnFrame);
  Engine.Run;
end.