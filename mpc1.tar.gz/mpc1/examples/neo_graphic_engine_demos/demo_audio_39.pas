program neo_demo_audio_39;
uses sysutils, neo_engine, neo_graphics, neo_audio_mod;
var Engine: TNeoEngineFacade; ModPlayer: TNeoModPlayer;
procedure OnFrame(Time: single); begin ModPlayer.Process; Engine.Graphics.Clear(RGB(Round(Time*10), 0, 0)); end;
begin Engine := TNeoEngineFacade.Create; Engine.Init(800, 600, 'Audio Demo 39'); ModPlayer := TNeoModPlayer.Create(44100); Engine.SetFrameCallback(@OnFrame); Engine.Run; end.