program neo_demo_proc_26;
uses sysutils, neo_engine, neo_graphics, neo_proc_automata;
var Engine: TNeoEngineFacade; Auto: TNeoAutomaton;
procedure OnFrame(Time: single); begin Auto.Step; Auto.Render(Engine.Graphics); end;
begin Engine := TNeoEngineFacade.Create; Engine.Init(800, 600, 'proc Demo 26'); Auto := TNeoAutomaton.Create(100, 100); Engine.SetFrameCallback(@OnFrame); Engine.Run; end.