program LargeProgram;
{ Large program structure concept }
{ A large program is organized into sections: }
{ 1. Constants and type definitions }
{ 2. Global variables }
{ 3. Procedure/function declarations }
{ 4. Main program body }
const
  MAX_ITEMS = 100;
var
  data: array[1..MAX_ITEMS] of integer;
  count: integer;
procedure AddItem(val: integer);
begin
  if count < MAX_ITEMS then
  begin
    count := count + 1;
    data[count] := val;
  end;
end;
function GetTotal: integer;
var
  i, sum: integer;
begin
  sum := 0;
  for i := 1 to count do
    sum := sum + data[i];
  GetTotal := sum;
end;
begin
  count := 0;
  AddItem(10);
  AddItem(20);
  AddItem(30);
  WriteLn('Total: ');
  WriteLn(GetTotal);
  WriteLn('Items: ');
  WriteLn(count);
end.
