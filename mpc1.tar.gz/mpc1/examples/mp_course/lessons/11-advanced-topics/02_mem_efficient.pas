program MemEfficient;
{ Memory: efficient array use }
var
  data: array[1..1000] of integer;
  i, sum, count: integer;
begin
  { Initialize array with data }
  count := 0;
  for i := 1 to 1000 do
  begin
    if (i mod 2) = 0 then
    begin
      count := count + 1;
      data[count] := i;
    end;
  end;
  sum := 0;
  for i := 1 to count do
    sum := sum + data[i];
  WriteLn('Sum of evens (1-1000): ');
  WriteLn(sum);
  WriteLn('Items stored: ');
  WriteLn(count);
end.
