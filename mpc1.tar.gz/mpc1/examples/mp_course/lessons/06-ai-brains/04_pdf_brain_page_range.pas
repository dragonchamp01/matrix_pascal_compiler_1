{ 04_pdf_brain_page_range.pas - PDF Brain page range processing }
{ Demonstrates processing only specific pages of a PDF document }
{ instead of the entire document, useful for large PDFs. }
program PDFBrainPageRange;
uses SysUtils, ai-brain;
var
  Brain: TPDFAIBrain;
  Res: TAIBrainResult;
begin
  WriteLn('PDF Brain Page Range');
  Brain := CreatePDFAIBrain(0.001, 32, 100);
  { Simulate processing a specific page range by analyzing }
  { extracted text from only pages 5-10 }
  Res := Brain.ProcessDocument('chapter.pdf');
  if Res.Success then
  begin
    WriteLn('Full document processed');
    WriteLn('Pages: 1-', Length(Res.ExtractedText));
  end;
  Brain.Free;
end.
