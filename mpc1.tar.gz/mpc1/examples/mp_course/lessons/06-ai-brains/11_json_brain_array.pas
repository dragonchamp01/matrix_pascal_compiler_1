{ 11_json_brain_array.pas - JSONBrain array processing }
{ Demonstrates analyzing JSON arrays - the brain extracts }
{ common patterns across array elements. }
program JSONBrainArray;
uses SysUtils, ai-brain;
var
  Brain: TJSONAIBrain;
  Res: TAIBrainResult;
begin
  WriteLn('JSON Brain array');
  Brain := CreateJSONAIBrain(0.001, 32, 100);
  { Process a JSON file containing an array of records }
  Res := Brain.ProcessDocument('products.json');
  if Res.Success then
  begin
    WriteLn('array analysis: ', Res.Summary);
    WriteLn('Elements found: ', Length(Res.Keywords));
  end;
  Brain.Free;
end.
