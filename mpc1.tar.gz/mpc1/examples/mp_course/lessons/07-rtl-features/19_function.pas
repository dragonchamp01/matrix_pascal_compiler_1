{ 19_function.pas - Program with function }
{ Functions are subroutines that return a value. }
{ They are declared with the 'function' keyword. }
{ The result is assigned to the function name or 'Result'. }
program FunctionExample;
{ Function that adds two integers }
function Add(a, b: integer): integer;
begin
  Result := a + b;
end;
{ Function that checks if a number is even (returns 1 for true, 0 for false) }
function IsEven(n: integer): integer;
begin
  if (n mod 2) = 0 then
    Result := 1
  else
    Result := 0;
end;
{ Function that returns the maximum of two values }
function Max(a, b: integer): integer;
begin
  if a > b then
    Result := a
  else
    Result := b;
end;
var
  x, y, sum: integer;
begin
  x := 15;
  y := 7;
  sum := Add(x, y);
  WriteLn('Add: ', x, ' + ', y, ' = ', sum);
  WriteLn('Max: ', Max(x, y));
  WriteLn('IsEven(10): ', IsEven(10));
  WriteLn('IsEven(7): ', IsEven(7));
end.
