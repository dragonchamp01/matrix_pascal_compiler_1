{ Matrix trace: sum of diagonal elements }
program MatrixTrace;
type
  TMatrix = array[0..3, 0..3] of integer;
var
  m: TMatrix;
  trace: integer;
  i: integer;
begin
  m[0,0] := 1; m[0,1] := 2; m[0,2] := 3; m[0,3] := 4;
  m[1,0] := 5; m[1,1] := 6; m[1,2] := 7; m[1,3] := 8;
  m[2,0] := 9; m[2,1] := 10; m[2,2] := 11; m[2,3] := 12;
  m[3,0] := 13; m[3,1] := 14; m[3,2] := 15; m[3,3] := 16;
  trace := 0;
  for i := 0 to 3 do
    trace := trace + m[i,i];
  WriteLn('matrix M (4x4):');
  for i := 0 to 3 do
  begin
    write('  Row', i, ': ');
    WriteLn(m[i,0], ' ', m[i,1], ' ', m[i,2], ' ', m[i,3]);
  end;
  WriteLn('Trace (sum of diagonal) = ', trace);
end.
