{ Matrix inverse concept demonstration }
program MatrixInverseConcept;
type
  TMatrix = array[0..2, 0..2] of integer;
var
  a, b, res: TMatrix;
  i, j, k: integer;
begin
  a[0,0] := 1; a[0,1] := 0; a[0,2] := 0;
  a[1,0] := 0; a[1,1] := 2; a[1,2] := 0;
  a[2,0] := 0; a[2,1] := 0; a[2,2] := 3;
  b[0,0] := 1; b[0,1] := 0; b[0,2] := 0;
  b[1,0] := 0; b[1,1] := 1; b[1,2] := 0;
  b[2,0] := 0; b[2,1] := 0; b[2,2] := 1;
  for i := 0 to 2 do
    for j := 0 to 2 do
    begin
      res[i,j] := 0;
      for k := 0 to 2 do
        res[i,j] := res[i,j] + a[i,k] * b[k,j];
    end;
  WriteLn('A * I = A (shown below):');
  for i := 0 to 2 do
  begin
    write('  Row', i, ': ');
    WriteLn(res[i,0], ' ', res[i,1], ' ', res[i,2]);
  end;
  WriteLn('{ Inverse exists if A * A^-1 = I }');
end.
