{ Normalization: scaling input data to a standard range }
program Normalization;
type
  TVector = array[0..2] of integer;
var
  raw, norm: TVector;
  maxVal, minVal, i: integer;
begin
  raw[0] := 255; raw[1] := 128; raw[2] := 64;
  maxVal := 255;
  minVal := 0;
  WriteLn('Raw data: (255, 128, 64)');
  WriteLn('Normalized to 0-10 range:');
  for i := 0 to 2 do
    norm[i] := (raw[i] - minVal) * 10 div (maxVal - minVal);
  for i := 0 to 2 do
    WriteLn('  norm[', i, '] = ', norm[i]);
  WriteLn('{ Normalization improves training stability }');
end.
