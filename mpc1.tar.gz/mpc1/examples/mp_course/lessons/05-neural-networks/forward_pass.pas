{ Forward pass through a 2-layer network }
program ForwardPass;
type
  TMatrix = array[0..2, 0..2] of integer;
  TVector = array[0..2] of integer;
var
  input, hidden: TVector;
  w1, w2: TMatrix;
  i, j: integer;
begin
  input[0] := 1; input[1] := 0; input[2] := 1;
  w1[0,0] := 1; w1[0,1] := -1; w1[0,2] := 2;
  w1[1,0] := -2; w1[1,1] := 1; w1[1,2] := 1;
  w1[2,0] := 1; w1[2,1] := 1; w1[2,2] := -1;
  for i := 0 to 2 do
  begin
    hidden[i] := 0;
    for j := 0 to 2 do
      hidden[i] := hidden[i] + input[j] * w1[j,i];
    if hidden[i] < 0 then hidden[i] := 0;
  end;
  WriteLn('Input: (1, 0, 1)');
  WriteLn('Hidden layer output (after ReLU):');
  WriteLn('  h0 = ', hidden[0], '  h1 = ', hidden[1], '  h2 = ', hidden[2]);
end.
