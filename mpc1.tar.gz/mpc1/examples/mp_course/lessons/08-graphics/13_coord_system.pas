program CoordSystem;
{ Print a coordinate system }
var
  row, col: integer;
const
  WIDTH = 20;
  HEIGHT = 10;
begin
  for row := 0 to HEIGHT do
  begin
    for col := 0 to WIDTH do
    begin
      if (row = HEIGHT) and (col = 0) then
        write('+')
      else if (row = HEIGHT) then
        write('-')
      else if (col = 0) then
        write('|')
      else
        write(' ');
    end;
    WriteLn;
  end;
  WriteLn('Origin at (0,0) shown as +');
  WriteLn('X-axis extends right, Y-axis extends up');
end.
