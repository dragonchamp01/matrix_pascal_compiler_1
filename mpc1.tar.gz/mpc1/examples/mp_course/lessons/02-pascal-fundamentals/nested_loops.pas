{ Nested loops - loop inside a loop }
program NestedLoops;
var
  i, j: integer;
begin
  WriteLn('Multiplication table 1x1 to 3x3:');
  for i := 1 to 3 do
  begin
    for j := 1 to 3 do
    begin
      WriteLn(i, ' x ', j, ' = ', i * j);
    end;
  end;
end.
