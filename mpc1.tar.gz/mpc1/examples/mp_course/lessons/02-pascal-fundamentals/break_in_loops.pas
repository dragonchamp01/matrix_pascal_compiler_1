{ Break and skip in loops }
program BreakInLoops;
var
  i: integer;
begin
  WriteLn('break at 5:');
  for i := 1 to 10 do
  begin
    if i = 5 then
      break;
    WriteLn('i = ', i);
  end;
  WriteLn('Skip even numbers:');
  for i := 1 to 10 do
  begin
    if i mod 2 = 1 then
      WriteLn('i = ', i);
  end;
end.
