program StudentGrades;
{ Student grades manager: add, list, average, letter grades }
uses Crt;
const
  MAX_STUDENTS = 30;
var
  names: array[1..MAX_STUDENTS] of string;
  scores: array[1..MAX_STUDENTS] of integer;
  count: integer;
  choice: integer;
procedure AddStudent;
var
  sname: string;
  sscore: integer;
begin
  if count >= MAX_STUDENTS then
  begin
    WriteLn('Database full');
    exit;
  end;
  WriteLn('Enter student name:');
  ReadLn(sname);
  WriteLn('Enter score (0-100):');
  ReadLn(sscore);
  if (sscore < 0) or (sscore > 100) then
  begin
    WriteLn('Invalid score');
    exit;
  end;
  count := count + 1;
  names[count] := sname;
  scores[count] := sscore;
  WriteLn('Student added');
end;
procedure ListStudents;
var
  i: integer;
begin
  if count = 0 then
  begin
    WriteLn('No students');
    exit;
  end;
  for i := 1 to count do
  begin
    write(i);
    write('. ');
    write(names[i]);
    write(' - ');
    WriteLn(scores[i]);
  end;
end;
procedure ShowAverage;
var
  i, total, avg: integer;
begin
  if count = 0 then
  begin
    WriteLn('No students');
    exit;
  end;
  total := 0;
  for i := 1 to count do
    total := total + scores[i];
  avg := total div count;
  WriteLn('Average: ');
  WriteLn(avg);
end;
begin
  count := 0;
  choice := 0;
  while choice <> 5 do
  begin
    ClrScr;
    WriteLn('Student Grades Manager');
    WriteLn('1. Add student');
    WriteLn('2. List all');
    WriteLn('3. Show average');
    WriteLn('4. Clear all');
    WriteLn('5. exit');
    ReadLn(choice);
    if choice = 1 then AddStudent
    else if choice = 2 then ListStudents
    else if choice = 3 then ShowAverage
    else if choice = 4 then count := 0;
    if (choice >= 1) and (choice <= 4) then
    begin
      WriteLn('Press Enter...');
      ReadLn;
    end;
  end;
end.
