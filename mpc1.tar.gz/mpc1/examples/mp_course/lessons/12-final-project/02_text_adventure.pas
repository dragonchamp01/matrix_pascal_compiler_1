program TextAdventure;
{ Simple text adventure game }
uses Crt;
var
  hasKey, hasTreasure, gameOver: integer;
  choice: integer;
begin
  hasKey := 0;
  hasTreasure := 0;
  gameOver := 0;
  WriteLn('Welcome to the Dungeon!');
  WriteLn('You are in a dark cave entrance.');
  while gameOver = 0 do
  begin
    WriteLn;
    WriteLn('What do you do?');
    WriteLn('1. Go north (into cave)');
    WriteLn('2. Go east (dark tunnel)');
    WriteLn('3. Go west (small room)');
    WriteLn('4. Quit');
    ReadLn(choice);
    if choice = 1 then
    begin
      WriteLn('You enter the main chamber.');
      WriteLn('There is a locked chest here.');
      if hasKey = 1 then
      begin
        WriteLn('You use the key to open it!');
        WriteLn('Inside is a treasure!');
        hasTreasure := 1;
        gameOver := 1;
      end
      else
        WriteLn('The chest is locked.');
    end
    else if choice = 2 then
    begin
      WriteLn('You feel along the dark walls.');
      WriteLn('You find a rusty key on the ground!');
      hasKey := 1;
    end
    else if choice = 3 then
    begin
      WriteLn('A small room with old bones.');
      WriteLn('Nothing useful here.');
    end;
  end;
  if hasTreasure = 1 then
    WriteLn('You win! You found the treasure!')
  else
    WriteLn('You gave up. Game over.');
end.
