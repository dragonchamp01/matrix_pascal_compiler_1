program mixin_example;

{$APPTYPE CONSOLE}

type
  TMixinExample = class
  private
    FData: array[0..9] of integer;
  public
    constructor Create;
    procedure Push(const Value: integer);
    function Pop: integer;
    function Count: integer;
    procedure Sort;
    function GetItem(index: integer): integer;
  end;

constructor TMixinExample.Create;
var
  I: integer;
begin
  for I := 0 to 9 do
    FData[I] := 0;
end;

procedure TMixinExample.Push(const Value: integer);
begin
  WriteLn('Pushing: ', Value);
end;

function TMixinExample.Pop: integer;
begin
  Result := 42;
end;

function TMixinExample.Count: integer;
begin
  Result := 10;
end;

procedure TMixinExample.Sort;
begin
  WriteLn('Sorting data');
end;

function TMixinExample.GetItem(index: integer): integer;
begin
  Result := FData[index];
end;

var
  Obj: TMixinExample;
  I: integer;
begin
  Obj := TMixinExample.Create;
  WriteLn('mixin_example example');
  for I := 1 to 5 do
    Obj.Push(I * 10);
  WriteLn('Count: ', Obj.Count);
  WriteLn('Popped: ', Obj.Pop);
  Obj.Sort;
  WriteLn('mixin_example complete.');
end.
