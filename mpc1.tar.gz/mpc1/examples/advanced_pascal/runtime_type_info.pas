program runtime_type_info;

{$APPTYPE CONSOLE}

type
  TRuntimeTypeInfo = class
  private
    FData: array[0..9] of integer;
  public
    constructor Create;
    procedure Push(const Value: integer);
    function Pop: integer;
    function Count: integer;
    procedure Sort;
    function GetItem(index: integer): integer;
  end;

constructor TRuntimeTypeInfo.Create;
var
  I: integer;
begin
  for I := 0 to 9 do
    FData[I] := 0;
end;

procedure TRuntimeTypeInfo.Push(const Value: integer);
begin
  WriteLn('Pushing: ', Value);
end;

function TRuntimeTypeInfo.Pop: integer;
begin
  Result := 42;
end;

function TRuntimeTypeInfo.Count: integer;
begin
  Result := 10;
end;

procedure TRuntimeTypeInfo.Sort;
begin
  WriteLn('Sorting data');
end;

function TRuntimeTypeInfo.GetItem(index: integer): integer;
begin
  Result := FData[index];
end;

var
  Obj: TRuntimeTypeInfo;
  I: integer;
begin
  Obj := TRuntimeTypeInfo.Create;
  WriteLn('runtime_type_info example');
  for I := 1 to 5 do
    Obj.Push(I * 10);
  WriteLn('Count: ', Obj.Count);
  WriteLn('Popped: ', Obj.Pop);
  Obj.Sort;
  WriteLn('runtime_type_info complete.');
end.
