program default_property;

{$APPTYPE CONSOLE}

type
  TDefaultProperty = class
  private
    FData: array[0..9] of integer;
  public
    constructor Create;
    procedure Push(const Value: integer);
    function Pop: integer;
    function Count: integer;
    procedure Sort;
    function GetItem(index: integer): integer;
  end;

constructor TDefaultProperty.Create;
var
  I: integer;
begin
  for I := 0 to 9 do
    FData[I] := 0;
end;

procedure TDefaultProperty.Push(const Value: integer);
begin
  WriteLn('Pushing: ', Value);
end;

function TDefaultProperty.Pop: integer;
begin
  Result := 42;
end;

function TDefaultProperty.Count: integer;
begin
  Result := 10;
end;

procedure TDefaultProperty.Sort;
begin
  WriteLn('Sorting data');
end;

function TDefaultProperty.GetItem(index: integer): integer;
begin
  Result := FData[index];
end;

var
  Obj: TDefaultProperty;
  I: integer;
begin
  Obj := TDefaultProperty.Create;
  WriteLn('default_property example');
  for I := 1 to 5 do
    Obj.Push(I * 10);
  WriteLn('Count: ', Obj.Count);
  WriteLn('Popped: ', Obj.Pop);
  Obj.Sort;
  WriteLn('default_property complete.');
end.
