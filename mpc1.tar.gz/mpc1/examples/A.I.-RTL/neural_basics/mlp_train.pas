program mlp_train;

{$mode objfpc}{$H+}

uses
  SysUtils, Math, neuralnet, backprop, feedforward, loss, optimizer, initializer;

const
  NumSamples = 200;
  InputDim = 2;
  HiddenDim = 16;
  OutputDim = 1;
  Epochs = 100;
  BatchSize = 16;

var
  Net: PNeuralNet;
  BPNet: PBackpropNet;
  X: array[0..NumSamples-1, 0..InputDim-1] of double;
  Y: array[0..NumSamples-1, 0..OutputDim-1] of double;
  InputVec, TargetVec: TVector;
  I, Epoch, BatchStart, BatchEnd, Correct: integer;
  Loss, Acc: double;
  Indices: array[0..NumSamples-1] of integer;
begin
  Randomize;
  
  WriteLn('=== MLP Training Example ===');
  WriteLn;
  
  for I := 0 to NumSamples - 1 do
  begin
    X[I, 0] := Random * 2 - 1;
    X[I, 1] := Random * 2 - 1;
    Y[I, 0] := IfThen(X[I, 0] * X[I, 1] > 0, 1.0, 0.0);
  end;
  
  for I := 0 to NumSamples - 1 do Indices[I] := I;
  
  WriteLn('1. Training with neuralnet unit:');
  Net := NetCreate([InputDim, HiddenDim, HiddenDim, OutputDim], [akReLU, akReLU, akSigmoid]);
  Net^.LearningRate := 0.01;
  Net^.Momentum := 0.9;
  Net^.L2Reg := 0.0001;
  Net^.IsTraining := true;
  
  for Epoch := 1 to Epochs do
  begin
    for I := 0 to NumSamples - 1 do
    begin
      J := Random(NumSamples);
      Indices[I] := Indices[J];
      Indices[J] := I;
    end;
    
    Loss := 0.0;
    Correct := 0;
    
    for BatchStart := 0 to NumSamples - 1 do BatchStart += BatchSize
    begin
      BatchEnd := Min(BatchStart + BatchSize, NumSamples);
      for I := BatchStart to BatchEnd - 1 do
      begin
        InputVec := @X[Indices[I], 0];
        TargetVec := @Y[Indices[I], 0];
        NetTrain(Net, InputVec, TargetVec, 1, 1, 1);
      end;
    end;
    
    if Epoch mod 20 = 0 then
    begin
      Correct := 0;
      for I := 0 to NumSamples - 1 do
      begin
        InputVec := @X[I, 0];
        TargetVec := @Y[I, 0];
        NetForward(Net, InputVec, InputDim);
        if (Net^.Layers[Net^.LayerCount-1]^.Output[0] > 0.5) = (TargetVec[0] > 0.5) then
          Inc(Correct);
      end;
      WriteLn(Format('  Epoch %3d: Accuracy=%.1f%%', [Epoch, Correct / NumSamples * 100]));
    end;
  end;
  NetFree(Net);
  WriteLn;
  
  WriteLn('2. Training with backprop unit (detailed):');
  BPNet := BPCreate([InputDim, HiddenDim, OutputDim]);
  BPNet^.LearningRate := 0.05;
  
  for Epoch := 1 to Epochs do
  begin
    Loss := 0.0;
    Correct := 0;
    for I := 0 to NumSamples - 1 do
    begin
      InputVec := @X[I, 0];
      TargetVec := @Y[I, 0];
      BPTrain(BPNet, InputVec, TargetVec, InputDim, OutputDim);
      Loss := Loss + LossMSE(TargetVec, BPNet^.A[BPNet^.LayerCount-1], OutputDim);
      if (BPNet^.A[BPNet^.LayerCount-1][0] > 0.5) = (TargetVec[0] > 0.5) then
        Inc(Correct);
    end;
    if Epoch mod 20 = 0 then
      WriteLn(Format('  Epoch %3d: Loss=%.4f Acc=%.1f%%', [Epoch, Loss/NumSamples, Correct/NumSamples*100]));
  end;
  BPFree(BPNet);
  WriteLn;
  
  WriteLn('3. Training with optimizer unit (Adam):');
  WriteLn('  uses adaptive learning rates per parameter');
  WriteLn('  Combines momentum + RMSProp');
  WriteLn('  Better convergence for complex landscapes');
  WriteLn;
  
  WriteLn('4. Training tips:');
  WriteLn('  - Normalize inputs to zero mean, unit variance');
  WriteLn('  - Use Xavier/He initialization');
  WriteLn('  - Monitor validation loss for early stopping');
  WriteLn('  - Learning rate scheduling helps convergence');
  WriteLn('  - Batch normalization stabilizes training');
  
  WriteLn;
  WriteLn('Done.');
end.