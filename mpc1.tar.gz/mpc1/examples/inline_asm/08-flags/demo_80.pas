program demo_80;

{ TEST instruction + flag reading }
{ TEST performs bitwise AND on operands, sets flags }
{ ZF set if outvar is zero, SF set if outvar is negative }

var
  val: integer;
  mask: integer;
  flags: integer;

begin
  val := 255;
  mask := 15;
  flags := 0;

  asm
    mov eax, [val]
    mov ebx, [mask]
    test eax, ebx
    lahf
    mov [flags], eax
  end;

  WriteLn('TEST 255 with 15 (low 4 bits mask)');
  WriteLn('flags register value:');
  WriteLn(flags);
  WriteLn('ZF is bit 6 in AH, SF is bit 7 in AH');
end.
