program demo_22;

var
  a, b, outvar: integer;

begin
  WriteLn('=== Demo 22: je (jump if equal) ===');
  a := 42;
  b := 42;
  WriteLn('a = ', a, ', b = ', b);
  WriteLn('je jumps when cmp finds equal values');
  asm
    mov eax, [a]
    cmp eax, [b]
    je equal_22
    mov eax, 0
    jmp done_22
equal_22:
    mov eax, 1
done_22:
    mov [outvar], eax
  end;
  WriteLn('equal flag (1=true) = ', outvar);
end.
