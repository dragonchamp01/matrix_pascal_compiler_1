program demo_33;

var
  a, b, outvar: integer;

begin
  WriteLn('=== Demo 33: and (bitwise) ===');
  a := 15;
  b := 6;
  WriteLn('a = ', a, ' (binary 1111)');
  WriteLn('b = ', b, ' (binary 0110)');
  WriteLn('and: each bit is 1 only if both operand bits are 1');
  asm
    mov eax, [a]
    and eax, [b]
    mov [outvar], eax
  end;
  WriteLn('a and b = ', outvar, ' (binary 0110)');
  WriteLn('and is commonly used to mask bits (clear unwanted bits)');
end.
