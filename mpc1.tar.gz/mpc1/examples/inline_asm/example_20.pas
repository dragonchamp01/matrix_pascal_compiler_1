program example_20;
var
  src: array[0..7] of char;
  dst: array[0..7] of char;
begin
  src[0] := 'M'; src[1] := 'a'; src[2] := 't'; src[3] := 'r';
  src[4] := 'i'; src[5] := 'x'; src[6] := '!'; src[7] := #0;
  asm
    lea rsi, [src]
    lea rdi, [dst]
    mov ecx, 7
    cld
    rep movsb
  end;
end.
