program example_15;
var
  result: integer;
begin
  asm
    mov ecx, 5
    xor eax, eax
  loop_15:
    add eax, 10
    loop loop_15
    mov [result], eax
  end;
end.
