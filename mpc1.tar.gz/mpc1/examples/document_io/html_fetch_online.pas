program html_fetch_online;

{$APPTYPE CONSOLE}

type
  THtmlFetchOnline = class
  public
    function Load(const Source: string): string;
    function Save(const Data, Dest: string): boolean;
    function Convert(const Data: string): string;
    function Parse(const Data: string): string;
  end;

function THtmlFetchOnline.Load(const Source: string): string;
begin
  WriteLn('Loading from: ', Source);
  Result := 'content';
end;

function THtmlFetchOnline.Save(const Data, Dest: string): boolean;
begin
  WriteLn('Saving to: ', Dest);
  Result := true;
end;

function THtmlFetchOnline.Convert(const Data: string): string;
begin
  Result := Data;
end;

function THtmlFetchOnline.Parse(const Data: string): string;
begin
  WriteLn('Parsing data');
  Result := 'parsed_' + Data;
end;

var
  Obj: THtmlFetchOnline;
begin
  Obj := THtmlFetchOnline.Create;
  WriteLn('html_fetch_online example');
  Obj.Load('input.txt');
  WriteLn('Parsed: ', Obj.Parse('sample data'));
  Obj.Save('output', 'output.txt');
  WriteLn('html_fetch_online complete.');
end.
