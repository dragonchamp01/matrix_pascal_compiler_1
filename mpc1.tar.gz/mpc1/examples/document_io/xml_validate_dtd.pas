program xml_validate_dtd;

{$APPTYPE CONSOLE}

type
  TXmlValidateDtd = class
  public
    function Load(const Source: string): string;
    function Save(const Data, Dest: string): boolean;
    function Convert(const Data: string): string;
    function Parse(const Data: string): string;
  end;

function TXmlValidateDtd.Load(const Source: string): string;
begin
  WriteLn('Loading from: ', Source);
  Result := 'content';
end;

function TXmlValidateDtd.Save(const Data, Dest: string): boolean;
begin
  WriteLn('Saving to: ', Dest);
  Result := true;
end;

function TXmlValidateDtd.Convert(const Data: string): string;
begin
  Result := Data;
end;

function TXmlValidateDtd.Parse(const Data: string): string;
begin
  WriteLn('Parsing data');
  Result := 'parsed_' + Data;
end;

var
  Obj: TXmlValidateDtd;
begin
  Obj := TXmlValidateDtd.Create;
  WriteLn('xml_validate_dtd example');
  Obj.Load('input.txt');
  WriteLn('Parsed: ', Obj.Parse('sample data'));
  Obj.Save('output', 'output.txt');
  WriteLn('xml_validate_dtd complete.');
end.
