program text_search;

{$APPTYPE CONSOLE}

type
  TTextSearch = class
  public
    function Load(const Source: string): string;
    function Save(const Data, Dest: string): boolean;
    function Convert(const Data: string): string;
    function Parse(const Data: string): string;
  end;

function TTextSearch.Load(const Source: string): string;
begin
  WriteLn('Loading from: ', Source);
  Result := 'content';
end;

function TTextSearch.Save(const Data, Dest: string): boolean;
begin
  WriteLn('Saving to: ', Dest);
  Result := true;
end;

function TTextSearch.Convert(const Data: string): string;
begin
  Result := Data;
end;

function TTextSearch.Parse(const Data: string): string;
begin
  WriteLn('Parsing data');
  Result := 'parsed_' + Data;
end;

var
  Obj: TTextSearch;
begin
  Obj := TTextSearch.Create;
  WriteLn('text_search example');
  Obj.Load('input.txt');
  WriteLn('Parsed: ', Obj.Parse('sample data'));
  Obj.Save('output', 'output.txt');
  WriteLn('text_search complete.');
end.
