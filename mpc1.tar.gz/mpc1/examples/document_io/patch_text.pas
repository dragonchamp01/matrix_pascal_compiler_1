program patch_text;

{$APPTYPE CONSOLE}

type
  TPatchText = class
  public
    function Load(const Source: string): string;
    function Save(const Data, Dest: string): boolean;
    function Convert(const Data: string): string;
    function Parse(const Data: string): string;
  end;

function TPatchText.Load(const Source: string): string;
begin
  WriteLn('Loading from: ', Source);
  Result := 'content';
end;

function TPatchText.Save(const Data, Dest: string): boolean;
begin
  WriteLn('Saving to: ', Dest);
  Result := true;
end;

function TPatchText.Convert(const Data: string): string;
begin
  Result := Data;
end;

function TPatchText.Parse(const Data: string): string;
begin
  WriteLn('Parsing data');
  Result := 'parsed_' + Data;
end;

var
  Obj: TPatchText;
begin
  Obj := TPatchText.Create;
  WriteLn('patch_text example');
  Obj.Load('input.txt');
  WriteLn('Parsed: ', Obj.Parse('sample data'));
  Obj.Save('output', 'output.txt');
  WriteLn('patch_text complete.');
end.
