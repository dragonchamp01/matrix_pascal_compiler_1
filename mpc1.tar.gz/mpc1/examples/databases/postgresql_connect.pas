program postgresql_connect;

{$APPTYPE CONSOLE}

type
  TPostgresqlConnect = class
  private
    FConnected: boolean;
  public
    constructor Create;
    function Connect(const ConnStr: string): boolean;
    function Execute(const SQL: string): integer;
    function Query(const SQL: string): string;
    procedure Disconnect;
  end;

constructor TPostgresqlConnect.Create;
begin
  FConnected := false;
end;

function TPostgresqlConnect.Connect(const ConnStr: string): boolean;
begin
  WriteLn('Connecting to database: ', ConnStr);
  FConnected := true;
  Result := true;
end;

function TPostgresqlConnect.Execute(const SQL: string): integer;
begin
  WriteLn('Executing: ', SQL);
  Result := 1;
end;

function TPostgresqlConnect.Query(const SQL: string): string;
begin
  WriteLn('Querying: ', SQL);
  Result := 'result_set';
end;

procedure TPostgresqlConnect.Disconnect;
begin
  WriteLn('Disconnecting from database');
  FConnected := false;
end;

var
  DB: TPostgresqlConnect;
begin
  DB := TPostgresqlConnect.Create;
  WriteLn('postgresql_connect example');
  if DB.Connect('localhost:3306') then
  begin
    DB.Execute('CREATE TABLE test (id INT)');
    WriteLn('Rows affected: ', DB.Execute('INSERT INTO test VALUES (1)'));
    WriteLn('Query result: ', DB.Query('SELECT * FROM test'));
    DB.Disconnect;
  end;
  WriteLn('postgresql_connect complete.');
end.
