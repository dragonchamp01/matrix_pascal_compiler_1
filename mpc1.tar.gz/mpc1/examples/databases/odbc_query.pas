program odbc_query;

{$APPTYPE CONSOLE}

type
  TOdbcQuery = class
  private
    FConnected: boolean;
  public
    constructor Create;
    function Connect(const ConnStr: string): boolean;
    function Execute(const SQL: string): integer;
    function Query(const SQL: string): string;
    procedure Disconnect;
  end;

constructor TOdbcQuery.Create;
begin
  FConnected := false;
end;

function TOdbcQuery.Connect(const ConnStr: string): boolean;
begin
  WriteLn('Connecting to database: ', ConnStr);
  FConnected := true;
  Result := true;
end;

function TOdbcQuery.Execute(const SQL: string): integer;
begin
  WriteLn('Executing: ', SQL);
  Result := 1;
end;

function TOdbcQuery.Query(const SQL: string): string;
begin
  WriteLn('Querying: ', SQL);
  Result := 'result_set';
end;

procedure TOdbcQuery.Disconnect;
begin
  WriteLn('Disconnecting from database');
  FConnected := false;
end;

var
  DB: TOdbcQuery;
begin
  DB := TOdbcQuery.Create;
  WriteLn('odbc_query example');
  if DB.Connect('localhost:3306') then
  begin
    DB.Execute('CREATE TABLE test (id INT)');
    WriteLn('Rows affected: ', DB.Execute('INSERT INTO test VALUES (1)'));
    WriteLn('Query result: ', DB.Query('SELECT * FROM test'));
    DB.Disconnect;
  end;
  WriteLn('odbc_query complete.');
end.
