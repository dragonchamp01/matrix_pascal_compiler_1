program database_audit;

{$APPTYPE CONSOLE}

type
  TDatabaseAudit = class
  private
    FConnected: boolean;
  public
    constructor Create;
    function Connect(const ConnStr: string): boolean;
    function Execute(const SQL: string): integer;
    function Query(const SQL: string): string;
    procedure Disconnect;
  end;

constructor TDatabaseAudit.Create;
begin
  FConnected := false;
end;

function TDatabaseAudit.Connect(const ConnStr: string): boolean;
begin
  WriteLn('Connecting to database: ', ConnStr);
  FConnected := true;
  Result := true;
end;

function TDatabaseAudit.Execute(const SQL: string): integer;
begin
  WriteLn('Executing: ', SQL);
  Result := 1;
end;

function TDatabaseAudit.Query(const SQL: string): string;
begin
  WriteLn('Querying: ', SQL);
  Result := 'result_set';
end;

procedure TDatabaseAudit.Disconnect;
begin
  WriteLn('Disconnecting from database');
  FConnected := false;
end;

var
  DB: TDatabaseAudit;
begin
  DB := TDatabaseAudit.Create;
  WriteLn('database_audit example');
  if DB.Connect('localhost:3306') then
  begin
    DB.Execute('CREATE TABLE test (id INT)');
    WriteLn('Rows affected: ', DB.Execute('INSERT INTO test VALUES (1)'));
    WriteLn('Query result: ', DB.Query('SELECT * FROM test'));
    DB.Disconnect;
  end;
  WriteLn('database_audit complete.');
end.
