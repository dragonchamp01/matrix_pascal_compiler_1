program csv_import_db;

{$APPTYPE CONSOLE}

type
  TCsvImportDb = class
  private
    FConnected: boolean;
  public
    constructor Create;
    function Connect(const ConnStr: string): boolean;
    function Execute(const SQL: string): integer;
    function Query(const SQL: string): string;
    procedure Disconnect;
  end;

constructor TCsvImportDb.Create;
begin
  FConnected := false;
end;

function TCsvImportDb.Connect(const ConnStr: string): boolean;
begin
  WriteLn('Connecting to database: ', ConnStr);
  FConnected := true;
  Result := true;
end;

function TCsvImportDb.Execute(const SQL: string): integer;
begin
  WriteLn('Executing: ', SQL);
  Result := 1;
end;

function TCsvImportDb.Query(const SQL: string): string;
begin
  WriteLn('Querying: ', SQL);
  Result := 'result_set';
end;

procedure TCsvImportDb.Disconnect;
begin
  WriteLn('Disconnecting from database');
  FConnected := false;
end;

var
  DB: TCsvImportDb;
begin
  DB := TCsvImportDb.Create;
  WriteLn('csv_import_db example');
  if DB.Connect('localhost:3306') then
  begin
    DB.Execute('CREATE TABLE test (id INT)');
    WriteLn('Rows affected: ', DB.Execute('INSERT INTO test VALUES (1)'));
    WriteLn('Query result: ', DB.Query('SELECT * FROM test'));
    DB.Disconnect;
  end;
  WriteLn('csv_import_db complete.');
end.
