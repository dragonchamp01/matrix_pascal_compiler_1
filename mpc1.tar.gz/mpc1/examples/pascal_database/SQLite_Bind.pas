program SQLite_Bind;
begin
  WriteLn('Database: SQLite_Bind');
    WriteLn('This demonstrates database operations for SQLite_Bind in pascal.');
    WriteLn('Example 38 of 108 in the Database category.');
    WriteLn('Example completed successfully.');
end.
