{$mode objfpc}{$H+}
program AICustomerSegmentation_Elite;

{
    Matrix Pascal - Elite AI Customer Segmentation
    ================================================
    This program implements an unsupervised learning system for customer 
    segmentation using the K-Means Clustering algorithm.
    
    The goal is to group customers into distinct segments based on 
    behavioral features (e.g., Annual Income, Spending Score, Age).
    
    K-Means Process:
    1. Initialize K random centroids.
    2. Assign each data point to the nearest centroid.
    3. Recalculate centroids as the mean of assigned points.
    4. Repeat until convergence or max iterations.
}

uses
  SysUtils, Classes, Math, 
  tensor;

type
  TCustomer = record
    ID: integer;
    Income: double;
    SpendingScore: double;
    Age: double;
    Cluster: integer;
  end;

  TKMeans = class
  private
    FCentroids: array of PTensor;
    FK: integer;
    FMaxIter: integer;
    function EuclideanDistance(const P1, P2: PTensor): double;
  public
    constructor Create(K, MaxIter: integer);
    destructor Destroy; override;
    
    procedure Fit(var Customers: array of TCustomer);
    function Predict(const Input: PTensor): integer;
    
    property Centroids: array of PTensor read FCentroids;
  end;

constructor TKMeans.Create(K, MaxIter: integer);
begin
  inherited Create;
  FK := K;
  FMaxIter := MaxIter;
end;

destructor TKMeans.Destroy;
begin
  for var i := 0 to High(FCentroids) do
    // FreeVector(FCentroids[i]); // RTL cleanup
  inherited Destroy;
end;

function TKMeans.EuclideanDistance(const P1, P2: PTensor): Double;
var
  i: Integer;
  SumSqr: Double;
begin
  SumSqr := 0.0;
  for i := 0 to TensorSize(P1) - 1 do
    SumSqr := SumSqr + Sqr(P1^[i] - P2^[i]);
  Result := Sqrt(SumSqr);
end;

procedure TKMeans.Fit(var Customers: array of TCustomer);
var
  i, j, k: Integer;
  Changed: Boolean;
  Counts: array of Integer;
  Sums: array of PTensor;
  CurrentPoint: PTensor;
begin
  // 1. Initialize Centroids randomly from existing customers
  SetLength(FCentroids, FK);
  for k := 0 to FK - 1 do
  begin
    var RandIdx := Random(Length(Customers));
    FCentroids[k] := TensorAllocate(3);
    FCentroids[k]^[0] := Customers[RandIdx].Income;
    FCentroids[k]^[1] := Customers[RandIdx].SpendingScore;
    FCentroids[k]^[2] := Customers[RandIdx].Age;
  end;
  
  for i := 1 to FMaxIter do
  begin
    Changed := False;
    SetLength(Counts, FK);
    SetLength(Sums, FK);
    for k := 0 to FK - 1 do Sums[k] := TensorAllocate(3);
    
    // 2. Assignment Phase
    for j := 0 to High(Customers) do
    begin
      CurrentPoint := TensorAllocate(3);
      CurrentPoint^[0] := Customers[j].Income;
      CurrentPoint^[1] := Customers[j].SpendingScore;
      CurrentPoint^[2] := Customers[j].Age;
      
      var MinDist := 1e18;
      var BestK := 0;
      for k := 0 to FK - 1 do
      begin
        var D := EuclideanDistance(CurrentPoint, FCentroids[k]);
        if D < MinDist then
        begin
          MinDist := D;
          BestK := k;
        end;
      end;
      
      if Customers[j].Cluster <> BestK then
      begin
        Customers[j].Cluster := BestK;
        Changed := True;
      end;
      
      Inc(Counts[BestK]);
      Sums[BestK] := TensorAdd(Sums[BestK], CurrentPoint);
    end;
    
    // 3. Update Phase
    for k := 0 to FK - 1 do
    begin
      if Counts[k] > 0 then
        FCentroids[k] := TensorScale(Sums[k], 1.0 / Counts[k]);
    end;
    
    if not Changed then Break;
  end;
end;

function TKMeans.Predict(const Input: PTensor): Integer;
var
  k: Integer;
  MinDist: Double;
begin
  MinDist := 1e18;
  Result := 0;
  for k := 0 to FK - 1 do
  begin
    var D := EuclideanDistance(Input, FCentroids[k]);
    if D < MinDist then
    begin
      MinDist := D;
      Result := k;
    end;
  end;
end;

var
  KMeans: TKMeans;
  Customers: array of TCustomer;
  i: Integer;
  TestCustomer: PTensor;
begin
  WriteLn('===========================================================');
  WriteLn('       MATRIX PASCAL ELITE: CUSTOMER SEGMENTATION AI        ');
  WriteLn('===========================================================');
  
  try
    // 1. Generate synthetic customer data
    SetLength(Customers, 500);
    for i := 0 to 499 do
    begin
      Customers[i].ID := i + 1;
      Customers[i].Income := 20000 + Random * 80000;
      Customers[i].SpendingScore := Random * 100;
      Customers[i].Age := 18 + Random * 60;
      Customers[i].Cluster := -1;
    end;
    
    // 2. Initialize K-Means with K=4 (4 segments: Budget, Luxury, Impulse, Conservative)
    KMeans := TKMeans.Create(4, 100);
    
    // 3. Fit the model to the data
    KMeans.Fit(Customers);
    
    WriteLn('Customer segmentation complete.');
    WriteLn('Segment Centroids:');
    for i := 0 to 3 do
    begin
      WriteLn(' Cluster ', i, ': Income=', KMeans.Centroids[i]^[0]:0:2, 
               ', Score=', KMeans.Centroids[i]^[1]:0:2, ', Age=', KMeans.Centroids[i]^[2]:0:2);
    end;
    
    // 4. Predict segment for a new customer
    TestCustomer := TensorAllocate(3);
    TestCustomer^[0] := 75000.0; // Income
    TestCustomer^[1] := 85.0;    // Spending Score
    TestCustomer^[2] := 32.0;    // Age
    
    WriteLn('New Customer Prediction -> Segment: ', KMeans.Predict(TestCustomer));
    
  except
    on E: Exception do
      WriteLn('Clustering Error: ', E.Message);
  end;
  
  if Assigned(KMeans) then KMeans.Free;
  
  WriteLn('===========================================================');
  WriteLn('               CUSTOMER SEGMENTATION FINISHED              ');
  WriteLn('===========================================================');
end.
