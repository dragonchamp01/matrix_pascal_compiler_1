{$mode objfpc}{$H+}
program KNN_Classifier_Elite;

{
    Matrix Pascal - Elite K-Nearest Neighbors (KNN) Classifier
    ========================================================
    This program implements a highly optimized K-Nearest Neighbors 
    classification algorithm. KNN is a non-parametric, lazy learning 
    algorithm that classifies a point based on the majority class 
    of its 'k' closest neighbors in the feature space.
    
    Algorithm:
    1. Calculate distance (Euclidean) between target point and all training points.
    2. Sort training points by distance.
    3. Take the top 'k' neighbors.
    4. Perform majority vote to determine the class.
}

uses
  SysUtils, Classes, Math, 
  tensor;

type
  TDataPoint = record
    Features: PTensor;
    label: integer;
  end;

  TDistancePair = record
    Distance: double;
    label: integer;
  end;

  TKNNClassifier = class
  private
    FTrainingSet: array of TDataPoint;
    FK: integer;
  public
    constructor Create(K: integer);
    destructor Destroy; override;
    
    procedure Fit(const X: array of PTensor; const Y: array of integer);
    function Predict(const Input: PTensor): integer;
    function EuclideanDistance(const P1, P2: PTensor): double;
    
    property K: integer read FK write FK;
  end;

constructor TKNNClassifier.Create(K: integer);
begin
  inherited Create;
  FK := K;
end;

destructor TKNNClassifier.Destroy;
begin
  // Free tensors in training set
  for var i := 0 to High(FTrainingSet) do
    // FreeVector(FTrainingSet[i].Features); // Assuming FreeVector exists in RTL
  inherited Destroy;
end;

procedure TKNNClassifier.Fit(const X: array of PTensor; const Y: array of Integer);
begin
  // KNN is a lazy learner; Fit just stores the data
  SetLength(FTrainingSet, Length(X));
  for var i := 0 to High(X) do
  begin
    FTrainingSet[i].Features := X[i];
    FTrainingSet[i].Label := Y[i];
  end;
end;

function TKNNClassifier.EuclideanDistance(const P1, P2: PTensor): Double;
var
  i: Integer;
  SumSqr: Double;
begin
  SumSqr := 0.0;
  for i := 0 to TensorSize(P1) - 1 do
  begin
    SumSqr := SumSqr + Sqr(P1^[i] - P2^[i]);
  end;
  Result := Sqrt(SumSqr);
end;

function TKNNClassifier.Predict(const Input: PTensor): Integer;
var
  i: Integer;
  Distances: array of TDistancePair;
  Votes: array of Integer;
  ClosestLabel: Integer;
  MaxVotes: Integer;
begin
  SetLength(Distances, Length(FTrainingSet));
  
  // 1. Calculate all distances
  for i := 0 to High(FTrainingSet) do
  begin
    Distances[i].Distance := EuclideanDistance(Input, FTrainingSet[i].Features);
    Distances[i].Label := FTrainingSet[i].Label;
  end;
  
  // 2. Sort by distance (Simple bubble sort for demonstration, elite uses QuickSort)
  for i := 0 to High(Distances) - 1 do
    for var j := i + 1 to High(Distances) do
      if Distances[j].Distance < Distances[i].Distance then
      begin
        var Temp := Distances[i];
        Distances[i] := Distances[j];
        Distances[j] := Temp;
      end;
      
  // 3. Count votes from k nearest neighbors
  SetLength(Votes, 10); // Assuming max 10 classes
  for i := 0 to FK - 1 do
  begin
    Inc(Votes[Distances[i].Label]);
  end;
  
  // 4. Return class with most votes
  MaxVotes := -1;
  ClosestLabel := 0;
  for i := 0 to High(Votes) do
  begin
    if Votes[i] > MaxVotes then
    begin
      MaxVotes := Votes[i];
      ClosestLabel := i;
    end;
  end;
  Result := ClosestLabel;
end;

var
  KNN: TKNNClassifier;
  X_Train: array of PTensor;
  Y_Train: array of Integer;
  i: Integer;
  TestInput: PTensor;
begin
  WriteLn('===========================================================');
  WriteLn('      MATRIX PASCAL ELITE: KNN CLASSIFIER DEMO              ');
  WriteLn('===========================================================');
  
  try
    // 1. Prepare Synthetic Data (Two clusters)
    SetLength(X_Train, 100);
    SetLength(Y_Train, 100);
    for i := 0 to 99 do
    begin
      X_Train[i] := TensorRandom(1, 2);
      if (X_Train[i]^[0] > 0.5) and (X_Train[i]^[1] > 0.5) then
        Y_Train[i] := 1
      else
        Y_Train[i] := 0;
    end;
    
    // 2. Initialize KNN with K=5
    KNN := TKNNClassifier.Create(5);
    
    // 3. Fit model
    KNN.Fit(X_Train, Y_Train);
    
    // 4. Test predictions
    TestInput := TensorRandom(1, 2);
    WriteLn('Test Input: [', TestInput^[0]:0:4, ', ', TestInput^[1]:0:4, ']');
    WriteLn('Predicted Class: ', KNN.Predict(TestInput));
    
    // Test another input
    TestInput := TensorConstant(1, 2, 0.8);
    WriteLn('Test Input: [0.8, 0.8] -> Predicted Class: ', KNN.Predict(TestInput));
    
  except
    on E: Exception do
      WriteLn('Error: ', E.Message);
  end;
  
  if Assigned(KNN) then KNN.Free;
  
  WriteLn('===========================================================');
  WriteLn('                KNN CLASSIFIER SESSION FINISHED             ');
  WriteLn('===========================================================');
end.
