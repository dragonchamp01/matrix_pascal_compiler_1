{$mode objfpc}{$H+}
program AIStockPredictor_Elite;

{
    Matrix Pascal - Elite AI Stock Market Predictor
    ================================================
    This program demonstrates a time-series forecasting system for 
    stock market prediction using a simulated LSTM (Long Short-Term Memory) 
    approach.
    
    The model analyzes historical price sequences (Open, High, Low, Close, Volume)
    to predict the next day's closing price.
    
    Concepts:
    - Sliding Window: Creating sequences of N days to predict day N+1.
    - Normalization: Scaling stock prices to [0, 1] to avoid gradient explosion.
    - Mean Absolute Error (MAE): Evaluating the accuracy of price predictions.
}

uses
  SysUtils, Classes, Math, 
  trainer, layers, loss_functions, optimizers, tensor;

type
  TStockData = record
    Date: string;
    Close: double;
    Volume: double;
  end;

  TStockPredictor = class
  private
    FModel: TModel;
    FConfig: TTrainingConfig;
    FWindowSize: integer;
    FMinPrice, FMaxPrice: double;
  public
    constructor Create(WindowSize: integer);
    destructor Destroy; override;
    
    procedure SetupArchitecture;
    procedure SetupConfig;
    function Normalize(Value: double): double;
    function Denormalize(Value: double): double;
    function PredictNextPrice(const Sequence: array of double): double;
    procedure Train(const History: array of TStockData);
    
    property Model: TModel read FModel;
  end;

constructor TStockPredictor.Create(WindowSize: integer);
begin
  inherited Create;
  FWindowSize := WindowSize;
  SetupArchitecture;
  SetupConfig;
end;

destructor TStockPredictor.Destroy;
begin
  FModel.Free;
  inherited Destroy;
end;

procedure TStockPredictor.SetupArchitecture;
begin
  WriteLn('Designing Elite Stock Prediction Neural network...');
  
  // Input: WindowSize (Days) -> Hidden Layers -> Output (Price)
  FModel := TModel.Create(TMeanSquaredErrorLoss.Create, TAdamOptimizer.Create(0.001));
  
  // Simulating LSTM layers with Dense blocks for sequence feature extraction
  FModel.AddLayer(TDenseLayer.Create(FWindowSize, 64));
  FModel.AddLayer(TReLULayer.Create);
  
  FModel.AddLayer(TDenseLayer.Create(64, 32));
  FModel.AddLayer(TReLULayer.Create);
  
  FModel.AddLayer(TDenseLayer.Create(32, 1));
  
  WriteLn('Stock architecture: Window(' + IntToStr(FWindowSize) + ') -> 64 -> 32 -> 1');
end;

procedure TStockPredictor.SetupConfig;
begin
  FConfig.Epochs := 150;
  FConfig.BatchSize := 16;
  FConfig.LearningRate := 0.001;
  FConfig.Verbose := False;
  FConfig.Shuffle := True;
end;

function TStockPredictor.Normalize(Value: Double): Double;
begin
  if FMaxPrice = FMinPrice then Exit(0.5);
  Result := (Value - FMinPrice) / (FMaxPrice - FMinPrice);
end;

function TStockPredictor.Denormalize(Value: Double): Double;
begin
  Result := Value * (FMaxPrice - FMinPrice) + FMinPrice;
end;

function TStockPredictor.PredictNextPrice(const Sequence: array of Double);
var
  InputT, OutputT: PTensor;
  i: Integer;
begin
  InputT := TensorAllocate(FWindowSize);
  for i := 0 to FWindowSize - 1 do
    InputT^[i] := Normalize(Sequence[i]);
    
  OutputT := FModel.Forward(InputT);
  Result := Denormalize(OutputT^[0]);
end;

procedure TStockPredictor.Train(const History: array of TStockData);
var
  Trainer: TModelTrainer;
  Dataset: TDataset;
  i: Integer;
  X, Y: PTensor;
begin
  WriteLn('Preparing stock market dataset...');
  
  // Determine min/max for normalization
  FMinPrice := 1e18; FMaxPrice := -1e18;
  for i := 0 to High(History) do
  begin
    if History[i].Close < FMinPrice then FMinPrice := History[i].Close;
    if History[i].Close > FMaxPrice then FMaxPrice := History[i].Close;
  end;
  
  Dataset := TDataset.Create;
  for i := 0 to Length(History) - FWindowSize - 1 do
  begin
    X := TensorAllocate(FWindowSize);
    for var j := 0 to FWindowSize - 1 do
      X^[j] := Normalize(History[i + j].Close);
      
    Y := TensorConstant(1, 1, Normalize(History[i + FWindowSize].Close));
    Dataset.AddSample(X, Y);
  end;
  
  Trainer := TModelTrainer.Create(FModel, FConfig);
  try
    Trainer.Fit(Dataset);
  finally
    Trainer.Free;
    Dataset.Free;
  end;
end;

var
  Predictor: TStockPredictor;
  MarketHistory: array of TStockData;
  i: Integer;
  TestSeq: array of Double;
  Prediction: Double;
begin
  WriteLn('===========================================================');
  WriteLn('       MATRIX PASCAL ELITE: STOCK MARKET PREDICTOR          ');
  WriteLn('===========================================================');
  
  try
    // 1. Generate synthetic stock price history (Random Walk with Drift)
    SetLength(MarketHistory, 500);
    var CurrentPrice := 150.0;
    for i := 0 to 499 do
    begin
      CurrentPrice := CurrentPrice + (Random * 4 - 2) + 0.1;
      MarketHistory[i].Date := '2026-01-' + IntToStr(i + 1);
      MarketHistory[i].Close := CurrentPrice;
      MarketHistory[i].Volume := 1000000 + Random * 500000;
    end;
    
    // 2. Init Predictor with a 10-day window
    Predictor := TStockPredictor.Create(10);
    
    // 3. Train on history
    Predictor.Train(MarketHistory);
    
    // 4. Test Prediction on the last sequence
    SetLength(TestSeq, 10);
    for i := 0 to 9 do
      TestSeq[i] := MarketHistory[490 + i].Close;
      
    Prediction := Predictor.PredictNextPrice(TestSeq);
    
    WriteLn('Last known price: ', MarketHistory[499].Close:0:2);
    WriteLn('Predicted price for tomorrow: ', Prediction:0:2);
    
  except
    on E: Exception do
      WriteLn('Prediction Error: ', E.Message);
  end;
  
  if Assigned(Predictor) then Predictor.Free;
  
  WriteLn('===========================================================');
  WriteLn('                STOCK PREDICTION SESSION FINISHED          ');
  WriteLn('===========================================================');
end.
