{$mode objfpc}{$H+}
program AIFuzzyLogic_Elite;

{
    Matrix Pascal - Elite AI Fuzzy Logic Controller
    ================================================
    This program implements a Fuzzy Logic Controller (FLC) for an 
    automated climate control system (AC).
    
    Unlike binary logic (True/False), Fuzzy Logic allows for 
    degrees of truth (e.g., "Slightly Hot", "Very Cold").
    
    Workflow:
    1. Fuzzification: Convert crisp inputs (Temperature) into fuzzy sets.
    2. Rule Evaluation: Apply "IF-THEN" rules (e.g., IF Temp is Hot THEN Fan is Fast).
    3. Defuzzification: Convert fuzzy output back to a crisp control value.
}

uses
  SysUtils, Classes, Math;

type
  TFuzzySet = record
    name: string;
    Center: double;
    Width: double;
    function Membership(Value: double): double;
  end;

  TFuzzyRule = record
    InputSet: string;
    OutputValue: double;
  end;

  TFuzzyController = class
  private
    FInputSets: array of TFuzzySet;
    FRules: array of TFuzzyRule;
  public
    constructor Create;
    procedure AddInputSet(name: string; Center, Width: double);
    procedure AddRule(InputSet: string; OutputValue: double);
    function Compute(Input: double): double;
  end;

function TFuzzySet.Membership(Value: double): double;
begin
  // Gaussian membership function
  Result := Exp(-Sqr(Value - Center) / (2 * Sqr(Width)));
end;

constructor TFuzzyController.Create;
begin
  inherited Create;
end;

procedure TFuzzyController.AddInputSet(Name: string; Center, Width: Double);
var
  S: TFuzzySet;
begin
  S.Name := Name;
  S.Center := Center;
  S.Width := Width;
  SetLength(FInputSets, Length(FInputSets) + 1);
  FInputSets[High(FInputSets)] := S;
end;

procedure TFuzzyController.AddRule(InputSet: string; OutputValue: Double);
var
  R: TFuzzyRule;
begin
  R.InputSet := InputSet;
  R.OutputValue := OutputValue;
  SetLength(FRules, Length(FRules) + 1);
  FRules[High(FRules)] := R;
end;

function TFuzzyController.Compute(Input: Double): Double;
var
  i: Integer;
  WeightedSum, TotalWeight: Double;
  Membership: Double;
begin
  WeightedSum := 0;
  TotalWeight := 0;
  
  for i := 0 to High(FRules) do
  begin
    // Find the membership value for the input set mentioned in the rule
    Membership := 0.0;
    for var s := 0 to High(FInputSets) do
      if FInputSets[s].Name = FRules[i].InputSet then
        Membership := FInputSets[s].Membership(Input);
        
    WeightedSum := WeightedSum + (Membership * FRules[i].OutputValue);
    TotalWeight := TotalWeight + Membership;
  end;
  
  if TotalWeight = 0 then Exit(0.0);
  Result := WeightedSum / TotalWeight; // Centroid defuzzification
end;

var
  AC_Controller: TFuzzyController;
  TestTemps: array of Double;
  i: Integer;
begin
  WriteLn('===========================================================');
  WriteLn('       MATRIX PASCAL ELITE: AI FUZZY LOGIC CONTROLLER       ');
  WriteLn('===========================================================');
  
  try
    AC_Controller := TFuzzyController.Create;
    
    // 1. Define Fuzzy Sets for Temperature
    AC_Controller.AddInputSet('Cold', 15.0, 5.0);
    AC_Controller.AddInputSet('Comfortable', 22.0, 3.0);
    AC_Controller.AddInputSet('Hot', 30.0, 5.0);
    
    // 2. Define Rules (Output is Fan Speed 0-100%)
    AC_Controller.AddRule('Cold', 10.0);        // If Cold -> Fan Low
    AC_Controller.AddRule('Comfortable', 40.0); // If Comfortable -> Fan Medium
    AC_Controller.AddRule('Hot', 90.0);         // If Hot -> Fan High
    
    // 3. Test the controller with various temperatures
    SetLength(TestTemps, 5);
    TestTemps[0] := 12.0; // Very Cold
    TestTemps[1] := 18.0; // Slightly Cold
    TestTemps[2] := 22.0; // Perfect
    TestTemps[3] := 26.0; // Warm
    TestTemps[4] := 35.0; // Very Hot
    
    for i := 0 to High(TestTemps) do
    begin
      WriteLn('Input Temp: ', TestTemps[i]:0:1, ' C -> Fan Speed: ', 
               AC_Controller.Compute(TestTemps[i]):0:2, '%');
    end;
    
  except
    on E: Exception do
      WriteLn('Fuzzy Logic Error: ', E.Message);
  end;
  
  if Assigned(AC_Controller) then AC_Controller.Free;
  
  WriteLn('===========================================================');
  WriteLn('                FUZZY LOGIC SESSION FINISHED               ');
  WriteLn('===========================================================');
end.
