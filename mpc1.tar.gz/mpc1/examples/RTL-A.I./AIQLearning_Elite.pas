{$mode objfpc}{$H+}
program AIQLearning_Elite;

{
    Matrix Pascal - Elite AI Q-Learning (Tabular)
    ==============================================
    This program implements a classic Tabular Q-Learning agent.
    Unlike Deep Q-Networks, Tabular Q-Learning maintains a 
    lookup table (Q-Table) where every state-action pair has a 
    stored value representing the expected future reward.
    
    Bellman Equation:
    Q(s, a) = Q(s, a) + alpha * [reward + gamma * max(Q(s', a')) - Q(s, a)]
    
    Use Case: GridWorld navigation.
}

uses
  SysUtils, Classes, Math;

type
  TState = record
    X, Y: integer;
  end;

  TQTable = class
  private
    FData: array of array of double; // [StateIdx, ActionIdx]
    FRows, FCols: Integer;
  public
    constructor Create(States, Actions: Integer);
    function GetValue(S: TState; A: Integer): Double;
    procedure SetValue(S: TState, A: Integer; Val: Double);
    function GetBestAction(S: TState): Integer;
  end;

constructor TQTable.Create(States, Actions: Integer);
begin
  FRows := States;
  FCols := Actions;
  SetLength(FData, States);
  for var i := 0 to States - 1 do SetLength(FData[i], Actions);
end;

function TQTable.GetValue(S: TState; A: Integer): Double;
begin
  // Simple indexing for 10x10 grid
  Result := FData[S.X * 10 + S.Y][A];
end;

procedure TQTable.SetValue(S: TState, A: Integer; Val: Double);
begin
  FData[S.X * 10 + S.Y][A] := Val;
end;

function TQTable.GetBestAction(S: TState): Integer;
var
  i: Integer;
  MaxQ: Double;
begin
  MaxQ := -1e18;
  Result := 0;
  for i := 0 to FCols - 1 do
  begin
    if GetValue(S, i) > MaxQ then
    begin
      MaxQ := GetValue(S, i);
      Result := i;
    end;
  end;
end;

type
  TQLearningAgent = class
  private
    FTable: TQTable;
    FAlpha, FGamma, FEpsilon: Double;
  public
    constructor Create;
    function ChooseAction(S: TState): Integer;
    procedure Update(S, SNext: TState; A, ANext: Integer; R: Double);
    property Table: TQTable read FTable;
  end;

constructor TQLearningAgent.Create;
begin
  FTable := TQTable.Create(100, 4); // 10x10 grid, 4 actions
  FAlpha := 0.1;
  FGamma := 0.95;
  FEpsilon := 0.2;
end;

function TQLearningAgent.ChooseAction(S: TState): Integer;
begin
  if Random < FEpsilon then
    Result := Random(4)
  else
    Result := FTable.GetBestAction(S);
end;

procedure TQLearningAgent.Update(S, SNext: TState; A, ANext: Integer; R: Double);
var
  OldQ, MaxNextQ: Double;
begin
  OldQ := FTable.GetValue(S, A);
  MaxNextQ := FTable.GetValue(SNext, FTable.GetBestAction(SNext));
  
  // Q-Learning Update Rule
  FTable.SetValue(S, A, OldQ + FAlpha * (R + FGamma * MaxNextQ - OldQ));
end;

var
  Agent: TQLearningAgent;
  S, SNext: TState;
  A, ANext: Integer;
  R: Double;
  Ep: Integer;
begin
  WriteLn('===========================================================');
  WriteLn('       MATRIX PASCAL ELITE: TABULAR Q-LEARNING AI           ');
  WriteLn('===========================================================');
  
  try
    Agent := TQLearningAgent.Create;
    
    for Ep := 1 to 1000 do
    begin
      S.X := 0; S.Y := 0; // Start
      while not (S.X = 9) or (S.Y = 9) do // Until goal
      begin
        A := Agent.ChooseAction(S);
        
        // Simulate Environment
        SNext := S;
        case A of
          0: SNext.X := S.X + 1;
          1: SNext.X := S.X - 1;
          2: SNext.Y := S.Y + 1;
          3: SNext.Y := S.Y - 1;
        end;
        // Bounds check
        if (SNext.X < 0) or (SNext.X > 9) or (SNext.Y < 0) or (SNext.Y > 9) then SNext := S;
        
        R := if (SNext.X = 9) and (SNext.Y = 9) then 100.0 else -1.0;
        
        Agent.Update(S, SNext, A, Agent.ChooseAction(SNext), R);
        S := SNext;
      end;
    end;
    
    WriteLn('Agent trained on GridWorld.');
    WriteLn('Optimal action at (0,0): ', Agent.ChooseAction(S));
    
  except
    on E: Exception do
      WriteLn('Q-Learning Error: ', E.Message);
  end;
  
  if Assigned(Agent) then Agent.Free;
  
  WriteLn('===========================================================');
  WriteLn('                TABULAR Q-LEARNING FINISHED                 ');
  WriteLn('===========================================================');
end.
