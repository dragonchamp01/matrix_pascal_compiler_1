program demo_167_image_test;

uses
  neo_core, neo_graphics;

var
  Engine: TNeoEngine;
  Graphics: TNeoGraphics;
begin
  Engine := TNeoEngine.Create;
  Graphics := TNeoGraphics.Create(Engine);
  while Engine.IsRunning do
  begin
    Graphics.Clear($00FF00); // Simulated Image Blit
    Engine.Present;
  end;
  Graphics.Free;
  Engine.Free;
end.
