program demo_153_scroller;

uses
  neo_core, neo_graphics;

var
  Engine: TNeoEngine;
  Graphics: TNeoGraphics;
begin
  Engine := TNeoEngine.Create;
  Graphics := TNeoGraphics.Create(Engine);
  while Engine.IsRunning do
  begin
    Graphics.Clear($000000); Graphics.DrawScroller(100, 500, 'Demo 153', $00FF00);
    Engine.Present;
  end;
  Graphics.Free;
  Engine.Free;
end.
