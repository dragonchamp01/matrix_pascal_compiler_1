program demo_216_color_cycle;

uses
  neo_core, neo_graphics;

var
  Engine: TNeoEngine;
  Graphics: TNeoGraphics;
begin
  Engine := TNeoEngine.Create;
  Graphics := TNeoGraphics.Create(Engine);
  while Engine.IsRunning do
  begin
    Graphics.Clear($002659);
    Engine.Present;
  end;
  Graphics.Free;
  Engine.Free;
end.
