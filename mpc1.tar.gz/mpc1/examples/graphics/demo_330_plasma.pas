program demo_330_plasma;

uses
  neo_core, neo_graphics;

var
  Engine: TNeoEngine;
  Graphics: TNeoGraphics;
begin
  Engine := TNeoEngine.Create;
  Graphics := TNeoGraphics.Create(Engine);
  while Engine.IsRunning do
  begin
    Graphics.DrawPlasma(0.1);
    Engine.Present;
  end;
  Graphics.Free;
  Engine.Free;
end.
