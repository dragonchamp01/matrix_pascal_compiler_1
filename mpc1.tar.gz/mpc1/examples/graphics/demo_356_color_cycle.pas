program demo_356_color_cycle;

uses
  neo_core, neo_graphics;

var
  Engine: TNeoEngine;
  Graphics: TNeoGraphics;
begin
  Engine := TNeoEngine.Create;
  Graphics := TNeoGraphics.Create(Engine);
  while Engine.IsRunning do
  begin
    Graphics.Clear($00644E);
    Engine.Present;
  end;
  Graphics.Free;
  Engine.Free;
end.
