program demo_348_circles;

uses
  neo_core, neo_graphics;

var
  Engine: TNeoEngine;
  Graphics: TNeoGraphics;
begin
  Engine := TNeoEngine.Create;
  Graphics := TNeoGraphics.Create(Engine);
  while Engine.IsRunning do
  begin
    Graphics.Clear($000000); // Simulated Circles
    Engine.Present;
  end;
  Graphics.Free;
  Engine.Free;
end.
