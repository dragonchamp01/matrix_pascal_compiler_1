program demo_flagship_003_copper;

uses
  neo_core, neo_graphics;

var
  Engine: TNeoEngine;
  Graphics: TNeoGraphics;
  Time: single;
  BarY: integer;
  ScrollText: string;

begin
  Engine := TNeoEngine.Create;
  Graphics := TNeoGraphics.Create(Engine);
  Time := 0;
  BarY := 540;
  ScrollText := 'COPPER BAR DEMO - Neo Graphic Engine - matrix pascal 2026 - Pure Demo Power!';

  while Engine.IsRunning do
  begin
    Time := Time + 0.05;
    BarY := 540 + Round(50 * Sin(Time));
    
    Graphics.Clear($000000);
    Graphics.DrawCopperBar(BarY, $FF0000, $0000FF);
    Graphics.DrawCopperBar(BarY + 1, $000000, $000000);
    Graphics.DrawCopperBar(BarY + 2, $FF0000, $0000FF);
    
    Graphics.DrawSineScroller(100, 600, ScrollText, $FFFFFF, 20.0, 0.2, Time);
    Engine.Present;
  end;

  Graphics.Free;
  Engine.Free;
end.
