program demo_142_sine;

uses
  neo_core, neo_graphics;

var
  Engine: TNeoEngine;
  Graphics: TNeoGraphics;
begin
  Engine := TNeoEngine.Create;
  Graphics := TNeoGraphics.Create(Engine);
  while Engine.IsRunning do
  begin
    Graphics.Clear($FFFF00); // Simulated Sine Wave
    Engine.Present;
  end;
  Graphics.Free;
  Engine.Free;
end.
