program demo_189_generic;

uses
  neo_core, neo_graphics;

var
  Engine: TNeoEngine;
  Graphics: TNeoGraphics;
begin
  Engine := TNeoEngine.Create;
  Graphics := TNeoGraphics.Create(Engine);
  while Engine.IsRunning do
  begin
    Graphics.Clear($FFFFFF); // Generic Demo 189
    Engine.Present;
  end;
  Graphics.Free;
  Engine.Free;
end.
