program StringUtils;

uses
  SysUtils;

function ReverseStr(const S: string): string;
var
  i: integer;
begin
  Result := '';
  for i := Length(S) downto 1 do
    Result := Result + S[i];
end;

function IsPalindrome(const S: string): boolean;
var
  Clean: string;
  i: integer;
begin
  Clean := '';
  for i := 1 to Length(S) do
    if S[i] in ['a'..'z', 'A'..'Z', '0'..'9'] then
      Clean := Clean + LowerCase(S[i]);
  Result := Clean = ReverseStr(Clean);
end;

var
  TestStr: string;

begin
  WriteLn('=== string Utility Functions ===');
  WriteLn;
  TestStr := 'racecar';
  WriteLn('string:     ', TestStr);
  WriteLn('Reversed:   ', ReverseStr(TestStr));
  WriteLn('Palindrome: ', IsPalindrome(TestStr));

  TestStr := 'A man a plan a canal panama';
  WriteLn;
  WriteLn('string:     ', TestStr);
  WriteLn('Reversed:   ', ReverseStr(TestStr));
  WriteLn('Palindrome: ', IsPalindrome(TestStr));

  TestStr := 'Hello World';
  WriteLn;
  WriteLn('string:     ', TestStr);
  WriteLn('Reversed:   ', ReverseStr(TestStr));
  WriteLn('Palindrome: ', IsPalindrome(TestStr));

  WriteLn;
  WriteLn('Example completed.');
end.
