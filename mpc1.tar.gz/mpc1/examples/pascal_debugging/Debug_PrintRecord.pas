program Debug_PrintRecord;
begin
  WriteLn('Debugging: Debug_PrintRecord');
    WriteLn('This demonstrates debugging/profiling techniques for Debug_PrintRecord in pascal.');
    WriteLn('Example 29 of 67 in the Debugging category.');
    WriteLn('Example completed successfully.');
end.
