program CodeCoverage_Branch;
begin
  WriteLn('Debugging: CodeCoverage_Branch');
    WriteLn('This demonstrates debugging/profiling techniques for CodeCoverage_Branch in pascal.');
    WriteLn('Example 66 of 67 in the Debugging category.');
    WriteLn('Example completed successfully.');
end.
