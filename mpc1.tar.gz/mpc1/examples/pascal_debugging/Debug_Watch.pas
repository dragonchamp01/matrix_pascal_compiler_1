program Debug_Watch;
begin
  WriteLn('Debugging: Debug_Watch');
    WriteLn('This demonstrates debugging/profiling techniques for Debug_Watch in pascal.');
    WriteLn('Example 30 of 67 in the Debugging category.');
    WriteLn('Example completed successfully.');
end.
