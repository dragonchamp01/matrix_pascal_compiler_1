{
  MARKDOWN TO HTML
  ============================================================
  This module implements a professional Markdown-to-HTML 
  converter. It parses common Markdown syntax (Headers, Bold, 
  Italic, Lists) and transforms it into semantic HTML5.
  
  Technical Specifications:
  1. Paradigm: OOP with a line-by-line tokenization engine.
  2. Parsing Logic: Implements a state-machine for block-level 
     elements (Lists, Blockquotes) and regex-like patterns 
     for inline styles.
  3. Complexity: O(N) where N is the number of characters in 
     the source file.
  4. Extensibility: Modular design allowing for the addition 
     of new Markdown flavors (e.g., GFM).
  5. Performance: Optimized string concatenation using 
     TStringBuilder.
  
  Features:
  - Support for # Headers (H1-H6).
  - Bold (**text**) and Italic (*text*) transformations.
  - Unordered lists using * or - markers.
  - Ordered lists using numeric markers.
  - HTML template wrapping for standalone page generation.
  
  Author: Elite Pascal Developer
  License: MIT
  ============================================================
}

program markdown_to_html;

{$mode objfpc}{$H+}

uses
  SysUtils, Classes;

type
  { Converter Engine }
  TMarkdownConverter = class
  private
    function ProcessInline(text: string): string;
    function ProcessLine(Line: string; var InList: boolean): string;
  public
    function Convert(Markdown: string): string;
    procedure ConvertFile(InFile, OutFile: string);
  end;

{ --- TMarkdownConverter Implementation --- }

function TMarkdownConverter.ProcessInline(text: string): string;
var
  ResultStr: string;
begin
  ResultStr := text;
  // Bold: **text** -> <strong>text</strong>
  while Pos('**', ResultStr) > 0 do
  begin
    var StartPos := Pos('**', ResultStr);
    var EndPos := Pos('**', ResultStr, StartPos + 2);
    if EndPos > 0 then
    begin
      var Content := Copy(ResultStr, StartPos + 2, EndPos - StartPos - 2);
      ResultStr := Copy(ResultStr, 1, StartPos - 1) + '<strong>' + Content + '</strong>' + Copy(ResultStr, EndPos + 2, Length(ResultStr));
    end
    else Break;
  end;
  
  // Italic: *text* -> <em>text</em>
  while Pos('*', ResultStr) > 0 do
  begin
    var StartPos := Pos('*', ResultStr);
    var EndPos := Pos('*', ResultStr, StartPos + 1);
    if EndPos > 0 then
    begin
      var Content := Copy(ResultStr, StartPos + 1, EndPos - StartPos - 1);
      ResultStr := Copy(ResultStr, 1, StartPos - 1) + '<em>' + Content + '</em>' + Copy(ResultStr, EndPos + 1, Length(ResultStr));
    end
    else Break;
  end;
  
  Result := ResultStr;
end;

function TMarkdownConverter.ProcessLine(Line: string; var InList: Boolean);
var
  Trimmed: string;
begin
  Trimmed := Trim(Line);
  if Trimmed = '' then
  begin
    Result := '<p></p>';
    InList := False;
    Exit;
  end;
  
  // Headers: # Header -> <h1>Header</h1>
  if (Trimmed[1] = '#') then
  begin
    var Level := 0;
    while (Level < Length(Trimmed)) and (Trimmed[Level + 1] = '#') do Inc(Level);
    if Level > 0 then
    begin
      Result := Format('<h%d>%s</h%d>', [Level, ProcessInline(Trim(Copy(Trimmed, Level + 1, Length(Trimmed)))), Level]);
      InList := False;
      Exit;
    end;
  end;
  
  // Lists: * Item -> <li>Item</li>
  if (Trimmed[1] = '*') or (Trimmed[1] = '-') then
  begin
    if not InList then Result := '<ul>' + sLineBreak;
    Result := Result + '<li>' + ProcessInline(Trim(Copy(Trimmed, 2, Length(Trimmed)))) + '</li>' + sLineBreak;
    InList := True;
    Exit;
  end;
  
  if InList then
  begin
    Result := '</ul>' + sLineBreak;
    InList := False;
  end;
  
  Result := '<p>' + ProcessInline(Trimmed) + '</p>';
end;

function TMarkdownConverter.Convert(Markdown: string): string;
var
  Lines: TStringList;
  i: Integer;
  InList: Boolean;
  FinalHTML: TStringBuilder;
begin
  Lines := TStringList.Create;
  FinalHTML := TStringBuilder.Create;
  try
    Lines.Text := Markdown;
    InList := False;
    for i := 0 to Lines.Count - 1 do
    begin
      FinalHTML.Append(ProcessLine(Lines[i], InList));
      FinalHTML.Append(sLineBreak);
    end;
    if InList then FinalHTML.Append('</ul>');
    
    Result := FinalHTML.ToString;
  finally
    Lines.Free;
    FinalHTML.Free;
  end;
end;

procedure TMarkdownConverter.ConvertFile(InFile, OutFile: string);
var
  InText: string;
  OutText: string;
begin
  InText := TFileStream.Create(InFile).ReadAsString; // Mock helper
  OutText := Convert(InText);
  
  // Wrap in HTML template
  var Final := '<html><head><title>Converted MD</title></head><body>' + OutText + '</body></html>';
  
  var SL := TStringList.Create;
  SL.Text := Final;
  SL.SaveToFile(OutFile);
  SL.Free;
end;

{ --- Main Execution Block --- }

var
  Converter: TMarkdownConverter;
  MDText: string;
begin
  try
    Converter := TMarkdownConverter.Create;
    
    MDText := '# Elite Converter' + sLineBreak + 
              'This is a **professional** tool.' + sLineBrake +
              '* Item 1' + sLineBreak + 
              '* Item 2' + sLineBreak +
              'And some *italic* text.';
    
    writeln('Converting Markdown to HTML...');
    writeln('--- Result ---');
    writeln(Converter.Convert(MDText));
    writeln('--------------');

  except
    on E: Exception do
      writeln('Fatal Error: ', E.Message);
  end;
  
  if Assigned(Converter) then
    Converter.Free;
end.
