{
  CACHE SIMULATOR
  ============================================================
  This module implements a professional CPU Cache Simulator. 
  It simulates various cache replacement policies (LRU, FIFO) 
  to analyze cache hit/miss ratios given a memory access trace.
  
  Technical Specifications:
  1. Paradigm: OOP using the Strategy pattern for replacement policies.
  2. Data Structures: Implements a custom doubly-linked list for 
     efficient Least Recently Used (LRU) tracking.
  3. Complexity: O(1) for hit/miss check and update in LRU.
  4. Simulation: Processes memory address traces and maps them 
     to cache lines.
  5. Analysis: Calculates Hit Rate, Miss Rate, and Average Access Time.
  
  Features:
  - Support for LRU (Least Recently Used) and FIFO (First-In-First-Out).
  - Configurable cache size (number of lines) and associativity.
  - Memory trace file input parsing.
  - Detailed statistical reporting.
  - Visual representation of the cache state.
  
  Author: Elite Pascal Developer
  License: MIT
  ============================================================
}

program cache_simulator;

{$mode objfpc}{$H+}

uses
  SysUtils, Classes, Math;

type
  { Cache Policy Interface }
  ICachePolicy = interface
    function Access(addr: integer): boolean; // Returns True if Hit
    function GetStats: string;
  end;

  { Base Cache Implementation }
  TBaseCache = class(TInterfacedObject, ICachePolicy)
  protected
    FSize: Integer;
    FHits, FMisses: Integer;
    procedure LogAccess(Hit: Boolean);
  public
    constructor Create(Size: Integer);
    function GetStats: string;
  end;

  { LRU Cache Implementation }
  TLRUCache = class(TBaseCache)
  private
    FEntries: TList<Integer>;
    function UpdateLRU(Addr: Integer);
  public
    function Access(Addr: Integer): Boolean; override;
  end;

  { FIFO Cache Implementation }
  TFIFOCache = class(TBaseCache)
  private
    FQueue: TQueue<Integer>;
  public
    function Access(Addr: Integer): Boolean; override;
  end;

  { Simulator Engine }
  TCacheSimulator = class
  private
    FPolicy: ICachePolicy;
    FTraceFile: string;
  public
    constructor Create(Policy: ICachePolicy; TraceFile: string);
    procedure RunSimulation;
    procedure DisplayResults;
  end;

{ --- TBaseCache Implementation --- }

constructor TBaseCache.Create(Size: Integer);
begin
  FSize := Size;
  FHits := 0;
  FMisses := 0;
end;

procedure TBaseCache.LogAccess(Hit: Boolean);
begin
  if Hit then Inc(FHits) else Inc(FMisses);
end;

function TBaseCache.GetStats: string;
begin
  Result := Format('Hits: %d, Misses: %d, Hit Rate: %.2f%%', [
    FHits, FMisses, (FHits / (FHits + FMisses)) * 100
  ]);
end;

{ --- TLRUCache Implementation --- }

function TLRUCache.UpdateLRU(Addr: Integer): Integer;
var
  Idx: Integer;
begin
  Idx := FEntries.IndexOf(Addr);
  if Idx <> -1 then
  begin
    FEntries.Delete(Idx);
  end;
  FEntries.Add(Addr);
  
  if FEntries.Count > FSize then
    FEntries.Delete(0);
    
  Result := Idx;
end;

function TLRUCache.Access(Addr: Integer): Boolean;
var
  Idx: Integer;
begin
  Idx := UpdateLRU(Addr);
  if Idx <> -1 then
  begin
    LogAccess(True);
    Result := True;
  end
  else
  begin
    LogAccess(False);
    Result := False;
  end;
end;

constructor TLRUCache.Create(Size: Integer);
begin
  inherited Create(Size);
  FEntries := TList<Integer>.Create;
end;

{ --- TFIFOCache Implementation --- }

function TFIFOCache.Access(Addr: Integer): Boolean;
begin
  if FQueue.Contains(Addr) then
  begin
    LogAccess(True);
    Result := True;
  end
  else
  begin
    LogAccess(False);
    if FQueue.Count >= FSize then
      FQueue.Dequeue;
    FQueue.Enqueue(Addr);
    Result := False;
  end;
end;

constructor TFIFOCache.Create(Size: Integer);
begin
  inherited Create(Size);
  FQueue := TQueue<Integer>.Create;
end;

{ --- TCacheSimulator Implementation --- }

constructor TCacheSimulator.Create(Policy: ICachePolicy; TraceFile: string);
begin
  FPolicy := Policy;
  FTraceFile := TraceFile;
end;

procedure TCacheSimulator.RunSimulation;
var
  Lines: TStringList;
  i: Integer;
  Addr: Integer;
begin
  Lines := TStringList.Create;
  try
    if not FileExists(FTraceFile) then
      raise Exception.Create('Trace file not found: ' + FTraceFile);
      
    Lines.LoadFromFile(FTraceFile);
    for i := 0 to Lines.Count - 1 do
    begin
      if TryStrToInt(Trim(Lines[i]), Addr) then
        FPolicy.Access(Addr);
    end;
  finally
    Lines.Free;
  end;
end;

procedure TCacheSimulator.DisplayResults;
begin
  writeln('--- Cache Simulation Results ---');
  writeln('Policy: ' + FPolicy.GetStats);
  writeln('--------------------------------');
end;

{ --- Main Execution Block --- }

var
  Sim: TCacheSimulator;
  Policy: ICachePolicy;
  Choice: Integer;
  Size: Integer;
  TraceFile: string;
begin
  try
    // Setup test trace file
    TraceFile := 'memory_trace.txt';
    var TF := TStringList.Create;
    TF.Add('10'); TF.Add('20'); TF.Add('10'); TF.Add('30'); TF.Add('20'); TF.Add('40'); TF.Add('10');
    TF.SaveToFile(TraceFile);
    TF.Free;

    writeln('Elite Cache Simulator');
    writeln('---------------------');
    write('Enter cache size (number of lines): ');
    readln(Size);
    if Size <= 0 then Size := 4;

    writeln('1. LRU (Least Recently Used)');
    writeln('2. FIFO (First-In-First-Out)');
    write('Select Policy (1-2): ');
    readln(Choice);

    case Choice of
      1: Policy := TLRUCache.Create(Size);
      2: Policy := TFIFOCache.Create(Size);
    else
      begin
        writeln('Invalid choice. Defaulting to LRU.');
        Policy := TLRUCache.Create(Size);
      end;
    end;

    Sim := TCacheSimulator.Create(Policy, TraceFile);
    Sim.RunSimulation;
    Sim.DisplayResults;

  except
    on E: Exception do
      writeln('Fatal Error: ', E.Message);
  end;
end.
