{
  CRON JOB MANAGER
  ============================================================
  This module implements a professional manager for Linux 
  crontab entries. It allows users to view, add, and remove 
  scheduled tasks without interacting directly with the 
  crontab editor.
  
  Technical Specifications:
  1. Paradigm: OOP with an emphasis on system file manipulation.
  2. Linux Integration: Interfaces with the 'crontab -l' and 
     'crontab <file>' commands.
  3. Parsing Logic: Implements a basic cron expression validator 
     (minute hour dom month dow command).
  4. Safety: Automatically creates backups of the current 
     crontab before applying any changes.
  5. Error Handling: Robust handling of empty crontabs and 
     invalid cron syntax.
  
  Features:
  - List current active cron jobs.
  - Add new jobs with validated cron expressions.
  - Remove jobs by index or keyword.
  - Backup and restore crontab state.
  - Professional CLI for task management.
  
  Author: Elite Pascal Developer
  License: MIT
  ============================================================
}

program cron_job_manager;

{$mode objfpc}{$H+}

uses
  SysUtils, Classes;

type
  { Cron Job Representation }
  TCronJob = record
    Schedule: string;
    Command: string;
    RawLine: string;
  end;

  { Cron Manager Engine }
  TCronManager = class
  private
    FJobs: TList<TCronJob>;
    function ValidateCronExpr(Expr: string): boolean;
    procedure LoadCrontab;
    procedure SaveCrontab;
  public
    constructor Create;
    destructor Destroy; override;
    procedure ListJobs;
    procedure AddJob(const Schedule, Command: string);
    procedure RemoveJob(index: integer);
    procedure BackupCrontab;
  end;

{ --- TCronManager Implementation --- }

constructor TCronManager.Create;
begin
  FJobs := TList<TCronJob>.Create;
  LoadCrontab;
end;

destructor TCronManager.Destroy;
begin
  FJobs.Free;
  inherited Destroy;
end;

function TCronManager.ValidateCronExpr(Expr: string): boolean;
var
  Parts: TArray<string>;
begin
  Parts := Expr.Split([' ']);
  // Basic cron expression must have 5 fields
  Result := (Length(Parts) >= 5);
end;

procedure TCronManager.LoadCrontab;
var
  Output: string;
  Lines: TStringList;
  i: Integer;
  Parts: TArray<string>;
  Job: TCronJob;
begin
  FJobs.Clear;
  // Get current crontab via command
  Output := fpSystemPChar(PChar('crontab -l'));
  
  Lines := TStringList.Create;
  try
    Lines.Text := Output;
    for i := 0 to Lines.Count - 1 do
    begin
      if (Trim(Lines[i]) <> '') and (Lines[i][1] <> '#') then
      begin
        Parts := Lines[i].Split([' ']);
        if Length(Parts) >= 6 then
        begin
          Job.RawLine := Lines[i];
          Job.Schedule := Copy(Lines[i], 1, Pos(' ', Lines[i], 10)); // Rough slice
          Job.Command := Copy(Lines[i], Pos(' ', Lines[i], 10), Length(Lines[i]));
          FJobs.Add(Job);
        end;
      end;
    end;
  finally
    Lines.Free;
  end;
end;

procedure TCronManager.SaveCrontab;
var
  TempFile: string;
  SL: TStringList;
  i: Integer;
begin
  TempFile := 'temp_cron';
  SL := TStringList.Create;
  try
    for i := 0 to FJobs.Count - 1 do
      SL.Add(FJobs[i].RawLine);
    SL.SaveToFile(TempFile);
    
    // Load the temp file into crontab
    fpSystem(PChar('crontab ' + TempFile));
    DeleteFile(TempFile);
  finally
    SL.Free;
  end;
end;

procedure TCronManager.ListJobs;
var
  i: Integer;
  Job: TCronJob;
begin
  writeln('--- Current Cron Jobs ---');
  if FJobs.Count = 0 then
    writeln('No active cron jobs found.');
  
  for i := 0 to FJobs.Count - 1 do
  begin
    Job := FJobs[i];
    writeln(Format('[%d] %s', [i + 1, Job.RawLine]));
  end;
  writeln('-------------------------');
end;

procedure TCronManager.AddJob(const Schedule, Command: string);
var
  Job: TCronJob;
begin
  if not ValidateCronExpr(Schedule) then
    raise Exception.Create('Invalid cron expression format.');
    
  Job.RawLine := Format('%s %s', [Schedule, Command]);
  Job.Schedule := Schedule;
  Job.Command := Command;
  
  FJobs.Add(Job);
  SaveCrontab;
end;

procedure TCronManager.RemoveJob(Index: Integer);
begin
  if (Index < 1) or (Index > FJobs.Count) then
    raise Exception.Create('Invalid job index.');
    
  FJobs.Delete(Index - 1);
  SaveCrontab;
end;

procedure TCronManager.BackupCrontab;
begin
  fpSystem(PChar('crontab -l > crontab_backup.bak'));
  writeln('Crontab backed up to crontab_backup.bak');
end;

{ --- Main Execution Block --- }

var
  Manager: TCronManager;
  Choice: Integer;
  Sched, Cmd: string;
  Idx: Integer;
begin
  try
    Manager := TCronManager.Create;
    
    repeat
      writeln;
      writeln('Elite Cron Job Manager');
      writeln('----------------------');
      writeln('1. List Jobs');
      writeln('2. Add Job');
      writeln('3. Remove Job');
      writeln('4. Backup Crontab');
      writeln('0. Exit');
      write('Choice: ');
      readln(Choice);
      
      case Choice of
        1: Manager.ListJobs;
        2: begin
             write('Enter schedule (e.g., "0 * * * *"): '); readln(Sched);
             write('Enter command: '); readln(Cmd);
             try
               Manager.AddJob(Sched, Cmd);
               writeln('Job added successfully.');
             except
               on E: Exception do writeln('Error: ', E.Message);
             end;
           end;
        3: begin
             Manager.ListJobs;
             write('Enter index to remove: '); readln(Idx);
             try
               Manager.RemoveJob(Idx);
               writeln('Job removed successfully.');
             except
               on E: Exception do writeln('Error: ', E.Message);
             end;
           end;
        4: Manager.BackupCrontab;
      end;
    until Choice = 0;

  except
    on E: Exception do
      writeln('Fatal Error: ', E.Message);
  end;
  
  if Assigned(Manager) then
    Manager.Free;
end.
