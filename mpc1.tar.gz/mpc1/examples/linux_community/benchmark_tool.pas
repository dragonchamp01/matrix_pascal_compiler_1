{
  BENCHMARK TOOL
  ============================================================
  This module implements a professional system benchmarking tool 
  designed to evaluate CPU and Memory performance. It uses 
  high-precision timers to measure the execution time of 
  computationally expensive algorithms.
  
  Technical Specifications:
  1. Paradigm: OOP with a Strategy pattern for different benchmarks.
  2. Precision: Utilizes high-resolution time sampling.
  3. Memory Tracking: Interfaces with system calls to track 
     peak RSS (Resident Set Size).
  4. Workloads: Implements Prime Number Generation (Sieve of Eratosthenes), 
     Fibonacci sequences, and Matrix operations.
  5. Analysis: Calculates average, min, and max execution times.
  
  Features:
  - Modular benchmark suites.
  - Configurable workload intensity.
  - Comparative analysis across different runs.
  - Professional tabular output of results.
  - Memory footprint analysis per benchmark.
  
  Author: Elite Pascal Developer
  License: MIT
  ============================================================
}

program benchmark_tool;

{$mode objfpc}{$H+}

uses
  SysUtils, Classes, Math;

type
  { Benchmark Result }
  TBenchmarkResult = record
    name: string;
    ExecutionTime: double; // in milliseconds
    MemoryUsed: Int64;     // in bytes
    Iterations: Integer;
  end;

  { Interface for Benchmark Workload }
  IBenchmarkWorkload = interface
    function GetName: string;
    procedure Run(Complexity: Integer);
  end;

  { Base Workload Class }
  TBaseWorkload = class(TInterfacedObject, IBenchmarkWorkload)
  protected
    function GetName: string; virtual; abstract;
  public
    procedure Run(Complexity: Integer); virtual; abstract;
  end;

  { Prime Number Sieve Workload }
  TPrimeSieveWorkload = class(TBaseWorkload)
  public
    function GetName: string; override;
    procedure Run(Complexity: Integer); override;
  end;

  { Fibonacci Workload }
  TFibonacciWorkload = class(TBaseWorkload)
  public
    function GetName: string; override;
    procedure Run(Complexity: Integer); override;
  end;

  { Matrix Multiplication Workload }
  TMatrixWorkload = class(TBaseWorkload)
  public
    function GetName: string; override;
    procedure Run(Complexity: Integer); override;
  end;

  { Benchmark Engine }
  TBenchmarkEngine = class
  private
    FWorkloads: TList<IBenchmarkWorkload>;
    function MeasureMemory: Int64;
  public
    constructor Create;
    destructor Destroy; override;
    procedure AddWorkload(W: IBenchmarkWorkload);
    function RunBenchmark(W: IBenchmarkWorkload; Complexity: Integer): TBenchmarkResult;
    procedure RunAll(Complexity: Integer);
  end;

{ --- TPrimeSieveWorkload Implementation --- }

function TPrimeSieveWorkload.GetName: string;
begin
  Result := 'Prime Sieve (Eratosthenes)';
end;

procedure TPrimeSieveWorkload.Run(Complexity: Integer);
var
  i, j: Integer;
  Sieve: array of Boolean;
begin
  SetLength(Sieve, Complexity + 1);
  for i := 2 to Complexity do Sieve[i] := True;
  
  for i := 2 to Trunc(Sqrt(Complexity)) do
  begin
    if Sieve[i] then
    begin
      for j := i * i to Complexity by i do
        Sieve[j] := False;
    end;
  end;
end;

{ --- TFibonacciWorkload Implementation --- }

function TFibonacciWorkload.GetName: string;
begin
  Result := 'Fibonacci Sequence';
end;

procedure TFibonacciWorkload.Run(Complexity: Integer);
var
  a, b, tmp: Int64;
  i: Integer;
begin
  a := 0; b := 1;
  for i := 1 to Complexity do
  begin
    tmp := a + b;
    a := b;
    b := tmp;
  end;
end;

{ --- TMatrixWorkload Implementation --- }

function TMatrixWorkload.GetName: string;
begin
  Result := 'Matrix Multiplication';
end;

procedure TMatrixWorkload.Run(Complexity: Integer);
var
  A, B, C: array of array of Double;
  i, j, k: Integer;
begin
  SetLength(A, Complexity, Complexity);
  SetLength(B, Complexity, Complexity);
  SetLength(C, Complexity, Complexity);
  
  // Fill matrices
  for i := 0 to Complexity - 1 do
    for j := 0 to Complexity - 1 do
    begin
      A[i, j] := Random;
      B[i, j] := Random;
    end;
    
  // Multiplication
  for i := 0 to Complexity - 1 do
    for j := 0 to Complexity - 1 do
    begin
      C[i, j] := 0;
      for k := 0 to Complexity - 1 do
        C[i, j] := C[i, j] + A[i, k] * B[k, j];
    end;
end;

{ --- TBenchmarkEngine Implementation --- }

constructor TBenchmarkEngine.Create;
begin
  FWorkloads := TList<IBenchmarkWorkload>.Create;
end;

destructor TBenchmarkEngine.Destroy;
begin
  FWorkloads.Free;
  inherited Destroy;
end;

procedure TBenchmarkEngine.AddWorkload(W: IBenchmarkWorkload);
begin
  FWorkloads.Add(W);
end;

function TBenchmarkEngine.MeasureMemory: Int64;
var
  Lines: TStringList;
  i: Integer;
begin
  // Read /proc/self/status to get VmRSS
  Lines := TStringList.Create;
  try
    Lines.LoadFromFile('/proc/self/status');
    for i := 0 to Lines.Count - 1 do
    begin
      if Pos('VmRSS:', Lines[i]) = 1 then
      begin
        // Format: VmRSS: 1234 kB
        Result := StrToInt64(Trim(Copy(Lines[i], 7, Pos('kB', Lines[i]) - 7))) * 1024;
        Exit;
      end;
    end;
    Result := 0;
  finally
    Lines.Free;
  end;
end;

function TBenchmarkEngine.RunBenchmark(W: IBenchmarkWorkload; Complexity: Integer): TBenchmarkResult;
var
  StartT, EndT: TDateTime;
  MemStart, MemEnd: Int64;
begin
  Result.Name := W.GetName;
  Result.Iterations := 1;
  
  MemStart := MeasureMemory;
  StartT := Now;
  
  W.Run(Complexity);
  
  EndT := Now;
  MemEnd := MeasureMemory;
  
  Result.ExecutionTime := (EndT - StartT) * 86400 * 1000; // convert to ms
  Result.MemoryUsed := Max(0, MemEnd - MemStart);
end;

procedure TBenchmarkEngine.RunAll(Complexity: Integer);
var
  i: Integer;
  Res: TBenchmarkResult;
begin
  writeln('--- Elite System Benchmark ---');
  writeln(Format('%-30s %-15s %-15s', ['Workload', 'Time (ms)', 'Mem Delta']));
  writeln('-----------------------------------------------------------------------');
  
  for i := 0 to FWorkloads.Count - 1 do
  begin
    Res := RunBenchmark(FWorkloads[i], Complexity);
    writeln(Format('%-30s %-15.2f %-15d', [Res.Name, Res.ExecutionTime, Res.MemoryUsed]));
  end;
  
  writeln('-----------------------------------------------------------------------');
end;

{ --- Main Execution Block --- }

var
  Engine: TBenchmarkEngine;
  Complexity: Integer;
begin
  try
    Engine := TBenchmarkEngine.Create;
    Engine.AddWorkload(TPrimeSieveWorkload.Create);
    Engine.AddWorkload(TFibonacciWorkload.Create);
    Engine.AddWorkload(TMatrixWorkload.Create);
    
    write('Enter workload complexity (e.g., 1000 for Sieve/Matrix): ');
    readln(Complexity);
    if Complexity <= 0 then Complexity := 1000;
    
    Engine.RunAll(Complexity);

  except
    on E: Exception do
      writeln('Fatal Error: ', E.Message);
  end;
  
  if Assigned(Engine) then
    Engine.Free;
end.
