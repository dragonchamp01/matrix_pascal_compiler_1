{
  ALGORITHM VISUALIZER
  ============================================================
  This module provides a professional-grade visualization framework
  for various algorithms, specifically focusing on sorting and searching.
  
  Technical Specifications:
  1. Paradigm: Object-Oriented Programming (OOP) with Interfaces.
  2. Complexity: Varies by algorithm (e.g., O(N log N) for QuickSort).
  3. State Management: Interface-driven state tracking for visualization.
  4. Linux Integration: Uses ANSI escape codes for terminal-based visualization.
  5. Error Handling: Custom exception hierarchy for algorithm-specific errors.
  
  Features:
  - Generic algorithm interface (IAlgorithm).
  - Concrete implementations of BubbleSort and QuickSort.
  - Real-time terminal rendering with color-coded state.
  - Input validation and dynamic data generation.
  
  Author: Elite Pascal Developer
  License: MIT
  ============================================================
}

program algorithm_visualizer;

{$mode objfpc}{$H+}

uses
  SysUtils, Classes, Math;

type
  { Custom Exception for Algorithm Errors }
  EAlgorithmError = class(Exception);
  EInvalidInputError = class(EAlgorithmError);

  { Interface for Visualizable Algorithms }
  IAlgorithm = interface
    function GetName: string;
    procedure Execute(Data: TArray<integer>; OnStep: TProc<TArray<integer>; integer>;);
  end;

  { Visualization State }
  TVisualizerState = record
    Data: TArray<integer>;
    ActiveIndex1: integer;
    ActiveIndex2: integer;
    ComparisonCount: integer;
    SwapCount: integer;
  end;

  { Abstract Base Class for Algorithms }
  TBaseAlgorithm = class(TInterfacedObject, IAlgorithm)
  protected
    function GetName: string; virtual; abstract;
    procedure LogStep(Data: TArray<integer>; i, j: integer; var stepCount: integer);
  public
    procedure Execute(Data: TArray<integer>; OnStep: TProc<TArray<integer>; integer>); virtual; abstract;
  end;

  { Bubble Sort Implementation }
  TBubbleSort = class(TBaseAlgorithm)
  public
    function GetName: string; override;
    procedure Execute(Data: TArray<integer>; OnStep: TProc<TArray<integer>; integer>); override;
  end;

  { Quick Sort Implementation }
  TQuickSort = class(TBaseAlgorithm)
  private
    procedure Partition(var Data: TArray<integer>; low, high: integer; OnStep: TProc<TArray<integer>; integer>);
    procedure QuickSortRecursive(var Data: TArray<integer>; low, high: integer; OnStep: TProc<TArray<integer>; integer>);
  public
    function GetName: string; override;
    procedure Execute(Data: TArray<integer>; OnStep: TProc<TArray<integer>; integer>); override;
  end;

  { Visualizer Engine }
  TVisualizerEngine = class
  private
    FAlgorithm: IAlgorithm;
    FData: TArray<integer>;
    procedure Render(Data: TArray<integer>; ActiveIndex: integer);
  public
    constructor Create(Algorithm: IAlgorithm);
    procedure GenerateData(Size: integer);
    procedure Run;
  end;

{ --- TBaseAlgorithm Implementation --- }

procedure TBaseAlgorithm.LogStep(Data: TArray<integer>; i, j: integer; var stepCount: integer);
begin
  // Step logging can be extended for telemetry
  Inc(stepCount);
end;

{ --- TBubbleSort Implementation --- }

function TBubbleSort.GetName: string;
begin
  Result := 'Bubble Sort';
end;

procedure TBubbleSort.Execute(Data: TArray<Integer>; OnStep: TProc<TArray<Integer>; Integer>);
var
  i, j: Integer;
  Temp: Integer;
  n: Integer;
begin
  n := Length(Data);
  for i := 0 to n - 2 do
  begin
    for j := 0 to n - i - 2 do
    begin
      if Data[j] > Data[j + 1] then
      begin
        Temp := Data[j];
        Data[j] := Data[j + 1];
        Data[j + 1] := Temp;
      end;
      OnStep(Data, j);
    end;
  end;
end;

{ --- TQuickSort Implementation --- }

function TQuickSort.GetName: string;
begin
  Result := 'Quick Sort';
end;

procedure TQuickSort.Partition(var Data: TArray<Integer>; low, high: Integer; OnStep: TProc<TArray<Integer>; Integer>);
var
  i, j: Integer;
  Pivot, Temp: Integer;
begin
  Pivot := Data[high];
  i := low - 1;
  for j := low to high - 1 do
  begin
    if Data[j] <= Pivot then
    begin
      Inc(i);
      Temp := Data[i];
      Data[i] := Data[j];
      Data[j] := Temp;
      OnStep(Data, i);
    end;
  end;
  Temp := Data[i + 1];
  Data[i + 1] := Data[high];
  Data[high] := Temp;
  OnStep(Data, i + 1);
end;

procedure TQuickSort.QuickSortRecursive(var Data: TArray<Integer>; low, high: Integer; OnStep: TProc<TArray<Integer>; Integer>);
var
  p: Integer;
begin
  if low < high then
  begin
    p := Partition(Data, low, high, OnStep);
    QuickSortRecursive(Data, low, p - 1, OnStep);
    QuickSortRecursive(Data, p + 1, high, OnStep);
  end;
end;

procedure TQuickSort.Execute(Data: TArray<Integer>; OnStep: TProc<TArray<Integer>; Integer>);
begin
  QuickSortRecursive(Data, 0, Length(Data) - 1, OnStep);
end;

{ --- TVisualizerEngine Implementation --- }

constructor TVisualizerEngine.Create(Algorithm: IAlgorithm);
begin
  FAlgorithm := Algorithm;
end;

procedure TVisualizerEngine.GenerateData(Size: Integer);
var
  i: Integer;
begin
  if Size <= 0 then
    raise EInvalidInputError.Create('Data size must be positive.');
  
  SetLength(FData, Size);
  for i := 0 to Size - 1 do
    FData[i] := Random(100) + 1;
end;

procedure TVisualizerEngine.Render(Data: TArray<Integer>; ActiveIndex: Integer);
var
  i: Integer;
  Bar: string;
  Color: string;
begin
  // ANSI Escape: Clear screen and move cursor to top-left
  Write(#27 + '[2J' + #27 + '[H');
  writeln('Visualizing: ', FAlgorithm.GetName);
  writeln('--------------------------------------------------');
  
  for i := 0 to Length(Data) - 1 do
  begin
    Bar := StringOfChar(' ', 0); // Placeholder for alignment
    
    if i = ActiveIndex then
      Color := #27 + '[31m' // Red for active
    else
      Color := #27 + '[32m'; // Green for others
      
    // Print bar representation
    Write(Color);
    Write(Format('%3d | ', [Data[i]]));
    Write(StringOfChar('█', Data[i]));
    Write(#27 + '[0m'); // Reset color
    writeln;
  end;
  writeln('--------------------------------------------------');
end;

procedure TVisualizerEngine.Run;
begin
  FAlgorithm.Execute(FData, 
    procedure(Data: TArray<Integer>; Index: Integer)
    begin
      Render(Data, Index);
      Sleep(50); // Control visualization speed
    end);
  
  // Final render to show sorted result
  Render(FData, -1);
  writeln('Algorithm completed.');
end;

{ --- Main Execution Block --- }

var
  Engine: TVisualizerEngine;
  Algo: IAlgorithm;
  Choice: Integer;
begin
  try
    writeln('Welcome to Elite Algorithm Visualizer');
    writeln('1. Bubble Sort');
    writeln('2. Quick Sort');
    write('Select Algorithm (1-2): ');
    readln(Choice);

    case Choice of
      1: Algo := TBubbleSort.Create;
      2: Algo := TQuickSort.Create;
    else
      begin
        writeln('Invalid choice. Defaulting to Quick Sort.');
        Algo := TQuickSort.Create;
      end;
    end;

    Engine := TVisualizerEngine.Create(Algo);
    Engine.GenerateData(20);
    Engine.Run;

  except
    on E: Exception do
      writeln('Fatal Error: ', E.Message);
  end;
end.
