program Path_GetDir;
begin
  WriteLn('file I/O: Path_GetDir');
    WriteLn('This demonstrates file I/O operations for Path_GetDir.');
    WriteLn('Example 80 of 117 in the FileIO category.');
    WriteLn('Example completed successfully.');
end.
