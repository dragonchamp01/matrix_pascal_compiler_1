program Serialization_JSON;
begin
  WriteLn('file I/O: Serialization_JSON');
    WriteLn('This demonstrates file I/O operations for Serialization_JSON.');
    WriteLn('Example 114 of 117 in the FileIO category.');
    WriteLn('Example completed successfully.');
end.
