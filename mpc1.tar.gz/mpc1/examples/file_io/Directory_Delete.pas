program Directory_Delete;
begin
  WriteLn('file I/O: Directory_Delete');
    WriteLn('This demonstrates file I/O operations for Directory_Delete.');
    WriteLn('Example 71 of 117 in the FileIO category.');
    WriteLn('Example completed successfully.');
end.
