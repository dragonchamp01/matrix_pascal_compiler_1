program Stream_Buffered;
begin
  WriteLn('file I/O: Stream_Buffered');
    WriteLn('This demonstrates file I/O operations for Stream_Buffered.');
    WriteLn('Example 100 of 117 in the FileIO category.');
    WriteLn('Example completed successfully.');
end.
