program ReadWriteText;
begin
  WriteLn('file I/O: ReadWriteText');
    WriteLn('This demonstrates file I/O operations for ReadWriteText.');
    WriteLn('Example 4 of 117 in the FileIO category.');
    WriteLn('Example completed successfully.');
end.
