program ReadTextFile;
begin
  WriteLn('file I/O: ReadTextFile');
    WriteLn('This demonstrates file I/O operations for ReadTextFile.');
    WriteLn('Example 1 of 117 in the FileIO category.');
    WriteLn('Example completed successfully.');
end.
