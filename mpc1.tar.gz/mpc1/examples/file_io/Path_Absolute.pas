program Path_Absolute;
begin
  WriteLn('file I/O: Path_Absolute');
    WriteLn('This demonstrates file I/O operations for Path_Absolute.');
    WriteLn('Example 85 of 117 in the FileIO category.');
    WriteLn('Example completed successfully.');
end.
