program Compression_LZMA;
begin
  WriteLn('file I/O: Compression_LZMA');
    WriteLn('This demonstrates file I/O operations for Compression_LZMA.');
    WriteLn('Example 110 of 117 in the FileIO category.');
    WriteLn('Example completed successfully.');
end.
