program FileInfo_Date;
begin
  WriteLn('file I/O: FileInfo_Date');
    WriteLn('This demonstrates file I/O operations for FileInfo_Date.');
    WriteLn('Example 65 of 117 in the FileIO category.');
    WriteLn('Example completed successfully.');
end.
