program Mandelbrot;

uses Xorg, Math;

const
  WIDTH = 800;
  HEIGHT = 600;
  MAX_ITER = 100;

var
  display: PDisplay;
  window: PWindow;
  screen: integer;
  root: integer;
  white_pixel, black_pixel: uint32;
  x, y, iter: integer;
  zx, zy, cx, cy, temp_x, temp_y: double;

begin
  display := XOpenDisplay(nil);
  if display = nil then
  begin
    WriteLn('Error: Cannot open X display.');
    exit;
  end;

  screen := XDefaultScreen(display);
  root := XDefaultRootWindow(display);
  white_pixel := XDefaultWhitePixel(display, screen);
  black_pixel := XDefaultBlackPixel(display, screen);

  window := XCreateSimpleWindow(display, root, 100, 100, WIDTH, HEIGHT, 1, black_pixel, white_pixel);
  XMapWindow(display, window);

  for y := 0 to HEIGHT - 1 do
  begin
    for x := 0 to WIDTH - 1 do
    begin
      cx := -2.0 + (x / WIDTH) * 3.0;
      cy := -1.0 + (y / HEIGHT) * 2.0;
      zx := 0; zy := 0;
      iter := 0;
      
      while (zx*zx + zy*zy <= 4.0) and (iter < MAX_ITER) do
      begin
        temp_x := zx*zx - zy*zy + cx;
        zy := 2*zx*zy + cy;
        zx := temp_x;
        Inc(iter);
      end;

      if iter < MAX_ITER then
      begin
        { Assume XDrawPoint(display, window, x, y, gc) exists or similar }
        XDrawPoint(display, window, x, y, 0); 
      end;
    end;
  end;

  WriteLn('Mandelbrot rendered. Press Enter to exit...');
  ReadLn;
  XDestroyWindow(display, window);
  XCloseDisplay(display);
end.
