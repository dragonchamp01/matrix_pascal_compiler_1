{ @ASM_MODE }
{ @ASSEMBLER64 }
program asm_67;
begin
    { Example $i: Demonstration of assembly instruction $i }
    mov rax, 67
    add rax, 1
    invoke WriteInteger, rax
end.
