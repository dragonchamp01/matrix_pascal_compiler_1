{ @ASM_MODE }
{ @ASSEMBLER64 }
program asm_38;
begin
    { Example $i: Demonstration of assembly instruction $i }
    mov rax, 38
    add rax, 1
    invoke WriteInteger, rax
end.
