{ @ASM_MODE }
{ @ASSEMBLER64 }
program asm_96;
begin
    { Example $i: Demonstration of assembly instruction $i }
    mov rax, 96
    add rax, 1
    invoke WriteInteger, rax
end.
