{ @ASM_MODE }
{ @ASSEMBLER64 }
program asm_72;
begin
    { Example $i: Demonstration of assembly instruction $i }
    mov rax, 72
    add rax, 1
    invoke WriteInteger, rax
end.
