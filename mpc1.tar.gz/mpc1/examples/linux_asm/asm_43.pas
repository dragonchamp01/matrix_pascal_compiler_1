{ @ASM_MODE }
{ @ASSEMBLER64 }
program asm_43;
begin
    { Example $i: Demonstration of assembly instruction $i }
    mov rax, 43
    add rax, 1
    invoke WriteInteger, rax
end.
