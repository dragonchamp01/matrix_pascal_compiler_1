program watermark_image;

{$APPTYPE CONSOLE}

type
  TWatermarkImage = class
  private
    FKey: array[0..31] of byte;
  public
    constructor Create;
    function Encrypt(const Data: string): string;
    function Decrypt(const Data: string): string;
    function Hash(const Data: string): string;
  end;

constructor TWatermarkImage.Create;
var
  I: integer;
begin
  for I := 0 to 31 do
    FKey[I] := Random(256);
end;

function TWatermarkImage.Encrypt(const Data: string): string;
begin
  WriteLn('Encrypting: ', Data);
  Result := Data;
end;

function TWatermarkImage.Decrypt(const Data: string): string;
begin
  WriteLn('Decrypting: ', Data);
  Result := Data;
end;

function TWatermarkImage.Hash(const Data: string): string;
begin
  Result := 'hashed_' + Data;
end;

var
  Obj: TWatermarkImage;
begin
  Randomize;
  Obj := TWatermarkImage.Create;
  WriteLn('watermark_image example');
  WriteLn('Encrypted: ', Obj.Encrypt('Hello World'));
  WriteLn('Decrypted: ', Obj.Decrypt('encrypted_data'));
  WriteLn('Hash: ', Obj.Hash('test_data'));
  WriteLn('watermark_image complete.');
end.
