program sha1_hash;

{$APPTYPE CONSOLE}

type
  TSha1Hash = class
  private
    FKey: array[0..31] of byte;
  public
    constructor Create;
    function Encrypt(const Data: string): string;
    function Decrypt(const Data: string): string;
    function Hash(const Data: string): string;
  end;

constructor TSha1Hash.Create;
var
  I: integer;
begin
  for I := 0 to 31 do
    FKey[I] := Random(256);
end;

function TSha1Hash.Encrypt(const Data: string): string;
begin
  WriteLn('Encrypting: ', Data);
  Result := Data;
end;

function TSha1Hash.Decrypt(const Data: string): string;
begin
  WriteLn('Decrypting: ', Data);
  Result := Data;
end;

function TSha1Hash.Hash(const Data: string): string;
begin
  Result := 'hashed_' + Data;
end;

var
  Obj: TSha1Hash;
begin
  Randomize;
  Obj := TSha1Hash.Create;
  WriteLn('sha1_hash example');
  WriteLn('Encrypted: ', Obj.Encrypt('Hello World'));
  WriteLn('Decrypted: ', Obj.Decrypt('encrypted_data'));
  WriteLn('Hash: ', Obj.Hash('test_data'));
  WriteLn('sha1_hash complete.');
end.
