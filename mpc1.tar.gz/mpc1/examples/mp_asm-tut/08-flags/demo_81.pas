program demo_81;

{ PUSHF / POPF - save and restore flags via stack }
{ pushf: pushes RFLAGS register onto stack }
{ popf: pops top of stack into RFLAGS register }
{ Useful for preserving flag state across operations }

var
  saved_flags: integer;
  modified_flags: integer;

begin
  saved_flags := 0;
  modified_flags := 0;

  asm
    pushf
    pop rax
    mov [saved_flags], eax

    stc
    mov eax, -1
    add eax, 1
    lahf
    mov [modified_flags], eax

    mov eax, [saved_flags]
    push rax
    popf
  end;

  WriteLn('Saved original flags: ');
  WriteLn(saved_flags);
  WriteLn('Flags after modification: ');
  WriteLn(modified_flags);
  WriteLn('Flags restored to original via popf');
end.
