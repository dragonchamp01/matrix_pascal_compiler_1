program DateTime_DiffMins;
begin
  WriteLn('System Utility: DateTime_DiffMins');
    WriteLn('This demonstrates system utility operations for DateTime_DiffMins in pascal.');
    WriteLn('Example 85 of 118 in the SysUtils category.');
    WriteLn('Example completed successfully.');
end.
