program Environment_OS;
begin
  WriteLn('System Utility: Environment_OS');
    WriteLn('This demonstrates system utility operations for Environment_OS in pascal.');
    WriteLn('Example 26 of 118 in the SysUtils category.');
    WriteLn('Example completed successfully.');
end.
