{
   Matrix Pascal AI Brain Example — Weekrapport
   web_weekly_report.pas
   ════════════════════════════════════════════════════════════════
   NL: Weekrapport
   EN: Weekly report
   Demonstrates: Comprehensive weekly learning report generation
}
program web_weekly_report;
{$mode objfpc}{$H+}
uses
  SysUtils, Classes,
  web_agent, knowledge_base, bookmark_manager, web_learner, keyword_engine;

  function GenerateWeekReport(Learner: TWebLearner; BM: TBookmarkManager;
    KE: TKeywordEngine; WeekNumber: integer): TStringList;
  var
    Report: TStringList;
  begin
    Report := TStringList.Create;
    Report.Add('========================================');
    Report.Add('  WEEKLY LEARNING REPORT - Week ' + IntToStr(WeekNumber));
    Report.Add('  Generated: ' + DateTimeToStr(Now));
    Report.Add('========================================');
    Report.Add('');
    Report.Add('Summary:');
    Report.Add('  Pages studied this week: ' + IntToStr(Learner.GetStudiedCount));
    Report.Add('  Bookmarks added: ' + IntToStr(BM.Count));
    Report.Add('  Keyword groups active: ' + IntToStr(KE.GetAllGroups.Count));
    Report.Add('');
    Report.Add('Studied URLs:');
    Report.AddStrings(Learner.StudiedURLs);
    Report.Add('');
    Report.Add('Bookmarks:');
    Report.AddStrings(BM.ListBookmarks);
    Report.Add('');
    Report.Add('Keyword Groups:');
    Report.AddStrings(KE.GetGroupSummary);
    Report.Add('');
    Report.Add('--- end of Report ---');
    Result := Report;
  end;

var
  Agent: TWebAgent;
  Knowledge: TKnowledgeBase;
  Bookmarks: TBookmarkManager;
  Learner: TWebLearner;
  KE: TKeywordEngine;
  WeekURLs: array[1..7] of string;
  I: integer;
  Report: TStringList;
begin
  WriteLn('=== Weekrapport ===');
  WriteLn('=== Weekly report ===');
  WriteLn;

  Agent := TWebAgent.Create;
  Knowledge := TKnowledgeBase.Create;
  Bookmarks := TBookmarkManager.Create('bookmarks_weekly.json');
  Learner := TWebLearner.Create(Agent, Knowledge, Bookmarks);
  KE := TKeywordEngine.Create;

  KE.AddKeyword('python', 'programming');
  KE.AddKeyword('javascript', 'programming');
  KE.AddKeyword('rust', 'programming');
  KE.AddKeyword('golang', 'programming');
  KE.AddKeyword('typescript', 'programming');

  WeekURLs[1] := 'https://en.wikipedia.org/wiki/Python_(programming_language)';
  WeekURLs[2] := 'https://en.wikipedia.org/wiki/JavaScript';
  WeekURLs[3] := 'https://en.wikipedia.org/wiki/Rust_(programming_language)';
  WeekURLs[4] := 'https://en.wikipedia.org/wiki/Go_(programming_language)';
  WeekURLs[5] := 'https://en.wikipedia.org/wiki/TypeScript';
  WeekURLs[6] := 'https://en.wikipedia.org/wiki/Comparison_of_programming_languages';
  WeekURLs[7] := 'https://en.wikipedia.org/wiki/Programming_language_generations';

  WriteLn('Simulating week of learning...');
  WriteLn;

  for I := 1 to 7 do
  begin
    WriteLn('Day ', I, ': ', WeekURLs[I]);
    WriteLn('  ', Learner.StudyAndLearn(WeekURLs[I]));
  end;

  WriteLn;
  Report := GenerateWeekReport(Learner, Bookmarks, KE, 12);
  for I := 0 to Report.Count - 1 do
    WriteLn(Report[I]);
  Report.SaveToFile('weekly_report_week12.txt');
  Report.Free;

  WriteLn;
  WriteLn('Report saved: weekly_report_week12.txt (',
    FileSize('weekly_report_week12.txt'), ' bytes)');

  Bookmarks.SaveToFile('bookmarks_weekly.json');

  WriteLn;
  WriteLn('Voorbeeld / Example: web_weekly_report — Status: OK');
  KE.Free;
  Learner.Free;
  Bookmarks.Free;
  Knowledge.Free;
  Agent.Free;
  ReadLn;
end.
