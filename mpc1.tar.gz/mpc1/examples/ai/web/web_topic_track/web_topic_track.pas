{
   Matrix Pascal AI Brain Example — Onderwerp volgen
   web_topic_track.pas
   ════════════════════════════════════════════════════════════════
   NL: Onderwerp volgen
   EN: Track topic
   Demonstrates: Topic tracking across multiple learning sessions
}
program web_topic_track;
{$mode objfpc}{$H+}
uses
  SysUtils, Classes,
  web_agent, knowledge_base, bookmark_manager, web_learner, keyword_engine;

var
  Agent: TWebAgent;
  Knowledge: TKnowledgeBase;
  Bookmarks: TBookmarkManager;
  Learner: TWebLearner;
  KE: TKeywordEngine;
  TopicSessions: array[1..3, 1..2] of string;
  Session, I: integer;
begin
  WriteLn('=== Onderwerp volgen ===');
  WriteLn('=== Track topic ===');
  WriteLn;

  Agent := TWebAgent.Create;
  Knowledge := TKnowledgeBase.Create;
  Bookmarks := TBookmarkManager.Create('bookmarks_track.json');
  Learner := TWebLearner.Create(Agent, Knowledge, Bookmarks);
  KE := TKeywordEngine.Create;

  KE.AddKeyword('ecology', 'environment');
  KE.AddKeyword('conservation', 'environment');
  KE.AddKeyword('biodiversity', 'environment');
  KE.AddKeyword('ecosystem', 'environment');
  KE.AddKeyword('climate', 'environment');
  KE.AddKeyword('sustainability', 'environment');

  TopicSessions[1, 1] := 'https://en.wikipedia.org/wiki/Ecology';
  TopicSessions[1, 2] := 'https://en.wikipedia.org/wiki/Ecosystem';

  TopicSessions[2, 1] := 'https://en.wikipedia.org/wiki/Biodiversity';
  TopicSessions[2, 2] := 'https://en.wikipedia.org/wiki/Conservation_biology';

  TopicSessions[3, 1] := 'https://en.wikipedia.org/wiki/Climate_change';
  TopicSessions[3, 2] := 'https://en.wikipedia.org/wiki/Sustainability';

  WriteLn('Topic tracking: Environmental Science');
  WriteLn('========================================');
  WriteLn;

  for Session := 1 to 3 do
  begin
    WriteLn('--- Session ', Session, ' ---');
    for I := 1 to 2 do
    begin
      WriteLn('  Studying: ', TopicSessions[Session, I]);
      WriteLn('  ', Learner.StudyAndLearn(TopicSessions[Session, I]));
    end;
    WriteLn('  Progress: ', Learner.GetStudiedCount, ' pages, ',
      Knowledge.GetTotalFragments, ' fragments');
    WriteLn;
  end;

  WriteLn('========================================');
  WriteLn('Topic tracking complete.');
  WriteLn('Total sessions: 3');
  WriteLn('Total pages: ', Learner.GetStudiedCount);
  WriteLn('Total fragments: ', Knowledge.GetTotalFragments);

  WriteLn;
  WriteLn('--- Topic classification ---');
  WriteLn('Topic: "', KE.Classify('ecology conservation biodiversity'), '"');

  WriteLn;
  WriteLn('--- Learning trajectory ---');
  for I := 0 to Learner.GetLearningSummary.Count - 1 do
    WriteLn(Learner.GetLearningSummary[I]);

  Bookmarks.SaveToFile('bookmarks_track.json');

  WriteLn;
  WriteLn('Voorbeeld / Example: web_topic_track — Status: OK');
  KE.Free;
  Learner.Free;
  Bookmarks.Free;
  Knowledge.Free;
  Agent.Free;
  ReadLn;
end.
