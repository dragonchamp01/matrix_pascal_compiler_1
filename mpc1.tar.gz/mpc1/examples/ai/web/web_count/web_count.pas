{
   Matrix Pascal AI Brain Example — Bestudeerde pagina's tellen
   web_count.pas
   ════════════════════════════════════════════════════════════════
   NL: Bestudeerde pagina's tellen
   EN: Count studied pages
   Demonstrates: TWebLearner.GetStudiedCount and URL tracking
}
program web_count;
{$mode objfpc}{$H+}
uses
  SysUtils, Classes,
  web_agent, knowledge_base, bookmark_manager, web_learner, keyword_engine;

var
  Agent: TWebAgent;
  Knowledge: TKnowledgeBase;
  Bookmarks: TBookmarkManager;
  Learner: TWebLearner;
  KE: TKeywordEngine;
  URLs: TStringList;
  I, StudyCount: integer;
begin
  WriteLn('=== Bestudeerde pagina's tellen ===');
  WriteLn('=== Count studied pages ===');
  WriteLn;

  Agent := TWebAgent.Create;
  Knowledge := TKnowledgeBase.Create;
  Bookmarks := TBookmarkManager.Create;
  Learner := TWebLearner.Create(Agent, Knowledge, Bookmarks);
  KE := TKeywordEngine.Create;

  KE.AddKeyword('programming', 'computer science');
  KE.AddKeyword('compiler', 'computer science');
  KE.AddKeyword('language', 'computer science');

  URLs := TStringList.Create;
  URLs.Add('https://en.wikipedia.org/wiki/Programming_language');
  URLs.Add('https://en.wikipedia.org/wiki/Compiler');
  URLs.Add('https://en.wikipedia.org/wiki/Interpreter_(computing)');
  URLs.Add('https://en.wikipedia.org/wiki/Assembly_language');
  URLs.Add('https://en.wikipedia.org/wiki/Comparison_of_programming_languages');
  URLs.Add('https://en.wikipedia.org/wiki/Type_system');
  URLs.Add('https://en.wikipedia.org/wiki/Programming_paradigm');
  URLs.Add('https://en.wikipedia.org/wiki/Programming_language_theory');

  WriteLn('Studying programming languages...');
  for I := 0 to URLs.Count - 1 do
  begin
    WriteLn('[', I + 1, '/', URLs.Count, '] ', Learner.StudyWebsite(URLs[I]));
  end;

  WriteLn;
  StudyCount := Learner.GetStudiedCount;
  WriteLn('Total pages studied: ', StudyCount);
  WriteLn('URL list size: ', Learner.StudiedURLs.Count);

  if StudyCount > 0 then
  begin
    WriteLn;
    WriteLn('Studied URLs:');
    for I := 0 to Learner.StudiedURLs.Count - 1 do
      WriteLn('  [', I + 1, '] ', Learner.StudiedURLs[I]);
  end;

  WriteLn;
  WriteLn('--- Duplicate prevention ---');
  WriteLn('Re-studying first URL:');
  WriteLn('  ', Learner.StudyWebsite(URLs[0]));
  WriteLn('  Count still: ', Learner.GetStudiedCount);

  WriteLn;
  if StudyCount > 5 then
    WriteLn('Good progress! Over 5 pages studied.')
  else
    WriteLn('Keep learning! Less than 5 pages studied.');

  WriteLn;
  WriteLn('Voorbeeld / Example: web_count — Status: OK');
  KE.Free;
  URLs.Free;
  Learner.Free;
  Bookmarks.Free;
  Knowledge.Free;
  Agent.Free;
  ReadLn;
end.
