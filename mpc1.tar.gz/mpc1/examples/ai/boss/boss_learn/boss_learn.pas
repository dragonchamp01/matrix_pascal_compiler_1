{ Matrix Pascal AI Brain Example — Leren via Boss Agent
   boss_learn.pas
   ============================================================================
   NL: Demonstreert hoe de Boss Agent kan leren via de Knowledge Base
   en Web Learner. De baas "marco neo" kan nieuwe kennis opnemen,
   documenten bestuderen, en autonoom bijleren.

   EN: Demonstrates how the Boss Agent can learn via the Knowledge
   Base and Web Learner. The boss "marco neo" can absorb new knowledge,
   study documents, and learn autonomously.

   Copyright (c) 2026 Graeme Geldenhuys
}
program boss_learn;
{$mode objfpc}{$H+}
uses
  SysUtils, Classes, boss_agent, knowledge_base, web_learner,
  bookmark_manager, swapfile_manager;

const
  LearningTopics: array[0..4] of string = (
    'Neural network Fundamentals',
    'pascal Programming for AI',
    'Machine Learning Algorithms',
    'Natural Language Processing',
    'Computer Vision Basics'
  );

procedure StudyDocuments(Boss: TBossAgent);
var
  I: integer;
begin
  WriteLn('Studying learning materials...');
  for I := Low(LearningTopics) to High(LearningTopics) do
  begin
    Boss.Knowledge.IngestFile('learn_' +
      LowerCase(StringReplace(LearningTopics[I], ' ', '_', [rfReplaceAll]))
      + '.txt');
    Boss.SwapFile.WriteLog('Studied: ' + LearningTopics[I]);
    WriteLn('  [', I + 1, '/', Length(LearningTopics), '] ',
      LearningTopics[I]);
  end;
  WriteLn;
end;

procedure TestKnowledge(Boss: TBossAgent);
var
  Queries: array[0..2] of string = (
    'neural network',
    'pascal programming',
    'machine learning'
  );
  Result: string;
  I: integer;
begin
  WriteLn('Testing acquired knowledge:');
  for I := Low(Queries) to High(Queries) do
  begin
    Result := Boss.Knowledge.Query(Queries[I]);
    if Pos('Found', Result) > 0 then
      WriteLn('  [OK] Knowledge found for: ', Queries[I])
    else
      WriteLn('  [--] No knowledge for: ', Queries[I]);
  end;
  WriteLn;
end;

procedure AutonomousLearningCycle(Boss: TBossAgent);
var
  Summary: TStringList;
  I: integer;
begin
  Boss.WebLearner.EnableAutonomousMode;
  WriteLn('Autonomous learning status: ',
    Boss.WebLearner.AutonomousLearn);

  Summary := Boss.WebLearner.GetLearningSummary;
  WriteLn('Learning summary:');
  for I := 0 to Summary.Count - 1 do
    WriteLn('  ', Summary[I]);
  Summary.Free;

  WriteLn('Pages studied: ', Boss.WebLearner.GetStudiedCount);
  Boss.WebLearner.DisableAutonomousMode;
  WriteLn;
end;

procedure RecordLearningProgress(Boss: TBossAgent);
begin
  Boss.SwapFile.WriteLog('Learning session completed');
  Boss.SwapFile.WriteLog('Topics studied: ' +
    IntToStr(Length(LearningTopics)));
  Boss.SwapFile.WriteLog('Knowledge fragments: ' +
    IntToStr(Boss.Knowledge.GetTotalFragments));
end;

procedure DemonstrateLearning;
var
  Boss: TBossAgent;
begin
  Boss := TBossAgent.Create('marco neo');
  try
    WriteLn('=== Boss Agent: Learning System ===');
    WriteLn('Boss: ', Boss.BossName);
    WriteLn;

    StudyDocuments(Boss);
    TestKnowledge(Boss);
    AutonomousLearningCycle(Boss);
    RecordLearningProgress(Boss);

    WriteLn;
    WriteLn('Learning demonstration complete.');
    WriteLn('Knowledge fragments: ', Boss.Knowledge.GetTotalFragments);
    WriteLn('Log entries: ', Boss.SwapFile.LogCount);
  finally
    Boss.Free;
  end;
end;

begin
  DemonstrateLearning;
  WriteLn;
  WriteLn('Press Enter to close...');
  ReadLn;
end.
