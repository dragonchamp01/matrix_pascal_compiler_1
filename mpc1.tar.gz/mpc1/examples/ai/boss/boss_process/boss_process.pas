{ Matrix Pascal AI Brain Example — Process via Boss Agent
   boss_process.pas
   ============================================================================
   NL: Demonstreert hoe de Boss Agent gebruikersinvoer verwerkt via
   de Process() en InterpretCommand() methodes. De baas "marco neo"
   kan commando's in natuurlijke taal geven.

   EN: Demonstrates how the Boss Agent processes user input via the
   Process() and InterpretCommand() methods. The boss "marco neo"
   can give commands in natural language.

   Copyright (c) 2026 Graeme Geldenhuys
}
program boss_process;
{$mode objfpc}{$H+}
uses
  SysUtils, Classes, boss_agent, planner, bookmark_manager, swarm_agent;

const
  UserInputs: array[0..7] of string = (
    'plan implement neural network from scratch',
    'bookmark https://github.com as GitHub',
    'swarm analyze the project structure',
    'wat is machine learning',
    'search latest AI frameworks',
    'hello boss agent',
    'what is the current status',
    'learn about transformer architectures'
  );

procedure ProcessUserInputs(Boss: TBossAgent);
var
  I: Integer;
  Response: string;
begin
  WriteLn('Processing user inputs through Boss Agent:');
  WriteLn('Boss configured as: "', Boss.BossName, '"');
  WriteLn;

  for I := Low(UserInputs) to High(UserInputs) do
  begin
    WriteLn('[', I + 1, '] Input: "', UserInputs[I], '"');
    Response := Boss.Process(UserInputs[I]);
    WriteLn('    Response: ', Copy(Response, 1, 80));
    WriteLn;
  end;
end;

procedure DemonstrateBossCommandProcessing(Boss: TBossAgent);
var
  Responses: array[0..2] of string;
  I: Integer;
begin
  WriteLn('Boss-only command processing:');
  Responses[0] := Boss.Process('@boss status');
  Responses[1] := Boss.Process('!execute plan');
  Responses[2] := Boss.Process('marco neo, give me a report');

  for I := Low(Responses) to High(Responses) do
  begin
    WriteLn('  Response ', I + 1, ':');
    WriteLn('    ', Copy(Responses[I], 1, 80));
  end;
  WriteLn;
end;

procedure AnalyzeProcessing(Boss: TBossAgent);
begin
  WriteLn('Process analysis:');
  WriteLn('  Total inputs processed: ', Length(UserInputs) + 3);
  WriteLn('  Log entries created: ', Boss.SwapFile.LogCount);
  WriteLn('  Plans created: ', Boss.Planner.PlanCount);
  WriteLn('  Conversation history recorded');
  Boss.SwapFile.WriteLog('Processing demonstration completed');
end;

procedure DemonstrateProcessing;
var
  Boss: TBossAgent;
begin
  Boss := TBossAgent.Create('marco neo');
  try
    WriteLn('=== Boss Agent: Input Processing ===');
    WriteLn;

    ProcessUserInputs(Boss);
    DemonstrateBossCommandProcessing(Boss);
    AnalyzeProcessing(Boss);

    WriteLn;
    WriteLn('Processing demonstration complete.');
  finally
    Boss.Free;
  end;
end;

begin
  DemonstrateProcessing;
  WriteLn;
  WriteLn('Press Enter to close...');
  ReadLn;
end.
