{ Matrix Pascal AI Brain Example — Plan aanmaken
   plan_create.pas
   ════════════════════════════════════════════════════════════════
   NL: Plan aanmaken — Maakt een nieuw plan met CreatePlan.
   EN: Create plan — Creates a new plan using CreatePlan.
}
program plan_create;
{$mode objfpc}{$H+}
uses
  SysUtils, Classes, planner;

var
  Planner: TPlanner;
  PlanID: integer;
  List: TStringList;
  I: integer;
  Desc: string;

  procedure ShowPlan(const label: string; PID: integer);
  var
    R: TStringList;
  begin
    R := Planner.GetPlanReport(PID);
    try
      WriteLn(label);
      WriteLn(R.text);
    finally
      R.Free;
    end;
  end;

begin
  WriteLn('=== Plan aanmaken ===');
  WriteLn('=== Create plan ===');
  WriteLn;

  Planner := TPlanner.Create;
  try
    PlanID := Planner.CreatePlan('Leer pascal programmeren');
    WriteLn('NL: Plan aangemaakt met ID: ', PlanID);
    WriteLn('EN: Plan created with ID: ', PlanID);
    Planner.AddStep(PlanID, 'Bestudeer syntax', prHigh);
    Planner.AddStep(PlanID, 'Maak eenvoudige programma''s', prHigh);
    Planner.AddStep(PlanID, 'Leer OOP concepten', prNormal);
    ShowPlan('  ---', PlanID);

    PlanID := Planner.CreatePlan('Bouw een AI Brain');
    WriteLn('NL: Plan aangemaakt met ID: ', PlanID);
    WriteLn('EN: Plan created with ID: ', PlanID);
    Planner.AddStep(PlanID, 'Definieer architectuur', prCritical);
    Planner.AddStep(PlanID, 'Implementeer planner module', prCritical);
    Planner.AddStep(PlanID, 'Implementeer knowledge base', prCritical);
    Planner.AddStep(PlanID, 'Test alle componenten', prHigh);
    ShowPlan('  ---', PlanID);

    PlanID := Planner.CreatePlan('Schrijf documentatie');
    WriteLn('NL: Plan aangemaakt met ID: ', PlanID);
    WriteLn('EN: Plan created with ID: ', PlanID);
    Planner.AddStep(PlanID, 'Maak overzicht', prNormal);
    Planner.AddStep(PlanID, 'Schrijf API docs', prHigh);
    ShowPlan('  ---', PlanID);

    PlanID := Planner.CreatePlan('Leer Nederlands');
    WriteLn('NL: Plan aangemaakt met ID: ', PlanID);
    WriteLn('EN: Plan created with ID: ', PlanID);

    WriteLn('NL: Totaal aantal plannen: ', Planner.PlanCount);
    WriteLn('EN: Total number of plans: ', Planner.PlanCount);
    WriteLn;

    List := Planner.ListPlans;
    try
      WriteLn('NL: Alle plannen:');
      WriteLn('EN: All plans:');
      for I := 0 to List.Count - 1 do
        WriteLn('  ', List[I]);
    finally
      List.Free;
    end;

  finally
    Planner.Free;
  end;

  WriteLn;
  WriteLn('Voorbeeld / Example: plan_create');
  WriteLn('Status: OK');
  ReadLn;
end.
