{ Matrix Pascal AI Brain Example — Plan exporteren
   plan_export.pas
   ════════════════════════════════════════════════════════════════
   NL: Plan exporteren — Exporteert een plan naar tekstformaat.
   EN: Export plan — Exports a plan to text format.
}
program plan_export;
{$mode objfpc}{$H+}
uses
  SysUtils, Classes, planner;

var
  Planner: TPlanner;
  PlanID: integer;
  Report: TStringList;
  I: integer;
  ExportLines: TStringList;

begin
  WriteLn('=== Plan exporteren ===');
  WriteLn('=== export plan ===');
  WriteLn;

  Planner := TPlanner.Create;
  try
    PlanID := Planner.CreatePlan('export demo - Project Alpha');

    Planner.AddStep(PlanID, 'Definieer requirements', prCritical);
    Planner.AddStep(PlanID, 'Ontwerp architectuur', prCritical);
    Planner.AddStep(PlanID, 'Implementeer core modules', prHigh);
    Planner.AddStep(PlanID, 'Schrijf unit tests', prHigh);
    Planner.AddStep(PlanID, 'Integreer componenten', prHigh);
    Planner.AddStep(PlanID, 'Voer systeemtest uit', prCritical);
    Planner.AddStep(PlanID, 'Documentatie schrijven', prNormal);
    Planner.AddStep(PlanID, 'Productie deployment', prCritical);

    WriteLn('NL: Exporteren naar tekstformaat:');
    WriteLn('EN: Exporting to text format:');
    WriteLn;

    Report := Planner.GetPlanReport(PlanID);
    try
      ExportLines := TStringList.Create;
      try
        ExportLines.Add('=== PLAN export ===');
        ExportLines.Add('Titel: Project Alpha');
        ExportLines.Add('Plan ID: ' + IntToStr(PlanID));
        ExportLines.Add('Aantal stappen: ' + IntToStr(Planner.GetStepCount(PlanID)));
        ExportLines.Add('Datum: ' + DateToStr(Now));
        ExportLines.Add('');

        for I := 0 to Report.Count - 1 do
          ExportLines.Add(Report[I]);

        ExportLines.Add('');
        ExportLines.Add('=== EINDE export / end export ===');

        WriteLn('--- begin export ---');
        for I := 0 to ExportLines.Count - 1 do
          WriteLn(ExportLines[I]);
        WriteLn('--- EINDE export ---');
      finally
        ExportLines.Free;
      end;
    finally
      Report.Free;
    end;

  finally
    Planner.Free;
  end;

  WriteLn;
  WriteLn('Voorbeeld / Example: plan_export');
  WriteLn('Status: OK');
  ReadLn;
end.
