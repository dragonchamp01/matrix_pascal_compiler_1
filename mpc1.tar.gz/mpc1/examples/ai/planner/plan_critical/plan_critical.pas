{ Matrix Pascal AI Brain Example — Kritieke taak
   plan_critical.pas
   ════════════════════════════════════════════════════════════════
   NL: Kritieke taak — Toont het gebruik van prCritical prioriteit.
   EN: Critical task — Demonstrates the use of prCritical priority.
}
program plan_critical;
{$mode objfpc}{$H+}
uses
  SysUtils, Classes, planner;

var
  Planner: TPlanner;
  PlanID: integer;
  Report: TStringList;
  I: integer;
  Step: TPlanStep;

  procedure ShowReport;
  begin
    Report := Planner.GetPlanReport(PlanID);
    try
      WriteLn(Report.text);
    finally
      Report.Free;
    end;
  end;

begin
  WriteLn('=== Kritieke taak ===');
  WriteLn('=== Critical task ===');
  WriteLn;

  Planner := TPlanner.Create;
  try
    PlanID := Planner.CreatePlan('Red het project - servercrash');

    Planner.AddStep(PlanID, 'Herstel database backup', prCritical);
    Planner.AddStep(PlanID, 'Herstart de server', prCritical);
    Planner.AddStep(PlanID, 'Controleer logbestanden', prHigh);
    Planner.AddStep(PlanID, 'Informeer stakeholders', prHigh);
    Planner.AddStep(PlanID, 'Dokumenteer de incident', prNormal);
    Planner.AddStep(PlanID, 'Plan preventieve maatregelen', prNormal);

    WriteLn('NL: Kritiek plan met 6 stappen (ID: ', PlanID, ').');
    WriteLn('EN: Critical plan with 6 steps (ID: ', PlanID, ').');
    WriteLn('NL: prCritical (3) = moet onmiddellijk gebeuren');
    WriteLn('EN: prCritical (3) = must happen immediately');
    WriteLn;

    for I := 0 to Planner.GetStepCount(PlanID) - 1 do
    begin
      Step := Planner.GetStep(PlanID, I);
      if Step <> nil then
        WriteLn(Format('  [%d] Prio=%d %s', [Step.ID, Ord(Step.Priority), Step.Description]));
    end;
    WriteLn;

    WriteLn('NL: Voer kritieke stappen eerst uit:');
    WriteLn('EN: Execute critical steps first:');
    Planner.UpdateStepStatus(PlanID, 1, psCompleted);
    WriteLn('NL: Stap 1 (Backup herstel) voltooid.');
    Planner.UpdateStepStatus(PlanID, 2, psCompleted);
    WriteLn('NL: Stap 2 (Server herstart) voltooid.');
    WriteLn;

    ShowReport;

  finally
    Planner.Free;
  end;

  WriteLn;
  WriteLn('Voorbeeld / Example: plan_critical');
  WriteLn('Status: OK');
  ReadLn;
end.
