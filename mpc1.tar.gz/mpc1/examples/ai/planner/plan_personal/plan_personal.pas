{ Matrix Pascal AI Brain Example — Persoonlijke planning
   plan_personal.pas
   ════════════════════════════════════════════════════════════════
   NL: Persoonlijke planning — Maakt een persoonlijk plan.
   EN: Personal planning — Creates a personal plan.
}
program plan_personal;
{$mode objfpc}{$H+}
uses
  SysUtils, Classes, planner;

var
  Planner: TPlanner;
  PlanID: integer;
  Report: TStringList;

  procedure StepStatus(SID: integer; Status: TPlanStatus);
  begin
    Planner.UpdateStepStatus(PlanID, SID, Status);
  end;

  procedure ShowReport;
  begin
    Report := Planner.GetPlanReport(PlanID);
    try
      WriteLn(Report.text);
    finally
      Report.Free;
    end;
  end;

begin
  WriteLn('=== Persoonlijke planning ===');
  WriteLn('=== Personal planning ===');
  WriteLn;

  Planner := TPlanner.Create;
  try
    PlanID := Planner.CreatePlan('Persoonlijke groei - 2026');

    Planner.AddStep(PlanID, 'Lees 12 boeken (1 per maand)', prHigh);
    Planner.AddStep(PlanID, 'Volg een online cursus', prHigh);
    Planner.AddStep(PlanID, 'begin met sporten (3x/week)', prCritical);
    Planner.AddStep(PlanID, 'Leer koken', prNormal);
    Planner.AddStep(PlanID, 'Doe vrijwilligerswerk', prLow);
    Planner.AddStep(PlanID, 'Reis naar 2 nieuwe landen', prNormal);
    Planner.AddStep(PlanID, 'Leer een muziekinstrument', prLow);
    Planner.AddStep(PlanID, 'Houd een dagboek bij', prNormal);
    Planner.AddStep(PlanID, 'Mediteer dagelijks', prHigh);

    WriteLn('NL: Persoonlijk groeiplan met ', Planner.GetStepCount(PlanID), ' doelen.');
    WriteLn('EN: Personal growth plan with ', Planner.GetStepCount(PlanID), ' goals.');
    WriteLn;

    ShowReport;

    WriteLn('NL: Voortgang bijwerken:');
    WriteLn('EN: Updating progress:');
    StepStatus(1, psCompleted);
    WriteLn('  "Lees 12 boeken" — voltooid');
    StepStatus(3, psInProgress);
    WriteLn('  "Begin met sporten" — bezig');
    StepStatus(4, psCompleted);
    WriteLn('  "Leer koken" — voltooid');

  finally
    Planner.Free;
  end;

  WriteLn;
  WriteLn('Voorbeeld / Example: plan_personal');
  WriteLn('Status: OK');
  ReadLn;
end.
