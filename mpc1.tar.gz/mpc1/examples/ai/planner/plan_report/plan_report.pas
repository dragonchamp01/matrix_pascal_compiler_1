{ Matrix Pascal AI Brain Example — Plan rapport
   plan_report.pas
   ════════════════════════════════════════════════════════════════
   NL: Plan rapport — Genereert een rapport met GetPlanReport.
   EN: Plan report — Generates a report using GetPlanReport.
}
program plan_report;
{$mode objfpc}{$H+}
uses
  SysUtils, Classes, planner;

var
  Planner: TPlanner;
  PlanID: integer;
  Report: TStringList;

  procedure GenerateAndShow(const label: string);
  begin
    WriteLn(label);
    Report := Planner.GetPlanReport(PlanID);
    try
      WriteLn(Report.text);
    finally
      Report.Free;
    end;
  end;

begin
  WriteLn('=== Plan rapport ===');
  WriteLn('=== Plan report ===');
  WriteLn;

  Planner := TPlanner.Create;
  try
    PlanID := Planner.CreatePlan('Rapport demo plan');

    Planner.AddStep(PlanID, 'Stap 1: Initiele analyse', prHigh);
    Planner.AddStep(PlanID, 'Stap 2: Data verzameling', prCritical);
    Planner.AddStep(PlanID, 'Stap 3: Data verwerking', prCritical);
    Planner.AddStep(PlanID, 'Stap 4: Rapportage', prHigh);
    Planner.AddStep(PlanID, 'Stap 5: Presentatie', prNormal);

    WriteLn('NL: Rapport voor plan ', PlanID);
    WriteLn('EN: Report for plan ', PlanID);
    WriteLn;

    GenerateAndShow('NL: Fase 1 — Alle stappen pending:');
    GenerateAndShow('EN: Phase 1 — All steps pending:');

    Planner.UpdateStepStatus(PlanID, 1, psCompleted);
    Planner.UpdateStepStatus(PlanID, 2, psInProgress);
    GenerateAndShow('NL: Fase 2 — Stap 1 voltooid, stap 2 bezig:');
    GenerateAndShow('EN: Phase 2 — Step 1 done, step 2 in progress:');

    Planner.UpdateStepStatus(PlanID, 2, psCompleted);
    Planner.UpdateStepStatus(PlanID, 3, psCompleted);
    Planner.UpdateStepStatus(PlanID, 4, psCompleted);
    Planner.UpdateStepStatus(PlanID, 5, psCancelled);
    GenerateAndShow('NL: Fase 3 — Stappen 1-4 voltooid, stap 5 geannuleerd:');
    GenerateAndShow('EN: Phase 3 — Steps 1-4 done, step 5 cancelled:');

  finally
    Planner.Free;
  end;

  WriteLn;
  WriteLn('Voorbeeld / Example: plan_report');
  WriteLn('Status: OK');
  ReadLn;
end.
