{ Matrix Pascal AI Brain Example — Prioriteit instellen
   plan_priority.pas
   ════════════════════════════════════════════════════════════════
   NL: Prioriteit instellen — Toont alle prioriteitsniveaus.
   EN: Set priority — Shows all priority levels.
}
program plan_priority;
{$mode objfpc}{$H+}
uses
  SysUtils, Classes, planner;

var
  Planner: TPlanner;
  PlanID: integer;
  Report: TStringList;
  I: integer;
  Step: TPlanStep;
  PrioNames: array[TPriority] of string = (
    'prLow (0) - Laag/Low',
    'prNormal (1) - Normaal/Normal',
    'prHigh (2) - Hoog/High',
    'prCritical (3) - Kritiek/Critical');

begin
  WriteLn('=== Prioriteit instellen ===');
  WriteLn('=== set priority ===');
  WriteLn;

  Planner := TPlanner.Create;
  try
    PlanID := Planner.CreatePlan('Prioriteit voorbeeldplan');

    Planner.AddStep(PlanID, 'Kritieke taak — moet vandaag', prCritical);
    Planner.AddStep(PlanID, 'Hoge prioriteit — belangrijk', prHigh);
    Planner.AddStep(PlanID, 'Normale prioriteit — standaard', prNormal);
    Planner.AddStep(PlanID, 'Lage prioriteit — kan wachten', prLow);
    Planner.AddStep(PlanID, 'Nog een kritieke taak', prCritical);
    Planner.AddStep(PlanID, 'Nog een normale taak', prNormal);

    WriteLn('NL: TPriority Enum met 4 waarden:');
    WriteLn('EN: TPriority Enum with 4 values:');
    for I := 0 to 3 do
      WriteLn('  ', PrioNames[TPriority(I)]);
    WriteLn;

    WriteLn('NL: Stappen met hun prioriteiten:');
    WriteLn('EN: Steps with their priorities:');
    for I := 0 to Planner.GetStepCount(PlanID) - 1 do
    begin
      Step := Planner.GetStep(PlanID, I);
      if Step <> nil then
        WriteLn(Format('  [%d] %-40s prio=%d', [Step.ID, Step.Description, Ord(Step.Priority)]));
    end;
    WriteLn;

    Report := Planner.GetPlanReport(PlanID);
    try
      WriteLn(Report.text);
    finally
      Report.Free;
    end;

  finally
    Planner.Free;
  end;

  WriteLn;
  WriteLn('Voorbeeld / Example: plan_priority');
  WriteLn('Status: OK');
  ReadLn;
end.
