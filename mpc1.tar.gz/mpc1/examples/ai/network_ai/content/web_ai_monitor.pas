{
    Matrix Pascal - AI Network Example
    web_ai_monitor: Monitor websites for changes with AI
    Uses: web_agent, knowledge_base, bookmark_manager, swapfile_manager
}
{$mode objfpc}{$H+}

program web_ai_monitor;

uses
  System, Classes, SysUtils, web_agent, knowledge_base, bookmark_manager,
  swapfile_manager, json_support;

type
  TChangeType = (ctContent, ctStructure, ctNewLink, ctRemovedLink, ctError);

  TChangeReport = class
  public
    URL: string;
    ChangeType: TChangeType;
    OldContent: string;
    NewContent: string;
    DiffPreview: string;
    Timestamp: TDateTime;
    Significance: double;
  end;

  TWebMonitorAI = class
  private
    FAgent: TWebAgent;
    FKnowledge: TKnowledgeBase;
    FSwap: TSwapFileManager;
    FMonitoredURLs: TStringList;
    FLastContents: TStringList;
    FCheckInterval: integer;
    FChangeThreshold: double;
    function FetchContent(const URL: string): string;
    function ComputeDiff(const Old, New: string): string;
    function ComputeSimilarity(const Old, New: string): double;
    function DetectChangeType(const Old, New: string): TChangeType;
    function NormalizeContent(const HTML: string): string;
    function ExtractKeyChanges(const Old, New: string): TStringList;
  public
    constructor Create;
    destructor Destroy; override;
    procedure AddURL(const URL: string);
    procedure RemoveURL(const URL: string);
    function CheckURL(const URL: string): TChangeReport;
    function CheckAll: TList;
    function Monitor(const URL: string; Checks: integer): TStringList;
    function GetChangeHistory(const URL: string): TStringList;
    function GenerateReport: TStringList;
    property CheckInterval: integer read FCheckInterval write FCheckInterval;
    property ChangeThreshold: double read FChangeThreshold write FChangeThreshold;
  end;

constructor TWebMonitorAI.Create;
begin
  inherited Create;
  FAgent := TWebAgent.Create;
  FKnowledge := TKnowledgeBase.Create;
  FSwap := TSwapFileManager.Create;
  FMonitoredURLs := TStringList.Create;
  FLastContents := TStringList.Create;
  FCheckInterval := 3600;
  FChangeThreshold := 0.1;
end;

destructor TWebMonitorAI.Destroy;
begin
  FAgent.Free;
  FKnowledge.Free;
  FSwap.Free;
  FMonitoredURLs.Free;
  FLastContents.Free;
  inherited Destroy;
end;

function TWebMonitorAI.FetchContent(const URL: string): string;
var
  HTML: string;
begin
  HTML := FAgent.Browse(URL);
  Result := NormalizeContent(HTML);
end;

function TWebMonitorAI.ComputeDiff(const Old, New: string): string;
var
  I, MaxLen: integer;
begin
  Result := '';
  MaxLen := Length(Old);
  if Length(New) < MaxLen then MaxLen := Length(New);
  for I := 1 to MaxLen do
    if Old[I] <> New[I] then
    begin
      Result := 'Diff at position ' + IntToStr(I) + ': ...' +
                Copy(Old, I - 10, 20) + ' -> ' + Copy(New, I - 10, 20) + '...';
      exit;
    end;
  if Length(Old) <> Length(New) then
    Result := 'Length changed: ' + IntToStr(Length(Old)) + ' -> ' + IntToStr(Length(New));
end;

function TWebMonitorAI.ComputeSimilarity(const Old, New: string): double;
var
  Matches, Total, I, J: integer;
begin
  Matches := 0;
  Total := Length(Old);
  if Total = 0 then exit(1.0);
  J := 1;
  for I := 1 to Length(Old) do
  begin
    while (J <= Length(New)) and (New[J] <> Old[I]) do Inc(J);
    if J <= Length(New) then
    begin
      Inc(Matches);
      Inc(J);
    end;
  end;
  Result := Matches / Total;
end;

function TWebMonitorAI.DetectChangeType(const Old, New: string): TChangeType;
var
  Sim: double;
begin
  Sim := ComputeSimilarity(Old, New);
  if Sim < 0.3 then Result := ctContent
  else if Sim < 0.7 then Result := ctStructure
  else Result := ctContent;
end;

function TWebMonitorAI.NormalizeContent(const HTML: string): string;
var
  I: integer;
  InTag: boolean;
begin
  Result := '';
  InTag := false;
  for I := 1 to Length(HTML) do
  begin
    if HTML[I] = '<' then InTag := true
    else if HTML[I] = '>' then InTag := false
    else if not InTag then
      Result := Result + HTML[I];
  end;
  Result := Trim(Result);
end;

function TWebMonitorAI.ExtractKeyChanges(const Old, New: string): TStringList;
var
  OldWords, NewWords: TStringList;
  I: integer;
begin
  Result := TStringList.Create;
  OldWords := TStringList.Create;
  NewWords := TStringList.Create;
  OldWords.Delimiter := ' ';
  OldWords.DelimitedText := Old;
  NewWords.Delimiter := ' ';
  NewWords.DelimitedText := New;
  for I := 0 to NewWords.Count - 1 do
    if OldWords.IndexOf(NewWords[I]) < 0 then
      Result.Add('+ ' + NewWords[I]);
  OldWords.Free;
  NewWords.Free;
end;

procedure TWebMonitorAI.AddURL(const URL: string);
begin
  if FMonitoredURLs.IndexOf(URL) < 0 then
  begin
    FMonitoredURLs.Add(URL);
    FLastContents.Values[URL] := FetchContent(URL);
  end;
end;

procedure TWebMonitorAI.RemoveURL(const URL: string);
var
  Idx: integer;
begin
  Idx := FMonitoredURLs.IndexOf(URL);
  if Idx >= 0 then
  begin
    FMonitoredURLs.Delete(Idx);
    FLastContents.Values[URL] := '';
  end;
end;

function TWebMonitorAI.CheckURL(const URL: string): TChangeReport;
var
  CurrentContent: string;
  LastContent: string;
begin
  Result := TChangeReport.Create;
  Result.URL := URL;
  Result.Timestamp := Now;
  try
    CurrentContent := FetchContent(URL);
    LastContent := FLastContents.Values[URL];
    if LastContent = '' then
    begin
      Result.ChangeType := ctContent;
      Result.Significance := 1.0;
      Result.DiffPreview := 'First check - content captured';
    end
    else
    begin
      Result.ChangeType := DetectChangeType(LastContent, CurrentContent);
      Result.Significance := 1.0 - ComputeSimilarity(LastContent, CurrentContent);
      Result.DiffPreview := ComputeDiff(LastContent, CurrentContent);
    end;
    FLastContents.Values[URL] := CurrentContent;
    FSwap.WriteString(sbtWebPage, URL + '|' + DateTimeToStr(Now) + '|' + Copy(CurrentContent, 1, 500));
  except
    Result.ChangeType := ctError;
    Result.DiffPreview := 'Error checking URL';
  end;
end;

function TWebMonitorAI.CheckAll: TList;
var
  I: integer;
  Report: TChangeReport;
begin
  Result := TList.Create;
  for I := 0 to FMonitoredURLs.Count - 1 do
  begin
    Report := CheckURL(FMonitoredURLs[I]);
    if Report.Significance > FChangeThreshold then
      Result.Add(Report)
    else
      Report.Free;
  end;
end;

function TWebMonitorAI.Monitor(const URL: string; Checks: integer): TStringList;
var
  I: integer;
  Report: TChangeReport;
begin
  Result := TStringList.Create;
  Result.Add('=== Monitoring: ' + URL + ' ===');
  for I := 1 to Checks do
  begin
    Report := CheckURL(URL);
    Result.Add('Check ' + IntToStr(I) + ' [' + DateTimeToStr(Report.Timestamp) + ']: ' +
               Report.DiffPreview);
    Report.Free;
  end;
end;

function TWebMonitorAI.GetChangeHistory(const URL: string): TStringList;
var
  I: integer;
  Entry: string;
begin
  Result := TStringList.Create;
  for I := 0 to FSwap.LogCount - 1 do
  begin
    Entry := FSwap.ReadLog(I);
    if Pos(URL, Entry) > 0 then
      Result.Add(Entry);
  end;
end;

function TWebMonitorAI.GenerateReport: TStringList;
var
  I: integer;
begin
  Result := TStringList.Create;
  Result.Add('=== Web Monitor Report ===');
  Result.Add('Monitored URLs: ' + IntToStr(FMonitoredURLs.Count));
  Result.Add('');
  for I := 0 to FMonitoredURLs.Count - 1 do
    Result.Add('  ' + IntToStr(I + 1) + '. ' + FMonitoredURLs[I]);
end;

var
  Monitor: TWebMonitorAI;
begin
  Monitor := TWebMonitorAI.Create;
  try
    Monitor.AddURL('https://example.com');
    Monitor.AddURL('https://en.wikipedia.org/wiki/Artificial_intelligence');
    WriteLn(Monitor.Monitor('https://example.com', 3).Text);
    WriteLn(Monitor.GenerateReport.Text);
  finally
    Monitor.Free;
  end;
end.
