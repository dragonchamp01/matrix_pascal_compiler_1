{
    Matrix Pascal - AI Network Example: web_ai_sports - Sports data analysis
    Uses: web_agent, knowledge_base, keyword_engine, json_support
}
{$mode objfpc}{$H+}

program web_ai_sports;

uses System, Classes, SysUtils, web_agent, knowledge_base, keyword_engine, json_support;

type
  TMatchResult = class
  public
    HomeTeam, AwayTeam, League: string;
    HomeScore, AwayScore: integer;
    Date: TDateTime;
    Attendance: integer;
    Completed: boolean;
  end;

  TPlayer = class
  public
    name, Team, Position, Nationality: string;
    Goals, Assists, Appearances, Rating: integer;
  end;

  TSportsAI = class
  private
    FAgent: TWebAgent;
    FKnowledge: TKnowledgeBase;
    FKeywords: TKeywordEngine;
    function FetchMatch(const URL: string): TMatchResult;
    function FetchPlayerStats(const Player: string): TPlayer;
    function PredictOutcome(const Home, Away: string): TMatchResult;
  public
    constructor Create; destructor Destroy; override;
    function GetMatchResult(const Home, Away: string): TMatchResult;
    function AnalyzePlayer(const Player: string): TPlayer;
    function ComparePlayers(const P1, P2: string): TStringList;
    function SearchTeams(const Query: string): TStringList;
    function GetLeagueStandings(const League: string): TStringList;
    function PredictMatch(const Home, Away: string): string;
    procedure LearnMatch(const Match: TMatchResult);
  end;

constructor TSportsAI.Create;
begin
  inherited Create; FAgent := TWebAgent.Create; FKnowledge := TKnowledgeBase.Create;
  FKeywords := TKeywordEngine.Create;
end;

destructor TSportsAI.Destroy;
begin FAgent.Free; FKnowledge.Free; FKeywords.Free; inherited Destroy; end;

function TSportsAI.FetchMatch(const URL: string): TMatchResult;
begin
  Result := TMatchResult.Create; Result.HomeTeam := 'Home Team';
  Result.AwayTeam := 'Away Team'; Result.League := 'Premier League';
  Result.HomeScore := Random(5); Result.AwayScore := Random(5);
  Result.Date := Now - Random(7); Result.Attendance := 30000 + Random(20000);
  Result.Completed := true;
end;

function TSportsAI.FetchPlayerStats(const Player: string): TPlayer;
begin
  Result := TPlayer.Create; Result.name := Player;
  Result.Team := 'FC Example'; Result.Position := 'forward';
  Result.Goals := Random(20); Result.Assists := Random(15);
  Result.Appearances := Random(30) + 5; Result.Rating := 6 + Random(4);
end;

function TSportsAI.PredictOutcome(const Home, Away: string): TMatchResult;
begin
  Result := TMatchResult.Create; Result.HomeTeam := Home; Result.AwayTeam := Away;
  Result.HomeScore := Random(4); Result.AwayScore := Random(3);
  Result.Completed := false;
end;

function TSportsAI.GetMatchResult(const Home, Away: string): TMatchResult;
begin Result := FetchMatch(''); Result.HomeTeam := Home; Result.AwayTeam := Away; end;

function TSportsAI.AnalyzePlayer(const Player: string): TPlayer;
begin Result := FetchPlayerStats(Player); end;

function TSportsAI.ComparePlayers(const P1, P2: string): TStringList;
var Pl1, Pl2: TPlayer;
begin
  Result := TStringList.Create; Pl1 := FetchPlayerStats(P1); Pl2 := FetchPlayerStats(P2);
  Result.Add(Pl1.name + ' (' + Pl1.Team + '): ' + IntToStr(Pl1.Goals) + ' goals, ' + IntToStr(Pl1.Assists) + ' assists');
  Result.Add(Pl2.name + ' (' + Pl2.Team + '): ' + IntToStr(Pl2.Goals) + ' goals, ' + IntToStr(Pl2.Assists) + ' assists');
  if Pl1.Goals > Pl2.Goals then Result.Add(Pl1.name + ' is better scorer') else Result.Add(Pl2.name + ' is better scorer');
  Pl1.Free; Pl2.Free;
end;

function TSportsAI.SearchTeams(const Query: string): TStringList;
begin
  Result := TStringList.Create;
  Result.Add('FC ' + Query); Result.Add(Query + ' United'); Result.Add(Query + ' City');
end;

function TSportsAI.GetLeagueStandings(const League: string): TStringList;
var I: integer;
begin
  Result := TStringList.Create; Result.Add('=== ' + League + ' Standings ===');
  for I := 1 to 5 do
    Result.Add(IntToStr(I) + '. Team ' + IntToStr(I) + ' - ' + IntToStr(20 - I * 3) + ' pts');
end;

function TSportsAI.PredictMatch(const Home, Away: string): string;
var M: TMatchResult;
begin
  M := PredictOutcome(Home, Away);
  if M.HomeScore > M.AwayScore then Result := Home + ' wins ' + IntToStr(M.HomeScore) + '-' + IntToStr(M.AwayScore)
  else if M.AwayScore > M.HomeScore then Result := Away + ' wins ' + IntToStr(M.AwayScore) + '-' + IntToStr(M.HomeScore)
  else Result := 'Draw ' + IntToStr(M.HomeScore) + '-' + IntToStr(M.AwayScore);
  M.Free;
end;

procedure TSportsAI.LearnMatch(const Match: TMatchResult);
begin
  FKnowledge.AddKnowledge('[Sports] ' + Match.HomeTeam + ' vs ' + Match.AwayTeam,
    IntToStr(Match.HomeScore) + '-' + IntToStr(Match.AwayScore));
end;

var Sports: TSportsAI;
begin
  Sports := TSportsAI.Create;
  try
    WriteLn(Sports.PredictMatch('FC Barcelona', 'real Madrid'));
    WriteLn(Sports.GetLeagueStandings('Premier League').text);
  finally
    Sports.Free;
  end;
end.
