{
    Matrix Pascal - AI Network Example: web_ai_docs - Documentation crawler with AI
    Uses: web_agent, knowledge_base, bookmark_manager, keyword_engine
}
{$mode objfpc}{$H+}

program web_ai_docs;

uses System, Classes, SysUtils, web_agent, knowledge_base, bookmark_manager, keyword_engine;

type
  TDocPage = class
  public
    Title, URL, Section, Content: string;
    Depth: integer;
    Links: TStringList;
    constructor Create; destructor Destroy; override;
  end;

  TDocCrawlerAI = class
  private
    FAgent: TWebAgent;
    FKnowledge: TKnowledgeBase;
    FBookmarks: TBookmarkManager;
    FKeywords: TKeywordEngine;
    FVisited: TStringList;
    FMaxDepth: integer;
    function FetchPage(const URL: string): TDocPage;
    function ExtractDocLinks(const HTML, BaseURL: string): TStringList;
    function IdentifySection(const URL: string): string;
    function GenerateDocIndex(const Pages: TList): TStringList;
  public
    constructor Create; destructor Destroy; override;
    function CrawlDocs(const StartURL: string): TList;
    function GenerateDocumentation(const StartURL: string): string;
    function SearchDocs(const Query: string): TStringList;
    function GetDocSummary(const URL: string): string;
    procedure LearnDocumentation(const URL: string);
    property MaxDepth: integer read FMaxDepth write FMaxDepth;
  end;

constructor TDocPage.Create;
begin inherited Create; Links := TStringList.Create; end;
destructor TDocPage.Destroy;
begin Links.Free; inherited Destroy; end;

constructor TDocCrawlerAI.Create;
begin
  inherited Create; FAgent := TWebAgent.Create; FKnowledge := TKnowledgeBase.Create;
  FBookmarks := TBookmarkManager.Create; FKeywords := TKeywordEngine.Create;
  FVisited := TStringList.Create; FMaxDepth := 3;
end;

destructor TDocCrawlerAI.Destroy;
begin FAgent.Free; FKnowledge.Free; FBookmarks.Free; FKeywords.Free; FVisited.Free; inherited Destroy; end;

function TDocCrawlerAI.FetchPage(const URL: string): TDocPage;
var HTML: string; InTag: boolean; I: integer;
begin
  Result := TDocPage.Create; Result.URL := URL;
  Result.Section := IdentifySection(URL); HTML := FAgent.Browse(URL);
  InTag := false;
  for I := 1 to Length(HTML) do
  begin
    if HTML[I] = '<' then InTag := true else if HTML[I] = '>' then InTag := false
    else if not InTag then Result.Content := Result.Content + HTML[I];
  end;
  Result.Title := Copy(Result.Content, 1, 100);
  Result.Links := ExtractDocLinks(HTML, URL);
end;

function TDocCrawlerAI.ExtractDocLinks(const HTML, BaseURL: string): TStringList;
var I, P, P2: integer; Link: string;
begin
  Result := TStringList.Create; I := 1;
  repeat
    P := PosEx('href="', HTML, I); if P = 0 then Break;
    P := P + 6; P2 := PosEx('"', HTML, P); if P2 = 0 then break;
    Link := Copy(HTML, P, P2 - P);
    if (Link <> '') and (Link[1] <> '#') and (Pos('http', Link) > 0) then Result.Add(Link);
    I := P2 + 1;
  until false;
end;

function TDocCrawlerAI.IdentifySection(const URL: string): string;
var Parts: TStringList;
begin
  Parts := TStringList.Create; Parts.Delimiter := '/'; Parts.DelimitedText := URL;
  if Parts.Count > 2 then Result := Parts[Parts.Count - 2] else Result := 'main';
  Parts.Free;
end;

function TDocCrawlerAI.GenerateDocIndex(const Pages: TList): TStringList;
var I: integer; Page: TDocPage;
begin
  Result := TStringList.Create;
  for I := 0 to Pages.Count - 1 do
  begin
    Page := TDocPage(Pages[I]);
    Result.Add(Format('  [%s] %s (%s)', [Page.Section, Copy(Page.Title, 1, 80), Page.URL]));
  end;
end;

function TDocCrawlerAI.CrawlDocs(const StartURL: string): TList;
var Queue: TStringList; I, Idx: integer; Page: TDocPage; J: integer;
begin
  Result := TList.Create; Queue := TStringList.Create; Queue.Add(StartURL);
  while Queue.Count > 0 do
  begin
    Idx := Queue.Count - 1; Page := FetchPage(Queue[Idx]); Queue.Delete(Idx);
    if FVisited.IndexOf(Page.URL) < 0 then
    begin
      FVisited.Add(Page.URL); Result.Add(Page);
      for J := 0 to Page.Links.Count - 1 do
        if (FVisited.IndexOf(Page.Links[J]) < 0) and (Queue.IndexOf(Page.Links[J]) < 0) then
          Queue.Add(Page.Links[J]);
    end
    else Page.Free;
    if Result.Count >= 30 then break;
  end;
  Queue.Free;
end;

function TDocCrawlerAI.GenerateDocumentation(const StartURL: string): string;
var Pages: TList; I: integer; Page: TDocPage;
begin
  Pages := CrawlDocs(StartURL);
  Result := '=== Documentation: ' + StartURL + ' ===' + sLineBreak;
  Result := Result + 'Pages crawled: ' + IntToStr(Pages.Count) + sLineBreak + sLineBreak;
  for I := 0 to Pages.Count - 1 do
  begin
    Page := TDocPage(Pages[I]);
    Result := Result + '--- ' + Page.Title + ' ---' + sLineBreak;
    Result := Result + Copy(Page.Content, 1, 300) + sLineBreak;
    Page.Free;
  end;
  Pages.Free;
end;

function TDocCrawlerAI.SearchDocs(const Query: string): TStringList;
var I: integer; Pages: TList; Page: TDocPage; LQ: string;
begin
  Result := TStringList.Create; LQ := LowerCase(Query);
  Pages := CrawlDocs('https://docs.example.com');
  for I := 0 to Pages.Count - 1 do
  begin
    Page := TDocPage(Pages[I]);
    if Pos(LQ, LowerCase(Page.Content)) > 0 then Result.Add(Page.Title + '=' + Page.URL);
    Page.Free;
  end;
  Pages.Free;
end;

function TDocCrawlerAI.GetDocSummary(const URL: string): string;
var Page: TDocPage;
begin
  Page := FetchPage(URL);
  Result := '=== ' + Page.Title + ' ===' + sLineBreak + 'Links: ' + IntToStr(Page.Links.Count) + sLineBreak + Copy(Page.Content, 1, 300);
  Page.Free;
end;

procedure TDocCrawlerAI.LearnDocumentation(const URL: string);
var Page: TDocPage;
begin
  Page := FetchPage(URL);
  FKnowledge.AddKnowledge('[Docs] ' + URL, Copy(Page.Content, 1, 1000));
  Page.Free;
end;

var Docs: TDocCrawlerAI;
begin
  Docs := TDocCrawlerAI.Create;
  try
    Docs.MaxDepth := 2;
    WriteLn(Docs.GetDocSummary('https://docs.example.com'));
    WriteLn(Docs.GenerateDocumentation('https://docs.example.com'));
  finally
    Docs.Free;
  end;
end.
