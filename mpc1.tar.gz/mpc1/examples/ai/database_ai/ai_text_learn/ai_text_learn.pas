program ai_text_learn;
{$mode objfpc}{$H+}
uses
  SysUtils, Classes, sqlite_driver, knowledge_base, keyword_engine;

procedure LearnFromText(DB: TSQLiteDriver; KB: TKnowledgeBase; KE: TKeywordEngine;
  const Topic, Content, Source: string);
var
  ClassName: string;
begin
  KB.IngestFile(Source);
  ClassName := KE.Classify(Topic);
  DB.Execute('INSERT INTO knowledge (topic, content, source) VALUES (?, ?, ?)',
    [Topic, Content, Source]);
  WriteLn('Learned "', Topic, '" classified as [', ClassName, ']');
end;

procedure GenerateSampleFiles;
var
  Content: TStringList;
  I: integer;
begin
  Content := TStringList.Create;
  Content.Add('Machine learning is a method of data analysis that automates analytical model building.');
  Content.Add('It is a branch of artificial intelligence based on the idea that systems can learn from data.');
  Content.Add('Deep learning uses neural networks with many layers to analyze complex patterns.');
  Content.SaveToFile('/tmp/ml_notes.txt');

  Content.Clear;
  Content.Add('SQLite is a self-contained, high-reliability, embedded SQL database engine.');
  Content.Add('PostgreSQL is a powerful, open source object-relational database system.');
  Content.SaveToFile('/tmp/db_notes.txt');

  for I := 1 to 3 do
  begin
    Content.Clear;
    Content.Add('Learning text sample ' + IntToStr(I) + ' for AI training purposes.');
    Content.Add('This demonstrates automated text ingestion.');
    Content.SaveToFile('/tmp/learn_sample_' + IntToStr(I) + '.txt');
  end;
  Content.Free;
end;

var
  DB: TSQLiteDriver;
  KB: TKnowledgeBase;
  KE: TKeywordEngine;
  Content: TStringList;
  Rows: TList;
  Row: TDBRow;
  I: integer;
begin
  WriteLn('=== AI text Learning from Files ===');
  WriteLn('Learn from text files, store in database');
  WriteLn;

  DB := TSQLiteDriver.Create('text_learn.db');
  KB := TKnowledgeBase.Create;
  KE := TKeywordEngine.Create;
  Content := TStringList.Create;

  DB.Open;
  DB.CreateKnowledgeTable;

  KE.AddKeyword('machine learning', 'AI');
  KE.AddKeyword('deep learning', 'AI');
  KE.AddKeyword('neural networks', 'AI');
  KE.AddKeyword('data analysis', 'technology');
  KE.AddKeyword('SQLite', 'database');
  KE.AddKeyword('PostgreSQL', 'database');

  GenerateSampleFiles;

  LearnFromText(DB, KB, KE, 'Machine Learning', '', '/tmp/ml_notes.txt');
  LearnFromText(DB, KB, KE, 'Databases', '', '/tmp/db_notes.txt');

  for I := 1 to 3 do
  begin
    KB.IngestFile('/tmp/learn_sample_' + IntToStr(I) + '.txt');
    DB.Execute('INSERT INTO knowledge (topic, content, source) VALUES (?, ?, ?)',
      ['Sample_' + IntToStr(I), 'Auto-generated learning content', 'auto_learn']);
  end;

  Rows := DB.Query('SELECT * FROM knowledge WHERE source LIKE ? ORDER BY topic', ['%learn%']);
  WriteLn('=== Learned from text Files (', Rows.Count, ' entries) ===');
  for I := 0 to Rows.Count - 1 do
  begin
    Row := TDBRow(Rows[I]);
    WriteLn('  Topic: ', Row.GetField('topic'));
    WriteLn('  Content: ', Copy(Row.GetField('content'), 1, 60), '...');
    WriteLn('  Classified as: ', KE.Classify(Row.GetField('topic')));
    WriteLn;
  end;

  WriteLn('Total KB fragments: ', KB.GetTotalFragments);
  WriteLn('Total DB entries: ', DB.Query('SELECT COUNT(*) as cnt FROM knowledge').Count);

  Content.Free;
  Rows.Free;
  DB.Close;
  KE.Free;
  KB.Free;
  DB.Free;
  WriteLn('text learning completed.');
  ReadLn;
end.
