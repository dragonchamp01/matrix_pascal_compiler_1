program ai_training_data;
{$mode objfpc}{$H+}
uses
  SysUtils, Classes, sqlite_driver, json_support, keyword_engine;

procedure AddTrainingSample(DB: TSQLiteDriver; const Input, Output, Category: string; Weight: double);
begin
  DB.Execute('INSERT INTO training_samples (input_text, output_text, category, weight) VALUES (?, ?, ?, ?)',
    [Input, Output, Category, FloatToStr(Weight)]);
end;

procedure AutoClassifyAndStore(DB: TSQLiteDriver; KE: TKeywordEngine; const Input, Output: string);
var
  Category: string;
begin
  Category := KE.Classify(Input);
  AddTrainingSample(DB, Input, Output, Category, 0.9);
  WriteLn('Classified "', Input, '" as [', Category, '] and stored.');
end;

var
  DB: TSQLiteDriver;
  JSON: TJSONObject;
  KE: TKeywordEngine;
  Rows: TList;
  Row: TDBRow;
  I: integer;
begin
  WriteLn('=== AI Training Data Management ===');
  WriteLn('Store/retrieve training data in database');
  WriteLn;

  DB := TSQLiteDriver.Create('training_data.db');
  KE := TKeywordEngine.Create;

  DB.Open;
  DB.Execute('CREATE TABLE if not EXISTS training_samples (id integer PRIMARY KEY AUTOINCREMENT, input_text text, output_text text, category text, weight real default 1.0, source text, created_at TIMESTAMP default CURRENT_TIMESTAMP)');
  DB.Execute('CREATE TABLE if not EXISTS training_datasets (id integer PRIMARY KEY AUTOINCREMENT, name text UNIQUE, description text, sample_count integer default 0, created_at TIMESTAMP default CURRENT_TIMESTAMP)');

  DB.Execute('INSERT INTO training_datasets (name, description) VALUES (?, ?)', ['qa_dataset', 'Question-answer training pairs']);
  DB.Execute('INSERT INTO training_datasets (name, description) VALUES (?, ?)', ['classification', 'text classification samples']);

  KE.AddKeyword('AI', 'technology');
  KE.AddKeyword('database', 'technology');
  KE.AddKeyword('pascal', 'programming');

  for I := 1 to 10 do
    AddTrainingSample(DB, 'Sample input ' + IntToStr(I), 'Expected output ' + IntToStr(I), 'general', 1.0);

  AutoClassifyAndStore(DB, KE, 'What is AI?', 'AI is artificial intelligence.');
  AutoClassifyAndStore(DB, KE, 'Explain database', 'A database stores data.');
  AutoClassifyAndStore(DB, KE, 'pascal language', 'pascal is a programming language.');
  AutoClassifyAndStore(DB, KE, 'Neural networks explained', 'Neural networks are AI models.');
  AutoClassifyAndStore(DB, KE, 'SQL query basics', 'SQL queries retrieve data.');

  Rows := DB.Query('SELECT * FROM training_samples ORDER BY weight DESC LIMIT 5');
  WriteLn('=== Top 5 Training Samples (by weight) ===');
  for I := 0 to Rows.Count - 1 do begin
    Row := TDBRow(Rows[I]);
    WriteLn('  [', Row.GetField('category'), '] ', Row.GetField('input_text'));
    WriteLn('  -> ', Row.GetField('output_text'));
    WriteLn('  Weight: ', Row.GetField('weight'));
    WriteLn;
  end;

  DB.Execute('UPDATE training_datasets set sample_count = (SELECT COUNT(*) FROM training_samples) WHERE name = ?', ['qa_dataset']);

  Rows := DB.Query('SELECT * FROM training_datasets');
  WriteLn('=== Datasets ===');
  for I := 0 to Rows.Count - 1 do begin
    Row := TDBRow(Rows[I]);
    WriteLn('  ', Row.GetField('name'), ': ', Row.GetField('sample_count'), ' samples');
  end;

  Rows.Free;
  DB.Close;
  KE.Free;
  DB.Free;
  WriteLn('Training data management completed.');
  ReadLn;
end.
