program ai_boss_audit;
{$mode objfpc}{$H+}
uses
  SysUtils, Classes, sqlite_driver, boss_agent, conversation, keyword_engine;

procedure LogBossCommand(DB: TSQLiteDriver; const Cmd, SubAgent, Status, ExecTime, Result: string);
begin
  DB.Execute('INSERT INTO boss_commands (command, sub_agent, status, execution_time, result) VALUES (?, ?, ?, ?, ?)',
    [Cmd, SubAgent, Status, ExecTime, Result]);
end;

var
  DB: TSQLiteDriver;
  Boss: TBossAgent;
  KE: TKeywordEngine;
  Rows: TList;
  Row: TDBRow;
  Response: string;
  I: integer;
begin
  WriteLn('=== AI Boss Agent Audit Trail ===');
  WriteLn('Boss agent audit trail in database');
  WriteLn;

  DB := TSQLiteDriver.Create('boss_audit.db');
  Boss := TBossAgent.Create('marco neo');
  KE := TKeywordEngine.Create;

  DB.Open;
  DB.Execute('CREATE TABLE if not EXISTS boss_audit (id integer PRIMARY KEY AUTOINCREMENT, input text, response text, action_type text, is_boss_command integer, timestamp TIMESTAMP default CURRENT_TIMESTAMP)');
  DB.Execute('CREATE TABLE if not EXISTS boss_commands (id integer PRIMARY KEY AUTOINCREMENT, command text, sub_agent text, status text, execution_time real, result text, issued_at TIMESTAMP default CURRENT_TIMESTAMP)');

  Response := Boss.Process('What is the status?');
  DB.Execute('INSERT INTO boss_audit (input, response, action_type, is_boss_command) VALUES (?, ?, ?, ?)',
    ['What is the status?', Response, 'status_query', '1']);

  Response := Boss.Process('Search web for AI news');
  DB.Execute('INSERT INTO boss_audit (input, response, action_type, is_boss_command) VALUES (?, ?, ?, ?)',
    ['Search web for AI news', Response, 'web_search', '0']);

  Response := Boss.Process('Plan a project');
  DB.Execute('INSERT INTO boss_audit (input, response, action_type, is_boss_command) VALUES (?, ?, ?, ?)',
    ['Plan a project', Response, 'planning', '0']);

  Response := Boss.Process('Bookmark this page');
  DB.Execute('INSERT INTO boss_audit (input, response, action_type, is_boss_command) VALUES (?, ?, ?, ?)',
    ['Bookmark this page', Response, 'bookmark', '0']);

  LogBossCommand(DB, 'status', 'chat_interface', 'completed', '0.05', 'All systems operational');
  LogBossCommand(DB, 'search', 'web_agent', 'completed', '0.12', 'Found 3 results');
  LogBossCommand(DB, 'plan', 'planner', 'completed', '0.08', 'Plan created');
  LogBossCommand(DB, 'learn', 'knowledge_base', 'completed', '0.15', 'Knowledge updated');

  KE.AddKeyword('status', 'admin');
  KE.AddKeyword('search', 'web');
  KE.AddKeyword('plan', 'planning');
  KE.AddKeyword('bookmark', 'admin');

  Rows := DB.Query('SELECT * FROM boss_audit ORDER BY timestamp DESC');
  WriteLn('=== Boss Audit Trail (', Rows.Count, ' entries) ===');
  for I := 0 to Rows.Count - 1 do
  begin
    Row := TDBRow(Rows[I]);
    WriteLn('  Input: ', Row.GetField('input'));
    WriteLn('  Action: ', Row.GetField('action_type'), ' | BossCmd: ', Row.GetField('is_boss_command'));
    WriteLn('  Response: ', Copy(Row.GetField('response'), 1, 60));
    WriteLn('  class: ', KE.Classify(Row.GetField('action_type')));
    WriteLn;
  end;

  Rows := DB.Query('SELECT * FROM boss_commands ORDER BY issued_at DESC');
  WriteLn('=== Boss Commands ===');
  for I := 0 to Rows.Count - 1 do
  begin
    Row := TDBRow(Rows[I]);
    WriteLn('  ', Row.GetField('command'), ' -> ', Row.GetField('sub_agent'),
            ' [', Row.GetField('status'), '] ', Row.GetField('execution_time'), 's');
  end;

  Rows.Free;
  DB.Close;
  KE.Free;
  Boss.Free;
  DB.Free;
  WriteLn('Boss audit completed.');
  ReadLn;
end.
