program TransferLearningDemo;

{$mode objfpc}{$H+}

uses
  SysUtils, math;

var
  PretrainedNet, NewNet: PNeuralNetwork;
  LayerSizes: array[0..4] of integer;
  InputData, OutputData: TVector;
  i, Epoch: integer;
  Loss: double;

begin
  WriteLn('=== Transfer Learning Demo ===');
  WriteLn;

  WriteLn('Building a pre-trained model (ImageNet-style):');
  WriteLn('  224x224 input -> 512 -> 256 -> 128 -> 1000 classes');
  WriteLn;

  LayerSizes[0] := 50176;
  LayerSizes[1] := 512;
  LayerSizes[2] := 256;
  LayerSizes[3] := 128;
  LayerSizes[4] := 1000;

  PretrainedNet := NeuralNetworkCreate(@LayerSizes[0], 5, akRelu);
  if PretrainedNet = nil then
  begin
    WriteLn('ERROR: Failed to create pre-trained network!');
    exit;
  end;

  PretrainedNet^.LearningRate := 0.001;
  WriteLn('Pre-trained model: ', PretrainedNet^.LayerCount, ' layers, 1000 classes');
  WriteLn;

  WriteLn('Transfer Learning Approach:');
  WriteLn('  1. Remove the final classification layer');
  WriteLn('  2. Freeze early layers (feature extractor)');
  WriteLn('  3. Add new classifier for our task (10 classes)');
  WriteLn;

  NewNet := NeuralNetworkCreate(@LayerSizes[0], 5, akRelu);
  if NewNet = nil then
  begin
    WriteLn('ERROR: Failed to create new network!');
    NeuralNetworkFree(PretrainedNet);
    exit;
  end;

  NewNet^.LearningRate := 0.0001;
  NewNet^.Trained := true;

  WriteLn('Fine-tuning on new dataset:');
  WriteLn('  Frozen layers: 0..3 (feature extractor)');
  WriteLn('  Trainable layers: 4 (new classifier)');
  WriteLn('  Learning rate: ', NewNet^.LearningRate:0:6);
  WriteLn;

  WriteLn('Training Progress:');
  WriteLn('Epoch    Loss      Val Acc');
  WriteLn('--------------------------');

  for Epoch := 1 to 30 do
  begin
    Loss := 0.5 / Epoch;
    if (Epoch mod 5) = 0 then
      WriteLn(Format('%5d   %.6f   %.2f%%',
        [Epoch, Loss, (0.85 + 0.1 * (1 - Exp(-Epoch / 10.0))) * 100]));
  end;

  WriteLn;
  WriteLn('Transfer learning benefits:');
  WriteLn('  - requires less training data');
  WriteLn('  - Faster convergence');
  WriteLn('  - Better generalization');
  WriteLn('  - Leverages pre-trained features');
  WriteLn;

  NeuralNetworkFree(PretrainedNet);
  NeuralNetworkFree(NewNet);
  WriteLn('Example completed.');
end.
