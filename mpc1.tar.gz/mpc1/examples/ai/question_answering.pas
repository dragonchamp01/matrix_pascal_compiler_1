program question_answering;

{$APPTYPE CONSOLE}

type
  TQuestionAnswering = class
  private
    FData: array[0..9] of double;
  public
    constructor Create;
    function Process(const Input: array of double): double;
    procedure Run;
  end;

constructor TQuestionAnswering.Create;
var
  I: integer;
begin
  for I := 0 to 9 do
    FData[I] := Random;
end;

function TQuestionAnswering.Process(const Input: array of double): double;
var
  Sum: double;
  I: integer;
begin
  Sum := 0;
  for I := 0 to Length(Input) - 1 do
    Sum := Sum + Input[I] * FData[I mod 10];
  Result := Sum / Length(Input);
end;

procedure TQuestionAnswering.Run;
var
  Input: array[0..4] of double;
  I: integer;
  Result: double;
begin
  for I := 0 to 4 do
    Input[I] := Random * 10;
  WriteLn('question_answering example');
  write('Input: ');
  for I := 0 to 4 do
    write(Input[I]:0:2, ' ');
  WriteLn;
  Result := Process(Input);
  WriteLn('Output: ', Result:0:4);
  WriteLn('question_answering complete.');
end;

var
  Obj: TQuestionAnswering;
begin
  Randomize;
  Obj := TQuestionAnswering.Create;
  Obj.Run;
end.
