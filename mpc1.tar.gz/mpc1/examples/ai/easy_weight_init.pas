{$mode objfpc}{$H+}
program easy_weight_init;

{
    Matrix Pascal - Easy AI Examples
    ================================
    Example 012: Easy Weight Initialization
    
    Showcases different ways to initialize layer weights.
}

uses
  SysUtils, Classes, brain_weight_init, tensor;

type
  TInitHelper = class(TObject)
  public
    function GetXavier(Dim: integer): PTensor;
    function GetHe(Dim: integer): PTensor;
  end;

implementation

function TInitHelper.GetXavier(Dim: integer): PTensor;
begin
  Result := TWeightInitializer.Create.Initialize(TensorAllocate(Dim), imXavier, Dim, Dim);
end;

function TInitHelper.GetHe(Dim: integer): PTensor;
begin
  Result := TWeightInitializer.Create.Initialize(TensorAllocate(Dim), imHe, Dim, Dim);
end;

var
  IH: TInitHelper;
  W: PTensor;
begin
  IH := TInitHelper.Create;
  W := IH.GetXavier(10);
  WriteLn('Xavier weights initialized.');
  IH.Free;
end.
