{ Matrix Pascal AI Brain Example — Index aanmaken
   db_index.pas
   ════════════════════════════════════════════════════════════════
   NL: Index aanmaken — CREATE INDEX voor query optimalisatie
   EN: Create index — CREATE INDEX for query optimization }
program db_index;
{$mode objfpc}{$H+}
uses
  SysUtils, Classes, sqlite_driver;

procedure CreateLargeDataset(DB: TSQLiteDriver; Count: integer);
var
  i: integer;
begin
  DB.Execute('CREATE TABLE if not EXISTS indexed_data (' +
    'id integer PRIMARY KEY AUTOINCREMENT, ' +
    'code text, category text, status text, value integer, created_at TIMESTAMP default CURRENT_TIMESTAMP)');
  DB.Execute('DELETE FROM indexed_data');
  WriteLn('Inserting ', Count, ' rows...');
  for i := 1 to Count do
    DB.Execute('INSERT INTO indexed_data (code, category, status, value) VALUES (?, ?, ?, ?)',
      ['CODE_' + IntToStr(i),
       Choose(1 + (i mod 10), 'Alpha', 'Beta', 'Gamma', 'Delta', 'Epsilon', 'Zeta', 'Eta', 'Theta', 'Iota', 'Kappa'),
       Choose(1 + (i mod 3), 'active', 'pending', 'archived'),
       IntToStr(i mod 100)]);
  WriteLn('Inserted ', Count, ' rows.');
end;

procedure CreateIndexes(DB: TSQLiteDriver);
begin
  WriteLn;
  WriteLn('Creating indexes:');
  WriteLn('  1. idx_code on code column...');
  DB.Execute('CREATE index if not EXISTS idx_code ON indexed_data(code)');
  WriteLn('  2. idx_category_status on (category, status)...');
  DB.Execute('CREATE index if not EXISTS idx_category_status ON indexed_data(category, status)');
  WriteLn('  3. idx_value on value column...');
  DB.Execute('CREATE index if not EXISTS idx_value ON indexed_data(value)');
  WriteLn('  4. idx_status_created on (status, created_at)...');
  DB.Execute('CREATE index if not EXISTS idx_status_created ON indexed_data(status, created_at)');
  WriteLn('All indexes created.');
end;

procedure MeasureQuery(DB: TSQLiteDriver; const Description, SQL: string);
var
  StartTime, EndTime: int64;
  Row: TDBRow;
begin
  StartTime := GetTickCount64;
  Row := DB.QuerySingle(SQL);
  EndTime := GetTickCount64;
  if Row <> nil then
  begin
    WriteLn(Format('  %-45s result=%s time=%dms',
      [Description, Row.GetField('result'), EndTime - StartTime]));
    Row.Free;
  end;
end;

procedure ShowIndexInfo(DB: TSQLiteDriver);
var
  Rows: TList;
  Row: TDBRow;
  i: integer;
begin
  WriteLn;
  WriteLn('Indexes in database:');
  Rows := DB.Query('SELECT name, sql FROM sqlite_master WHERE type=''index'' and name not LIKE ''sqlite_%'' ORDER BY name');
  try
    for i := 0 to Rows.Count - 1 do
    begin
      Row := TDBRow(Rows[i]);
      WriteLn(Format('  %-25s %s', [Row.GetField('name'), Row.GetField('sql')]));
    end;
    if Rows.Count = 0 then
      WriteLn('  (no indexes)');
  finally
    Rows.Free;
  end;
end;

procedure QueryWithAndWithoutIndex(DB: TSQLiteDriver);
begin
  WriteLn;
  WriteLn('Query performance comparison:');
  MeasureQuery(DB, 'COUNT(*)',
    'SELECT COUNT(*) as result FROM indexed_data');
  MeasureQuery(DB, 'WHERE code = ''CODE_5000''',
    'SELECT COUNT(*) as result FROM indexed_data WHERE code = ''CODE_5000''');
  MeasureQuery(DB, 'WHERE category = ''Gamma'' and status = ''active''',
    'SELECT COUNT(*) as result FROM indexed_data WHERE category = ''Gamma'' and status = ''active''');
  MeasureQuery(DB, 'WHERE status = ''archived'' ORDER BY created_at',
    'SELECT COUNT(*) as result FROM indexed_data WHERE status = ''archived''');
  MeasureQuery(DB, 'WHERE value BETWEEN 10 and 20',
    'SELECT COUNT(*) as result FROM indexed_data WHERE value BETWEEN 10 and 20');
end;

begin
  WriteLn('=== Create index ===');
  WriteLn('Demonstrates creating indexes for query performance optimization.');
  WriteLn;
  with TSQLiteDriver.Create('index_example.db') do
  try
    if not Open then
    begin
      WriteLn('ERROR: Could not open database');
      exit;
    end;
    CreateLargeDataset(DB, 1000);
    ShowIndexInfo(DB);
    CreateIndexes(DB);
    ShowIndexInfo(DB);
    QueryWithAndWithoutIndex(DB);
    WriteLn;
    WriteLn('index example completed.');
  finally
    Close;
    Free;
  end;
  WriteLn;
  WriteLn('Voorbeeld / Example: db_index');
  WriteLn('Status: OK');
  ReadLn;
end.
