{ Matrix Pascal AI Brain Example — Database herstellen
   db_restore.pas
   ════════════════════════════════════════════════════════════════
   NL: Database herstellen — herstel database uit SQL dump
   EN: Restore database — restore database from SQL dump }
program db_restore;
{$mode objfpc}{$H+}
uses
  SysUtils, Classes, sqlite_driver;

procedure CreateBackupFile(const BackupPath: string);
var
  Lines: TStringList;
begin
  Lines := TStringList.Create;
  try
    Lines.Add('-- SQLite dump for restore test');
    Lines.Add('PRAGMA foreign_keys=OFF;');
    Lines.Add('begin TRANSACTION;');
    Lines.Add('CREATE TABLE if not EXISTS restore_test (id integer PRIMARY KEY, name text, value integer);');
    Lines.Add('INSERT INTO restore_test VALUES(1, ''alpha'', 100);');
    Lines.Add('INSERT INTO restore_test VALUES(2, ''beta'', 200);');
    Lines.Add('INSERT INTO restore_test VALUES(3, ''gamma'', 300);');
    Lines.Add('INSERT INTO restore_test VALUES(4, ''delta'', 400);');
    Lines.Add('INSERT INTO restore_test VALUES(5, ''epsilon'', 500);');
    Lines.Add('CREATE TABLE if not EXISTS restore_config (key text PRIMARY KEY, val text);');
    Lines.Add('INSERT INTO restore_config VALUES(''version'', ''1.0'');');
    Lines.Add('INSERT INTO restore_config VALUES(''created'', ''2026-06-08'');');
    Lines.Add('COMMIT;');
    Lines.SaveToFile(BackupPath);
    WriteLn('Created backup file: ', BackupPath, ' (', Lines.Count, ' lines)');
  finally
    Lines.Free;
  end;
end;

procedure RestoreFromBackup(const BackupPath, DbPath: string);
var
  Lines: TStringList;
  DB: TSQLiteDriver;
  Line: string;
  ExecCount: integer;
begin
  WriteLn('Restoring database from backup file...');
  if not FileExists(BackupPath) then
  begin
    WriteLn('ERROR: Backup file not found: ', BackupPath);
    exit;
  end;
  Lines := TStringList.Create;
  try
    Lines.LoadFromFile(BackupPath);
    WriteLn('Loaded ', Lines.Count, ' lines from backup.');
    DB := TSQLiteDriver.Create(DbPath);
    try
      if not DB.Open then
      begin
        WriteLn('ERROR: Could not create target database');
        exit;
      end;
      ExecCount := 0;
      for Line in Lines do
      begin
        if Line = '' then continue;
        if Line.StartsWith('--') then continue;
        if Line.StartsWith('begin') or Line.StartsWith('COMMIT') or Line.StartsWith('PRAGMA') then
        begin
          DB.Execute(Line);
          Inc(ExecCount);
          continue;
        end;
        if Line.EndsWith(';') then
        begin
          DB.Execute(Line);
          Inc(ExecCount);
        end;
      end;
      WriteLn('Executed ', ExecCount, ' SQL statements from backup.');
    finally
      DB.Close;
      DB.Free;
    end;
  finally
    Lines.Free;
  end;
end;

procedure VerifyRestore(const DbPath: string);
var
  DB: TSQLiteDriver;
  Rows: TList;
  Row: TDBRow;
  i: integer;
begin
  WriteLn;
  WriteLn('Verifying restored database:');
  DB := TSQLiteDriver.Create(DbPath);
  try
    if not DB.Open then
    begin
      WriteLn('ERROR: Cannot open restored database');
      exit;
    end;
    WriteLn('Tables present:');
    Rows := DB.Query("SELECT name FROM sqlite_master WHERE type='table' ORDER BY name");
    try
      for i := 0 to Rows.Count - 1 do
      begin
        Row := TDBRow(Rows[i]);
        WriteLn('  - ', Row.GetField('name'));
      end;
    finally
      Rows.Free;
    end;
    WriteLn;
    WriteLn('Data in restore_test:');
    Rows := DB.Query('SELECT * FROM restore_test ORDER BY id');
    try
      for i := 0 to Rows.Count - 1 do
      begin
        Row := TDBRow(Rows[i]);
        WriteLn(Format('  %s: %s (val=%s)', [Row.GetField('id'), Row.GetField('name'), Row.GetField('value')]));
      end;
    finally
      Rows.Free;
    end;
    WriteLn;
    WriteLn('Data in restore_config:');
    Rows := DB.Query('SELECT * FROM restore_config');
    try
      for i := 0 to Rows.Count - 1 do
      begin
        Row := TDBRow(Rows[i]);
        WriteLn(Format('  %s = %s', [Row.GetField('key'), Row.GetField('val')]));
      end;
    finally
      Rows.Free;
    end;
    Row := DB.QuerySingle('SELECT COUNT(*) as cnt FROM restore_test');
    if Row <> nil then
    begin
      WriteLn('Total restored rows: ', Row.GetField('cnt'));
      Row.Free;
    end;
  finally
    DB.Close;
    DB.Free;
  end;
end;

begin
  WriteLn('=== Restore database ===');
  WriteLn('Demonstrates restoring a database from a SQL backup file.');
  WriteLn;
  CreateBackupFile('sample_backup.sql');
  WriteLn;
  RestoreFromBackup('sample_backup.sql', 'restored_example.db');
  VerifyRestore('restored_example.db');
  WriteLn;
  WriteLn('Voorbeeld / Example: db_restore');
  WriteLn('Status: OK');
  ReadLn;
end.
