{ Matrix Pascal AI Brain Example — DBRow aanmaken
   db_row_create.pas
   ════════════════════════════════════════════════════════════════
   NL: DBRow aanmaken — maak en manipuleer TDBRow objecten
   EN: Create DBRow — create and manipulate TDBRow objects }
program db_row_create;
{$mode objfpc}{$H+}
uses
  SysUtils, Classes, sqlite_driver;

procedure DemonstrateRowCreation;
var
  Row: TDBRow;
  Rows: TList;
  i: integer;
begin
  WriteLn('Demonstrating TDBRow creation and manipulation:');
  WriteLn;
  WriteLn('1. Creating a TDBRow programmatically:');
  Row := TDBRow.Create;
  try
    Row.Fields.Add('name=John Doe');
    Row.Fields.Add('email=john@example.com');
    Row.Fields.Add('age=30');
    Row.Fields.Add('salary=55000.50');
    Row.Fields.Add('is_active=true');
    WriteLn('   Created row with ', Row.Fields.Count, ' fields:');
    for i := 0 to Row.Fields.Count - 1 do
      WriteLn('     ', Row.Fields[i]);
  finally
    Row.Free;
  end;
  WriteLn;
  WriteLn('2. Creating rows from database query:');
  with TSQLiteDriver.Create('row_create_example.db') do
  try
    if not Open then
    begin
      WriteLn('ERROR: Could not open database');
      exit;
    end;
    Execute('CREATE TABLE if not EXISTS employees (' +
      'id integer PRIMARY KEY AUTOINCREMENT, name text, department text, salary real)');
    Execute('DELETE FROM employees');
    Execute('INSERT INTO employees VALUES (1, ''Alice'', ''Engineering'', 85000)');
    Execute('INSERT INTO employees VALUES (2, ''Bob'', ''Marketing'', 62000)');
    Execute('INSERT INTO employees VALUES (3, ''Charlie'', ''Sales'', 72000)');
    WriteLn('   Querying 3 employees:');
    Rows := Query('SELECT * FROM employees ORDER BY id');
    try
      for i := 0 to Rows.Count - 1 do
      begin
        Row := TDBRow(Rows[i]);
        WriteLn(Format('     Row %d: %s fields', [i + 1, Row.Fields.Count]));
      end;
    finally
      Rows.Free;
    end;
  finally
    Close;
    Free;
  end;
  WriteLn;
  WriteLn('3. Accessing fields by name:');
  Row := TDBRow.Create;
  try
    Row.Fields.Add('product=Widget');
    Row.Fields.Add('price=19.99');
    Row.Fields.Add('quantity=100');
    WriteLn('   product = ', Row.GetField('product'));
    WriteLn('   price   = ', Row.GetField('price'));
    WriteLn('   quantity= ', Row.GetField('quantity'));
    WriteLn('   non_existent = "', Row.GetField('non_existent'), '" (empty string)');
  finally
    Row.Free;
  end;
  WriteLn;
  WriteLn('4. Iterating over fields:');
  Row := TDBRow.Create;
  try
    Row.Fields.Add('key1=value1');
    Row.Fields.Add('key2=value2');
    Row.Fields.Add('key3=value3');
    for i := 0 to Row.Fields.Count - 1 do
      WriteLn('   Field ', i, ': ', Row.Fields[i]);
  finally
    Row.Free;
  end;
  WriteLn;
  WriteLn('5. TDBRow lifecycle (create, fill, read, free):');
  Row := TDBRow.Create;
  try
    Row.Fields.Add('a=1');
    Row.Fields.Add('b=2');
    Row.Fields.Add('c=3');
    WriteLn('   Created row with 3 fields, values: a=', Row.GetField('a'),
      ', b=', Row.GetField('b'), ', c=', Row.GetField('c'));
  finally
    Row.Free;
  end;
  WriteLn('   Row freed successfully.');
end;

begin
  WriteLn('=== Create DBRow ===');
  WriteLn('Demonstrates TDBRow creation, field management, and data access.');
  WriteLn;
  DemonstrateRowCreation;
  WriteLn;
  WriteLn('Voorbeeld / Example: db_row_create');
  WriteLn('Status: OK');
  ReadLn;
end.
