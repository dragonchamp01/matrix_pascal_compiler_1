program classification_example;

{$APPTYPE CONSOLE}

type
  TClassifier = class
  private
    FWeights: array[0..1] of double;
    FBias: double;
  public
    constructor Create;
    function Sigmoid(X: double): double;
    function forward(X1, X2: double): double;
    procedure Train(X1, X2, Y: double; LR: double);
  end;

constructor TClassifier.Create;
begin
  FWeights[0] := Random - 0.5;
  FWeights[1] := Random - 0.5;
  FBias := Random - 0.5;
end;

function TClassifier.Sigmoid(X: double): double;
begin
  Result := 1 / (1 + Exp(-X));
end;

function TClassifier.forward(X1, X2: double): double;
begin
  Result := Sigmoid(X1 * FWeights[0] + X2 * FWeights[1] + FBias);
end;

procedure TClassifier.Train(X1, X2, Y, LR: double);
var
  Pred: double;
begin
  Pred := forward(X1, X2);
  FWeights[0] := FWeights[0] + LR * (Y - Pred) * X1;
  FWeights[1] := FWeights[1] + LR * (Y - Pred) * X2;
  FBias := FBias + LR * (Y - Pred);
end;

var
  C: TClassifier;
  I: integer;
begin
  Randomize;
  C := TClassifier.Create;
  for I := 1 to 500 do
  begin
    C.Train(1, 2, 1, 0.1);
    C.Train(3, 4, 0, 0.1);
  end;
  WriteLn('Classification Example');
  WriteLn('(1,2) prob=', C.forward(1,2):0:4, ' expected=1');
  WriteLn('(3,4) prob=', C.forward(3,4):0:4, ' expected=0');
  WriteLn('Classification complete.');
end.
