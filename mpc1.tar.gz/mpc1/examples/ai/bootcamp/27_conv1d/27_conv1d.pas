{$mode objfpc}{$H+}
{
  27_conv1d.pas — 1D Convolutionele Laag
  1D Convolutional Layer
  ────────────────────────────────────────
  NL: 1D convolutie voor sequentie data
  (tekst, audio, tijdreeksen).
  
  EN: 1D convolution for sequence data
  (text, audio, time series).
}
program conv1d;

uses
  SysUtils, Math;

{ Eenvoudige 1D convolutie / Simple 1D convolution }
function Conv1D(
  const Input: TVector;
  const Kernel: TVector;
  N, KSize: integer;
  Stride, Padding: integer): TVector;
var
  OutLen, I, J, InputIdx: integer;
  Sum: double;
begin
  OutLen := (N + 2 * Padding - KSize) div Stride + 1;
  Result := AllocMem(OutLen * SizeOf(double));
  for I := 0 to OutLen - 1 do
  begin
    Sum := 0.0;
    for J := 0 to KSize - 1 do
    begin
      InputIdx := I * Stride + J - Padding;
      if (InputIdx >= 0) and (InputIdx < N) then
        Sum := Sum + Input[InputIdx] * Kernel[J];
    end;
    Result[I] := Sum;
  end;
end;

var
  Signal, Kernel, Output: TVector;
  N, KSize, I: integer;
begin
  WriteLn('=== 27: 1D Convolutionele Laag / 1D Convolutional layer ===');
  WriteLn;

  N := 16; KSize := 3;
  WriteLn(Format('Signaal lengte: %d', [N]));
  WriteLn(Format('Kernel grootte: %d', [KSize]));
  WriteLn;

  { ─── Signaal en kernel / Signal and kernel ─── }
  Signal := AllocMem(N * SizeOf(double));
  for I := 0 to N - 1 do
    Signal[I] := Sin(I * 0.5) + Random * 0.1;

  Kernel := AllocMem(KSize * SizeOf(double));
  Kernel[0] := 0.5; Kernel[1] := 1.0; Kernel[2] := 0.5;

  write('Signaal:     '); for I := 0 to N - 1 do write(Format('%.2f ', [Signal[I]])); WriteLn;
  write('Kernel:      '); for I := 0 to KSize - 1 do write(Format('%.1f ', [Kernel[I]])); WriteLn;
  WriteLn;

  { ─── Convolutie / Convolution ─── }
  WriteLn('NL: 1D convolutie met stride=1, padding=1 (same)');
  WriteLn('EN: 1D convolution with stride=1, padding=1 (same)');
  Output := Conv1D(Signal, Kernel, N, KSize, 1, 1);
  write('Output:      '); for I := 0 to (N + 2 - KSize) div 1 do write(Format('%.2f ', [Output[I]])); WriteLn;
  WriteLn;

  { ─── Effecten van stride en padding ─── }
  WriteLn('NL: Effect van stride en padding');
  WriteLn('EN: Effect of stride and padding');
  WriteLn('  Stride=1, Pad=1:  same convolutie (zelfde lengte)');
  WriteLn('  Stride=2, Pad=0:  downsample (helft lengte)');
  WriteLn('  Stride=1, Pad=0:  valid convolutie (korter)');
  WriteLn;

  FreeMem(Signal); FreeMem(Kernel); FreeMem(Output);

  WriteLn('NL: 1D convolutie begrepen!');
  WriteLn('EN: 1D convolution understood!');
end.
