{$mode objfpc}{$H+}
{
  17_tokenizer.pas — Tokenizer
  Tokenizer
  ────────────────────────────
  NL: Tokenizer voor tekstverwerking:
  woorden splitsen, vocabulaire bouwen,
  en teksten coderen/decoderen.
  
  EN: Tokenizer for text processing:
  word splitting, vocabulary building,
  and encoding/decoding texts.
}
program tokenizer_demo;

uses
  SysUtils, Math, tokenizer;

var
  Tokenizer: PTokenizer;
  Encoded: PTokenizedSequence;
  DecodedText: string;
  I: integer;
begin
  WriteLn('=== 17: Tokenizer / Tokenizer ===');
  WriteLn;

  Tokenizer := TokenizerCreate;
  WriteLn('NL: Tokenizer aangemaakt');
  WriteLn('EN: Tokenizer created');
  WriteLn(Format('  Unknown token: %s', [Tokenizer^.UnknownToken]));
  WriteLn(Format('  Pad token:     %s', [Tokenizer^.PadToken]));
  WriteLn(Format('  Start token:   %s', [Tokenizer^.StartToken]));
  WriteLn(Format('  end token:     %s', [Tokenizer^.EndToken]));
  WriteLn;

  { ─── Vocabulaire / Vocabulary ─── }
  WriteLn('NL: Bouw een vocabulaire uit teksten');
  WriteLn('EN: Build a vocabulary from texts');
  TokenizerBuild(Tokenizer, ['hello world', 'hello ai', 'matrix pascal'], 100);
  WriteLn(Format('Vocab grootte / Vocab size: %d', [Tokenizer^.VocabSize]));
  WriteLn;

  { ─── Encode ─── }
  WriteLn('NL: Encode een tekst naar token IDs');
  WriteLn('EN: Encode a text to token IDs');
  Encoded := TokenizerEncode(Tokenizer, 'hello world');
  if Encoded <> nil then
  begin
    write('Token IDs: ');
    for I := 0 to Encoded^.Length - 1 do
      write(Format('%d ', [Encoded^.IDs[I]]));
    WriteLn;
    FreeMem(Encoded^.IDs);
    Dispose(Encoded);
  end;
  WriteLn;

  { ─── Decode ─── }
  WriteLn('NL: Decode token IDs terug naar tekst');
  WriteLn('EN: Decode token IDs back to text');
  DecodedText := TokenizerDecode(Tokenizer, nil, 0);
  WriteLn(Format('Gedecodeerd / Decoded: "%s"', [DecodedText]));
  WriteLn;

  { ─── Tokenizer flow ─── }
  WriteLn('NL: Volledige tokenizer workflow');
  WriteLn('EN: Complete tokenizer workflow');
  WriteLn('  Tekst:  "I love Matrix Pascal"');
  WriteLn('  ─────────────────────────────');
  WriteLn('  1. Split: ["I", "love", "Matrix", "Pascal"]');
  WriteLn('  2. Map:   [5, 12, 8, 3]  (token IDs)');
  WriteLn('  3. Special tokens: [CLS] 5 12 8 3 [SEP]');
  WriteLn('  4. Padding: [CLS] 5 12 8 3 [SEP] [PAD] [PAD]');
  WriteLn('  5. attention mask: [1, 1, 1, 1, 1, 1, 0, 0]');
  WriteLn;

  TokenizerFree(Tokenizer);

  WriteLn('NL: Tokenizer begrepen!');
  WriteLn('EN: Tokenizer understood!');
end.
