{$mode objfpc}{$H+}
{
  42_planner_intro.pas — Inleiding tot Planner
  Introduction to Planner
  ──────────────────────────────────────────────
  NL: TPlanner voor taakplanning en -beheer.
  Leer hoe je plannen maakt met stappen en
  prioriteiten.
  
  EN: TPlanner for task planning and management.
  Learn how to create plans with steps and
  priorities.
}
program planner_intro;

uses
  SysUtils, Math, planner;

var
  Plan: TPlanner;
  PlanID: integer;
  Plans: TStringList;
begin
  WriteLn('=== 42: Inleiding tot Planner / Introduction to Planner ===');
  WriteLn;

  Plan := TPlanner.Create;
  WriteLn('NL: Planner aangemaakt');
  WriteLn('EN: Planner created');
  WriteLn;

  { ─── Plan maken / Create plan ─── }
  WriteLn('NL: Maak een plan');
  WriteLn('EN: Create a plan');
  PlanID := Plan.CreatePlan('Leer matrix pascal');
  WriteLn(Format('Plan aangemaakt / Plan created: ID %d', [PlanID]));
  WriteLn;

  { ─── Stappen toevoegen / Add steps ─── }
  WriteLn('NL: Voeg stappen toe met prioriteiten');
  WriteLn('EN: Add steps with priorities');
  Plan.AddStep(PlanID, 'Leer tensor basis', prHigh);
  Plan.AddStep(PlanID, 'Bestudeer neural networks', prHigh);
  Plan.AddStep(PlanID, 'Implementeer een model', prNormal);
  Plan.AddStep(PlanID, 'Test en evalueer', prNormal);
  Plan.AddStep(PlanID, 'Documenteer resultaten', prLow);
  WriteLn(Format('Stappen toegevoegd: %d', [Plan.GetStepCount(PlanID)]));
  WriteLn;

  { ─── Plan rapport / Plan report ─── }
  WriteLn('NL: Plan rapport');
  WriteLn('EN: Plan report');
  Plans := Plan.GetPlanReport(PlanID);
  WriteLn(Plans.text);
  Plans.Free;
  WriteLn;

  { ─── Plan uitvoeren / Execute plan ─── }
  WriteLn('NL: Voer het plan uit');
  WriteLn('EN: Execute the plan');
  Plan.ExecuteTask(PlanID);
  WriteLn('Plan uitgevoerd! / Plan executed!');
  WriteLn;

  { ─── Plan status na uitvoering / Plan status after execution ─── }
  Plans := Plan.GetPlanReport(PlanID);
  WriteLn(Plans.text);
  Plans.Free;

  Plan.Free;

  WriteLn('NL: Planner introductie voltooid!');
  WriteLn('EN: Planner introduction completed!');
end.
