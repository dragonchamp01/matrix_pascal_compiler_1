{$mode objfpc}{$H+}
{
  25_encoder_decoder.pas — Encoder-Decoder Architectuur
  Encoder-Decoder Architecture
  ────────────────────────────────────────────────────────
  NL: Encoder-decoder model voor sequence-to-sequence
  taken zoals vertaling en samenvatting.
  
  EN: Encoder-decoder model for sequence-to-sequence
  tasks like translation and summarization.
}
program encoder_decoder;

uses
  SysUtils, Math, rnn, tensor;

type
  PEncoderDecoder = ^TEncoderDecoder;
  TEncoderDecoder = record
    Encoder: array[0..1] of PRNNLayer;
    Decoder: array[0..1] of PRNNLayer;
    EncoderCount: integer;
    DecoderCount: integer;
  end;

function EDCreate(InputSize, HiddenSize, OutputSize: integer): PEncoderDecoder;
var I: integer;
begin
  New(Result);
  for I := 0 to 1 do
  begin
    Result^.Encoder[I] := RNNLayerCreate(InputSize, HiddenSize);
    Result^.Decoder[I] := RNNLayerCreate(HiddenSize, OutputSize);
  end;
  Result^.EncoderCount := 2;
  Result^.DecoderCount := 2;
end;

procedure EDFree(var ED: PEncoderDecoder);
var I: integer;
begin
  for I := 0 to 1 do
  begin
    RNNLayerFree(ED^.Encoder[I]);
    RNNLayerFree(ED^.Decoder[I]);
  end;
  Dispose(ED);
end;

var
  ED: PEncoderDecoder;
  I: integer;
begin
  WriteLn('=== 25: Encoder-Decoder Architectuur / Encoder-Decoder Architecture ===');
  WriteLn;

  ED := EDCreate(4, 8, 5);
  WriteLn('Encoder-Decoder model aangemaakt / created');
  WriteLn(Format('  Encoder lagen: %d', [ED^.EncoderCount]));
  WriteLn(Format('  Decoder lagen: %d', [ED^.DecoderCount]));
  WriteLn;

  { ─── Encoder-Decoder workflow ─── }
  WriteLn('NL: Encoder-Decoder workflow voor vertaling');
  WriteLn('EN: Encoder-Decoder workflow for translation');
  WriteLn;
  WriteLn('  Encoder:');
  WriteLn('    "I love AI" → [rnn] → hidden state (context)');
  WriteLn('                    ↓');
  WriteLn('  Decoder:');
  WriteLn('    context → [rnn] → "Ik"');
  WriteLn('           → [rnn] → "hou"');
  WriteLn('           → [rnn] → "van"');
  WriteLn('           → [rnn] → "AI"');
  WriteLn('           → [rnn] → [EOS]');
  WriteLn;

  { ─── Teacher forcing ─── }
  WriteLn('NL: Teacher forcing tijdens training');
  WriteLn('EN: Teacher forcing during training');
  WriteLn('  In plaats van eigen voorspelling als input,');
  WriteLn('  geven we het correcte vorige token (versnelt leren)');
  WriteLn;

  { ─── Beam search ─── }
  WriteLn('NL: Beam search voor generatie');
  WriteLn('EN: Beam search for generation');
  WriteLn('  Beam width = 3: hou de 3 beste hypotheses');
  WriteLn('  Beter dan greedy (altijd de beste kiezen)');
  WriteLn;

  EDFree(ED);

  WriteLn;
  WriteLn('NL: Encoder-Decoder architectuur begrepen!');
  WriteLn('EN: Encoder-Decoder architecture understood!');
end.
