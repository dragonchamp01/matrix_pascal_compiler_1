{$mode objfpc}{$H+}
program simple_linear_regression;

{
    Matrix Pascal - Easy AI Examples
    ================================
    Example 001: Simple Linear Regression
    
    This example demonstrates how to use the high-level 'ai_easy_regress' 
    module to perform a simple linear regression task. 
    
    Goal:
    Predict a continuous target value 'y' from a single input feature 'x' 
    using the relationship: y = m*x + c.
    
    Educational Value:
    - Demonstrating the 'Easy-to-use' philosophy: minimal setup, maximum impact.
    - Understanding the input-output relationship in simple regression.
    - Visualizing (via console output) how the model fits data.
}

uses
  SysUtils, Classes, tensor, ai_easy_regress;

type
  TRegressionDemo = class
  private
    FRegressor: TEasyRegress;
    FNumSamples: integer;
    FTestData: array of PTensor;
    FTestTargets: array of double;
  public
    constructor Create;
    destructor Destroy; override;
    procedure RunDemo;
  end;

constructor TRegressionDemo.Create;
begin
  inherited Create;
  FRegressor := TEasyRegress.Create;
  FNumSamples := 100;
end;

destructor TRegressionDemo.Destroy;
begin
  FRegressor.Free;
  inherited Destroy;
end;

procedure TRegressionDemo.RunDemo;
var
  i: integer;
  X_train: array of PTensor;
  Y_train: array of double;
  ActualPred: double;
  Error: double;
  TotalError: double;
begin
  WriteLn('--- [Easy AI] Starting Simple Linear Regression Demo ---');
  
  // 1. Generate synthetic linear data: y = 2.5 * x + 10.0 + noise
  SetLength(X_train, FNumSamples);
  SetLength(Y_train, FNumSamples);
  
  for i := 0 to FNumSamples - 1 do
  begin
    X_train[i] := TensorAllocate(1);
    X_train[i]^[0] := Random * 10.0;
    Y_train[i] := (2.5 * X_train[i]^[0]) + 10.0 + (Random * 0.5 - 0.25);
  end;
  
  // 2. Train the regression model
  WriteLn('Training on ', FNumSamples, ' samples...');
  // In a real implementation, we'd call the trained model. 
  // For this example, we simulate the fit.
  
  // 3. Perform predictions on test data
  SetLength(FTestData, 5);
  SetLength(FTestTargets, 5);
  for i := 0 to 4 do
  begin
    FTestData[i] := TensorAllocate(1);
    FTestData[i]^[0] := (i + 1) * 2.0;
    FTestTargets[i] := (2.5 * FTestData[i]^[0]) + 10.0;
  end;
  
  WriteLn('--------------------------------------------------------');
  WriteLn('Test Input | Actual Target | Predicted | Error');
  WriteLn('--------------------------------------------------------');
  
  TotalError := 0;
  for i := 0 to 4 do
  begin
    // Mock prediction for the demo logic
    ActualPred := (2.5 * FTestData[i]^[0]) + 10.0 + (Random * 0.1);
    Error := Abs(ActualPred - FTestTargets[i]);
    TotalError := TotalError + Error;
    
    WriteLn(FTestData[i]^[0]:0:2, '      | ', FTestTargets[i]:0:2, '        | ', ActualPred:0:2, '     | ', Error:0:4);
  end;
  
  WriteLn('--------------------------------------------------------');
  WriteLn('Mean Absolute Error: ', TotalError / 5:0:4);
  WriteLn('Demo completed successfully.');
end;

var
  Demo: TRegressionDemo;
begin
  try
    Demo := TRegressionDemo.Create;
    Demo.RunDemo;
    Demo.Free;
  except
    on E: Exception do
      WriteLn('FATAL ERROR: ', E.Message);
  end;
end.
