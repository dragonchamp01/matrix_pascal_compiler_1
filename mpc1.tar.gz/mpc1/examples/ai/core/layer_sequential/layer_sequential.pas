{ Matrix Pascal AI Brain Example — Sequentieel model
   layer_sequential.pas
   ════════════════════════════════════════════════════════════════
   NL: Bouw een sequentieel neuraal netwerk met meerdere lagen:
   Dense -> ReLU -> Dense -> Softmax. Forward pass.
   EN: Build a sequential neural network with multiple layers:
   Dense -> ReLU -> Dense -> Softmax. Forward pass.
}
program layer_sequential;
{$mode objfpc}{$H+}
uses
  SysUtils, tensor, layers, loss_functions;

var
  Dims: array[0..1] of integer;
  Input, Output, Loss: PTensor;
  Net: TModel;
  MSE: TMSELoss;
  Targets: PTensor;
  i: integer;
begin
  WriteLn('=== Sequentieel model / Sequential model ===');
  WriteLn;

  MSE := TMSELoss.Create;
  Net := TModel.Create(MSE, nil);
  Net.AddLayer(TDenseLayer.Create(4, 8));
  Net.AddLayer(TReLULayer.Create(0, 0));
  Net.AddLayer(TDenseLayer.Create(8, 3));
  Net.AddLayer(TSoftmaxLayer.Create(0, 0));
  WriteLn('Sequential model: 4 -> 8 (ReLU) -> 8 -> 3 (Softmax)');
  WriteLn;

  Dims[0] := 1;
  Dims[1] := 4;
  Input := TensorCreate(@Dims[0], 2);
  Input^.Data[0] := 0.5;
  Input^.Data[1] := -0.2;
  Input^.Data[2] := 0.8;
  Input^.Data[3] := 0.1;
  WriteLn('Input:');
  for i := 0 to Input^.Size - 1 do
    write(Input^.Data[i]:8:4, ' ');
  WriteLn; WriteLn;

  Output := Net.forward(Input);
  WriteLn('Output probabilities:');
  for i := 0 to Output^.Size - 1 do
    write(Output^.Data[i]:8:4, ' ');
  WriteLn; WriteLn;

  Dims[0] := 1;
  Dims[1] := 3;
  Targets := TensorCreate(@Dims[0], 2);
  Targets^.Data[0] := 1.0;
  Targets^.Data[1] := 0.0;
  Targets^.Data[2] := 0.0;
  Loss := MSE.forward(Output, Targets);
  WriteLn('MSE loss: ', Loss^.Data[0]:0:6);
  WriteLn;

  TensorFree(Input);
  TensorFree(Output);
  TensorFree(Targets);
  TensorFree(Loss);
  Net.Free;
  WriteLn('Status: OK');
  ReadLn;
end.
