{ Matrix Pascal AI Brain Example — Cross-Entropy verlies
   loss_crossentropy.pas
   ════════════════════════════════════════════════════════════════
   NL: Cross-Entropy verlies voor multi-class classificatie.
   De standaard loss voor classificatie met softmax output.
   Formule: CE = -mean(sum(y_true * log(y_pred))).
   Gradient: dCE/d(logits) = softmax(logits) - y_true.
   EN: Cross-Entropy loss for multi-class classification.
   The standard loss for classification with softmax output.
   Formula: CE = -mean(sum(y_true * log(y_pred))).
   Gradient: dCE/d(logits) = softmax(logits) - y_true.
}
program loss_crossentropy;
{$mode objfpc}{$H+}
uses
  SysUtils, tensor, loss_functions;

var
  Dims: array[0..1] of integer;
  Predictions, Targets, Loss, Grad: PTensor;
  CE: TCrossEntropyLoss;
  i: integer;
begin
  WriteLn('=== Cross-Entropy verlies / Cross-Entropy Loss ===');
  WriteLn('CE = -sum(y_true * log(y_pred)) per sample');
  WriteLn('Used for classification with 3+ classes');
  WriteLn;

  CE := TCrossEntropyLoss.Create;
  WriteLn('CrossEntropy Loss created');
  WriteLn('  Expects predictions as probabilities (softmax output)');
  WriteLn('  Targets are one-hot encoded');
  WriteLn('  Lower loss = better prediction');
  WriteLn;

  Dims[0] := 1;
  Dims[1] := 4;
  Predictions := TensorCreate(@Dims[0], 2);
  Targets := TensorCreate(@Dims[0], 2);
  Predictions^.Data[0] := 0.7; Targets^.Data[0] := 1.0;
  Predictions^.Data[1] := 0.1; Targets^.Data[1] := 0.0;
  Predictions^.Data[2] := 0.1; Targets^.Data[2] := 0.0;
  Predictions^.Data[3] := 0.1; Targets^.Data[3] := 0.0;
  WriteLn('Predictions (class probs, good: class 0):');
  for i := 0 to 3 do write(Predictions^.Data[i]:8:4, ' ');
  WriteLn;
  WriteLn('Targets (one-hot):');
  for i := 0 to 3 do write(Targets^.Data[i]:8:4, ' ');
  WriteLn; WriteLn;

  Loss := CE.forward(Predictions, Targets);
  WriteLn('CrossEntropy Loss (good prediction): ', Loss^.Data[0]:0:6);
  WriteLn;

  Predictions^.Data[0] := 0.1;
  Predictions^.Data[1] := 0.7;
  Predictions^.Data[2] := 0.1;
  Predictions^.Data[3] := 0.1;
  Loss := CE.forward(Predictions, Targets);
  WriteLn('CrossEntropy Loss (poor: predicts class 1): ', Loss^.Data[0]:0:6);
  WriteLn;

  Grad := CE.Backward(Predictions, Targets);
  WriteLn('Gradient dL/dPred (pred - target):');
  for i := 0 to Grad^.Size - 1 do write(Grad^.Data[i]:8:4, ' ');
  WriteLn; WriteLn;

  TensorFree(Predictions);
  TensorFree(Targets);
  TensorFree(Loss);
  TensorFree(Grad);
  CE.Free;
  WriteLn('Status: OK');
  ReadLn;
end.
