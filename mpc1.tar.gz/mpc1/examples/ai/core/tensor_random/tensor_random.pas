{ Matrix Pascal AI Brain Example — Tensor random
   tensor_random.pas
   ════════════════════════════════════════════════════════════════
   NL: Initialisatie methodes: random uniform, normaal, Xavier,
   He. Belangrijk voor gewichtsinitialisatie.
   EN: Initialization methods: random uniform, normal, Xavier,
   He. Important for weight initialization.
}
program tensor_random;
{$mode objfpc}{$H+}
uses
  SysUtils, tensor;

var
  Dims: array[0..1] of integer;
  T: PTensor;
  i: integer;
begin
  WriteLn('=== tensor random / tensor random ===');
  WriteLn;

  Dims[0] := 2; Dims[1] := 4;
  WriteLn('Shape: [2, 4] (8 elements)');
  WriteLn;

  T := TensorRandU(@Dims[0], 2);
  WriteLn('Uniform random [0,1):');
  for i := 0 to T^.Size - 1 do
  begin
    write(T^.Data[i]:8:4, ' ');
    if (i + 1) mod 4 = 0 then WriteLn;
  end;
  TensorFree(T);
  WriteLn;

  T := TensorRandN(@Dims[0], 2);
  WriteLn('Normal random N(0,1):');
  for i := 0 to T^.Size - 1 do
  begin
    write(T^.Data[i]:8:4, ' ');
    if (i + 1) mod 4 = 0 then WriteLn;
  end;
  TensorFree(T);
  WriteLn;

  T := TensorXavier(@Dims[0], 2);
  WriteLn('Xavier/Glorot init:');
  for i := 0 to T^.Size - 1 do
  begin
    write(T^.Data[i]:8:4, ' ');
    if (i + 1) mod 4 = 0 then WriteLn;
  end;
  TensorFree(T);
  WriteLn;

  T := TensorHe(@Dims[0], 2);
  WriteLn('He init (for ReLU):');
  for i := 0 to T^.Size - 1 do
  begin
    write(T^.Data[i]:8:4, ' ');
    if (i + 1) mod 4 = 0 then WriteLn;
  end;
  TensorFree(T);
  WriteLn;

  T := TensorOnes(@Dims[0], 2);
  WriteLn('Ones:');
  for i := 0 to T^.Size - 1 do write(T^.Data[i]:6:2, ' ');
  WriteLn;
  TensorFree(T);

  T := TensorZeros(@Dims[0], 2);
  WriteLn('Zeros:');
  for i := 0 to T^.Size - 1 do write(T^.Data[i]:6:2, ' ');
  WriteLn;
  TensorFree(T);
  WriteLn;

  WriteLn('Status: OK');
  ReadLn;
end.
