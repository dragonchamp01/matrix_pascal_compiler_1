{ Matrix Pascal AI Brain Example — AdamW Optimizer
   optimizer_adamw.pas
   ════════════════════════════════════════════════════════════════
   NL: Adam met decoupled weight decay. Anders dan klassieke
   L2 regularisatie wordt weight decay APART van de gradient
   toegepast. Cruciaal voor transformer modellen (BERT, GPT).
   EN: Adam with decoupled weight decay. Unlike classic L2
   regularization, weight decay is applied SEPARATELY from the
   gradient. Crucial for transformer models (BERT, GPT).
}
program optimizer_adamw;
{$mode objfpc}{$H+}
uses
  SysUtils, tensor, optimizers;

var
  Dims: array[0..1] of integer;
  Param, Grad: PTensor;
  Optim: TAdamW;
  i, step: integer;
begin
  WriteLn('=== AdamW optimizer / AdamW optimizer ===');
  WriteLn('AdamW: W = W - lr * (m_hat / (sqrt(v_hat) + eps) + wd * W)');
  WriteLn('Weight decay is decoupled from gradient-based updates');
  WriteLn;

  Optim := TAdamW.Create(0.001, 0.9, 0.999, 1e-8, 0.01);
  WriteLn('AdamW parameters:');
  WriteLn('  lr=0.001, beta1=0.9, beta2=0.999, weight_decay=0.01');
  WriteLn('  Key difference: weight decay does not affect m/v');
  WriteLn('  Better generalization than L2 in Adam');
  WriteLn('  Recommended for ALL transformer training');
  WriteLn;

  Dims[0] := 2;
  Dims[1] := 3;
  Param := TensorCreate(@Dims[0], 2);
  TensorFill(Param, 1.0);
  Grad := TensorCreate(@Dims[0], 2);
  TensorFill(Grad, 0.1);
  Optim.AddParameter(Param, Grad);
  WriteLn('Initial param (all 1.0):');
  for i := 0 to Param^.Size - 1 do write(Param^.Data[i]:8:4, ' ');
  WriteLn; WriteLn;

  for step := 1 to 3 do
  begin
    Optim.Step;
    WriteLn('Step ', step, ' (with decoupled weight decay):');
    for i := 0 to Param^.Size - 1 do write(Param^.Data[i]:8:4, ' ');
    WriteLn;
  end;
  WriteLn;

  WriteLn('AdamW vs Adam + L2:');
  WriteLn('  Adam + L2: grad = loss_grad + wd * W (affects m/v)');
  WriteLn('  AdamW: W -= lr * wd * W (separate, no m/v effect)');
  WriteLn('  AdamW gives better validation loss in practice');
  WriteLn;

  TensorFree(Param);
  TensorFree(Grad);
  Optim.Free;
  WriteLn('Status: OK');
  ReadLn;
end.
