{ Matrix Pascal AI Brain Example — SGD Optimizer
   optimizer_sgd.pas
   ════════════════════════════════════════════════════════════════
   NL: Stochastic Gradient Descent met momentum en Nesterov.
   SGD is de meest fundamentele optimizer. Momentum versnelt
   convergentie. Nesterov geeft een voorsprong-effect.
   EN: Stochastic Gradient Descent with momentum and Nesterov.
   SGD is the most fundamental optimizer. Momentum accelerates
   convergence. Nesterov has a look-ahead effect.
}
program optimizer_sgd;
{$mode objfpc}{$H+}
uses
  SysUtils, tensor, optimizers;

var
  Dims: array[0..1] of integer;
  Param, Grad: PTensor;
  Optim: TSGD;
  i, step: integer;
begin
  WriteLn('=== SGD optimizer / SGD optimizer ===');
  WriteLn('SGD: W = W - lr * (grad + wd * W) + momentum * v');
  WriteLn('SGD is simple but effective, especially with momentum');
  WriteLn;

  Optim := TSGD.Create(0.01, 0.9, false, 0.0);
  WriteLn('SGD parameters:');
  WriteLn('  learning_rate = 0.01');
  WriteLn('  momentum = 0.9');
  WriteLn('  Nesterov = false');
  WriteLn('  weight_decay = 0.0');
  WriteLn('  v_t = momentum * v_{t-1} + grad');
  WriteLn('  W = W - lr * v_t');
  WriteLn;

  Dims[0] := 2;
  Dims[1] := 3;
  Param := TensorCreate(@Dims[0], 2);
  TensorFill(Param, 1.0);
  Grad := TensorCreate(@Dims[0], 2);
  TensorFill(Grad, 0.1);
  Optim.AddParameter(Param, Grad);
  WriteLn('Initial param (all 1.0, gradient all 0.1):');
  for i := 0 to Param^.Size - 1 do write(Param^.Data[i]:8:4, ' ');
  WriteLn; WriteLn;

  for step := 1 to 5 do
  begin
    Optim.Step;
    WriteLn('Step ', step, ': W = W - 0.01 * (0.1 + 0.9 * velocity)');
    for i := 0 to Param^.Size - 1 do write(Param^.Data[i]:8:4, ' ');
    WriteLn;
  end;
  WriteLn;

  WriteLn('SGD with momentum > 0 accelerates in consistent direction');
  WriteLn('SGD often generalizes better than Adam for CV tasks');
  WriteLn;

  TensorFree(Param);
  TensorFree(Grad);
  Optim.Free;
  WriteLn('Status: OK');
  ReadLn;
end.
