{ Matrix Pascal AI Brain Example — RMSProp Optimizer
   optimizer_rmsprop.pas
   ════════════════════════════════════════════════════════════════
   NL: RMSProp: past leersnelheid aan per parameter op basis
   van de grootte van recente gradienten. Goed voor RNNs en
   online/ non-stationaire problemen. Gebruikt bewegend
   gemiddelde van kwadratische gradienten.
   EN: RMSProp: adjusts learning rate per parameter based on
   recent gradient magnitudes. Good for RNNs and online/
   non-stationary problems. Uses moving average of squared grads.
}
program optimizer_rmsprop;
{$mode objfpc}{$H+}
uses
  SysUtils, tensor, optimizers;

var
  Dims: array[0..1] of integer;
  Param, Grad: PTensor;
  Optim: TRMSProp;
  i, step: integer;
begin
  WriteLn('=== RMSProp optimizer / RMSProp optimizer ===');
  WriteLn('RMSProp: W = W - lr * grad / (sqrt(v_t) + eps)');
  WriteLn('  v_t = decay * v_{t-1} + (1-decay) * grad^2');
  WriteLn;

  Optim := TRMSProp.Create(0.001, 0.9, 1e-8, 0.0);
  WriteLn('RMSProp parameters:');
  WriteLn('  lr=0.001, decay=0.9, epsilon=1e-8');
  WriteLn('  Large gradients => smaller effective lr (divided)');
  WriteLn('  Small gradients => larger effective lr');
  WriteLn('  Adapts learning rate to each parameter');
  WriteLn;

  Dims[0] := 2;
  Dims[1] := 3;
  Param := TensorCreate(@Dims[0], 2);
  TensorFill(Param, 1.0);
  Grad := TensorCreate(@Dims[0], 2);
  TensorFill(Grad, 0.1);
  Optim.AddParameter(Param, Grad);
  WriteLn('Initial param (all 1.0, gradient all 0.1):');
  for i := 0 to Param^.Size - 1 do write(Param^.Data[i]:8:4, ' ');
  WriteLn; WriteLn;

  for step := 1 to 3 do
  begin
    Optim.Step;
    WriteLn('Step ', step, ': adaptive per-parameter update');
    for i := 0 to Param^.Size - 1 do write(Param^.Data[i]:8:4, ' ');
    WriteLn;
  end;
  WriteLn;

  WriteLn('optimizer comparison:');
  WriteLn('  SGD: fixed lr for all params (simple)');
  WriteLn('  RMSProp: adaptive lr per param (good for RNNs)');
  WriteLn('  Adam: RMSProp + momentum (general purpose)');
  WriteLn('  AdamW: Adam + decoupled weight decay (transformers)');
  WriteLn;

  TensorFree(Param);
  TensorFree(Grad);
  Optim.Free;
  WriteLn('Status: OK');
  ReadLn;
end.
