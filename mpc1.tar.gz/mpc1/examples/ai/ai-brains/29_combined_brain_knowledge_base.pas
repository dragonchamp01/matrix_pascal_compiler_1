program CombinedBrainKnowledgeBase;

--  ====================================================================
--  |  LESSON: Combined AI Brain - Knowledge Base Builder
--  |  --------------------------------
--  |  Build a KNOWLEDGE BASE by processing documents with
--  |  multiple brains and storing the extracted knowledge.
--  |  Each document adds to the brain's understanding.
--  |
--  |  NEW CONCEPTS: Knowledge base, Incremental learning
--  |
--  |  XP TIP: Knowledge bases are BUILT OVER TIME. Start
--  |  with 10-20 documents and add more as you go. Each
--  |  new document makes the brain SMARTER!
--  ====================================================================

uses ai-brain, SysUtils;

var
  TextBrain: TTextFileAIBrain;
  Result: TAIBrainResult;
  KnowledgeDocs: array[0..4] of string;
  AllKeywords: array[0..4] of TAIBrainResult;
  i, TotalKeywords: integer;

begin
  WriteLn('=== Combined AI Brain: Knowledge Base Builder ===');
  WriteLn('');

  TextBrain := CreateTextFileAIBrain(0.001, 32, 200);

  if TextBrain = nil then
  begin
    WriteLn('ERROR: Could not create Knowledge Base Brain.');
    exit;
  end;

  --  Documents to add to the knowledge base.
  KnowledgeDocs[0] := 'company_history.txt';
  KnowledgeDocs[1] := 'product_catalog.txt';
  KnowledgeDocs[2] := 'technical_manual.txt';
  KnowledgeDocs[3] := 'faq_common_questions.txt';
  KnowledgeDocs[4] := 'research_findings.txt';

  WriteLn('Building Knowledge Base from ', Length(KnowledgeDocs), ' documents...');
  WriteLn('');

  for i := 0 to 4 do
  begin
    write('Processing [', i + 1, '/5]: ', KnowledgeDocs[i], '... ');

    Result := TextBrain.ProcessDocument(KnowledgeDocs[i]);

    if Result.Success then
    begin
      WriteLn('ADDED to knowledge base.');
      AllKeywords[i] := Result;

      --  Show what was learned from this document.
      WriteLn('  Learned: ', Result.Keywords[0], ', ', Result.Keywords[1], ', ', Result.Keywords[2]);
      WriteLn('  Confidence: ', (Result.Confidence * 100):0:1, '%');
      WriteLn('  Summary: ', Copy(Result.Summary, 1, 150));
    end
    else
    begin
      WriteLn('FAILED to process.');
      WriteLn('  Error: ', Result.ErrorMessage);
    end;
    WriteLn('');
  end;

  --  Show knowledge base statistics.
  WriteLn('=== Knowledge Base Statistics ===');
  WriteLn('');
  WriteLn('Documents processed: ', Length(KnowledgeDocs));

  TotalKeywords := 0;
  for i := 0 to 4 do
    if AllKeywords[i].Success then
      TotalKeywords := TotalKeywords + Length(AllKeywords[i].Keywords);

  WriteLn('Total keywords extracted: ~', TotalKeywords);
  WriteLn('Knowledge categories: company, products, technical, FAQ, research');
  WriteLn('');
  WriteLn('The knowledge base is ready for QUERYING!');

  TextBrain.Free;

  WriteLn('');
  WriteLn('-- end of Lesson --');
end.
