program TextFileAIBrainBasic;

{$mode objfpc}{$H+}

uses
  SysUtils, ai-brain;

var
  TextBrain: TTextFileAIBrain;
  Result: TAIBrainResult;
begin
  WriteLn('=== text file AI Brain Basic Example ===');
  WriteLn;
  
  try
    // Create a Text File AI brain with default parameters
    TextBrain := CreateTextFileAIBrain(
      0.001,  // Learning rate
      32,     // Batch size
      100     // Max epochs
    );
    
    WriteLn('Text File AI Brain created successfully.');
    WriteLn('Configuration:');
    WriteLn('  Learning Rate: 0.001');
    WriteLn('  Batch Size: 32');
    WriteLn('  Max Epochs: 100');
    WriteLn;
    
    // Process a text file (we'll create one first)
    WriteLn('Creating sample text file...');
    var SampleFile := TFileStream.Create('sample_text.txt', fmCreate);
    try
      var SampleText := 'This is a sample text file for testing the AI brain.' + #13#10 +
                       'It contains multiple lines of text to demonstrate' + #13#10 +
                       'the capabilities of the text processing AI brain.' + #13#10 +
                       'The AI brain will extract features from this text' + #13#10 +
                       'and process them through a neural network.';
      SampleFile.WriteBuffer(SampleText[1], Length(SampleText));
    finally
      SampleFile.Free;
    end;
    
    WriteLn('Processing document: sample_text.txt');
    Result := TextBrain.ProcessDocument('sample_text.txt');
    
    if Result.Success then
    begin
      WriteLn;
      WriteLn('Processing successful!');
      WriteLn('-------------------');
      WriteLn('Summary: ', Result.Summary);
      WriteLn('Confidence: ', Result.Confidence:0:3);
      WriteLn('Processing Time: ', Result.ProcessingTime:0:2, ' seconds');
      WriteLn;
      WriteLn('Extracted Text Preview:');
      WriteLn('-----------------------');
      if Length(Result.ExtractedText) > 100 then
        WriteLn(Copy(Result.ExtractedText, 1, 100) + '...')
      else
        WriteLn(Result.ExtractedText);
      WriteLn;
      WriteLn('Keywords: ');
      for var i := 0 to High(Result.Keywords) do
        WriteLn('  - ', Result.Keywords[i]);
    end
    else
    begin
      WriteLn;
      WriteLn('Processing failed!');
      WriteLn('Error: ', Result.ErrorMessage);
    end;
  except
    on E: Exception do
    begin
      WriteLn;
      WriteLn('Exception occurred: ', E.Message);
    end;
  end;
  
  // Clean up
  if Assigned(TextBrain) then
    TextBrain.Free;
    
  WriteLn;
  WriteLn('Example completed.');
end.