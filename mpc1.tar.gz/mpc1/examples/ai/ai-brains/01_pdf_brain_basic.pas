program PDFAIBrainBasic;

{$mode objfpc}{$H+}

uses
  SysUtils, ai-brain;

var
  PDFBrain: TPDFAIBrain;
  Result: TAIBrainResult;
begin
  WriteLn('=== PDF AI Brain Basic Example ===');
  WriteLn;
  
  try
    // Create a PDF AI brain with default parameters
    PDFBrain := CreatePDFAIBrain(
      0.001,  // Learning rate
      32,     // Batch size
      50      // Max epochs
    );
    
    WriteLn('PDF AI Brain created successfully.');
    WriteLn('Configuration:');
    WriteLn('  Learning Rate: 0.001');
    WriteLn('  Batch Size: 32');
    WriteLn('  Max Epochs: 50');
    WriteLn;
    
    // Process a PDF file (simulated)
    WriteLn('Processing document: sample_document.pdf');
    Result := PDFBrain.ProcessDocument('sample_document.pdf');
    
    if Result.Success then
    begin
      WriteLn;
      WriteLn('Processing successful!');
      WriteLn('-------------------');
      WriteLn('Summary: ', Result.Summary);
      WriteLn('Confidence: ', Result.Confidence:0:3);
      WriteLn('Processing Time: ', Result.ProcessingTime:0:2, ' seconds');
      WriteLn;
      WriteLn('Extracted Text Preview:');
      WriteLn('-----------------------');
      if Length(Result.ExtractedText) > 100 then
        WriteLn(Copy(Result.ExtractedText, 1, 100) + '...')
      else
        WriteLn(Result.ExtractedText);
      WriteLn;
      WriteLn('Keywords: ');
      for var i := 0 to High(Result.Keywords) do
        WriteLn('  - ', Result.Keywords[i]);
    end
    else
    begin
      WriteLn;
      WriteLn('Processing failed!');
      WriteLn('Error: ', Result.ErrorMessage);
    end;
  except
    on E: Exception do
    begin
      WriteLn;
      WriteLn('Exception occurred: ', E.Message);
    end;
  end;
  
  // Clean up
  if Assigned(PDFBrain) then
    PDFBrain.Free;
    
  WriteLn;
  WriteLn('Example completed.');
end.