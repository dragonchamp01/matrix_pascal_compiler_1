{ Matrix Pascal AI Brain Example — Array parsen
   json_parse_array.pas
   ════════════════════════════════════════════════════════════════
   NL: Array parsen — JSON arrays inlezen uit string
   EN: Parse array — read JSON arrays from string
}
program json_parse_array;
{$mode objfpc}{$H+}
uses
  SysUtils, Classes, json_support;

procedure ParseAndShowArray(const JsonStr: string; const Desc: string);
var
  Parser: TJSONParser;
  Val: TJSONValue;
  Arr: TJSONArray;
  I: integer;
  Item: TJSONValue;
begin
  WriteLn('Parsing: ', Desc);
  WriteLn('  Input: ', JsonStr);
  Parser := TJSONParser.Create(JsonStr);
  Val := Parser.Parse;

  if Val.ValueType = jvtArray then
  begin
    Arr := TJSONArray(Val);
    WriteLn(Format('  Count: %d', [Arr.Count]));
    for I := 0 to Arr.Count - 1 do
    begin
      Item := Arr.GetItem(I);
      write('  [' + IntToStr(I) + '] ');
      case Item.ValueType of
        jvtString:  WriteLn('string: "', Item.StringValue, '"');
        jvtNumber:  WriteLn('Number: ', Item.NumberValue:0:4);
        jvtBoolean: WriteLn('boolean: ', BoolToStr(Item.BoolValue, true));
        jvtNull:    WriteLn('Null');
        jvtObject:  WriteLn('object');
        jvtArray:   WriteLn('array');
      end;
    end;
  end
  else
    WriteLn('  ERROR: Expected array, got type ', Ord(Val.ValueType));

  Val.Free;
  Parser.Free;
  WriteLn;
end;

var
  Parser: TJSONParser;
  Val: TJSONValue;
  Arr: TJSONArray;
  I, J: integer;
  InnerArr: TJSONArray;
begin
  WriteLn('=== array parsen ===');
  WriteLn('=== Parse array ===');
  WriteLn;

  WriteLn('1. Parsing simple arrays:');
  WriteLn(StringOfChar('-', 60));

  ParseAndShowArray('[1, 2, 3, 4, 5]', 'integer array');
  ParseAndShowArray('["a", "b", "c"]', 'string array');
  ParseAndShowArray('[true, false, true]', 'boolean array');
  ParseAndShowArray('[null, 1, "text", false]', 'Mixed array');
  ParseAndShowArray('[]', 'Empty array');
  ParseAndShowArray('[[1,2],[3,4],[5,6]]', 'Nested array');
  ParseAndShowArray('[{"x":1},{"x":2},{"x":3}]', 'array of objects');

  WriteLn('2. Parsing array of objects and accessing properties:');
  WriteLn(StringOfChar('-', 60));
  Parser := TJSONParser.Create('[{"name":"Alice","age":30},{"name":"Bob","age":25},{"name":"Charlie","age":35}]');
  Val := Parser.Parse;
  if Val.ValueType = jvtArray then
  begin
    Arr := TJSONArray(Val);
    for I := 0 to Arr.Count - 1 do
    begin
      if Arr.GetItem(I).ValueType = jvtObject then
      begin
        WriteLn(Format('  Person %d: %s, age %.0f',
          [I + 1, TJSONObject(Arr.GetItem(I)).GetString('name'),
           TJSONObject(Arr.GetItem(I)).GetNumber('age')]));
      end;
    end;
  end;
  Val.Free;
  Parser.Free;

  WriteLn;
  WriteLn('3. Iterating nested arrays:');
  WriteLn(StringOfChar('-', 60));
  Parser := TJSONParser.Create('[[1,2,3],[4,5,6],[7,8,9]]');
  Val := Parser.Parse;
  if Val.ValueType = jvtArray then
  begin
    Arr := TJSONArray(Val);
    for I := 0 to Arr.Count - 1 do
    begin
      if Arr.GetItem(I).ValueType = jvtArray then
      begin
        InnerArr := TJSONArray(Arr.GetItem(I));
        write(Format('  Row %d: ', [I + 1]));
        for J := 0 to InnerArr.Count - 1 do
        begin
          if J > 0 then write(', ');
          write(Format('%.0f', [InnerArr.GetItem(J).NumberValue]));
        end;
        WriteLn;
      end;
    end;
  end;
  Val.Free;
  Parser.Free;

  WriteLn;
  WriteLn('array parse example completed.');
end.
