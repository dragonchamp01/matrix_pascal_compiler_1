{ Matrix Pascal AI Brain Example — Agent verwijderen
   swarm_remove.pas
   ════════════════════════════════════════════════════════════════
   NL: Demonstreert RemoveAgent — specifieke agents
   verwijderen uit de zwerm.
   EN: Demonstrates RemoveAgent — removing specific agents
   from the swarm.
   Gegeneerd door: marco
   Datum: 2026-05-28
}
program swarm_remove;
{$mode objfpc}{$H+}
uses
  SysUtils, Classes, swarm_agent;

var
  Swarm: TSwarmAgent;
  I: integer;
begin
  WriteLn;
  WriteLn('═══════════════════════════════════════════════');
  WriteLn('  Agent verwijderen / Remove Agent');
  WriteLn('═══════════════════════════════════════════════');
  WriteLn;

  Swarm := TSwarmAgent.Create('RemoveDemoSwarm');
  try
    Swarm.AddAgent('Analist1', asAnalysis);
    Swarm.AddAgent('Analist2', asAnalysis);
    Swarm.AddAgent('Generator1', asGenerate);
    Swarm.AddAgent('Generator2', asGenerate);
    Swarm.AddAgent('Codeur1', asCode);
    Swarm.AddAgent('Codeur2', asCode);
    Swarm.AddAgent('Criticus', asCritique);
    Swarm.AddAgent('Planner', asPlan);
    Swarm.AddAgent('Vertaler', asTranslate);
    Swarm.AddAgent('Onderzoeker', asResearch);

    WriteLn('Oorspronkelijke zwerm / Original swarm:');
    WriteLn(Format('  Totaal: %d agents', [Swarm.MemberCount]));
    WriteLn;

    for I := 0 to Swarm.MemberCount - 1 do
      WriteLn(Format('  [%d] %s', [I + 1, Swarm.Members[I].name]));
    WriteLn;

    WriteLn('Verwijderen stap 1: RemoveAgent("Generator2")');
    Swarm.RemoveAgent('Generator2');
    WriteLn(Format('  Resterend: %d agents', [Swarm.MemberCount]));
    WriteLn;

    WriteLn('Verwijderen stap 2: RemoveAgent("Criticus")');
    Swarm.RemoveAgent('Criticus');
    WriteLn(Format('  Resterend: %d agents', [Swarm.MemberCount]));
    WriteLn;

    WriteLn('Verwijderen stap 3: RemoveAgent("NietBestaand")');
    Swarm.RemoveAgent('NietBestaand');
    WriteLn('  Geen effect (agent bestaat niet)');
    WriteLn(Format('  Resterend: %d agents', [Swarm.MemberCount]));
    WriteLn;

    WriteLn('Huidige zwerm / Current swarm:');
    for I := 0 to Swarm.MemberCount - 1 do
      WriteLn(Format('  [%d] %s', [I + 1, Swarm.Members[I].name]));
    WriteLn;

    WriteLn('Verwijderen stap 4: dubbele verwijdering');
    Swarm.RemoveAgent('Analist1');
    Swarm.RemoveAgent('Analist2');
    WriteLn('  Analist1 en Analist2 verwijderd');
    WriteLn(Format('  Resterend: %d agents', [Swarm.MemberCount]));
    WriteLn;

    for I := 0 to Swarm.MemberCount - 1 do
      WriteLn(Format('  [%d] %s', [I + 1, Swarm.Members[I].name]));
    WriteLn;

    WriteLn('Remove demo voltooid / Remove demo completed.');
  finally
    Swarm.Free;
  end;
  WriteLn;
  write('Druk op Enter om af te sluiten / Press Enter to exit...');
  ReadLn;
end.
