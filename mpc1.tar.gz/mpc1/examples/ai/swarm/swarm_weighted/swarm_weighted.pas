{ Matrix Pascal AI Brain Example — Gewogen samenvoeging
   swarm_weighted.pas
   ════════════════════════════════════════════════════════════════
   NL: Demonstreert WeightedMerge — resultaten worden
   samengevoegd met gewichten op basis van confidence.
   EN: Demonstrates WeightedMerge — results are merged
   with weights based on confidence.
   Gegeneerd door: marco
   Datum: 2026-05-28
}
program swarm_weighted;
{$mode objfpc}{$H+}
uses
  SysUtils, Classes, swarm_agent;

var
  Swarm: TSwarmAgent;
  Resultaat: string;
  I: integer;
begin
  WriteLn;
  WriteLn('═══════════════════════════════════════════════');
  WriteLn('  Gewogen samenvoeging / Weighted Merge');
  WriteLn('═══════════════════════════════════════════════');
  WriteLn;

  Swarm := TSwarmAgent.Create('WeightedSwarm');
  try
    Swarm.AddAgent('HoogBetrouwbaar', asAnalysis);
    Swarm.AddAgent('MiddenBetrouwbaar', asAnalysis);
    Swarm.AddAgent('LaagBetrouwbaar', asAnalysis);
    Swarm.AddAgent('ExpertAdviseur', asAnalysis);
    Swarm.AddAgent('BasisAnalist', asAnalysis);

    Swarm.Members[0].Confidence := 0.99;
    Swarm.Members[1].Confidence := 0.70;
    Swarm.Members[2].Confidence := 0.30;
    Swarm.Members[3].Confidence := 0.95;
    Swarm.Members[4].Confidence := 0.50;

    Swarm.VoteThreshold := 1.50;

    WriteLn('WeightedMerge configuratie:');
    WriteLn('  VoteThreshold > 1.0 = altijd WeightedMerge');
    WriteLn;

    WriteLn('Agent gewichten / Agent weights:');
    WriteLn;
    for I := 0 to Swarm.MemberCount - 1 do
    begin
      WriteLn(Format('  %-20s | Confidence: %.2f | Relatief gewicht: %.1f%%',
        [Swarm.Members[I].name,
         Swarm.Members[I].Confidence,
         (Swarm.Members[I].Confidence / 3.44) * 100]));
    end;
    WriteLn;

    WriteLn('Taak 1: Eerste gewogen analyse');
    WriteLn('  "Wat is de verwachte omzetgroei?"');
    WriteLn;
    Resultaat := Swarm.ProcessTask('Wat is de verwachte omzetgroei?');
    WriteLn('  ' + Resultaat);
    WriteLn;

    WriteLn('Taak 2: Confidence aanpassen en opnieuw');
    Swarm.Members[0].Confidence := 0.50;
    Swarm.Members[4].Confidence := 0.98;
    WriteLn('  HoogBetrouwbaar -> 0.50, BasisAnalist -> 0.98');
    WriteLn;

    Resultaat := Swarm.ProcessTask('Wat is de verwachte omzetgroei? (na wijziging)');
    WriteLn('  ' + Resultaat);
    WriteLn;

    WriteLn('Voordeel van WeightedMerge:');
    WriteLn('  - Expert agents wegen zwaarder');
    WriteLn('  - Onbetrouwbare agents hebben minder invloed');
    WriteLn('  - Geen harde consensus nodig');
    WriteLn;

    WriteLn('Weighted demo voltooid / Weighted demo completed.');
  finally
    Swarm.Free;
  end;
  WriteLn;
  write('Druk op Enter om af te sluiten / Press Enter to exit...');
  ReadLn;
end.
