# Keyword Voorbeelden / Keyword Examples

**NL:** Deze voorbeelden demonstreren het beheren van trefwoorden via `TKeywordEngine`. Leer hoe je keywords toevoegt, groepeert, classificeert, filtert, normaliseert en tekst analyseert op trefwoordgebruik.

**EN:** These examples demonstrate managing keywords via `TKeywordEngine`. Learn how to add, group, classify, filter, normalize keywords and analyze text for keyword usage.

## Vereisten / Prerequisites

- Matrix Pascal compiler (`matrix_pascal_c`)
- RTL units: `keyword_engine`, `SysUtils`, `Classes`

## Compileren / Compiling

```bash
matrix_pascal_c --source voorbeeld/pad/naar/voorbeeld.pas -o uitvoerbaar
./uitvoerbaar
```

## Voorbeelden / Examples

| Bestand / File | Beschrijving (NL) | Description (EN) | RTL Units |
|----------------|-------------------|-------------------|-----------|
| `key_add/key_add.pas` | Voeg keywords toe en groepeer ze | Add keywords and group them | `keyword_engine`, `SysUtils`, `Classes` |
| `key_find/key_find.pas` | Vind keywords in tekst | Find keywords in text | `keyword_engine`, `SysUtils`, `Classes` |
| `key_remove/key_remove.pas` | Verwijder keywords | Remove keywords | `keyword_engine`, `SysUtils`, `Classes` |
| `key_group/key_group.pas` | Groepeer keywords in categorieën | Group keywords into categories | `keyword_engine`, `SysUtils`, `Classes` |
| `key_groups/key_groups.pas` | Toon alle groepen en hun keywords | Show all groups and their keywords | `keyword_engine`, `SysUtils`, `Classes` |
| `key_multi_group/key_multi_group.pas` | Keywords in meerdere groepen | Keywords in multiple groups | `keyword_engine`, `SysUtils`, `Classes` |
| `key_classify/key_classify.pas` | Classificeer tekst op basis van keywords | Classify text based on keywords | `keyword_engine`, `SysUtils`, `Classes` |
| `key_auto_classify/key_auto_classify.pas` | Automatische classificatie van tekst | Automatic text classification | `keyword_engine`, `SysUtils`, `Classes` |
| `key_batch/key_batch.pas` | Batch-verwerking van keywords | Batch processing of keywords | `keyword_engine`, `SysUtils`, `Classes` |
| `key_extract/key_extract.pas` | Extraheer keywords uit tekst | Extract keywords from text | `keyword_engine`, `SysUtils`, `Classes` |
| `key_filter/key_filter.pas` | Filter keywords op criteria | Filter keywords by criteria | `keyword_engine`, `SysUtils`, `Classes` |
| `key_normalize/key_normalize.pas` | Normaliseer keyword-tekst | Normalize keyword text | `keyword_engine`, `SysUtils`, `Classes` |
| `key_stopword/key_stopword.pas` | Verwijder stopwoorden uit tekst | Remove stopwords from text | `keyword_engine`, `SysUtils`, `Classes` |
| `key_synonym/key_synonym.pas` | Beheer synoniemen voor keywords | Manage synonyms for keywords | `keyword_engine`, `SysUtils`, `Classes` |
| `key_context/key_context.pas` | Context-gebaseerde keyword analyse | Context-based keyword analysis | `keyword_engine`, `SysUtils`, `Classes` |
| `key_dominant/key_dominant.pas` | Vind dominante keywords in tekst | Find dominant keywords in text | `keyword_engine`, `SysUtils`, `Classes` |
| `key_event/key_event.pas` | Koppel keywords aan gebeurtenissen | Associate keywords with events | `keyword_engine`, `SysUtils`, `Classes` |
| `key_events_group/key_events_group.pas` | Groepeer gebeurtenissen per keyword | Group events by keyword | `keyword_engine`, `SysUtils`, `Classes` |
| `key_group_summary/key_group_summary.pas` | Samenvatting per keyword-groep | Summary per keyword group | `keyword_engine`, `SysUtils`, `Classes` |
| `key_threshold/key_threshold.pas` | Stel drempelwaarden in voor keywords | Set threshold values for keywords | `keyword_engine`, `SysUtils`, `Classes` |
| `key_report/key_report.pas` | Genereer keyword-rapport | Generate keyword report | `keyword_engine`, `SysUtils`, `Classes` |
| `key_export/key_export.pas` | Exporteer keywords naar JSON/XML | Export keywords to JSON/XML | `keyword_engine`, `json_support`, `SysUtils` |
| `key_import/key_import.pas` | Importeer keywords uit JSON/XML | Import keywords from JSON/XML | `keyword_engine`, `json_support`, `SysUtils` |
| `key_learning/key_learning.pas` | Leer nieuwe keywords automatisch | Auto-learn new keywords | `keyword_engine`, `SysUtils`, `Classes` |
| `key_text_analysis/key_text_analysis.pas` | Volledige tekstanalyse met keywords | Full text analysis with keywords | `keyword_engine`, `SysUtils`, `Classes` |
| `key_combine/key_combine.pas` | Combineer keywords voor zoekopdrachten | Combine keywords for searches | `keyword_engine`, `SysUtils`, `Classes` |
| `key_custom/key_custom.pas` | Aangepaste keyword-regels | Custom keyword rules | `keyword_engine`, `SysUtils`, `Classes` |
| `key_resolve/key_resolve.pas` | Los conflicten tussen keywords op | Resolve conflicts between keywords | `keyword_engine`, `SysUtils`, `Classes` |
| `key_recent/key_recent.pas` | Toon recent toegevoegde keywords | Show recently added keywords | `keyword_engine`, `SysUtils`, `Classes` |
| `key_visualize/key_visualize.pas` | Visualiseer keyword-relaties | Visualize keyword relationships | `keyword_engine`, `SysUtils`, `Classes` |

## Aan de slag / Getting Started

Begin met `key_add/key_add.pas` — voeg keywords toe en groepeer ze. Daarna probeer je `key_classify/key_classify.pas` om tekst te classificeren en `key_extract/key_extract.pas` om keywords te extraheren.

Start with `key_add/key_add.pas` — add keywords and group them. Then try `key_classify/key_classify.pas` to classify text and `key_extract/key_extract.pas` to extract keywords.

## Auteur / Author

Copyright (c) 2026 Graeme Geldenhuys. Alle rechten voorbehouden / All rights reserved.
