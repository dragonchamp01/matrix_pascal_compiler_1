{ Matrix Pascal AI Brain Example — Gebeurtenis toevoegen
   key_event.pas
   ════════════════════════════════════════════════════════════════
   NL: Voeg gebeurtenissen toe aan groepen in de engine
   EN: Add events to groups in the engine
}
program key_event;
{$mode objfpc}{$H+}
uses
  SysUtils, Classes, keyword_engine;

procedure PrintHeader(const Title: string);
begin
  WriteLn;
  WriteLn('=== ', Title, ' ===');
  WriteLn;
end;

var
  KE: TKeywordEngine;
  Events: TStringList;
  I: integer;
begin
  PrintHeader('Gebeurtenis toevoegen / Add event');
  KE := TKeywordEngine.Create;
  try
    KE.AddEvent('User logged in', 'security');
    KE.AddEvent('Password changed', 'security');
    KE.AddEvent('file uploaded', 'files');
    KE.AddEvent('file deleted', 'files');
    KE.AddEvent('Backup started', 'system');
    KE.AddEvent('Backup completed', 'system');
    KE.AddEvent('Error: disk full', 'errors');
    KE.AddEvent('Error: permission denied', 'errors');
    KE.AddEvent('CPU usage high', 'performance');
    KE.AddEvent('Memory low', 'performance');
    KE.AddEvent('network timeout', 'network');
    KE.AddEvent('DNS resolution failed', 'network');

    WriteLn('Alle gebeurtenissen / All events:');
    Events := KE.GetRecentEvents(100);
    try
      for I := 0 to Events.Count - 1 do
        WriteLn('  ', Events[I]);
    finally
      Events.Free;
    end;

    WriteLn;
    WriteLn('Gebeurtenissen in groep "errors":');
    Events := KE.GetEventsByGroup('errors');
    try
      for I := 0 to Events.Count - 1 do
        WriteLn('  ', Events[I]);
    finally
      Events.Free;
    end;

    WriteLn;
    WriteLn('Meest recente gebeurtenissen / Recent events (3):');
    Events := KE.GetRecentEvents(3);
    try
      for I := 0 to Events.Count - 1 do
        WriteLn('  ', Events[I]);
    finally
      Events.Free;
    end;

    WriteLn;
    WriteLn('Events in groep "system":');
    Events := KE.GetEventsByGroup('system');
    try
      for I := 0 to Events.Count - 1 do
        WriteLn('  ', Events[I]);
    finally
      Events.Free;
    end;
  finally
    KE.Free;
  end;
  WriteLn;
  WriteLn('Status: Success');
  ReadLn;
end.
