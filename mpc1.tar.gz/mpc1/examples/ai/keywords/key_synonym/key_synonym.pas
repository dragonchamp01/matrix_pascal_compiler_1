{ Matrix Pascal AI Brain Example — Synoniem toevoegen
   key_synonym.pas
   ════════════════════════════════════════════════════════════════
   NL: Voeg synoniemen toe en groepeer onder hoofdtrefwoord
   EN: Add synonyms and group under a main keyword
}
program key_synonym;
{$mode objfpc}{$H+}
uses
  SysUtils, Classes, keyword_engine;

procedure PrintHeader(const Title: string);
begin
  WriteLn;
  WriteLn('=== ', Title, ' ===');
  WriteLn;
end;

var
  KE: TKeywordEngine;
  I: integer;
begin
  PrintHeader('Synoniem toevoegen / Add synonym');
  KE := TKeywordEngine.Create;
  try
    KE.AddSynonym('quick', 'fast');
    KE.AddSynonym('swift', 'fast');
    KE.AddSynonym('rapid', 'fast');
    KE.AddSynonym('speedy', 'fast');
    KE.AddSynonym('big', 'large');
    KE.AddSynonym('huge', 'large');
    KE.AddSynonym('enormous', 'large');
    KE.AddSynonym('massive', 'large');
    KE.AddSynonym('gigantic', 'large');
    KE.AddSynonym('happy', 'glad');
    KE.AddSynonym('cheerful', 'glad');
    KE.AddSynonym('delighted', 'glad');
    KE.AddSynonym('joyful', 'glad');
    KE.AddSynonym('pleased', 'glad');
    KE.AddSynonym('sad', 'unhappy');
    KE.AddSynonym('miserable', 'unhappy');
    KE.AddSynonym('depressed', 'unhappy');
    KE.AddSynonym('gloomy', 'unhappy');

    WriteLn('Synoniem mapping / Synonym mapping:');
    WriteLn;
    WriteLn('  quick  -> ', KE.ResolveSynonym('quick'));
    WriteLn('  swift  -> ', KE.ResolveSynonym('swift'));
    WriteLn('  rapid  -> ', KE.ResolveSynonym('rapid'));
    WriteLn('  big    -> ', KE.ResolveSynonym('big'));
    WriteLn('  huge   -> ', KE.ResolveSynonym('huge'));
    WriteLn('  happy  -> ', KE.ResolveSynonym('happy'));
    WriteLn('  joyful -> ', KE.ResolveSynonym('joyful'));
    WriteLn('  sad    -> ', KE.ResolveSynonym('sad'));
    WriteLn('  gloomy -> ', KE.ResolveSynonym('gloomy'));

    WriteLn;
    WriteLn('Synoniemen groeperen meerdere woorden onder 1 concept.');
    WriteLn;
    WriteLn('Test met onbekend woord (valt terug op zichzelf):');
    WriteLn('  "unknown"       -> ', KE.ResolveSynonym('unknown'));
    WriteLn('  "fantastic"     -> ', KE.ResolveSynonym('fantastic'));
    WriteLn('  "terrible"      -> ', KE.ResolveSynonym('terrible'));

    WriteLn;
    WriteLn('Alle unieke hoofdtrefwoorden / All unique root keywords:');
    WriteLn('  fast, large, glad, unhappy');

    WriteLn;
    WriteLn('Synoniem mapping helpt bij zoeken / Synonym helps searching:');
    WriteLn('  ResolveSynonym wordt gebruikt om variaties te normaliseren');
    WriteLn('  naar een enkel hoofdtrefwoord voor consistente matching.');
    WriteLn('  Dit is essentieel voor natuurlijke taalverwerking.');
  finally
    KE.Free;
  end;
  WriteLn;
  WriteLn('Status: Success');
  ReadLn;
end.
