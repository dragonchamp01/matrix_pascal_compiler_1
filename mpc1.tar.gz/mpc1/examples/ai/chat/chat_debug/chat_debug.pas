{ Matrix Pascal AI Brain Example — Debug informatie
   chat_debug.pas
   ════════════════════════════════════════════════════════════════
   NL: Toon debug informatie van de chat interface
   EN: Display debug information of the chat interface
}
program chat_debug;
{$mode objfpc}{$H+}
uses
  SysUtils, Classes, chat_interface;

var
  Chat: TChatInterface;
  Hist: TStringList;
  I, J: integer;
begin
  WriteLn('=== Debug informatie / Debug information ===');
  WriteLn;

  Chat := TChatInterface.Create('marco', 'marco neo');

  Chat.CreateSession('Debug A', 'debug_a');
  Chat.CreateSession('Debug B', 'debug_b');
  Chat.CreateSession('Debug C', 'debug_c');

  Chat.SendMessage('debug_a', 'Debug bericht A1');
  Chat.SendMessage('debug_a', 'Debug bericht A2');
  Chat.SendMessage('debug_b', 'Debug bericht B1');

  WriteLn('=== DEBUG INFO ===');
  WriteLn;
  WriteLn('Gebruiker: ' + Chat.UserName);
  WriteLn('Baas: ' + Chat.BossName);
  WriteLn('IsBoss: ' + BoolToStr(Chat.IsBoss(Chat.UserName), true));
  WriteLn('Actieve sessie: ' + Chat.ActiveSessionID);
  WriteLn('Sessie count: ' + IntToStr(Chat.SessionCount));
  WriteLn('Totaal berichten: ' + IntToStr(Chat.TotalMessages));
  WriteLn;

  for I := 0 to Chat.SessionCount - 1 do
  begin
    WriteLn('--- Sessie ' + IntToStr(I) + ' ---');
    Hist := Chat.GetHistory(Chat.ActiveSessionID);
    if I = 0 then
    begin
      Hist := Chat.GetHistory('debug_a');
      WriteLn('  ID: debug_a');
      WriteLn('  Berichten: ' + IntToStr(Hist.Count));
      for J := 0 to Hist.Count - 1 do
        WriteLn('    [' + IntToStr(J) + '] ' + Hist[J]);
    end;
    Hist.Free;
  end;

  WriteLn;
  WriteLn('Sessie "debug_b" details:');
  Hist := Chat.GetHistory('debug_b');
  WriteLn('  Berichten: ' + IntToStr(Hist.Count));
  for J := 0 to Hist.Count - 1 do
    WriteLn('    [' + IntToStr(J) + '] ' + Hist[J]);
  Hist.Free;

  WriteLn;
  WriteLn('Poging tot schakelen naar niet-bestaande sessie:');
  if Chat.SwitchSession('niet_bestaand') then
    WriteLn('  Gelukt (onverwacht)')
  else
    WriteLn('  Mislukt (verwacht)');

  WriteLn;
  WriteLn('Debug van TotalMessages: ' + IntToStr(Chat.TotalMessages));
  WriteLn('Debug van SessionCount: ' + IntToStr(Chat.SessionCount));
  WriteLn('Gebruiker: ' + Chat.UserName + ', Baas: ' + Chat.BossName);

  WriteLn;
  WriteLn('Debug sessie afgerond.');
  WriteLn('  Totaal gesessies: ' + IntToStr(Chat.SessionCount));
  WriteLn('  Totaal berichten: ' + IntToStr(Chat.TotalMessages));

  Chat.Free;
  WriteLn;
  WriteLn('Voorbeeld voltooid / Example completed.');
  ReadLn;
end.
