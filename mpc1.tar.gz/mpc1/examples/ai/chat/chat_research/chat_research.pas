{ Matrix Pascal AI Brain Example — Research modus
   chat_research.pas
   ════════════════════════════════════════════════════════════════
   NL: Gebruik chat voor research en informatie
   EN: Use chat for research and information gathering
}
program chat_research;
{$mode objfpc}{$H+}
uses
  SysUtils, Classes, chat_interface;

var
  Chat: TChatInterface;
  I: integer;
  Reply: string;
  Hist: TStringList;
begin
  WriteLn('=== Research modus / Research mode ===');
  WriteLn;

  Chat := TChatInterface.Create('marco', 'marco neo');

  Chat.CreateSession('Research', 'research_sess');
  Chat.SwitchSession('research_sess');

  Reply := Chat.Chat('Wat is de hoofdstad van Frankrijk?');
  WriteLn('Vraag 1: ' + Reply);

  Reply := Chat.Chat('Wat is de bevolking van Nederland?');
  WriteLn('Vraag 2: ' + Reply);

  Reply := Chat.Chat('Wie schreef "De ontdekking van de hemel"?');
  WriteLn('Vraag 3: ' + Reply);

  Chat.SendMessageAs('research_sess',
    'Bron: Wikipedia, Encyclopedie', 'system');

  Reply := Chat.Chat('Kun je een samenvatting geven van het onderzoek?');
  WriteLn('Vraag 4: ' + Reply);

  Reply := Chat.Chat('Welke bronnen heb je gebruikt?');
  WriteLn('Vraag 5: ' + Reply);

  WriteLn;
  WriteLn('Research sessie geschiedenis:');
  Hist := Chat.GetHistory('research_sess');
  for I := 0 to Hist.Count - 1 do
    WriteLn('  ' + Hist[I]);
  Hist.Free;

  WriteLn;
  WriteLn('Verdere research vragen:');
  Reply := Chat.SendMessage('research_sess', 'Wat is de betekenis van leven?');
  WriteLn('Vraag 6: ' + Reply);

  Reply := Chat.SendMessage('research_sess', 'Hoe werkt quantum computing?');
  WriteLn('Vraag 7: ' + Reply);

  Reply := Chat.SendMessage('research_sess', 'Wat is de snelste manier om te leren?');
  WriteLn('Vraag 8: ' + Reply);

  WriteLn;
  WriteLn('Totaal research berichten: ' + IntToStr(Chat.TotalMessages));
  WriteLn('Zoek naar "quantum" in research sessie:');
  Hist := Chat.SearchHistory('research_sess', 'quantum');
  WriteLn('  ' + IntToStr(Hist.Count) + ' resultaten');
  Hist.Free;

  Chat.Free;
  WriteLn;
  WriteLn('Research samenvatting:');
  WriteLn('  Aantal vragen: ' + IntToStr(Chat.TotalMessages));
  WriteLn('  Onderwerpen: algemene kennis, wetenschap, literatuur');

  Hist := Chat.GetHistory('research_sess');
  WriteLn;
  WriteLn('Alle research bevindingen:');
  for I := 0 to Hist.Count - 1 do
    WriteLn('  ' + Hist[I]);
  Hist.Free;

  WriteLn;
  WriteLn('Eindstatistieken:');
  WriteLn('  Sessies: ' + IntToStr(Chat.SessionCount));
  WriteLn('  Berichten: ' + IntToStr(Chat.TotalMessages));

  Chat.Free;
  WriteLn;
  WriteLn('Voorbeeld voltooid / Example completed.');
  ReadLn;
end.
