program AgentIntention;

uses
  SysUtils, Math;

var
  i: integer;
  vals: array[1..5] of real;

begin
  WriteLn('=== Swarm Intelligence and Multi-Agent AI ===');
  WriteLn('file: agent_intention.pas');
  WriteLn('program: AgentIntention');
  WriteLn;
  WriteLn('This example demonstrates AgentIntention functionality.');
  WriteLn;
  WriteLn('Computations and demonstrations:');
  for i := 1 to 5 do
  begin
    vals[i] := i * Pi / 4.0;
    WriteLn('  val[', i, '] = ', vals[i]:0:4, '  sin = ', Sin(vals[i]):0:4, '  cos = ', Cos(vals[i]):0:4);
  end;
  WriteLn;
  WriteLn('Example completed successfully.');
end.
