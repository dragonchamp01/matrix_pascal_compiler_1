{$mode objfpc}{$H+}
program service_dhcp;

uses
  System, SysUtils, Classes, sockets, threading, logger;

type
  TDhcpLease = record
    MAC: string;
    IP: string;
    Hostname: string;
    Expires: TDateTime;
  end;

  TDhcpServer = class(TThread)
  private
    FPort: word;
    FPoolStart: string;
    FPoolEnd: string;
    FSubnet: string;
    FGateway: string;
    FDnsServers: TStringList;
    FLeases: array of TDhcpLease;
    FLogger: TLogger;
    function PoolToInt(const IP: string): longword;
    function IntToPool(Value: longword): string;
    function GetAvailableIP: string;
    function FindLease(const MAC: string): integer;
  protected
    procedure Execute; override;
  public
    constructor Create(const APoolStart, APoolEnd, ASubnet, AGateway: string);
    destructor Destroy; override;
  end;

constructor TDhcpServer.Create(const APoolStart, APoolEnd, ASubnet, AGateway: string);
begin
  inherited Create('DHCPServer');
  FPort := 67;
  FPoolStart := APoolStart;
  FPoolEnd := APoolEnd;
  FSubnet := ASubnet;
  FGateway := AGateway;
  FDnsServers := TStringList.Create;
  FDnsServers.Add('8.8.8.8');
  FDnsServers.Add('8.8.4.4');
  FLogger := TLogger.Create('dhcpd', llInfo, ltBoth, '/var/log/dhcpd.log');
end;

destructor TDhcpServer.Destroy;
begin
  FDnsServers.Free;
  FLogger.Free;
  inherited Destroy;
end;

function TDhcpServer.PoolToInt(const IP: string): longword;
var
  Parts: TStringArray;
begin
  Parts := IP.Split('.');
  Result := (StrToIntDef(Parts[0], 0) shl 24) or
            (StrToIntDef(Parts[1], 0) shl 16) or
            (StrToIntDef(Parts[2], 0) shl 8) or
            StrToIntDef(Parts[3], 0);
end;

function TDhcpServer.IntToPool(Value: longword): string;
begin
  Result := Format('%d.%d.%d.%d', [
    (Value shr 24) and $FF,
    (Value shr 16) and $FF,
    (Value shr 8) and $FF,
    Value and $FF]);
end;

function TDhcpServer.GetAvailableIP: string;
var
  StartIP, EndIP: longword;
  I, J: longword;
  Found: boolean;
begin
  Result := '';
  StartIP := PoolToInt(FPoolStart);
  EndIP := PoolToInt(FPoolEnd);
  for I := StartIP to EndIP do
  begin
    Found := false;
    for J := 0 to Length(FLeases) - 1 do
    begin
      if PoolToInt(FLeases[J].IP) = I then
      begin
        Found := true;
        break;
      end;
    end;
    if not Found then
    begin
      Result := IntToPool(I);
      exit;
    end;
  end;
end;

function TDhcpServer.FindLease(const MAC: string): integer;
var
  I: integer;
begin
  for I := 0 to Length(FLeases) - 1 do
    if FLeases[I].MAC = MAC then
      exit(I);
  Result := -1;
end;

procedure TDhcpServer.Execute;
var
  UDP: TSocket;
  Buf: array[0..1023] of byte;
  Len: integer;
  ClientMAC: string;
  ClientIP: string;
  Idx: integer;
begin
  FLogger.Info('DHCP server starting on port 67');
  FLogger.Info(Format('pool: %s - %s', [FPoolStart, FPoolEnd]));
  UDP := TSocket.Create(sockets._NetCreate(AF_INET, SOCK_DGRAM, 17));
  if UDP.Handle < 0 then
  begin
    FLogger.Error('Failed to create DHCP socket');
    exit;
  end;
  if sockets._NetBind(UDP.Handle, 0, 67) < 0 then
  begin
    FLogger.Error('Failed to bind to port 67');
    UDP.Free;
    exit;
  end;
  while not Terminated do
  begin
    Len := UDP.Recv(Buf, SizeOf(Buf));
    if Len > 0 then
    begin
      ClientMAC := Format('%.2x:%.2x:%.2x:%.2x:%.2x:%.2x',
        [Buf[28], Buf[29], Buf[30], Buf[31], Buf[32], Buf[33]]);
      Idx := FindLease(ClientMAC);
      if Idx >= 0 then
        ClientIP := FLeases[Idx].IP
      else
      begin
        ClientIP := GetAvailableIP;
        if ClientIP = '' then
        begin
          FLogger.Error('No available IP addresses');
          continue;
        end;
        SetLength(FLeases, Length(FLeases) + 1);
        FLeases[Length(FLeases) - 1].MAC := ClientMAC;
        FLeases[Length(FLeases) - 1].IP := ClientIP;
        FLeases[Length(FLeases) - 1].Expires := Now + 1;
      end;
      FLogger.Info(Format('DHCP offer: %s -> %s', [ClientMAC, ClientIP]));
    end;
    Sleep(100);
  end;
  UDP.Free;
  FLogger.Info('DHCP server stopped');
end;

var
  Dhcp: TDhcpServer;
begin
  Dhcp := TDhcpServer.Create('192.168.1.100', '192.168.1.200',
    '255.255.255.0', '192.168.1.1');
  Dhcp.Start;
  Dhcp.WaitFor;
  Dhcp.Free;
end.
