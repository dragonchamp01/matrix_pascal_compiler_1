{$mode objfpc}{$H+}
program service_dns;

uses
  System, SysUtils, Classes, sockets, threading, logger;

type
  TDnsResolver = class
  private
    FDnsServers: TStringList;
    FLogger: TLogger;
    function ResolveUDP(const Hostname: string): string;
  public
    constructor Create;
    destructor Destroy; override;
    function Resolve(const Hostname: string): string;
    function ReverseLookup(const IP: string): string;
    procedure AddDnsServer(const Server: string);
  end;

  TDnsQuery = record
    ID: word;
    QR: boolean;
    Opcode: byte;
    Questions: array of string;
  end;

constructor TDnsResolver.Create;
begin
  FDnsServers := TStringList.Create;
  FDnsServers.Add('8.8.8.8');
  FDnsServers.Add('1.1.1.1');
  FLogger := TLogger.Create('dns-resolver', llInfo, ltConsole);
end;

destructor TDnsResolver.Destroy;
begin
  FDnsServers.Free;
  FLogger.Free;
  inherited Destroy;
end;

procedure TDnsResolver.AddDnsServer(const Server: string);
begin
  FDnsServers.Add(Server);
  FLogger.Info(Format('Added DNS server: %s', [Server]));
end;

function TDnsResolver.ResolveUDP(const Hostname: string): string;
var
  Sock: TSocket;
  addr: cardinal;
  Port: word;
  Buf: array[0..511] of byte;
  Len: integer;
  I: integer;
  Resp: string;
begin
  Result := '';
  Sock := TSocket.Create(sockets._NetCreate(AF_INET, SOCK_DGRAM, 17));
  if Sock.Handle < 0 then exit;

  addr := StrToIntDef(FDnsServers[0], 0);
  Port := 53;

  FillChar(Buf, SizeOf(Buf), 0);
  Buf[0] := $AA; Buf[1] := $AA;
  Buf[2] := $01; Buf[3] := $00;
  Buf[4] := $00; Buf[5] := $01;
  Buf[6] := $00; Buf[7] := $00;
  Buf[8] := $00; Buf[9] := $00;
  Buf[10] := $00; Buf[11] := $00;

  Len := 12;
  var Parts: TStringArray;
  Parts := Hostname.Split('.');
  for I := 0 to Length(Parts) - 1 do
  begin
    Buf[Len] := Length(Parts[I]);
    Inc(Len);
    Move(Parts[I][1], Buf[Len], Length(Parts[I]));
    Inc(Len, Length(Parts[I]));
  end;
  Buf[Len] := 0; Inc(Len);
  Buf[Len] := 0; Buf[Len+1] := 1;
  Buf[Len+2] := 0; Buf[Len+3] := 1;
  Inc(Len, 4);

  Sock.Send(Buf, Len);
  Len := Sock.Recv(Buf, SizeOf(Buf));
  if Len > 12 then
    Result := Format('%d.%d.%d.%d', [Buf[Len-4], Buf[Len-3], Buf[Len-2], Buf[Len-1]]);
  Sock.Free;
end;

function TDnsResolver.Resolve(const Hostname: string): string;
begin
  FLogger.Info(Format('Resolving: %s', [Hostname]));
  Result := ResolveUDP(Hostname);
  if Result <> '' then
    FLogger.Info(Format('Resolved %s -> %s', [Hostname, Result]))
  else
    FLogger.Error(Format('Failed to resolve: %s', [Hostname]));
end;

function TDnsResolver.ReverseLookup(const IP: string): string;
begin
  Result := 'ptr.' + IP;
  FLogger.Info(Format('Reverse lookup: %s -> %s', [IP, Result]));
end;

var
  Resolver: TDnsResolver;
  IP: string;
begin
  Resolver := TDnsResolver.Create;
  Resolver.AddDnsServer('8.8.8.8');
  Resolver.AddDnsServer('8.8.4.4');
  IP := Resolver.Resolve('google.com');
  if IP <> '' then
    WriteLn('Google IP: ', IP);
  IP := Resolver.Resolve('github.com');
  if IP <> '' then
    WriteLn('GitHub IP: ', IP);
  Resolver.ReverseLookup('8.8.8.8');
  Resolver.Free;
end.
