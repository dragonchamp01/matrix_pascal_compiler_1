{$mode objfpc}{$H+}
program service_audit;

uses
  System, SysUtils, Classes, threading, logger, dateutils;

type
  TAuditEntry = record
    Timestamp: TDateTime;
    User: string;
    Action: string;
    Resource: string;
    Result: string;
    Detail: string;
  end;

  TAuditService = class(TThread)
  private
    FAuditLog: string;
    FEntries: array of TAuditEntry;
    FLogger: TLogger;
    FMutex: TMutex;
    function FormatEntry(const Entry: TAuditEntry): string;
    procedure FlushToFile;
  protected
    procedure Execute; override;
  public
    constructor Create(const ALogFile: string);
    destructor Destroy; override;
    procedure Log(const User, Action, Resource, Result, Detail: string);
    function QueryByUser(const User: string): TStringList;
    function QueryByAction(const Action: string): TStringList;
    function QueryByTime(const StartTime, EndTime: TDateTime): TStringList;
  end;

constructor TAuditService.Create(const ALogFile: string);
begin
  inherited Create('AuditService');
  FAuditLog := ALogFile;
  FMutex := TMutex.Create;
  FLogger := TLogger.Create('audit', llInfo, ltBoth, '/var/log/auditd.log');
end;

destructor TAuditService.Destroy;
begin
  FlushToFile;
  FMutex.Free;
  FLogger.Free;
  inherited Destroy;
end;

procedure TAuditService.Log(const User, Action, Resource, Result, Detail: string);
var
  Entry: TAuditEntry;
begin
  Entry.Timestamp := Now;
  Entry.User := User;
  Entry.Action := Action;
  Entry.Resource := Resource;
  Entry.Result := Result;
  Entry.Detail := Detail;

  FMutex.Lock;
  try
    SetLength(FEntries, Length(FEntries) + 1);
    FEntries[Length(FEntries) - 1] := Entry;
    FLogger.Info(Format('%s %s %s %s %s',
      [User, Action, Resource, Result, Detail]));
  finally
    FMutex.Unlock;
  end;
end;

function TAuditService.FormatEntry(const Entry: TAuditEntry): string;
begin
  Result := Format('%s|%s|%s|%s|%s|%s', [
    FormatDateTime('yyyy-mm-dd hh:nn:ss', Entry.Timestamp),
    Entry.User, Entry.Action, Entry.Resource, Entry.Result, Entry.Detail]);
end;

procedure TAuditService.FlushToFile;
var
  F: text;
  I: integer;
begin
  FMutex.Lock;
  try
    Assign(F, FAuditLog);
    if FileExists(FAuditLog) then
      Append(F)
    else
      Rewrite(F);
    for I := 0 to Length(FEntries) - 1 do
      WriteLn(F, FormatEntry(FEntries[I]));
    Close(F);
    SetLength(FEntries, 0);
  finally
    FMutex.Unlock;
  end;
end;

procedure TAuditService.Execute;
begin
  FLogger.Info('Audit service started');
  Log('SYSTEM', 'STARTUP', 'audit.service', 'SUCCESS', 'Audit logging initialized');
  while not Terminated do
  begin
    if Length(FEntries) >= 100 then
      FlushToFile;
    Sleep(5000);
  end;
  FlushToFile;
  FLogger.Info('Audit service stopped');
end;

function TAuditService.QueryByUser(const User: string): TStringList;
var
  I: integer;
begin
  Result := TStringList.Create;
  for I := 0 to Length(FEntries) - 1 do
    if FEntries[I].User = User then
      Result.Add(FormatEntry(FEntries[I]));
end;

function TAuditService.QueryByAction(const Action: string): TStringList;
var
  I: integer;
begin
  Result := TStringList.Create;
  for I := 0 to Length(FEntries) - 1 do
    if FEntries[I].Action = Action then
      Result.Add(FormatEntry(FEntries[I]));
end;

function TAuditService.QueryByTime(const StartTime, EndTime: TDateTime): TStringList;
var
  I: integer;
begin
  Result := TStringList.Create;
  for I := 0 to Length(FEntries) - 1 do
    if (FEntries[I].Timestamp >= StartTime) and (FEntries[I].Timestamp <= EndTime) then
      Result.Add(FormatEntry(FEntries[I]));
end;

var
  Audit: TAuditService;
begin
  Audit := TAuditService.Create('/var/log/audit/audit.log');
  Audit.Start;
  Audit.Log('root', 'LOGIN', '/dev/tty1', 'SUCCESS', 'Root login from console');
  Audit.Log('www-data', 'MODIFY', '/etc/nginx/nginx.conf', 'SUCCESS', 'Config changed');
  Audit.Log('root', 'EXEC', '/usr/bin/apt', 'SUCCESS', 'Package update');
  Sleep(2000);
  Audit.Log('admin', 'read', '/etc/shadow', 'DENIED', 'Unauthorized access attempt');
  Audit.Terminate;
  Audit.WaitFor;
  Audit.Free;
end.
