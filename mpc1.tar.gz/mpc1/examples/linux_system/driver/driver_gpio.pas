{$mode objfpc}{$H+}
program driver_gpio;

uses
  System, SysUtils, Classes, threading, device.gpio;

type
  TGpioDemo = class
  private
    FPins: array of TGPIO;
    FPatterns: array of array of TGPIOValue;
    function SysfsExport(Pin: integer): boolean;
    function SysfsUnexport(Pin: integer): boolean;
    function SysfsSetDirection(Pin: integer; Dir: string): boolean;
    function SysfsWriteValue(Pin: integer; Value: integer): boolean;
    function SysfsReadValue(Pin: integer): integer;
    function DevMemAccess(Pin: integer): boolean;
    function LibGpiodAccess(Pin: integer): boolean;
  public
    constructor Create;
    destructor Destroy; override;
    function InitPin(Pin: integer; Direction: TGPIOMode): boolean;
    function DigitalWrite(Pin: integer; Value: TGPIOValue): boolean;
    function DigitalRead(Pin: integer): TGPIOValue;
    function Blink(Pin: integer; Frequency: integer; Duration: integer): boolean;
    function PWMRange(Pin, Frequency, DutyCycle: integer): boolean;
    procedure ButtonInterrupt(Pin: integer; Callback: TProc);
    procedure Cleanup;
  end;

constructor TGpioDemo.Create;
begin
  WriteLn('GPIO Driver Demo for matrix pascal');
  WriteLn('===================================');
end;

destructor TGpioDemo.Destroy;
begin
  Cleanup;
  inherited Destroy;
end;

function TGpioDemo.SysfsExport(Pin: integer): boolean;
var
  F: text;
begin
  Result := false;
  try
    Assign(F, '/sys/class/gpio/export');
    Rewrite(F);
    WriteLn(F, Pin);
    Close(F);
    Result := true;
  except
  end;
end;

function TGpioDemo.SysfsUnexport(Pin: integer): boolean;
var
  F: text;
begin
  try
    Assign(F, '/sys/class/gpio/unexport');
    Rewrite(F);
    WriteLn(F, Pin);
    Close(F);
    Result := true;
  except
    Result := false;
  end;
end;

function TGpioDemo.SysfsSetDirection(Pin: integer; Dir: string): boolean;
var
  F: text;
begin
  try
    Assign(F, Format('/sys/class/gpio/gpio%d/direction', [Pin]));
    Rewrite(F);
    WriteLn(F, Dir);
    Close(F);
    Result := true;
  except
    Result := false;
  end;
end;

function TGpioDemo.SysfsWriteValue(Pin: integer; Value: integer): boolean;
var
  F: text;
begin
  try
    Assign(F, Format('/sys/class/gpio/gpio%d/value', [Pin]));
    Rewrite(F);
    WriteLn(F, Value);
    Close(F);
    Result := true;
  except
    Result := false;
  end;
end;

function TGpioDemo.SysfsReadValue(Pin: integer): integer;
var
  F: text;
  S: string;
begin
  Result := 0;
  try
    Assign(F, Format('/sys/class/gpio/gpio%d/value', [Pin]));
    Reset(F);
    ReadLn(F, S);
    Close(F);
    Result := StrToIntDef(S, 0);
  except
  end;
end;

function TGpioDemo.DevMemAccess(Pin: integer): boolean;
begin
  Result := false;
end;

function TGpioDemo.LibGpiodAccess(Pin: integer): boolean;
begin
  Result := false;
end;

function TGpioDemo.InitPin(Pin: integer; Direction: TGPIOMode): boolean;
begin
  WriteLn(Format('Initializing GPIO%d as %s', [Pin,
    IfThen(Direction = gmOutput, 'OUTPUT', 'INPUT')]));
  SysfsExport(Pin);
  Sleep(100);
  SysfsSetDirection(Pin, IfThen(Direction = gmOutput, 'out', 'in'));
  SetLength(FPins, Length(FPins) + 1);
  FPins[Length(FPins) - 1] := TGPIO.Create(Pin);
  FPins[Length(FPins) - 1].SetMode(Direction);
  Result := true;
end;

function TGpioDemo.DigitalWrite(Pin: integer; Value: TGPIOValue): boolean;
begin
  Result := SysfsWriteValue(Pin, Ord(Value));
  WriteLn(Format('GPIO%d = %s', [Pin, IfThen(Value = gvHigh, 'HIGH', 'LOW')]));
end;

function TGpioDemo.DigitalRead(Pin: integer): TGPIOValue;
var
  Val: integer;
begin
  Val := SysfsReadValue(Pin);
  Result := TGPIOValue(Val);
  WriteLn(Format('GPIO%d = %s', [Pin, IfThen(Val = 1, 'HIGH', 'LOW')]));
end;

function TGpioDemo.Blink(Pin: integer; Frequency: integer; Duration: integer): boolean;
var
  I, Cycles: integer;
  DelayMs: integer;
begin
  DelayMs := 500 div Frequency;
  Cycles := (Duration * 1000) div (DelayMs * 2);
  WriteLn(Format('Blinking GPIO%d at %dHz for %ds', [Pin, Frequency, Duration]));
  for I := 1 to Cycles do
  begin
    DigitalWrite(Pin, gvHigh);
    Sleep(DelayMs);
    DigitalWrite(Pin, gvLow);
    Sleep(DelayMs);
  end;
  Result := true;
end;

function TGpioDemo.PWMRange(Pin, Frequency, DutyCycle: integer): boolean;
begin
  WriteLn(Format('PWM on GPIO%d: freq=%dHz, duty=%d%%', [Pin, Frequency, DutyCycle]));
  Result := true;
end;

procedure TGpioDemo.ButtonInterrupt(Pin: integer; Callback: TProc);
begin
  WriteLn(Format('Listening for interrupts on GPIO%d...', [Pin]));
  if Assigned(Callback) then Callback;
end;

procedure TGpioDemo.Cleanup;
var
  I: integer;
begin
  for I := 0 to Length(FPins) - 1 do
  begin
    SysfsUnexport(FPins[I].Pin);
    FPins[I].Free;
  end;
  SetLength(FPins, 0);
  WriteLn('GPIO cleanup complete');
end;

var
  Demo: TGpioDemo;
begin
  Demo := TGpioDemo.Create;
  try
    Demo.InitPin(17, gmOutput);
    Demo.InitPin(18, gmInput);
    Demo.DigitalWrite(17, gvHigh);
    Sleep(1000);
    Demo.DigitalWrite(17, gvLow);
    Demo.DigitalRead(18);
    Demo.Blink(17, 2, 3);
    Demo.PWMRange(17, 1000, 50);
    Demo.ButtonInterrupt(18, procedure begin
      WriteLn('Button pressed!');
    end);
  finally
    Demo.Free;
  end;
end.
