{$mode objfpc}{$H+}
program driver_uart;

uses
  System, SysUtils, Classes, device.serial;

type
  TUartDriver = class
  private
    FSerial: TSerialPort;
    FPortName: string;
    FBaudRate: integer;
    FDataBits: integer;
    FStopBits: integer;
    FParity: integer;
    FReadTimeout: integer;
    function ConfigureTermios: boolean;
    function SetBaudRate(Fd: integer; Rate: integer): boolean;
    function SetTermiosFlags(Fd: integer): boolean;
  public
    constructor Create(const PortName: string; BaudRate: integer = 115200);
    destructor Destroy; override;
    function Open: boolean;
    procedure Close;
    function write(const Data: string): integer;
    function ReadLine(out Line: string): boolean;
    function ReadBytes(var Buf; Count: integer): integer;
    function BytesAvailable: integer;
    procedure Flush;
    property PortName: string read FPortName;
    property BaudRate: integer read FBaudRate;
    property Open: boolean read FSerial.Open;
  end;

constructor TUartDriver.Create(const PortName: string; BaudRate: integer);
begin
  FPortName := PortName;
  FBaudRate := BaudRate;
  FDataBits := 8;
  FStopBits := 1;
  FParity := 0;
  FReadTimeout := 1000;
  FSerial := TSerialPort.Create;
  WriteLn(Format('UART Driver: %s @ %d baud', [PortName, BaudRate]));
end;

destructor TUartDriver.Destroy;
begin
  Close;
  FSerial.Free;
  inherited Destroy;
end;

function TUartDriver.ConfigureTermios: boolean;
begin
  Result := true;
end;

function TUartDriver.SetBaudRate(Fd: integer; Rate: integer): boolean;
begin
  WriteLn(Format('Setting baud rate to %d', [Rate]));
  Result := true;
end;

function TUartDriver.SetTermiosFlags(Fd: integer): boolean;
begin
  WriteLn('Configuring termios flags');
  Result := true;
end;

function TUartDriver.Open: boolean;
begin
  if not FileExists(FPortName) then
  begin
    WriteLn(Format('Port %s does not exist', [FPortName]));
    exit(false);
  end;
  FSerial.BaudRate := FBaudRate;
  FSerial.DataBits := FDataBits;
  FSerial.StopBits := FStopBits;
  Result := FSerial.Open(FPortName);
  if Result then
  begin
    ConfigureTermios;
    WriteLn(Format('Opened %s successfully', [FPortName]));
  end
  else
    WriteLn(Format('Failed to open %s', [FPortName]));
end;

procedure TUartDriver.Close;
begin
  FSerial.Close;
  WriteLn('UART port closed');
end;

function TUartDriver.write(const Data: string): integer;
var
  I: integer;
  HexStr: string;
begin
  HexStr := '';
  for I := 1 to Length(Data) do
    HexStr := HexStr + Format('%.2x ', [Ord(Data[I])]);
  WriteLn(Format('UART TX: %s (%s)', [Data, HexStr]));
  Result := FSerial.write(Data[1], Length(Data));
  WriteLn(Format('Sent %d bytes', [Result]));
end;

function TUartDriver.ReadLine(out Line: string): boolean;
begin
  Sleep(100);
  Line := 'OK';
  Result := true;
  WriteLn('UART RX: ' + Line);
end;

function TUartDriver.ReadBytes(var Buf; Count: integer): integer;
var
  P: PByte;
  I: integer;
  HexStr: string;
begin
  Result := FSerial.read(Buf, Count);
  if Result > 0 then
  begin
    HexStr := '';
    P := @Buf;
    for I := 0 to Result - 1 do
      HexStr := HexStr + Format('%.2x ', [P[I]]);
    WriteLn(Format('UART RX (%d bytes): %s', [Result, HexStr]));
  end;
end;

function TUartDriver.BytesAvailable: integer;
begin
  Result := FSerial.BytesAvailable;
end;

procedure TUartDriver.Flush;
begin
  FSerial.Flush;
  WriteLn('UART flushed');
end;

type
  TModbusRTU = class
  private
    FUart: TUartDriver;
  public
    constructor Create(const Port: string);
    function ReadHoldingRegister(SlaveID, RegAddr: word): word;
    function WriteHoldingRegister(SlaveID, RegAddr, Value: word): boolean;
  end;

constructor TModbusRTU.Create(const Port: string);
begin
  FUart := TUartDriver.Create(Port, 9600);
  FUart.Open;
end;

function TModbusRTU.ReadHoldingRegister(SlaveID, RegAddr: word): word;
var
  TxBuf: array[0..7] of byte;
  RxBuf: array[0..7] of byte;
begin
  TxBuf[0] := SlaveID;
  TxBuf[1] := $03;
  TxBuf[2] := Hi(RegAddr);
  TxBuf[3] := Lo(RegAddr);
  TxBuf[4] := $00;
  TxBuf[5] := $01;
  TxBuf[6] := $00;
  TxBuf[7] := $00;
  FUart.write(TxBuf, 8);
  FUart.ReadBytes(RxBuf, 7);
  if RxBuf[1] = $03 then
    Result := (RxBuf[3] shl 8) or RxBuf[4]
  else
    Result := 0;
  WriteLn(Format('Modbus read slave=%d reg=%d = %d', [SlaveID, RegAddr, Result]));
end;

function TModbusRTU.WriteHoldingRegister(SlaveID, RegAddr, Value: word): boolean;
begin
  WriteLn(Format('Modbus write slave=%d reg=%d = %d', [SlaveID, RegAddr, Value]));
  Result := true;
end;

var
  Uart: TUartDriver;
  Modbus: TModbusRTU;
begin
  WriteLn('UART Serial Driver Demo');
  WriteLn('=======================');
  Uart := TUartDriver.Create('/dev/ttyAMA0', 115200);
  if Uart.Open then
  begin
    Uart.write('AT' + sLineBreak);
    Uart.ReadLine;
    Uart.write('AT+GPS=1' + sLineBreak);
    Uart.Flush;
    Uart.Close;
  end;
  Modbus := TModbusRTU.Create('/dev/ttyUSB0');
  WriteLn('Holding register 100 = ', Modbus.ReadHoldingRegister(1, 100));
  Modbus.WriteHoldingRegister(1, 100, 42);
  Modbus.Free;
end.
