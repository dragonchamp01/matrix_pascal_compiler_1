{ @ASM_MODE }
{ @ASSEMBLER64 }
program asm_08;
begin
    mov rax, 0xF0
    or rax, 0x0F
    invoke WriteInteger, rax
end.
