{ @ASM_MODE }
{ @ASSEMBLER64 }
program asm_13;
begin
    mov rax, 42
    mov rbx, 42
    cmp rax, rbx
    je equal_13
    mov rax, 0
    jmp done_13
equal_13:
    mov rax, 1
done_13:
    invoke WriteInteger, rax
end.
