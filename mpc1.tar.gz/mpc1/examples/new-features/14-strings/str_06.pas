program str_06;

  { --- String operations --- }
  { String operations with new features — example 6. }

var
  msg: integer;
  outvar: integer;
begin
  asm
    mov byte ptr [msg], 77
    invoke write, 1, offset msg, 1
    invoke write, 1, offset msg, 1
  end;
end.
