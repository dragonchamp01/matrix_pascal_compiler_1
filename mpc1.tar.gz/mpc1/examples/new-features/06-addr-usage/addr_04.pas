program addr_04;

  { --- addr keyword --- }
  { addr keyword demo — synonym for offset. }

var
  msg: integer;
  val, val2, saved: integer;
begin
  asm
    mov rsi, addr msg
    lodsb
    mov [val], eax
    mov [val2], eax
  end;
  WriteLn('addr with lodsb: val = ', val);
end.
