program inv_ext_03;

  { --- invoke with extern --- }
  { invoke with external C functions — example 3. }

function printf(fmt: string): integer; cdecl; external;
var
  msg: integer;
  retval: integer;
begin
  asm
    mov byte ptr [msg+1], 66
    mov byte ptr [msg+2], 10
    invoke printf, offset msg
    mov [retval], eax
  end;
  WriteLn('printf returned ', retval);
end.
