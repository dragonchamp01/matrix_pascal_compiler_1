program mixed_02;

  { --- Mixed features --- }
  { Combined feature demo — example 2. }

function printf(fmt: string): integer; cdecl; external;
var
  msg: integer;
  outvar: integer;
begin
  asm
    mov byte ptr [msg], 65
    mov byte ptr [msg+1], 10
    mov rax, 1
    mov rdi, 1
    mov rsi, offset msg
    mov rdx, 2
    syscall
    mov [outvar], eax
  end;
  printf('syscall via offset wrote %d bytes');
end.
