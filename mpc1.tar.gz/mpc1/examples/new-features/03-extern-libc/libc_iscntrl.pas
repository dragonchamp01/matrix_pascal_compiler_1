program libc_iscntrl;

  { Calling C iscntrl() from libc via external declaration. }

function iscntrl(c: integer): integer; cdecl; external;
var
  dummy: integer;
begin
  WriteLn('iscntrl(0) = ', iscntrl(0));
end.
