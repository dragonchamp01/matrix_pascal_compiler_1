{$mode objfpc}{$H+}

program tcp_echo_client;

uses
  SysUtils, sockets, netdb, ssockets, threading;

var
  Client: TTcpClient;
  Stream: TSocketStream;
  Buffer: array[0..4095] of byte;
  Received: integer;
  Host: string;
  Port: word;
  message: string;
  I: integer;
  StartTime, EndTime: int64;
  TotalSent, TotalRecv: int64;

begin
  WriteLn('=== TCP Echo Client ===');
  WriteLn;

  if ParamCount < 2 then
  begin
    WriteLn('Usage: tcp_echo_client <host> <port> [message]');
    WriteLn('Example: tcp_echo_client 127.0.0.1 8080 "Hello World"');
    Halt(1);
  end;

  Host := ParamStr(1);
  Port := StrToIntDef(ParamStr(2), 8080);
  if ParamCount >= 3 then
    message := ParamStr(3)
  else
    message := 'Echo test message ' + IntToStr(Random(10000));

  WriteLn('Connecting to ', Host, ':', Port, '...');
  try
    Client := TTcpClient.Create(Host, Port);
    WriteLn('Connected!');
  except
    on E: Exception do
    begin
      WriteLn('Connection failed: ', E.message);
      Halt(1);
    end;
  end;

  Stream := TSocketStream.Create(Client, true);
  try
    Stream.ReadTimeout := 5000;
    Stream.WriteTimeout := 5000;

    TotalSent := 0;
    TotalRecv := 0;
    StartTime := GetTickCount64;

    for I := 1 to 10 do
    begin
      message := 'message #' + IntToStr(I) + ' - ' + IntToStr(Random(10000)) + #10;
      write('Sending: ', message);
      Stream.write(message[1], Length(message));
      Inc(TotalSent, Length(message));

      Received := Stream.read(Buffer, SizeOf(Buffer));
      if Received > 0 then
      begin
        SetString(Buffer, pansichar(@Buffer[0]), Received);
        WriteLn('Received: ', Buffer);
        Inc(TotalRecv, Received);
      end
      else
      begin
        WriteLn('Connection closed by server');
        break;
      end;

      Sleep(100);
    end;

    EndTime := GetTickCount64;
    WriteLn;
    WriteLn('Statistics:');
    WriteLn('  Messages sent: 10');
    WriteLn('  Bytes sent: ', TotalSent);
    WriteLn('  Bytes received: ', TotalRecv);
    WriteLn('  Time elapsed: ', EndTime - StartTime, ' ms');
    WriteLn('  Throughput: ', (TotalSent + TotalRecv) * 1000 div (EndTime - StartTime + 1), ' bytes/sec');

  finally
    Stream.Free;
  end;

  WriteLn('Done.');
end.