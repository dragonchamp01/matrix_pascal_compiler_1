program scroller_raster_2;
var
  fb: array[0..191] of integer;
  x, y, i: integer;
  t: integer;
  freq: integer;
begin
  t := 0;
  freq := 32;
  while true do begin
    for y := 0 to 11 do begin
      for x := 0 to 15 do begin
        i := y * 16 + x;
        asm
          lea rdi, [fb]
          mov eax, [i]
          shl eax, 2
          add rdi, rax
          mov eax, [y]
          mov ecx, [freq]
          imul eax, ecx
          add eax, [t]
          shr eax, 2
          and eax, 15
          mov ecx, eax
          shl ecx, 4
          mov eax, [x]
          shl eax, 4
          add eax, ecx
          mov dword ptr [rdi], eax
        end;
      end;
    end;
    t := t + 1;
  end;
end.
