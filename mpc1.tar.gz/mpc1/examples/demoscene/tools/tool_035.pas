program tool_035;
{ Tool 035 - utility program }
var i, s: integer;
begin
  WriteLn('Tool 035');
  s := 0;
  for i := 1 to 45 do begin
    s := s + i;
  end;
  WriteLn('Sum 1 to 45: ', s);
  WriteLn('Done.');
end.
