program tool_040;
{ Tool 040 - utility program }
var i, s: integer;
begin
  WriteLn('Tool 040');
  s := 0;
  for i := 1 to 50 do begin
    s := s + i;
  end;
  WriteLn('Sum 1 to 50: ', s);
  WriteLn('Done.');
end.
