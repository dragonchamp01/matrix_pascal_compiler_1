program tool_011;
{ Tool 011 - utility program }
var i, s: integer;
begin
  WriteLn('Tool 011');
  s := 0;
  for i := 1 to 21 do begin
    s := s + i;
  end;
  WriteLn('Sum 1 to 21: ', s);
  WriteLn('Done.');
end.
