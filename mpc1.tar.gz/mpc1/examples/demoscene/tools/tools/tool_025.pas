program tool_025;
var
  i: integer;
  s: integer;
begin
  s := 0;
  i := 3;
  while i < 95 do begin
    s := s + i;
    i := i + 1;
  end;
  WriteLn('Sum from 3 to 95 step 1: ', s);
end.
