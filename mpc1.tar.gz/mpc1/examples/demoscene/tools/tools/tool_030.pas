program tool_030;
var
  i: integer;
  s: integer;
begin
  s := 0;
  i := 8;
  while i < 110 do begin
    s := s + i;
    i := i + 1;
  end;
  WriteLn('Sum from 8 to 110 step 1: ', s);
end.
