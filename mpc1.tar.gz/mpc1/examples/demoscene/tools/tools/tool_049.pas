program tool_049;
var
  i: integer;
  s: integer;
begin
  s := 0;
  i := 5;
  while i < 56 do begin
    s := s + i;
    i := i + 5;
  end;
  WriteLn('Sum from 5 to 56 step 5: ', s);
end.
