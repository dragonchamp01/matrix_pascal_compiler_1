program tool_001;
var
  i: integer;
  s: integer;
begin
  s := 0;
  i := 1;
  while i < 23 do begin
    s := s + i;
    i := i + 2;
  end;
  WriteLn('Sum from 1 to 23 step 2: ', s);
end.
