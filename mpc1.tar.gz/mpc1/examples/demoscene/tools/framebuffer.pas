program framebuffer;
{ Framebuffer Simulator Tool }
var fb: array[0..191] of integer;
    y, x, i: integer;
begin
  WriteLn('Framebuffer Tool');
  for y := 0 to 11 do begin
    for x := 0 to 15 do begin
      fb[y * 16 + x] := y * 16 + x;
    end;
  end;
  for y := 0 to 11 do begin
    for x := 0 to 15 do begin
      write(HexStr(fb[y * 16 + x], 2), ' ');
    end;
    WriteLn;
  end;
  WriteLn('Done.');
end.
