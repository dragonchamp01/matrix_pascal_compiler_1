program tool_006;
{ Tool 006 - utility program }
var i, s: integer;
begin
  WriteLn('Tool 006');
  s := 0;
  for i := 1 to 16 do begin
    s := s + i;
  end;
  WriteLn('Sum 1 to 16: ', s);
  WriteLn('Done.');
end.
