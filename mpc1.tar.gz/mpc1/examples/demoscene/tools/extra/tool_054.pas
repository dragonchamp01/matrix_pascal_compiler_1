program tool_054;
var i: integer;
begin
  WriteLn('Tool 054');
  for i := 0 to 4 do WriteLn('  op ', i);
  WriteLn('Done.');
end.
