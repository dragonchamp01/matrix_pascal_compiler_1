program tool_078;
var i: integer;
begin
  WriteLn('Tool 078');
  for i := 0 to 4 do WriteLn('  op ', i);
  WriteLn('Done.');
end.
