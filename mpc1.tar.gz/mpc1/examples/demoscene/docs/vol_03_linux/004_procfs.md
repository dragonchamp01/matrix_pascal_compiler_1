# /proc Filesystem

## Overview
- Virtual filesystem for kernel data
- Process information: /proc/[pid]/
- System info: /proc/cpuinfo, /proc/meminfo
- Dynamic data generated on read

## Creating proc Entries
#include <linux/proc_fs.h>
struct proc_dir_entry *proc_create(
    const char *name, umode_t mode,
    struct proc_dir_entry *parent,
    const struct proc_ops *proc_ops);

## proc_ops
struct proc_ops proc_fops = {
    .proc_open = my_open,
    .proc_read = seq_read,
    .proc_write = my_write,
    .proc_release = single_release,
};

## Example
static int my_show(struct seq_file *m, void *v) {
    seq_printf(m, "framecount: %d\n", counter);
    return 0;
}
proc_create("demo_stats", 0444, NULL, &my_proc_ops);

## Removal
- remove_proc_entry("demo_stats", NULL)
