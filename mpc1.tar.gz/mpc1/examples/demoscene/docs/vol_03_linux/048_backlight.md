# Backlight Driver

## Overview
- Backlight control for displays
- Brightness, power curve, dimming
- /sys/class/backlight/
- Used by LCD panels, OLED displays

## Backlight Device
struct backlight_device {
    struct backlight_properties props;
    const struct backlight_ops *ops;
};
- struct backlight_properties {
    int brightness;
    int max_brightness;
    int power;     // FB_BLANK_UNBLANK, FB_BLANK_POWERDOWN
    enum backlight_type type;
};

## Backlight Operations
struct backlight_ops {
    int (*update_status)(struct backlight_device *);
    int (*get_brightness)(struct backlight_device *);
    int (*check_fb)(struct backlight_device *, struct fb_info *);
};

## Power Curve
- Gamma correction for human perception
- Linear brightness not perceived linear
- Power curve: actual = (brightness/max)^gamma * max
- Smooth transitions for eye comfort

## Demoscene
- Smooth display fading
- Flash/strobe effects (with caution)
- Disable backlight for black frames
