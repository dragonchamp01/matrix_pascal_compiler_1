# ioctl Command Encoding

## Overview
ioctl commands encode: type, number, direction, size
- type (magic): 8-bit unique byte per driver
- number: 8-bit command number within type
- direction: read, write, or both
- size: argument size in bytes

## Macros (linux/ioctl.h)
- _IO(type, nr): No data transfer
- _IOR(type, nr, data_type): Read from device
- _IOW(type, nr, data_type): Write to device
- _IOWR(type, nr, data_type): Read and write

## Examples
#define MY_MAGIC 'D'
#define MY_GET_FPS _IOR(MY_MAGIC, 1, int)
#define MY_SET_RES _IOW(MY_MAGIC, 2, struct res)
#define MY_GET_INFO _IOWR(MY_MAGIC, 3, struct info)

## Kernel Handling
static long my_ioctl(struct file *file,
    unsigned int cmd, unsigned long arg) {
    switch (cmd) {
    case MY_GET_FPS:
        if (copy_to_user((void *)arg, &fps, sizeof(fps)))
            return -EFAULT;
        return 0;
    case MY_SET_RES:
        if (copy_from_user(&res, (void *)arg, sizeof(res)))
            return -EFAULT;
        return 0;
    }
    return -ENOTTY;
}

## Demoscene
- Control demo parameters via ioctl
- FPS query, resolution set, effect select
