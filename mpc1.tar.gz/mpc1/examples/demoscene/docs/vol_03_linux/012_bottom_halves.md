# Bottom Halves

## Softirqs
- Statically allocated at compile time
- HI_SOFTIRQ, TIMER_SOFTIRQ, TASKLET_SOFTIRQ
- NET_TX_SOFTIRQ, NET_RX_SOFTIRQ, BLOCK_SOFTIRQ
- Rarely used directly (use tasklets)
- Same CPU as original interrupt

## Tasklets
- Softirq-based deferral mechanism
- tasklet_init(&t, fn, data)
- tasklet_schedule(&t): schedule for execution
- tasklet_hi_schedule(&t): high priority
- tasklet_kill(&t): ensure stopped
- Runs on same CPU that scheduled it

## Workqueues
- Process context (can sleep!)
- struct work_struct work;
- INIT_WORK(&work, fn);
- schedule_work(&work): schedule on system_wq
- system_wq: default workqueue
- create_workqueue("name"): custom WQ

## Which to Use?
- Tasklet: fast, non-sleepable, same CPU
- Workqueue: slower, sleepable, any CPU
- Threaded IRQ: best for complex devices
- Prefer workqueues in modern drivers
