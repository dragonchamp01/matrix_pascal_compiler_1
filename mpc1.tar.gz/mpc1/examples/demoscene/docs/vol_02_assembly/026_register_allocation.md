# Register Allocation

## Allocation Goals
- Maximize architectural register usage
- Minimize spill loads/stores to stack
- Respect ABI calling conventions
- Minimize register copy instructions

## Spilling
- When all registers in use, save to stack
- Spill cost: store + load = ~10 cycles
- Reduce spills with software pipelining
- Register allocator uses heuristics (graph coloring)

## Live Ranges
- From definition to last use of a value
- Non-overlapping ranges can share registers
- Interference graph: nodes = live ranges
- Graph coloring is NP-complete, GCC uses iterated coalescing

## Two-Address vs Three-Address
- x86 default: two-address (dest = dest op src)
- AVX/VEX: three-address (dest = src1 op src2)
- Three-address reduces register copies
- VEX prefix enables non-destructive operations

## Demoscene
- 16 GPRs on x86-64 (previously 8 on x86)
- 16 XMM registers (previously 8)
- Keep hot loop values in callee-saved registers
- Avoid spills in inner rendering loops
