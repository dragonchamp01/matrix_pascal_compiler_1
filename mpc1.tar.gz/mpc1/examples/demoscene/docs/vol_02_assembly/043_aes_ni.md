# AES-NI Instructions

## Overview
- Hardware acceleration for AES encryption
- 6 instructions added in Westmere (2010)
- Part of the AESNI instruction set
- Constant time execution (no timing side channels)

## Instructions
- AESENC: AES encrypt round
- AESENCLAST: AES encrypt final round
- AESDEC: AES decrypt round
- AESDECLAST: AES decrypt final round
- AESKEYGENASSIST: AES round key generation
- AESIMC: invert MixColumns transformation

## Intrinsics
- __m128i _mm_aesenc_si128(__m128i data, __m128i key)
- __m128i _mm_aesdec_si128(__m128i data, __m128i key)
- __m128i _mm_aeskeygenassist_si128(__m128i key, int rcon)
- Each round: SubBytes, ShiftRows, MixColumns, AddRoundKey

## Performance
- AES-128-CBC: ~0.7 cycles per byte
- AES-256-CBC: ~1.0 cycles per byte
- 10-20x faster than software implementation
- Best when processing multiple blocks in parallel

## Demoscene
- Encrypt demo assets (music, textures, code)
- Fast random number generation using AES
- AES-based procedural texture generation
