# Float Argument Passing

## Register Assignment
- xmm0-xmm7: args 1-8
- Stack: args 9+

## Hybrid Classification
- INTEGER class: rdi,rsi,rdx,rcx,r8,r9
- SSE class: xmm0-xmm7
- Each arg uses appropriate class

## Return Values
- float: xmm0
- double: xmm0
- complex: xmm0+xmm1

## Varargs Float
- Float varargs on stack (not xmm)
- va_start cannot know float args
- float promoted to double
