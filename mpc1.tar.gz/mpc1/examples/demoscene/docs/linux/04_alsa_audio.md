# ALSA Audio Output

Advanced Linux Sound Architecture for PCM playback:

- **Library**: `libasound` (`-lasound`)
- **Device**: `default`, `hw:0,0`, `plughw:0,0`
- **PCM handle**: `snd_pcm_open`, `snd_pcm_set_params`
- **Sample format**: S16_LE, S32_LE, FLOAT
- **Buffer**: `snd_pcm_writei` writes interleaved frames
- **Mode**: Blocking or non-blocking (`SND_PCM_NONBLOCK`)
- **Period**: Size of audio fragment (typically 1024-4096 frames)

Demoscene: Generate procedural audio and stream via ALSA.

## Expert: ALSA underrun Recovery
An underrun (buffer underflow) occurs when application doesn't feed data fast enough. Recovery: `snd_pcm_recover(handle, err, 1)` handles -EPIPE, -ESTRPIPE. For -EPIPE: calls `snd_pcm_prepare` then rewrites pending frames. For -ESTRPIPE (suspend): waits for resume. Prevent underruns: use double buffering, larger period size, or RT priority. Monitor: `snd_pcm_avail()` shows available frames, `snd_pcm_delay()` shows delay. For demoscene: underrun causes audio glitch — use `SCHED_FIFO` priority for audio thread.
