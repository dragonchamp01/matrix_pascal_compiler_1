# SMBIOS/DMI

## SMBIOS Overview
System Management BIOS provides hardware inventory information:
- Standardized format for BIOS to describe hardware
- Tables accessed via entry point (23F0h or UEFI config table)
- Each table has a type (0-255)

## Key Table Types
- **Type 0**: BIOS Information (vendor, version, date)
- **Type 1**: System Information (manufacturer, product, serial)
- **Type 2**: Baseboard (motherboard) Information
- **Type 3**: Chassis Information
- **Type 4**: Processor Information (socket, frequency, cores, cache)
- **Type 7**: Cache Information (size, type, associativity)
- **Type 16/17**: Physical Memory Array / Device (DIMMs, size, speed)

## DMI Decode
The dmidecode tool parses SMBIOS tables:
- dmidecode -t bios: BIOS info
- dmidecode -t processor: CPU details
- dmidecode -t memory: RAM configuration

## Programming Access
- /sys/firmware/dmi/tables/DMI: Raw SMBIOS entry point
- /sys/firmware/dmi/tables/smbios_entry_point: 32-bit entry

## Demoscene Relevance
SMBIOS helps demos introspect hardware for adaptive quality settings.
