# stb_image.h

Single-file image loader library:

- **Author**: Sean Barrett
- **File**: Just `#define STB_IMAGE_IMPLEMENTATION` + `#include "stb_image.h"`
- **Formats**: PNG, JPEG, BMP, GIF, TGA, PSD, HDR
- **API**: `stbi_load(filename, &w, &h, &channels, 4)`
- **Free**: `stbi_image_free(data)`
- **No linking**: Header-only, compiles into your source
- **Also**: `stb_image_write.h`, `stb_truetype.h` for font rendering

## Expert: stb_image Threading
`stb_image.h` is NOT thread-safe by default. Multiple threads must not call `stbi_load`/`stbi_load_from_memory` simultaneously without a mutex. The loader reads from FILE* which has internal buffering. For threaded loading: call `stbi_set_flip_vertically_on_load_thread` (thread-local). Supported formats: JPEG (baseline + progressive), PNG (8-bit), BMP, TGA, PSD, GIF, HDR, PIC, PNM. JPEG decoding is the slowest — use `stbi__jpeg_reset` for multiple loads from the same file. stb_image_write.h: stbi_write_png/write_bmp/write_tga.
