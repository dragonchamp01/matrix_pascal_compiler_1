# SSE/AVX SIMD Overview

Single Instruction Multiple Data extensions:

- **SSE**: 128-bit XMM registers, packed float/int operations
- **SSE2**: Double-precision float, integer SIMD in XMM
- **SSSE3/SSE4.1/4.2**: Shuffle, blend, string ops
- **AVX**: 256-bit YMM registers, VEX encoding
- **AVX2**: Gather, FMA, integer 256-bit
- **Demoscene**: Fast pixel processing, 4-8 pixels per instruction

Use `-msse4` or `-mavx2` flags to enable.

## Expert: SIMD Pitfalls
1. **Alignment**: `_mm_load_ps` faults on unaligned addresses; use `_mm_loadu_ps` for potentially unaligned data, or align to 16 bytes with `_mm_malloc`/`posix_memalign`. 2. **VZEROUPPER**: After using 256/512-bit YMM/ZMM registers, call `_mm256_zeroupper()` before calling legacy SSE code to avoid transition penalties (~50 cycles). 3. **Denormals**: Flush-to-zero (FTZ) and denormals-are-zero (DAZ) modes in MXCSR improve performance for graphics code where denormals are visually irrelevant. 4. **Non-temporal stores**: `_mm_stream_ps` bypasses cache for write-only data (framebuffers). Requires SFENCE/MFENCE after the last streaming store.
