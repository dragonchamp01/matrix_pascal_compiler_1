# Dithering Algorithms

Reduce color depth while preserving visual quality:

- **Ordered dither**: Bayer matrix threshold comparison
- **Floyd-Steinberg**: Error diffusion to neighbors
- **Atkinson**: Modified error diffusion (Pocket PC standard)
- **Sierra**: Error distribution to 6 neighbors
- **Random dither**: Compare pixel against random threshold

Bayer 4x4 matrix is fastest for real-time demoscene.

## Expert: Dither Matrix Size
Bayer dithering: matrix size N gives N^2+1 levels. 4x4 = 17 levels, 8x8 = 65 levels. Error diffusion (Floyd-Steinberg) spreads error to 4 neighbors with coefficients: right 7/16, down-left 3/16, down 5/16, down-right 1/16. For demoscene: ordered dither is fastest (lookup + compare), error diffusion gives best quality. Modulated dither: vary dither intensity with signal level (perceptual). On GPU: use dither in fragment shader for banding reduction in HDR-to-LDR.
