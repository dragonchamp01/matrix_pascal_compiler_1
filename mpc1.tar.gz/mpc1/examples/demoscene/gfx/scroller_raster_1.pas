program scroller_raster_1;
{ Raster Text Scroller #1 }
var fb: array[0..3071] of integer;
    x, y, i, t, c: integer;
begin
  WriteLn('Raster Scroller #1');
  for t := 0 to 19 do begin
    asm
      lea rdi, [fb]
      xor eax, eax
      mov ecx, 3072
      cld
      rep stosd
    end;
    for y := 0 to 47 do begin
      for x := 0 to 63 do begin
        c := x + y + t * 3;
        i := y * 64 + x;
        asm
          lea rdi, [fb]
          mov eax, [i]
          shl eax, 2
          add rdi, rax
          mov eax, [c]
          mov [rdi], al
          mov [rdi + 1], al
          shr eax, 1
          mov [rdi + 2], al
        end;
      end;
    end;
    WriteLn('Frame ', t);
  end;
  WriteLn('Done.');
end.
