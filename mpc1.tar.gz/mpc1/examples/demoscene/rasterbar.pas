program rasterbar;

var
  fb: array[0..255] of integer;
  x, y, i, t: integer;

begin
  WriteLn('Raster Bar Demo');
  WriteLn;

  for t := 0 to 9 do begin
    { Clear buffer with REP STOSD }
    asm
      lea rdi, [fb]
      xor eax, eax
      mov ecx, 256
      cld
      rep stosd
    end;

    { Render colored bars }
    for y := 0 to 15 do begin
      for x := 0 to 15 do begin
        i := y * 16 + x;
        asm
          mov edi, [fb]
          mov eax, [i]
          shl eax, 2
          add rdi, rax
          mov byte ptr [rdi], 0
          mov byte ptr [rdi+1], 0
          mov byte ptr [rdi+2], 0
        end;
      end;
    end;
  end;

  WriteLn('Done - output rendered to fb array');
  WriteLn('Frame buffer pixel count: 256 integers');
end.
