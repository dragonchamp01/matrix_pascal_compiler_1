{
  Matrix Pascal Example: Vector Operators Demo
  Demonstrates the new vector operators in Matrix Pascal.
  This example is for the operators/vector directory.
}

program VectorOpsDemo;

{$MODE MATRIXOPS} // Enable Matrix Pascal operator extensions

uses
  Math; // Import the Math unit

// We assume that the Math unit provides vector types and operator overloading for:
//   Vector (dynamic array of Double)
//   and the new operators: **, |v|, ⟨⟩, ∘, ⊕, ⊗, @, ∥·∥, ∇, ∂/∂

var
  v1, v2, v3: Vector; // Vector type (dynamic array of Double)
  s: Double;          // Scalar
  m: Matrix;          // Matrix type (for demonstration)
  result: Double;
  vResult: Vector;

begin
  WriteLn('--- Vector Operators Demo ---');

  // Initialize vectors
  v1 := [1.0, 2.0, 3.0];
  v2 := [4.0, 5.0, 6.0];
  v3 := [0.0, 0.0, 0.0]; // placeholder

  Scalar s := 2.0;

  // Power operator **
  WriteLn('Power operator:');
  WriteLn('  2.0 ** 3.0 = ', 2.0 ** 3.0); // 8
  WriteLn('  v1 ** 2 = [', (v1 ** 2)[0]:0:2, ', ', (v1 ** 2)[1]:0:2, ', ', (v1 ** 2)[2]:0:2, ']'); // element-wise power

  // Vector magnitude operator |v|
  WriteLn('');
  WriteLn('Magnitude operator:');
  WriteLn('  |v1| = ', |v1|); // sqrt(1^2+2^2+3^2) = sqrt(14)
  WriteLn('  |v2| = ', |v2|); // sqrt(4^2+5^2+6^2) = sqrt(77)

  // Inner product operator ⟨⟩
  WriteLn('');
  WriteLn('Inner product operator:');
  WriteLn('  ⟨v1, v2⟩ = ', ⟨v1, v2⟩); // 1*4 + 2*5 + 3*6 = 4+10+18 = 32

  // Hadamard (element-wise) product operator ∘
  WriteLn('');
  WriteLn('Hadamard product:');
  vResult := v1 ∘ v2;
  WriteLn('  v1 ∘ v2 = [', vResult[0]:0:2, ', ', vResult[1]:0:2, ', ', vResult[2]:0:2, ']'); // [4,10,18]

  // Vector concatenation operator ⊕
  WriteLn('');
  WriteLn('Concatenation operator:');
  vResult := v1 ⊕ v2;
  WriteLn('  v1 ⊕ v2 = [', vResult[0]:0:2, ', ', vResult[1]:0:2, ', ', vResult[2]:0:2, ', ',
          vResult[3]:0:2, ', ', vResult[4]:0:2, ', ', vResult[5]:0:2, ']'); // [1,2,3,4,5,6]

  // Outer product operator ⊗ (results in a matrix)
  WriteLn('');
  WriteLn('Outer product:');
  // Note: This would require a Matrix type and operator overloading for Vector ⊗ Vector -> Matrix
  // We'll demonstrate the concept with a comment.
  WriteLn('  v1 ⊗ v2 = 3x3 matrix:');
  WriteLn('    [1*4, 1*5, 1*6]   [4, 5, 6]');
  WriteLn('    [2*4, 2*5, 2*6] = [8,10,12]');
  WriteLn('    [3*4, 3*5, 3*6]   [12,15,18]');

  // Matrix-vector multiplication operator @
  WriteLn('');
  WriteLn('Matrix-vector multiplication:');
  // Note: This would require a Matrix type and operator overloading for Vector @ Matrix -> Vector
  // We'll demonstrate the concept with a comment.
  WriteLn('  v1 @ M (where M is identity) = v1');
  WriteLn('  v1 @ M (where M is 2*I) = 2*v1');

  // L2 norm operator ∥·∥
  WriteLn('');
  WriteLn('L2 norm operator:');
  WriteLn('  ∥v1∥ = ', ∥v1∥); // same as |v1|
  WriteLn('  ∥v2∥ = ', ∥v2∥); // same as |v2|

  // Numerical gradient operator ∇
  WriteLn('');
  WriteLn('Numerical gradient:');
  // Note: This would require a function expression. We'll demonstrate with a comment.
  WriteLn('  ∇(x^2 + y^2 + z^2) at (1,2,3) = [2*1, 2*2, 2*3] = [2,4,6]');

  // Partial derivative operator ∂/∂
  WriteLn('');
  WriteLn('Partial derivative:');
  // Note: This would require a function of multiple variables. We'll demonstrate with a comment.
  WriteLn('  ∂/∂(x^2 + y^2 + z^2, x) at (1,2,3) = 2*x = 2');
  WriteLn('  ∂/∂(x^2 + y^2 + z^2, y) at (1,2,3) = 2*y = 4');
  WriteLn('  ∂/∂(x^2 + y^2 + z^2, z) at (1,2,3) = 2*z = 6');

  WriteLn('');
  WriteLn('Example completed.');
end.