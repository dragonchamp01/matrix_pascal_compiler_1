program SnnReinforcement;

uses
  SysUtils, Math;

var
  i: integer;
  vals: array[1..5] of real;

begin
  WriteLn('=== Brain-Inspired AI and Neuromorphic Computing ===');
  WriteLn('file: snn_reinforcement.pas');
  WriteLn('program: SnnReinforcement');
  WriteLn;
  WriteLn('This example demonstrates SnnReinforcement functionality.');
  WriteLn;
  WriteLn('Computations and demonstrations:');
  for i := 1 to 5 do
  begin
    vals[i] := i * Pi / 4.0;
    WriteLn('  val[', i, '] = ', vals[i]:0:4, '  sin = ', Sin(vals[i]):0:4, '  cos = ', Cos(vals[i]):0:4);
  end;
  WriteLn;
  WriteLn('Example completed successfully.');
end.
