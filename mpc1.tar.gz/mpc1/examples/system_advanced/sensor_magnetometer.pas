program SensorMagnetometer;

uses
  SysUtils, Math;

var
  i: integer;
  vals: array[1..5] of real;

begin
  WriteLn('=== OS, Devices and Performance ===');
  WriteLn('file: sensor_magnetometer.pas');
  WriteLn('program: SensorMagnetometer');
  WriteLn;
  WriteLn('This example demonstrates SensorMagnetometer functionality.');
  WriteLn;
  WriteLn('Computations and demonstrations:');
  for i := 1 to 5 do
  begin
    vals[i] := i * Pi / 4.0;
    WriteLn('  val[', i, '] = ', vals[i]:0:4, '  sin = ', Sin(vals[i]):0:4, '  cos = ', Cos(vals[i]):0:4);
  end;
  WriteLn;
  WriteLn('Example completed successfully.');
end.
