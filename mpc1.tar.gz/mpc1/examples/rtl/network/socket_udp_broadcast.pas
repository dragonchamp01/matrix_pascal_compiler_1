program SocketUdpBroadcast;
{$mode objfpc}{$H+}
uses
  SysUtils, sockets, netdb;
var
  Sock: TSocket;
  BroadcastMsg: string;
  Sent: integer;
  OptVal: integer;
  I: integer;
begin
  WriteLn('=== UDP Broadcast Example ===');
  WriteLn;
  WriteLn('UDP broadcast sends datagrams to all hosts');
  WriteLn('on the local network. The broadcast address');
  WriteLn('is typically 255.255.255.255 or the subnet');
  WriteLn('broadcast address.');
  WriteLn;
  try
    WriteLn('1. Creating UDP socket...');
    Sock := TSocket.Create(_NetCreate(AF_INET, SOCK_DGRAM, IPPROTO_UDP));
    WriteLn('   Handle: ', Sock.Handle);
    WriteLn;
    WriteLn('2. Enabling broadcast socket option...');
    OptVal := 1;
    WriteLn('   Calling setsockopt with SO_BROADCAST');
    WriteLn('   (may be simulated if no kernel support)');
    WriteLn;
    WriteLn('3. Sending broadcast discovery packets...');
    WriteLn;
    for I := 1 to 3 do
    begin
      BroadcastMsg := 'DISCOVER: MatrixPascal Node #' + IntToStr(I) +
                       ' Timestamp=' + IntToStr(GetTickCount);
      Sent := Sock.Send(BroadcastMsg[1], Length(BroadcastMsg));
      WriteLn('   Broadcast #', I, ': ', Sent, ' bytes sent');
      WriteLn('   message: "', BroadcastMsg, '"');
      WriteLn('   Target: 255.255.255.255:9000');
      WriteLn;
    end;
    WriteLn('Broadcast applications:');
    WriteLn('  - Service discovery (mDNS, SSDP)');
    WriteLn('  - DHCP discovery');
    WriteLn('  - ARP resolution');
    WriteLn('  - network time protocols');
    WriteLn('  - Device discovery on LAN');
    WriteLn;
    Sock.Free;
    WriteLn('Socket closed.');
  except
    on E: Exception do
      WriteLn('Error: ', E.message);
  end;
  WriteLn;
  WriteLn('UDP broadcast vs multicast:');
  WriteLn('  Broadcast: all hosts on subnet');
  WriteLn('  Multicast: specific group membership');
  WriteLn('  Broadcast cannot cross routers');
  WriteLn('  Multicast can (with IGMP)');
  WriteLn;
  WriteLn('Socket options for broadcast:');
  WriteLn('  SO_BROADCAST - enable broadcast send');
  WriteLn('  IP_ADD_MEMBERSHIP - join multicast group');
  WriteLn('  IP_DROP_MEMBERSHIP - leave multicast group');
  WriteLn('  IP_MULTICAST_TTL - set TTL for multicast');
  WriteLn;
  WriteLn('Broadcast security considerations:');
  WriteLn('  - Limit to LAN only (firewall blocks)');
  WriteLn('  - Validate received broadcast messages');
  WriteLn('  - Use authentication in discovery protocols');
  WriteLn('  - Rate-limit broadcast responses');
  WriteLn;
  WriteLn('Broadcast address calculation:');
  WriteLn('  Subnet 192.168.1.0/24:');
  WriteLn('    network: 192.168.1.0');
  WriteLn('    Broadcast: 192.168.1.255');
  WriteLn('    Limited broadcast: 255.255.255.255');
  WriteLn;
  WriteLn('Practical broadcasting tips:');
  WriteLn('  Always set SO_BROADCAST before sending');
  WriteLn('  Use a specific port for your application');
  WriteLn('  Include magic bytes/protocol version');
  WriteLn('  Handle responses asynchronously');
  WriteLn;
  WriteLn('UDP broadcast completed.');
end.
