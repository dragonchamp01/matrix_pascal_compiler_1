program HttpProxy;
{$mode objfpc}{$H+}
uses
  SysUtils, http, classes, Net.Proxy;
var
  Response: THTTPResponse;
  Proxy: TProxy;
  ProxyHeaders: TStringList;
begin
  WriteLn('=== HTTP Proxy Example ===');
  WriteLn;
  WriteLn('HTTP proxies act as intermediaries between');
  WriteLn('a client and the target server.');
  WriteLn;
  WriteLn('1. Configuring HTTP proxy...');
  Proxy := TProxy.Create(ptHTTP);
  Proxy.Host := 'proxy.example.com';
  Proxy.Port := 8080;
  Proxy.Enabled := true;
  Proxy.Username := 'proxyuser';
  Proxy.Password := 'proxypass';
  Proxy.FAuthRequired := true;
  WriteLn('   Proxy type: HTTP');
  WriteLn('   Host: ', Proxy.Host);
  WriteLn('   Port: ', Proxy.Port);
  WriteLn('   Enabled: ', Proxy.Enabled);
  WriteLn('   Auth required: ', Proxy.FAuthRequired);
  WriteLn('   Proxy authenticated: ', Proxy.IsAuthenticated);
  WriteLn;
  WriteLn('2. Setting proxy headers...');
  ProxyHeaders := TStringList.Create;
  ProxyHeaders.Add('Proxy-Authorization: Basic ' +
                    'cHJveHl1c2VyOnByb3h5cGFzcw==');
  ProxyHeaders.Add('X-Forwarded-for: 192.168.1.100');
  WriteLn;
  WriteLn('3. Sending request through HTTP proxy...');
  WriteLn('   URL: http://httpbin.org/get');
  WriteLn;
  Response := HTTP.Get('http://httpbin.org/get', ProxyHeaders);
  if Response <> nil then
  begin
    WriteLn('   Status: ', Response.StatusCode);
    if Response.IsSuccess then
      WriteLn('   Request via proxy succeeded!')
    else
      WriteLn('   Proxy returned error: ', Response.StatusCode);
    Response.Free;
  end;
  ProxyHeaders.Free;
  Proxy.Free;
  WriteLn;
  WriteLn('4. Proxy types:');
  WriteLn('   - Forward proxy (client-side)');
  WriteLn('   - Reverse proxy (server-side)');
  WriteLn('   - Transparent proxy (invisible)');
  WriteLn('   - SOCKS proxy (lower level)');
  WriteLn;
  WriteLn('5. Proxy authentication:');
  WriteLn('   - Basic (base64)');
  WriteLn('   - Digest (MD5 hash)');
  WriteLn('   - NTLM (Windows)');
  WriteLn('   - Bearer token');
  WriteLn;
  WriteLn('6. Proxy detection methods:');
  WriteLn('   - Environment variable (http_proxy)');
  WriteLn('   - WPAD (Web Proxy Auto-Discovery)');
  WriteLn('   - PAC file (Proxy Auto-Config)');
  WriteLn('   - System proxy settings');
  WriteLn('   - Direct configuration');
  WriteLn;
  WriteLn('7. Proxy chaining:');
  WriteLn('   Client -> HTTP proxy -> SOCKS5 -> Internet');
  WriteLn('   Each proxy adds a layer of indirection');
  WriteLn('   Chain can mix different proxy types');
  WriteLn;
  WriteLn('8. Proxy limitations:');
  WriteLn('   HTTP proxy: only HTTP/HTTPS traffic');
  WriteLn('   Can inspect/modify traffic');
  WriteLn('   Adds latency (extra hop)');
  WriteLn('   May cache responses');
  WriteLn;
  WriteLn('HTTP proxy example completed.');
end.
