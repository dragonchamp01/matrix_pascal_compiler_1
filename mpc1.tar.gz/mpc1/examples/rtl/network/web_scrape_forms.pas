program WebScrapeForms;
{$mode objfpc}{$H+}
uses
  SysUtils, http, classes, uri;
var
  Response: THTTPResponse;
  Body: string;
  Forms: TStringList;
  P, endp, ActionStart, ActionEnd: integer;
  FormHTML: string;
  Action: string;
  Method: string;
  InputCount: integer;
  I: integer;
begin
  WriteLn('=== Web Scraping - Extract Forms ===');
  WriteLn;

  WriteLn('HTML forms are used for user input and');
  WriteLn('data submission. Extracting form details');
  WriteLn('helps automate form filling and testing.');
  WriteLn;

  WriteLn('1. Fetching page...');
  WriteLn('   URL: http://httpbin.org/forms/post');
  WriteLn;

  Response := HTTP.Get('http://httpbin.org/forms/post');

  Forms := TStringList.Create;

  if Response.IsSuccess then
  begin
    Body := Response.Body;
    WriteLn('   Page size: ', Length(Body), ' bytes');
    WriteLn;

    WriteLn('2. Parsing form elements...');
    P := 1;

    while True do
    begin
      P := Pos('<form', LowerCase(Body), P);
      if P = 0 then Break;

      EndP := Pos('</form>', LowerCase(Body), P);
      if EndP = 0 then Break;

      FormHTML := Copy(Body, P, EndP - P + 7);

      ActionStart := Pos('action="', LowerCase(FormHTML));
      if ActionStart > 0 then
      begin
        Inc(ActionStart, 8);
        ActionEnd := PosEx('"', FormHTML, ActionStart);
        if ActionEnd > ActionStart then
          Action := Copy(FormHTML, ActionStart,
                         ActionEnd - ActionStart)
        else
          Action := '';
      end
      else
        Action := '(none)';

      if Pos('method="post"', LowerCase(FormHTML)) > 0 then
        Method := 'POST'
      else
        Method := 'GET';

      InputCount := 0;
      I := 1;
      while True do
      begin
        I := Pos('<input', LowerCase(FormHTML), I);
        if I = 0 then Break;
        Inc(InputCount);
        Inc(I);
      end;

      Forms.Add(Format('Action=%s, Method=%s, Inputs=%d',
                [Action, Method, InputCount]));
      P := EndP + 7;
    end;

    WriteLn('   Found ', Forms.Count, ' form(s):');
    WriteLn;
    for I := 0 to Forms.Count - 1 do
      WriteLn('   [', I+1, '] ', Forms[I]);

    WriteLn;
    WriteLn('3. Form field types:');
    WriteLn('   - text, password, email');
    WriteLn('   - checkbox, radio');
    WriteLn('   - select (dropdown)');
    WriteLn('   - textarea');
    WriteLn('   - file (upload)');
    WriteLn('   - submit, button');
  end
  else
    WriteLn('   Failed to fetch page (offline).');

  Forms.Free;
  Response.Free;
  WriteLn;
  WriteLn('Form extraction example completed.');
end.
