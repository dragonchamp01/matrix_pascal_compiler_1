program HttpAuthBasic;
{$mode objfpc}{$H+}
uses
  SysUtils, http, classes;
var
  Response: THTTPResponse;
  Headers: TStringList;
  AuthStr: string;
begin
  WriteLn('=== HTTP Basic Authentication Example ===');
  WriteLn;
  WriteLn('Basic Auth sends a base64-encoded');
  WriteLn('username:password string in the');
  WriteLn('Authorization header.');
  WriteLn;
  WriteLn('1. Creating credentials...');
  WriteLn('   Username: admin');
  WriteLn('   Password: secret');
  AuthStr := 'YWRtaW46c2VjcmV0';
  WriteLn('   Base64("admin:secret") = ', AuthStr);
  WriteLn;
  Headers := TStringList.Create;
  Headers.Add('Authorization: Basic ' + AuthStr);
  WriteLn('2. Sending authenticated request...');
  WriteLn('   URL: http://httpbin.org/basic-auth/admin/secret');
  WriteLn;
  Response := HTTP.Get('http://httpbin.org/basic-auth/admin/secret',
                        Headers);
  WriteLn('   Status: ', Response.StatusCode, ' ', Response.StatusText);
  WriteLn;
  if Response.IsSuccess then
  begin
    WriteLn('   Authentication successful!');
    WriteLn('   Response body:');
    WriteLn(Response.Body);
  end
  else if Response.StatusCode = 401 then
  begin
    WriteLn('   Authentication failed.');
    WriteLn('   WWW-Authenticate: ',
             Response.HeaderValue('WWW-Authenticate'));
  end;
  Headers.Free;
  Response.Free;
  WriteLn;
  WriteLn('3. HTTP Basic Auth flow:');
  WriteLn('   Client -> Authorization: Basic <base64>');
  WriteLn('   Server -> 200 OK (success)');
  WriteLn('   Server -> 401 + WWW-Authenticate (fail)');
  WriteLn;
  WriteLn('4. Security considerations:');
  WriteLn('   - Base64 is NOT encryption or hashing');
  WriteLn('   - Must use HTTPS in production');
  WriteLn('   - Credentials sent with every request');
  WriteLn('   - No built-in expiration mechanism');
  WriteLn('   - Prefer Bearer token or Digest auth');
  WriteLn;
  WriteLn('5. Implementation in server:');
  WriteLn('   Server decodes base64, splits at ":",');
  WriteLn('   compares username and password, and');
  WriteLn('   returns 401 if invalid.');
  WriteLn;
  WriteLn('6. Server-side Basic Auth validation:');
  WriteLn('   function ValidateBasicAuth(AuthHeader: string):');
  WriteLn('     Boolean;');
  WriteLn('   var Decoded, UserPass: string;');
  WriteLn('       SepPos: Integer;');
  WriteLn('   begin');
  WriteLn('     if Copy(AuthHeader, 1, 6) <> ''Basic '' then');
  WriteLn('       Exit(False);');
  WriteLn('     Decoded := DecodeBase64(Copy(AuthHeader, 7));');
  WriteLn('     SepPos := Pos('':'', Decoded);');
  WriteLn('     // Compare user:password');
  WriteLn('     Result := True;');
  WriteLn('   end;');
  WriteLn;
  WriteLn('7. Base64 encoding in RTL:');
  WriteLn('   EncodeBase64, DecodeBase64 from base64 unit');
  WriteLn('   Or use TNetEncoding.Base64 in Pascal net');
  WriteLn;
  WriteLn('8. Alternative: THttpClient with credentials:');
  WriteLn('   Client := THttpClient.Create;');
  WriteLn('   Client.SetCredentials(''admin'', ''secret'');');
  WriteLn('   Client automatically adds Basic header.');
  WriteLn;
  WriteLn('HTTP Basic Auth example completed.');
end.
