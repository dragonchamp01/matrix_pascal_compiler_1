program CurlMulti;
{$mode objfpc}{$H+}
uses
  SysUtils, curl, ctypes;
var
  Curl: PCurl;
  Slist: PCurlSlist;
  Res: TCurlCode;
  Info: TCurlInfo;
  ContentType: pansichar;
  ResponseCode: longint;
begin
  WriteLn('=== cURL Easy Handle Options Example ===');
  WriteLn;

  WriteLn('This example demonstrates configuring a');
  WriteLn('cURL easy handle with options for custom');
  WriteLn('requests, headers, and timeouts.');
  WriteLn;

  WriteLn('1. Initializing cURL...');
  Curl := curl_easy_init;
  if Curl = nil then
  begin
    WriteLn('   libcurl not available.');
    Halt(1);
  end;
  WriteLn('   cURL handle created.');
  WriteLn;

  WriteLn('2. Setting basic options...');
  curl_easy_setopt(Curl, CURLOPT_URL,
                    pansichar('http://httpbin.org/get'));
  curl_easy_setopt(Curl, CURLOPT_TIMEOUT, Pointer(30));
  curl_easy_setopt(Curl, CURLOPT_CONNECTTIMEOUT, Pointer(10));
  curl_easy_setopt(Curl, CURLOPT_USERAGENT,
                    PAnsiChar('MatrixPascal/1.0'));
  curl_easy_setopt(Curl, CURLOPT_FOLLOWLOCATION, Pointer(1));
  curl_easy_setopt(Curl, CURLOPT_MAXREDIRS, Pointer(5));
  curl_easy_setopt(Curl, CURLOPT_SSL_VERIFYPEER, Pointer(1));
  WriteLn('   URL, timeouts, user-agent, redirects set.');
  WriteLn;

  WriteLn('3. Adding custom headers...');
  Slist := curl_slist_append(nil, 'X-Custom: MatrixPascal');
  Slist := curl_slist_append(Slist, 'Accept: application/json');
  Slist := curl_slist_append(Slist, 'X-Debug: true');
  curl_easy_setopt(Curl, CURLOPT_HTTPHEADER, Slist);
  WriteLn('   3 custom headers added.');
  WriteLn;

  WriteLn('4. Performing request...');
  Res := curl_easy_perform(Curl);

  if Res = CURLE_OK then
  begin
    WriteLn('   Request completed successfully!');
  end
  else
  begin
    WriteLn('   Request failed, code=', Ord(Res));
    WriteLn('   Error: ', curl_easy_strerror(Res));
  end;

  WriteLn;
  WriteLn('5. Cleaning up...');
  curl_slist_free_all(Slist);
  curl_easy_cleanup(Curl);
  WriteLn('   Resources freed.');
  WriteLn;

  WriteLn('cURL options reference:');
  WriteLn('  CURLOPT_URL          - Target URL');
  WriteLn('  CURLOPT_TIMEOUT      - Max request time');
  WriteLn('  CURLOPT_FOLLOWLOCATION - Follow redirects');
  WriteLn('  CURLOPT_SSL_VERIFYPEER - Verify SSL cert');
  WriteLn('  CURLOPT_HTTPHEADER   - Custom headers');
  WriteLn('  CURLOPT_POSTFIELDS   - POST data');
  WriteLn('  CURLOPT_PROXY        - Proxy configuration');
  WriteLn('  CURLOPT_COOKIE       - Cookie string');
  WriteLn;
  WriteLn('cURL easy handle example completed.');
end.
