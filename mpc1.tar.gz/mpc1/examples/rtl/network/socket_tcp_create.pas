program SocketTcpCreate;
{$mode objfpc}{$H+}
uses
  SysUtils, sockets, netdb;
var
  Sock: TSocket;
  Server: TTcpServer;
  Client: TTcpClient;
  Entry: THostEntry;
  I: integer;
begin
  WriteLn('=== TCP Socket Creation Examples ===');
  WriteLn;

  WriteLn('This example demonstrates multiple ways');
  WriteLn('to create and initialize TCP sockets');
  WriteLn('using the matrix pascal RTL Sockets unit.');
  WriteLn;

  WriteLn('1. Creating a server socket on port 8080...');
  try
    Server := TTcpServer.Create(8080);
    Server.SetBlocking(false);
    WriteLn('   Server socket created, handle=', Server.Handle);
    WriteLn('   Port: 8080, Backlog: 5 (default)');
    WriteLn('   Closed property: ', Server.Closed);
    Server.Free;
    WriteLn('   Server socket freed.');
  except
    on E: Exception do
      WriteLn('   Server creation failed: ', E.message);
  end;

  WriteLn;
  WriteLn('2. Creating server with custom backlog...');
  try
    Server := TTcpServer.Create(9090, 10);
    WriteLn('   Server on port 9090, backlog=10');
    Server.Free;
  except
    on E: Exception do
      WriteLn('   Failed: ', E.message);
  end;

  WriteLn;
  WriteLn('3. Creating client socket via Connect utility...');
  try
    Sock := Connect('localhost', 80);
    if Sock <> nil then
    begin
      WriteLn('   Connected to localhost:80');
      WriteLn('   Handle: ', Sock.Handle);
      WriteLn('   Closed: ', Sock.Closed);
      Sock.Free;
    end;
  except
    on E: Exception do
      WriteLn('   Connection failed: ', E.message);
  end;

  WriteLn;
  WriteLn('4. Creating TTcpClient with host resolution...');
  try
    if ResolveHost('example.com', Entry) = 0 then
    begin
      WriteLn('   Resolved example.com -> ', Entry.AddrStr);
      Client := TTcpClient.Create('example.com', 80);
      WriteLn('   Client created and connected.');
      Client.Free;
    end;
  except
    on E: Exception do
      WriteLn('   Connection failed (offline): ', E.message);
  end;

  WriteLn;
  WriteLn('5. Socket handle lifecycle...');
  try
    Server := TTcpServer.Create(7070, 3);
    WriteLn('   Created server handle=', Server.Handle);
    WriteLn('   is it closed? ', Server.Closed);
    Server.Close;
    WriteLn('   After Close: Closed=', Server.Closed);
    Server.Free;
  except
    on E: Exception do
      WriteLn('   Error: ', E.message);
  end;

  WriteLn;
  WriteLn('6. Creating raw socket with _NetCreate...');
  Sock := TSocket.Create(_NetCreate(AF_INET, SOCK_STREAM, IPPROTO_TCP));
  if Sock.Handle >= 0 then
  begin
    WriteLn('   Raw TCP socket created, handle=', Sock.Handle);
    Sock.Close;
  end;
  Sock.Free;

  WriteLn;
  WriteLn('Socket creation examples complete.');
end.
