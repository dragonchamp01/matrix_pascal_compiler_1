program HttpCookies;
{$mode objfpc}{$H+}
uses
  SysUtils, http, httpcookie, classes;
var
  Response: THTTPResponse;
  CookieJar: THttpCookieJar;
  Cookie: THttpCookie;
  I: integer;
begin
  WriteLn('=== HTTP Cookies Example ===');
  WriteLn;

  WriteLn('HTTP cookies store state between requests.');
  WriteLn('Servers set cookies via set-Cookie header,');
  WriteLn('clients send them back via Cookie header.');
  WriteLn;

  CookieJar := THttpCookieJar.Create;

  WriteLn('1. Adding cookies to the HTTP client...');
  HTTP.Cookies.Add('session_id=abc123xyz');
  HTTP.Cookies.Add('user_pref=dark_mode');
  HTTP.Cookies.Add('language=en-US');

  WriteLn('   Cookies in client:');
  for I := 0 to HTTP.Cookies.Count - 1 do
    WriteLn('     ', HTTP.Cookies[I]);

  WriteLn;
  WriteLn('2. Sending cookies with GET request...');
  Response := HTTP.Get('http://httpbin.org/cookies');

  if Response.IsSuccess then
  begin
    WriteLn('   Status: ', Response.StatusCode);
    WriteLn('   Server received our cookies:');
    WriteLn(Response.Body);
  end;
  Response.Free;

  WriteLn;
  WriteLn('3. Parsing Set-Cookie from response...');
  Response := HTTP.Get('http://httpbin.org/cookies/set?name=value');

  if Response.Cookies.Count > 0 then
  begin
    WriteLn('   Server sent ', Response.Cookies.Count, ' cookies:');
    for I := 0 to Response.Cookies.Count - 1 do
    begin
      WriteLn('     Raw: ', Response.Cookies[I]);

      Cookie := THttpCookie.Create('parsed', Response.Cookies[I]);
      Cookie.Path := '/';
      CookieJar.AddCookie(Cookie);
      WriteLn('     Stored in jar.');
    end;
  end;

  WriteLn;
  WriteLn('4. Cookie jar contents: ', CookieJar.Count, ' cookies');

  Cookie := CookieJar.FindCookie('session_id');
  if Cookie <> nil then
    WriteLn('   Found session_id: ', Cookie.Value);

  CookieJar.Free;
  Response.Free;

  WriteLn;
  WriteLn('Cookie attributes:');
  WriteLn('  Domain - restricts cookie scope');
  WriteLn('  Path   - URL path restriction');
  WriteLn('  Secure - HTTPS only');
  WriteLn('  HttpOnly - not accessible via JS');
  WriteLn('  Max-Age / Expires - lifetime');
  WriteLn('  SameSite - CSRF protection');
  WriteLn;
  WriteLn('HTTP cookies example completed.');
end.
