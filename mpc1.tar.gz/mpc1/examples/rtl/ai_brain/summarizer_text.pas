{$mode objfpc}{$H+}
program summarizer_text;

uses SysUtils, Math, nlp, summarizer;

procedure TestExtractive;
var
  S: PSummarizer;
  text: string;
  Summary: string;
begin
  WriteLn('--- Testing Extractive Summarization ---');
  S := SummarizerCreate;
  try
    text := 'matrix pascal is an advanced AI programming language. ' +
            'It supports neural networks, deep learning, and reinforcement learning. ' +
            'The language includes built-in tensor operations and automatic differentiation. ' +
            'It can run on multiple platforms including Linux, Windows, and macOS. ' +
            'matrix pascal is designed for both research and production AI applications. ' +
            'The integration of high-performance computing and ease of use makes it unique.';
    WriteLn('Original text: ', text);
    Summary := SummarizeExtractive(S, text, 2);
    WriteLn('Summary (2 sentences): ', Summary);
    if Length(Summary) > 0 then
      WriteLn('Status: SUCCESS')
    else
      WriteLn('Status: FAILED');
  finally
    SummarizerFree(S);
  end;
end;

procedure TestAbstractive;
var
  S: PSummarizer;
  text: string;
  Summary: string;
begin
  WriteLn('--- Testing Abstractive Summarization ---');
  S := SummarizerCreate;
  try
    text := 'matrix pascal is an advanced AI programming language. ' +
            'It supports neural networks, deep learning, and reinforcement learning. ' +
            'The language includes built-in tensor operations and automatic differentiation. ' +
            'It can run on multiple platforms including Linux, Windows, and macOS. ' +
            'matrix pascal is designed for both research and production AI applications. ' +
            'The integration of high-performance computing and ease of use makes it unique.';
    WriteLn('Original text: ', text);
    Summary := SummarizeAbstractive(S, text, 50);
    WriteLn('Summary (approx 50 chars): ', Summary);
    if Length(Summary) > 0 then
      WriteLn('Status: SUCCESS')
    else
      WriteLn('Status: FAILED');
  finally
    SummarizerFree(S);
  end;
end;

procedure TestEmptyText;
var
  S: PSummarizer;
begin
  WriteLn('--- Testing Empty text ---');
  S := SummarizerCreate;
  try
    WriteLn('Summary of empty text: ', SummarizeExtractive(S, '', 2));
    WriteLn('Status: SUCCESS (handled gracefully)');
  except
    on E: Exception do
      WriteLn('Status: FAILED - Exception: ', E.message);
  end;
  SummarizerFree(S);
end;

procedure TestLongText;
var
  S: PSummarizer;
  text: string;
begin
  WriteLn('--- Testing Long text ---');
  S := SummarizerCreate;
  try
    text := '';
    for var i := 1 to 10 do
      text := text + 'This is a repetitive sentence to increase length. ';
    WriteLn('Long text length: ', Length(text));
    WriteLn('Summary: ', SummarizeExtractive(S, text, 3));
    WriteLn('Status: SUCCESS');
  finally
    SummarizerFree(S);
  end;
end;

procedure TestParameterValidation;
var
  S: PSummarizer;
begin
  WriteLn('--- Testing Parameter Validation ---');
  S := SummarizerCreate;
  try
    // Testing with zero sentences
    WriteLn('Summary (0 sentences): ', SummarizeExtractive(S, 'Some text.', 0));
    WriteLn('Status: SUCCESS');
  finally
    SummarizerFree(S);
  end;
end;

procedure TestStress;
var
  S: PSummarizer;
  Text: string;
  i: Integer;
begin
  WriteLn('--- Stress Testing ---');
  S := SummarizerCreate;
  try
    Text := 'Quick test. ';
    for i := 1 to 100 do
    begin
      if i mod 20 = 0 then WriteLn('Iteration ', i);
      SummarizeExtractive(S, Text, 1);
    end;
    WriteLn('Status: SUCCESS');
  finally
    SummarizerFree(S);
  end;
end;

begin
  WriteLn('=== Summarizer Text Comprehensive Tests ===');
  TestExtractive;
  WriteLn;
  TestAbstractive;
  WriteLn;
  TestEmptyText;
  WriteLn;
  TestLongText;
  WriteLn;
  TestParameterValidation;
  WriteLn;
  TestStress;
  WriteLn('============================================');
  WriteLn('All summarizer_text tests passed.');
end.
