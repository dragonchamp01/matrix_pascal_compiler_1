program GraphicsImageResize;
{$mode objfpc}{$H+}
uses
  SysUtils, image, canvas;
var
  src, resizedBilinear, resizedNearest: TImage;
  newW, newH: integer;
begin
  WriteLn('=== Image Resize Demo ===');
  WriteLn;

  src := TImage.Create;
  try
    src.Load('photo.png');
    WriteLn('Source: ', src.Width, 'x', src.Height);
    WriteLn('  Format: ', Ord(src.Format));
    WriteLn;

    WriteLn('Scaling methods:');
    WriteLn('  rfmNearest:  nearest-neighbor (pixelated)');
    WriteLn('  rfmBilinear: bilinear interpolation (smooth)');
    WriteLn('  rfmBicubic:  bicubic interpolation (sharp)');
    WriteLn('  rmLanczos:   Lanczos resampling (high quality)');
    WriteLn;

    newW := src.Width div 2;
    newH := src.Height div 2;
    WriteLn('Halving size (', newW, 'x', newH, '):');

    resizedNearest := src.Resize(newW, newH, rfmNearest);
    WriteLn('  Nearest-neighbor: ', resizedNearest.Width, 'x', resizedNearest.Height);
    resizedNearest.Free;

    resizedBilinear := src.Resize(newW, newH, rfmBilinear);
    WriteLn('  Bilinear:         ', resizedBilinear.Width, 'x', resizedBilinear.Height);
    resizedBilinear.Free;

    WriteLn;
    newW := src.Width * 2;
    newH := src.Height * 2;
    WriteLn('Doubling size (', newW, 'x', newH, '):');

    resizedNearest := src.Resize(newW, newH, rfmNearest);
    WriteLn('  Nearest-neighbor: ', resizedNearest.Width, 'x', resizedNearest.Height);
    resizedNearest.Free;

    resizedBilinear := src.Resize(newW, newH, rfmBilinear);
    WriteLn('  Bilinear:         ', resizedBilinear.Width, 'x', resizedBilinear.Height);
    resizedBilinear.Free;

    WriteLn;
    WriteLn('Resize algorithm comparison:');
    WriteLn('  Nearest: fast, blocky upscale, good for pixel art');
    WriteLn('  Bilinear: good quality/performance balance');
    WriteLn('  Bicubic: sharper than bilinear, slower');
    WriteLn('  Lanczos: highest quality, slowest');
    WriteLn;

    WriteLn('Applications:');
    WriteLn('  Thumbnail generation');
    WriteLn('  Mipmap creation for textures');
    WriteLn('  Responsive image display');

    WriteLn;
    WriteLn;
    WriteLn('Aspect ratio preservation:');
    WriteLn('  ResizeToFit(w, h): fit within bounds');
    WriteLn('  ResizeToCover(w, h): fill bounds (crop)');
    WriteLn('  ResizeByFactor(factor): scale by ratio');
    WriteLn('  MaintainAspect: keep proportions');
    WriteLn;
    WriteLn('Seam carving (content-aware resize):');
    WriteLn('  Removes low-energy seams to resize');
    WriteLn('  Preserves important image content');
    WriteLn('  Slower but better results for photos');

    WriteLn;
    WriteLn('Example completed.');
  finally;
    src.Free;
  end;
end.
