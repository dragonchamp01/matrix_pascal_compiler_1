program OpenGLTexture;
{$mode objfpc}{$H+}
uses
  SysUtils, gl, glext, image;
var
  texId: GLuint;
  img: TImage;
begin
  WriteLn('=== OpenGL Texture Demo ===');
  WriteLn;

  img := TImage.Create;
  try
    img.Load('texture.png');
    WriteLn('Source image: ', img.Width, 'x', img.Height);
    WriteLn('  Format: ', Ord(img.Format));
    WriteLn('  HasAlpha: ', img.HasAlpha);
    WriteLn;

    WriteLn('Texture creation steps:');
    WriteLn('  1. glGenTextures(1, @texId)');
    WriteLn('  2. glBindTexture(GL_TEXTURE_2D, texId)');
    WriteLn('  3. glTexImage2D(...) upload pixel data');
    WriteLn('  4. glTexParameteri set filtering/wrapping');
    WriteLn('  5. Use in shaders');
    WriteLn;

    glGenTextures(1, @texId);
    glBindTexture(GL_TEXTURE_2D, texId);
    WriteLn('  Generated texture ID: ', texId);
    WriteLn;

    WriteLn('Texture parameters:');
    WriteLn('  GL_TEXTURE_MIN_FILTER: GL_LINEAR_MIPMAP_LINEAR');
    WriteLn('  GL_TEXTURE_MAG_FILTER: GL_LINEAR');
    WriteLn('  GL_TEXTURE_WRAP_S: GL_REPEAT');
    WriteLn('  GL_TEXTURE_WRAP_T: GL_REPEAT');
    WriteLn;

    WriteLn('Common pixel formats for glTexImage2D:');
    WriteLn('  GL_RGBA: 4 channels (RGBA)');
    WriteLn('  GL_RGB:  3 channels (no alpha)');
    WriteLn('  GL_RED:  single channel (heightmap)');
    WriteLn;

    WriteLn('Mipmap generation:');
    WriteLn('  glGenerateMipmap(GL_TEXTURE_2D)');
    WriteLn('  Auto-generates smaller versions');
    WriteLn('  Improves quality at distance');
    WriteLn;

    glBindTexture(GL_TEXTURE_2D, 0);
    WriteLn('  Texture unbound (bind 0)');
    WriteLn;

    WriteLn('Texture units:');
    WriteLn('  glActiveTexture(GL_TEXTURE0 + unit)');
    WriteLn('  Up to 32+ units in modern OpenGL');
    WriteLn('  Each unit can bind a different texture');

    WriteLn;
    WriteLn;
    WriteLn('Texture compression:');
    WriteLn('  S3TC/DXT: BC1-BC5 (desktop)');
    WriteLn('  ETC2: standard on mobile (GLES 3.0)');
    WriteLn('  ASTC: advanced compression (modern GPU)');
    WriteLn;
    WriteLn('Cube maps:');
    WriteLn('  6 faces: +X, -X, +Y, -Y, +Z, -Z');
    WriteLn('  Used for skyboxes, environment maps');
    WriteLn('  glTexImage2D for each face');
    WriteLn;
    WriteLn('Texture arrays:');
    WriteLn('  Multiple layers in one texture object');
    WriteLn('  Efficient for sprite atlases');
    WriteLn('  layer index from vertex shader');

    WriteLn;
    WriteLn('Example completed.');
  finally;
    img.Free;
  end;
end.
