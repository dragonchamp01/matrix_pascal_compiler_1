program SDL2Window;
{$mode objfpc}{$H+}
uses
  SysUtils, sdl2;
var
  win: PSDL_Window;
  screenSurface: PSDL_Surface;
  flags: uint32;
begin
  WriteLn('=== SDL2 Window Demo ===');
  WriteLn;

  WriteLn('Window creation flags:');
  WriteLn('  SDL_WINDOW_FULLSCREEN:       $00000001');
  WriteLn('  SDL_WINDOW_OPENGL:           $00000002');
  WriteLn('  SDL_WINDOW_SHOWN:            $00000004');
  WriteLn('  SDL_WINDOW_HIDDEN:           $00000008');
  WriteLn('  SDL_WINDOW_RESIZABLE:        $00000020');
  WriteLn('  SDL_WINDOW_MINIMIZED:        $00000040');
  WriteLn('  SDL_WINDOW_MAXIMIZED:        $00000080');
  WriteLn('  SDL_WINDOW_BORDERLESS:       $00000100');
  WriteLn('  SDL_WINDOW_FULLSCREEN_DESKTOP: $00001001');
  WriteLn;

  WriteLn('Window set up:');
  WriteLn('  SDL_CreateWindow(''Demo'', 100, 100, 800, 600,');
  WriteLn('    SDL_WINDOW_SHOWN or SDL_WINDOW_RESIZABLE)');
  WriteLn;

  WriteLn('Window operations:');
  WriteLn('  SDL_SetWindowTitle(win, title)');
  WriteLn('  SDL_SetWindowSize(win, w, h)');
  WriteLn('  SDL_SetWindowPosition(win, x, y)');
  WriteLn('  SDL_MaximizeWindow(win)');
  WriteLn('  SDL_MinimizeWindow(win)');
  WriteLn('  SDL_RaiseWindow(win)');
  WriteLn('  SDL_HideWindow(win)');
  WriteLn('  SDL_ShowWindow(win)');
  WriteLn;

  WriteLn('Screen surface (software rendering):');
  WriteLn('  screenSurface := SDL_GetWindowSurface(win)');
  WriteLn('  SDL_FillRect(screenSurface, nil, color)');
  WriteLn('  SDL_UpdateWindowSurface(win)');
  WriteLn;

  WriteLn('Window events:');
  WriteLn('  SDL_WINDOWEVENT_SIZE_CHANGED');
  WriteLn('  SDL_WINDOWEVENT_MINIMIZED / RESTORED');
  WriteLn('  SDL_WINDOWEVENT_FOCUS_GAINED / LOST');
  WriteLn;

  WriteLn('Display info:');
  WriteLn('  SDL_GetNumVideoDisplays(): number of monitors');
  WriteLn('  SDL_GetDisplayBounds(0, @rect): primary res');
  WriteLn;

  WriteLn('Window management best practices:');
  WriteLn('  Use SDL_WINDOW_RESIZABLE for flexible layouts');
  WriteLn('  Handle SDL_WINDOWEVENT for responsive UI');
  WriteLn('  Query display bounds for fullscreen');

  WriteLn;
  WriteLn;
  WriteLn('High DPI support:');
  WriteLn('  SDL_WINDOW_ALLOW_HIGHDPI flag');
  WriteLn('  SDL_GetWindowSize: logical pixels');
  WriteLn('  SDL_GL_GetDrawableSize: actual pixels');
  WriteLn('  On Retina: drawable = 2x window size');
  WriteLn;
  WriteLn('Window flags for specific uses:');
  WriteLn('  Popup menu:   SDL_WINDOW_POPUP_MENU');
  WriteLn('  Tooltip:      SDL_WINDOW_TOOLTIP');
  WriteLn('  Utility:      SDL_WINDOW_UTILITY');
  WriteLn('  Always on top: SDL_WINDOW_ALWAYS_ON_TOP');
  WriteLn;
  WriteLn('Window icon:');
  WriteLn('  SDL_SetWindowIcon(win, surface)');
  WriteLn('  Use 32x32 or 16x16 BMP/PNG icon');

  WriteLn;
  WriteLn('Example completed.');
end.
