program SoundWaveLoad;
{$mode objfpc}{$H+}
uses
  SysUtils, sound, audio;
var
  wav: TSoundSample;
begin
  WriteLn('=== Sound Wave Loading Demo ===');
  WriteLn;

  wav := TSoundSample.Create;
  try
    wav.Load('sound.wav');
    WriteLn('Loaded: sound.wav');
    WriteLn;

    WriteLn('WAV format details:');
    WriteLn('  SampleRate: ', wav.SampleRate, ' Hz');
    WriteLn('  Channels: ', wav.Channels, ' (', wav.Channels, '=mono, 2=stereo)');
    WriteLn('  BitsPerSample: ', wav.BitsPerSample);
    WriteLn('  DataSize: ', wav.DataSize, ' bytes');
    WriteLn('  Duration: ', (wav.DataSize / (wav.SampleRate * wav.Channels * (wav.BitsPerSample div 8))):0:2, ' seconds');
    WriteLn;

    WriteLn('WAV file structure:');
    WriteLn('  RIFF header (4 bytes: "RIFF")');
    WriteLn('  file size (4 bytes)');
    WriteLn('  WAVE identifier (4 bytes: "WAVE")');
    WriteLn('  fmt sub-chunk: format, channels, rate, etc.');
    WriteLn('  data sub-chunk: PCM sample data');
    WriteLn;

    WriteLn('Supported formats:');
    WriteLn('  WAV: standard PCM audio');
    WriteLn('  OGG: Vorbis compressed audio');
    WriteLn('  MP3: MPEG audio (if decoder available)');
    WriteLn;

    WriteLn('Loading other formats:');
    wav.Load('music.ogg');
    WriteLn('  music.ogg:');
    WriteLn('    SampleRate: ', wav.SampleRate, ' Hz');
    WriteLn('    Channels: ', wav.Channels);
    WriteLn('    Duration: ~', (wav.DataSize / (wav.SampleRate * wav.Channels * 2)):0:1, 's (decoded)');
    WriteLn;

    WriteLn('Properties after load:');
    WriteLn('  IsLoaded: ', wav.DataSize > 0);
    WriteLn('  Data: pointer to PCM buffer');
    WriteLn('  DataSize in bytes');

    WriteLn;
    WriteLn;
    WriteLn('Audio data access:');
    WriteLn('  wav.Data: raw PCM buffer access');
    WriteLn('  wav.DataSize: total bytes in buffer');
    WriteLn('  Iterate samples: for i := 0 to (DataSize div 2) - 1');
    WriteLn('    16-bit mono: sample := PSmallIntArray(Data)[i]');
    WriteLn;
    WriteLn('Format conversion:');
    WriteLn('  ConvertToMono: average channels');
    WriteLn('  ConvertToStereo: duplicate channel');
    WriteLn('  Resample: change sample rate');
    WriteLn('  ConvertBitDepth: 8/16/24/32 bit');
    WriteLn;
    WriteLn('Loading from stream:');
    WriteLn('  wav.LoadFromStream(memoryStream)');
    WriteLn('  Useful for embedded resources');
    WriteLn('  Supported: WAV, OGG (if codec available)');

    WriteLn;
    WriteLn;
    WriteLn('VALIDATION: Check IsLoaded before accessing data.');
    WriteLn('  SampleRate=0 or DataSize=0 indicates load failure.');

    WriteLn;
    WriteLn('Example completed.');
  finally;
    wav.Free;
  end;
end.
