program AudioEffects;
{$mode objfpc}{$H+}
uses
  SysUtils, effect, filter_audio;
var
  reverb: TReverbEffect;
  echo: TEchoEffect;
  filter: TAudioFilter;
  i: integer;
  input, output: single;
begin
  WriteLn('=== Audio Effects Demo ===');
  WriteLn;

  reverb := TReverbEffect.Create;
  try
    echo := TEchoEffect.Create(200, 0.5);
    try
      WriteLn('Reverb effect:');
      WriteLn('  Effect type: ', Ord(reverb.EffectType));
      WriteLn('  Room size: ', reverb.RoomSize:0:2, ' (0.0-1.0)');
      WriteLn('  Damping: ', reverb.Damping:0:2, ' (0.0-1.0)');
      WriteLn('  Mix: ', reverb.Mix:0:2, ' (0.0-1.0 wet/dry)');
      WriteLn('  Enabled: ', reverb.Enabled);
      WriteLn;

      reverb.RoomSize := 0.8;
      reverb.Damping := 0.3;
      WriteLn('Adjusted: room=0.8 (large hall), damping=0.3 (bright)');
      WriteLn;

      WriteLn('Echo effect:');
      WriteLn('  Effect type: ', Ord(echo.EffectType));
      WriteLn('  Delay: 200ms');
      WriteLn('  Decay: ', echo.Decay:0:2, ' (echo volume per tap)');
      WriteLn('  Mix: ', echo.Mix:0:2);
      WriteLn('  Enabled: ', echo.Enabled);
      WriteLn;

      WriteLn('Low-pass filter:');
      filter := TAudioFilter.Create(aftLowPass, 1000.0, 0.707, 44100);
      try
        WriteLn('  Filter type: ', Ord(filter.FilterType));
        WriteLn('  Cutoff: ', filter.Cutoff:0:1, ' Hz');
        WriteLn('  Resonance (Q): ', filter.Resonance:0:3);
        WriteLn;

        WriteLn('Filter biquad structure:');
        WriteLn('  y[n] = b0*x[n] + b1*x[n-1] + b2*x[n-2]');
        WriteLn('         - a1*y[n-1] - a2*y[n-2]');
        WriteLn;

        WriteLn('Impulse response (first 10 samples):');
        for i := 0 to 9 do
        begin
          if i = 0 then input := 1.0 else input := 0.0;
          output := filter.Process(input);
          WriteLn('  n=', i:2, ' input=', input:4:1, ' output=', output:8:4);
        end;

        WriteLn;
        filter.Reset;
        WriteLn('Filter coefficients reset.');

        WriteLn;
        WriteLn('Audio effect types:');
        WriteLn('  aeReverb, aeEcho, aeDelay');
        WriteLn('  aeChorus, aeFlanger, aeDistortion');

        WriteLn;
        WriteLn('Filter types:');
        WriteLn('  aftLowPass, aftHighPass, aftBandPass, aftNotch');

        WriteLn;
        WriteLn('Example completed.');
      finally;
        filter.Free;
      end;
    finally;
      echo.Free;
    end;
  finally;
    reverb.Free;
  end;
end.
