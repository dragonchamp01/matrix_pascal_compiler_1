program SoundSynthEnvelope;
{$mode objfpc}{$H+}
uses
  SysUtils, sound, sound_synth;
var
  env: TEnvelope;
  i: integer;
  t: single;
  val: single;
begin
  WriteLn('=== Sound Synthesis Envelope Demo ===');
  WriteLn;

  env := TEnvelope.Create;
  try
    env.Attack := 0.1;
    env.Decay := 0.2;
    env.Sustain := 0.6;
    env.Release := 0.3;

    WriteLn('ADSR envelope parameters:');
    WriteLn('  Attack:  ', env.Attack:0:2, 's (time to peak)');
    WriteLn('  Decay:   ', env.Decay:0:2, 's (time to sustain level)');
    WriteLn('  Sustain: ', env.Sustain:0:2, ' (held level 0.0-1.0)');
    WriteLn('  Release: ', env.Release:0:2, 's (fade to 0 after note off)');
    WriteLn;

    WriteLn('ADSR stages:');
    WriteLn('  - Attack:  amplitude rises from 0 to 1');
    WriteLn('  - Decay:   amplitude falls from 1 to sustain');
    WriteLn('  - Sustain: amplitude held at sustain level');
    WriteLn('  - Release: amplitude fades from sustain to 0');
    WriteLn;

    WriteLn('Envelope value over time (note on at 0s, off at 1.5s):');
    WriteLn('  t(ms)   value   stage');
    WriteLn('  ----------------------------');
    for i := 0 to 24 do
    begin
      t := i * 0.1;
      if t <= 1.5 then
        val := env.GetValue(t, true)
      else
        val := env.GetValue(t - 1.5, false);
      WriteLn('  ', (t * 1000):5:0, '  ', val:6:3);
    end;

    WriteLn;
    WriteLn('Envelope modulation:');
    WriteLn('  Applied to amplitude of oscillator');
    WriteLn('  Shapes the volume contour of a note');
    WriteLn('  Different for each instrument type');
    WriteLn;

    WriteLn('Common envelope presets:');
    WriteLn('  Piano:  fast A, med D, low S, short R');
    WriteLn('  Organ:  slow A, zero D, full S, zero R');
    WriteLn('  Drum:   fast A, fast D, zero S, short R');
    WriteLn('  Pad:    slow A, slow D, high S, long R');

    WriteLn;
    WriteLn;
    WriteLn('Envelope modulation sources:');
    WriteLn('  Velocity: key press speed affects attack');
    WriteLn('  Key follow: pitch affects envelope timing');
    WriteLn('  LFO: low-frequency oscillation modulates env');
    WriteLn;
    WriteLn('ADSR + R (Release) variants:');
    WriteLn('  ADSR: standard four-stage');
    WriteLn('  AHDSR: adds Hold stage between Attack and Decay');
    WriteLn('  ADBDR: Breakpoint for complex shapes');
    WriteLn;
    WriteLn('Visualizing envelopes:');
    WriteLn('  Draw line segments for each stage');
    WriteLn('  X axis: time, Y axis: amplitude');
    WriteLn('  Slopes show transition curves');

    WriteLn;
    WriteLn('Example completed.');
  finally;
    env.Free;
  end;
end.
