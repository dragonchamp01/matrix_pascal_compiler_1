program AnimJointConstraint;
{$mode objfpc}{$H+}
uses
  SysUtils, physics, rigidbody, joint;
var
  world: TPhysicsWorld;
  bodyA, bodyB: TPhysicsBody;
  jnt: TJoint;
  i: integer;
  dist: single;
begin
  WriteLn('=== Joint Constraint Demo ===');
  WriteLn;

  world := TPhysicsWorld.Create;
  try
    bodyA := TPhysicsBody.Create(world, 0.0, 0.0, 10.0);
    bodyB := TPhysicsBody.Create(world, 50.0, 0.0, 10.0);
    world.AddBody(bodyA);
    world.AddBody(bodyB);

    jnt := TJoint.Create(bodyA, bodyB, jtDistance);
    jnt.Stiffness := 50.0;

    WriteLn('Distance joint configuration:');
    WriteLn('  BodyA: pos=(', bodyA.Position.X:0:2, ', ', bodyA.Position.Y:0:2, ') mass=10');
    WriteLn('  BodyB: pos=(', bodyB.Position.X:0:2, ', ', bodyB.Position.Y:0:2, ') mass=10');
    WriteLn('  Rest length: ', jnt.RestLength:0:2);
    WriteLn('  Stiffness: ', jnt.Stiffness:0:2);
    WriteLn;

    WriteLn('Joint force formula:');
    WriteLn('  dx = B.x - A.x;  dy = B.y - A.y');
    WriteLn('  dist = sqrt(dx*dx + dy*dy)');
    WriteLn('  force = (dist - restLength) * stiffness');
    WriteLn('  A += force * (dx/dist, dy/dist)');
    WriteLn('  B -= force * (dx/dist, dy/dist)');
    WriteLn;

    WriteLn('Simulating 1 second with joint constraint:');
    for i := 0 to 10 do
    begin
      if i = 3 then
      begin
        bodyB.ApplyForce(200.0, 0.0);
        WriteLn('  * Force applied to BodyB at t=0.3s');
      end;
      world.Update(0.1);
      jnt.Update(0.1);
      if i mod 2 = 0 then
      begin
        dist := Sqrt(Sqr(bodyB.Position.X - bodyA.Position.X) +
                     Sqr(bodyB.Position.Y - bodyA.Position.Y));
        WriteLn('  t=', (i * 0.1):4:1,
          's A=(', bodyA.Position.X:6:1, ',', bodyA.Position.Y:6:1,
          ') B=(', bodyB.Position.X:6:1, ',', bodyB.Position.Y:6:1,
          ') dist=', dist:5:1);
      end;
    end;

    WriteLn;
    WriteLn('Joint types:');
    WriteLn('  jtDistance:  maintains distance between bodies');
    WriteLn('  jtRevolute:  allows rotation around shared anchor');
    WriteLn('  jtPrismatic: restricts movement along a single axis');

    WriteLn;
    WriteLn;
    WriteLn('Joint constraint parameters:');
    WriteLn('  RestLength: equilibrium distance');
    WriteLn('  Stiffness:  spring constant (higher = more rigid)');
    WriteLn('  Damping:    velocity dissipation');
    WriteLn('  BreakForce: max force before joint breaks');

    WriteLn;
    WriteLn('Example completed.');
  finally;
    world.Free;
  end;
end.
