program AnimPhysicsFall;
{$mode objfpc}{$H+}
uses
  SysUtils, physics, rigidbody, canvas, shapes;
var
  world: TPhysicsWorld;
  bodies: array[0..4] of TPhysicsBody;
  i, j: integer;
begin
  WriteLn('=== Physics Falling Bodies Demo ===');
  WriteLn;

  world := TPhysicsWorld.Create;
  try
    world.GravityX := 0.0;
    world.GravityY := 300.0;

    WriteLn('Gravity set to (', world.GravityX:0:1, ', ', world.GravityY:0:1, ')');
    WriteLn;

    for i := 0 to 4 do
    begin
      bodies[i] := TPhysicsBody.Create(world, 100.0 + i * 80.0, 50.0, 1.0 + i * 2.0);
      bodies[i].Friction := 0.3;
      bodies[i].Restitution := 0.5;
      world.AddBody(bodies[i]);
      WriteLn('  Body', i, ': pos=(', bodies[i].Position.X:6:1, ',',
        bodies[i].Position.Y:6:1, ') mass=', bodies[i].Mass:4:1,
        ' rest=', bodies[i].Restitution:0:2);
    end;

    WriteLn;
    WriteLn('The Euler integration step:');
    WriteLn('  velocity += gravity * dt');
    WriteLn('  position += velocity * dt');
    WriteLn;

    WriteLn('Simulating 5 seconds of free fall:');
    for i := 0 to 5 do
    begin
      world.Update(1.0);
      for j := 0 to 4 do
        WriteLn('  t=', i:1, 's Body', j, ': (',
          bodies[j].Position.X:7:1, ',', bodies[j].Position.Y:7:1,
          ') vel=(', bodies[j].Velocity.X:7:1, ',', bodies[j].Velocity.Y:7:1, ')');
    end;

    WriteLn;
    WriteLn('Physics parameters per body:');
    WriteLn('  Mass:     heavier objects harder to accelerate');
    WriteLn('  Friction: tangential resistance on contact');
    WriteLn('  Restitution: bounciness (0=inelastic, 1=elastic)');
    WriteLn('  BodyType: btDynamic (moves), btStatic (fixed)');
    WriteLn;
    WriteLn('Gravity: (', world.GravityX:0:0, ', ', world.GravityY:0:0, ')');
    WriteLn('Gravity can be changed at runtime or set to 0 for zero-G.');

    WriteLn;
    WriteLn;
    WriteLn('Verlet integration (alternative):');
    WriteLn('  pos = pos + (pos - prevPos) + accel * dt^2');
    WriteLn('  More stable for cloth/rope simulations');
    WriteLn('  Doesn''t require explicit velocity');
    WriteLn;
    WriteLn('Collision response types:');
    WriteLn('  Reflect: bounce off surface');
    WriteLn('  Stick: attach to surface (zero restitution)');
    WriteLn('  Slide: follow surface tangent');
    WriteLn('  Absorb: stop at surface (full damping)');

    WriteLn;
    WriteLn;
    WriteLn('Terminal velocity:');
    WriteLn('  When drag force equals gravity');
    WriteLn('  Velocity stops increasing');
    WriteLn('  Depends on body shape and drag coeff');

    WriteLn;
    WriteLn('Example completed.');
  finally;
    world.Free;
  end;
end.
