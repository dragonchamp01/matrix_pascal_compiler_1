{$mode objfpc}{$H+}
program xml_dom_parse;
uses System, Classes, SysUtils, XML.DOM;
var
  Doc: TXMLDocument;
  Root, Child: TXMLNode;
  I: integer;
  S: string;
  AttrVal: string;
begin
  WriteLn('XML DOM Parsing Demonstration');
  WriteLn('==============================');

  Doc := TXMLDocument.Create('root');
  try
    Doc.LoadFromString(
      '<?xml version="1.0" encoding="UTF-8"?>' +
      '<catalog>' +
      '  <book id="bk101" category="fiction">' +
      '    <author>John Doe</author>' +
      '    <title>XML Programming Guide</title>' +
      '    <price currency="USD">39.95</price>' +
      '    <year>2024</year>' +
      '  </book>' +
      '  <book id="bk102" category="non-fiction">' +
      '    <author>Jane Smith</author>' +
      '    <title>Advanced XML Techniques</title>' +
      '    <price currency="USD">49.95</price>' +
      '    <year>2025</year>' +
      '  </book>' +
      '  <book id="bk103" category="reference">' +
      '    <author>Bob Wilson</author>' +
      '    <title>XML Schema Reference</title>' +
      '    <price currency="EUR">59.95</price>' +
      '    <year>2026</year>' +
      '  </book>' +
      '</catalog>'
    );
    WriteLn('XML document loaded and parsed');
    WriteLn;

    WriteLn('Document info:');
    WriteLn('  Root node: ', Doc.NodeName);
    WriteLn('  Version: ', Doc.Version);
    WriteLn('  Encoding: ', Doc.Encoding);
    WriteLn('  Child count: ', Doc.ChildNodes.Count);
    WriteLn;

    Root := Doc.FindElement('catalog');
    if Assigned(Root) then
    begin
      WriteLn('Catalog root element found');
      WriteLn('  Children: ', Root.ChildNodes.Count);
      WriteLn;

      for I := 0 to Root.ChildNodes.Count - 1 do
      begin
        Child := TXMLNode(Root.ChildNodes[I]);
        if Child.NodeType = ntElement then
        begin
          AttrVal := Child.GetAttribute('id');
          S := Child.NodeName;
          WriteLn('  Element ', I, ': "', S, '" id="', AttrVal, '"');
          WriteLn('    Category: ', Child.GetAttribute('category'));
        end;
      end;

      WriteLn;
      WriteLn('FindElement search:');
      Child := Root.FindElement('book');
      if Assigned(Child) then
        WriteLn('  First book id: ', Child.GetAttribute('id'));

      FoundList := Root.FindElements('book');
      if Assigned(FoundList) then
      begin
        WriteLn('  Total books: ', FoundList.Count);
        FoundList.Free;
      end;
    end;

    WriteLn;
    WriteLn('Full XML:');
    WriteLn(Doc.XML);
  finally
    Doc.Free;
  end;
end.
