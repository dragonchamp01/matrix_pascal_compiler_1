{$mode objfpc}{$H+}
program directory_delete;
uses System, Classes, SysUtils, fileutils;
var
  Dir: string;
  I: integer;
begin
  Dir := '/tmp/matrix_delete_test';

  if TFileUtils.DirectoryExists(Dir) then
    TFileUtils.RemoveDirectory(Dir);

  TFileUtils.CreateDirectory(Dir);
  for I := 1 to 5 do
    TFileUtils.WriteAllText(Dir + '/file' + IntToStr(I) + '.tmp',
      'Temporary file number ' + IntToStr(I));

  TFileUtils.CreateDirectory(Dir + '/sub1');
  TFileUtils.WriteAllText(Dir + '/sub1/nested.tmp', 'Nested temp file');

  TFileUtils.CreateDirectory(Dir + '/sub2');

  TFileUtils.CreateDirectory(Dir + '/sub1/deep');
  TFileUtils.WriteAllText(Dir + '/sub1/deep/deep.tmp', 'Deeply nested');

  WriteLn('Directory Deletion Demonstration');
  WriteLn('=================================');
  WriteLn('Created test structure in: ', Dir);
  WriteLn('  Files: 5 top-level, 2 nested');
  WriteLn('  Dirs: sub1, sub2, sub1/deep');

  WriteLn;
  WriteLn('Step 1 - Delete individual files:');
  for I := 1 to 3 do
  begin
    if TFileUtils.DeleteFile(Dir + '/file' + IntToStr(I) + '.tmp') then
      WriteLn('  Deleted file', I, '.tmp');
  end;

  WriteLn;
  WriteLn('Step 2 - Remove empty subdirectory:');
  if TFileUtils.RemoveDirectory(Dir + '/sub2') then
    WriteLn('  Removed sub2 (empty)');

  WriteLn;
  WriteLn('Step 3 - file existence checks:');
  for I := 1 to 5 do
    WriteLn('  file', I, '.tmp exists: ',
      TFileUtils.FileExists(Dir + '/file' + IntToStr(I) + '.tmp'));

  WriteLn;
  WriteLn('Step 4 - Directory cleanup:');
  TFileUtils.DeleteFile(Dir + '/sub1/deep/deep.tmp');
  TFileUtils.DeleteFile(Dir + '/sub1/nested.tmp');
  TFileUtils.DeleteFile(Dir + '/file4.tmp');
  TFileUtils.DeleteFile(Dir + '/file5.tmp');
  TFileUtils.RemoveDirectory(Dir + '/sub1/deep');
  TFileUtils.RemoveDirectory(Dir + '/sub1');
  if TFileUtils.RemoveDirectory(Dir) then
    WriteLn('  Removed base directory');

  WriteLn;
  WriteLn('final check:');
  WriteLn('  Directory exists: ', TFileUtils.DirectoryExists(Dir));

  WriteLn;
  WriteLn('DeleteFile on nonexistent file:');
  if not TFileUtils.DeleteFile('/tmp/nonexistent_file_xyz') then
    WriteLn('  Returns false (expected)');

  WriteLn;
  WriteLn('RemoveDirectory on nonexistent dir:');
  if not TFileUtils.RemoveDirectory('/tmp/nonexistent_dir_xyz') then
    WriteLn('  Returns false (expected)');

  WriteLn;
  WriteLn('Creating directory for delete test then deleting:');
  TFileUtils.CreateDirectory('/tmp/quick_test_dir');
  WriteLn('  Created: ', TFileUtils.DirectoryExists('/tmp/quick_test_dir'));
  TFileUtils.RemoveDirectory('/tmp/quick_test_dir');
  WriteLn('  Deleted: ', not TFileUtils.DirectoryExists('/tmp/quick_test_dir'));
end.
