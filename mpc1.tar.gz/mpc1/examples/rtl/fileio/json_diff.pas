{$mode objfpc}{$H+}
program json_diff;
uses System, Classes, SysUtils, JSON.Diff;
var
  Source, Target: string;
  Patches: TList;
  Merged: string;
  I: integer;
  Patch: TJSONPatch;
  OpStr: string;
begin
  WriteLn('JSON Diff/Patch/Merge Demonstration');
  WriteLn('=====================================');

  WriteLn;
  WriteLn('1. Diff two JSON objects:');
  Source := '{"name":"John","age":30,"city":"New York","hobbies":["reading"]}';
  Target := '{"name":"John","age":31,"city":"Boston","hobbies":["reading","swimming"]}';

  Patches := TJSONDiff.Diff(Source, Target);
  try
    WriteLn('   Source: ', Source);
    WriteLn('   Target: ', Target);
    WriteLn;
    WriteLn('   Patches (', Patches.Count, '):');
    for I := 0 to Patches.Count - 1 do
    begin
      Patch := TJSONPatch(Patches[I]);
      case Patch.Op of
        jdAdd:    OpStr := 'ADD';
        jdRemove: OpStr := 'REMOVE';
        jdReplace:OpStr := 'REPLACE';
      end;
      WriteLn('     ', OpStr, ' ', Patch.Path, ' = "', Patch.Value, '"');
    end;
  finally
    Patches.Free;
  end;

  WriteLn;
  WriteLn('2. Patch application:');
  Patches := TJSONDiff.Diff(Source, Target);
  try
    Merged := TJSONDiff.Apply(Source, Patches);
    WriteLn('   Original: ', Source);
    WriteLn('   Patched:  ', Merged);
    WriteLn('   Expected: ', Target);
  finally
    Patches.Free;
  end;

  WriteLn;
  WriteLn('3. Three-way merge:');
  Merged := TJSONDiff.Merge('{"a":1}', '{"a":2}', '{"a":3}');
  WriteLn('   Base:   {"a":1}');
  WriteLn('   local:  {"a":2}');
  WriteLn('   Remote: {"a":3}');
  WriteLn('   Merge:  ', Merged);

  WriteLn;
  WriteLn('4. Identical objects:');
  Source := '{"x":1,"y":2}';
  Patches := TJSONDiff.Diff(Source, Source);
  try
    WriteLn('   Diff identical: ', Patches.Count, ' patches (expected 0)');
  finally
    Patches.Free;
  end;

  WriteLn;
  WriteLn('5. Nested diff:');
  Source := '{"a":{"b":{"c":1}}}';
  Target := '{"a":{"b":{"c":2,"d":3}}}';
  Patches := TJSONDiff.Diff(Source, Target);
  try
    WriteLn('   Nested patches: ', Patches.Count);
    for I := 0 to Patches.Count - 1 do
    begin
      Patch := TJSONPatch(Patches[I]);
      case Patch.Op of
        jdAdd:    OpStr := 'ADD';
        jdRemove: OpStr := 'REMOVE';
        jdReplace:OpStr := 'REPLACE';
      end;
      WriteLn('     ', OpStr, ' ', Patch.Path, ' = ', Patch.Value);
    end;
  finally
    Patches.Free;
  end;
end.
