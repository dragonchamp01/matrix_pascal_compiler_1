{$mode objfpc}{$H+}
program json_schema_validate;
uses System, Classes, SysUtils, JSON.Schema;
var
  Schema: TJSONSchema;
  Errors: TStringList;
  I: integer;
begin
  WriteLn('JSON Schema Validation');
  WriteLn('=======================');

  Schema := TJSONSchema.Create;
  try
    Schema.LoadFromString(
      '{"type":"object","properties":{' +
      '"name":{"type":"string"},' +
      '"age":{"type":"integer","minimum":0,"maximum":150},' +
      '"email":{"type":"string","pattern":"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$"},' +
      '"active":{"type":"boolean"},' +
      '"score":{"type":"number","minimum":0,"maximum":100}' +
      '},"required":["name","email"]}'
    );
    WriteLn('Schema loaded successfully');
    WriteLn;

    WriteLn('Test Case 1 - Valid object:');
    if Schema.Validate('{"name":"John","age":30,"email":"john@example.com","active":true,"score":85.5}') then
      WriteLn('  PASS')
    else
    begin
      WriteLn('  FAIL');
      Errors := Schema.GetErrors;
      for I := 0 to Errors.Count - 1 do
        WriteLn('    Error: ', Errors[I]);
    end;

    WriteLn;
    WriteLn('Test Case 2 - Missing required email:');
    if Schema.Validate('{"name":"Alice"}') then
      WriteLn('  PASS (unexpected)')
    else
    begin
      WriteLn('  FAIL (expected)');
      Errors := Schema.GetErrors;
      for I := 0 to Errors.Count - 1 do
        WriteLn('    Error: ', Errors[I]);
    end;

    WriteLn;
    WriteLn('Test Case 3 - Invalid age (negative):');
    if Schema.Validate('{"name":"Bob","age":-5,"email":"bob@test.com"}') then
      WriteLn('  PASS (unexpected)')
    else
    begin
      WriteLn('  FAIL (expected)');
      Errors := Schema.GetErrors;
      for I := 0 to Errors.Count - 1 do
        WriteLn('    Error: ', Errors[I]);
    end;

    WriteLn;
    WriteLn('Test Case 4 - Invalid email format:');
    if Schema.Validate('{"name":"Bob","age":25,"email":"not-an-email"}') then
      WriteLn('  PASS (unexpected)')
    else
    begin
      WriteLn('  FAIL (expected)');
      Errors := Schema.GetErrors;
      for I := 0 to Errors.Count - 1 do
        WriteLn('    Error: ', Errors[I]);
    end;

    WriteLn;
    WriteLn('Test Case 5 - Wrong type (number instead of string):');
    if Schema.Validate('{"name":123,"email":"test@test.com"}') then
      WriteLn('  PASS')
    else
      WriteLn('  FAIL (expected type mismatch)');
  finally
    Schema.Free;
  end;
end.
