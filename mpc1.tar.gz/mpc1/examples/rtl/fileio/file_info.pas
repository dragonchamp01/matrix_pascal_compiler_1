{$mode objfpc}{$H+}
program file_info;
uses System, Classes, SysUtils, fileutils;
var
  FileName: string;
  SearchRec: TSearchRec;
  TempFile: string;
  I: integer;
begin
  FileName := ParamStr(0);
  WriteLn('file Information Utility');
  WriteLn('========================');
  WriteLn('Examining: ', FileName);
  WriteLn;

  if TFileUtils.FileExists(FileName) then
  begin
    WriteLn('Basic Info:');
    WriteLn('  file exists: Yes');
    WriteLn('  Size: ', TFileUtils.GetFileSize(FileName), ' bytes');
    WriteLn('  Modified: ', DateTimeToStr(TFileUtils.GetFileDate(FileName)));
    WriteLn('  Extension: ', TFileUtils.GetFileExtension(FileName));
    WriteLn('  file name: ', TFileUtils.GetFileName(FileName));
    WriteLn('  file path: ', TFileUtils.GetFilePath(FileName));
    WriteLn('  Hash (simple): ', TFileUtils.GetFileHash(FileName));
  end;

  WriteLn;
  WriteLn('Detailed info via SearchRec:');
  if FindFirst(FileName, faAnyFile, SearchRec) = 0 then
  begin
    WriteLn('  name: ', SearchRec.name);
    WriteLn('  Size: ', SearchRec.Size, ' bytes');
    WriteLn('  Attributes: $', HexStr(SearchRec.Attr, 4));
    WriteLn('  Modified: ', DateTimeToStr(FileDateToDateTime(SearchRec.Time)));

    write('  Flags: ');
    if (SearchRec.Attr and faReadOnly)  = faReadOnly  then write('readonly ');
    if (SearchRec.Attr and faHidden)    = faHidden    then write('Hidden ');
    if (SearchRec.Attr and faSysFile)   = faSysFile   then write('System ');
    if (SearchRec.Attr and faDirectory) = faDirectory then write('Directory ');
    if (SearchRec.Attr and faArchive)   = faArchive   then write('Archive ');
    if (SearchRec.Attr and faSymLink)   = faSymLink   then write('SymLink ');
    WriteLn;

    FindClose(SearchRec);
  end;

  WriteLn;
  WriteLn('Comparison & Hash:');
  if TFileUtils.CompareFiles(FileName, FileName) then
    WriteLn('  self-comparison: files are IDENTICAL');

  WriteLn;
  WriteLn('Multiple file sizes:');
  WriteLn('  Current file: ', TFileUtils.GetFileSize(FileName), ' bytes');
  if TFileUtils.FileExists('/etc/hostname') then
  begin
    WriteLn('  /etc/hostname: ', TFileUtils.GetFileSize('/etc/hostname'), ' bytes');
    WriteLn('  /etc/hostname content: "', Trim(TFileUtils.ReadAllText('/etc/hostname')), '"');
  end;
  WriteLn('  Nonexistent file size: ', TFileUtils.GetFileSize('/nonexistent'), ' bytes');

  WriteLn;
  WriteLn('Utility methods:');
  WriteLn('  Temp directory: ', TFileUtils.GetTempDir);
  WriteLn('  Generated temp filenames:');
  for I := 1 to 3 do
    WriteLn('    ', TFileUtils.GetTempFile('mp_'));

  WriteLn;
  WriteLn('Extension operations:');
  WriteLn('  Current ext: ', TFileUtils.GetFileExtension(FileName));
  WriteLn('  Change to .bak: ', TFileUtils.ChangeExtension(FileName, '.bak'));
  WriteLn('  Remove ext: ', TFileUtils.ChangeExtension(FileName, ''));
end.
