{
  Matrix Pascal - RTL Example
  parallel_task.pas — TTask from parallel unit
}
{$mode objfpc}{$H+}
program parallel_task;

uses
  System, Classes, SysUtils, threading, parallel.task;

type
  TMyTask = class(TTask)
  protected
    procedure Execute; override;
  public
    constructor Create(TaskProc: TProc; const AName: string = '');
  end;

var
  Task1, Task2: TMyTask;
  Results: array[1..2] of string;

constructor TMyTask.Create(TaskProc: TProc; const AName: string);
begin
  inherited Create(TaskProc, AName);
end;

procedure TMyTask.Execute;
var
  I: integer;
begin
  for I := 1 to 5 do
  begin
    if Terminated then exit;
    WriteLn('  Task ', name, ' executing step ', I);
    Sleep(50);
  end;
  WriteLn('  Task ', name, ' completed.');
end;

begin
  WriteLn('Parallel Task Example');
  WriteLn('=====================');

  Task1 := TMyTask.Create(nil, 'ComputeTask');
  Task2 := TMyTask.Create(nil, 'IOTask');

  WriteLn('Starting parallel tasks...');
  Task1.Start;
  Task2.Start;

  WriteLn('Main thread is free during task execution...');
  Sleep(100);

  Task1.WaitFor;
  Task2.WaitFor;

  Task1.Free;
  Task2.Free;

  WriteLn;

  WriteLn;
  WriteLn('--- Additional Threading/Prallel Details ---');
  WriteLn('Threading unit provides:');
  WriteLn('  - TThread: base class with status tracking');
  WriteLn('  - TMutex: mutual exclusion for critical sections');
  WriteLn('  - TSemaphore: counting semaphore for resource limiting');
  WriteLn('  - TEvent: event signaling with auto/manual reset');
  WriteLn('  - TAtomic: atomic increment/decrement/exchange');
  WriteLn('  - TThreadPool: pool of reusable worker threads');
  WriteLn('  - TParallel: parallel for/forEach loops');
  WriteLn('  - TTask: simple async task execution');
  WriteLn;
  WriteLn('Parallel unit adds:');
  WriteLn('  - TThreadPool: configurable with min/max threads');
  WriteLn('  - TFuture: async result with wait capability');
  WriteLn('  - Barriers, spinlocks, RW locks');
  WriteLn('  - Parallel sort algorithms');
  WriteLn('  - Atomic operations with memory ordering');
  WriteLn('  - Work stealing and load balancing');
end.
