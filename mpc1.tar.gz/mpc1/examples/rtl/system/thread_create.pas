{
  Matrix Pascal - RTL Example
  thread_create.pas — Basic thread creation
}
{$mode objfpc}{$H+}
program thread_create;

uses
  System, Classes, SysUtils, threading;

type
  TMyThread = class(TThread)
  protected
    procedure Execute; override;
  end;

var
  Threads: array[1..5] of TMyThread;
  I: integer;

procedure TMyThread.Execute;
var
  J: integer;
begin
  for J := 1 to 5 do
  begin
    if Terminated then exit;
    WriteLn('  Thread ', name, ' iteration ', J);
    Sleep(100);
  end;
  ReturnValue := 42;
end;

begin
  WriteLn('Thread Creation Example');
  WriteLn('=======================');

  for I := 1 to 5 do
  begin
    Threads[I] := TMyThread.Create('Worker_' + IntToStr(I));
    WriteLn('Created thread: ', Threads[I].name);
  end;

  WriteLn;
  WriteLn('Starting all threads...');
  for I := 1 to 5 do
    Threads[I].Start;

  WriteLn('Waiting for threads to finish...');
  for I := 1 to 5 do
  begin
    Threads[I].WaitFor;
    WriteLn('Thread ', Threads[I].name, ' finished with ReturnValue: ', Threads[I].ReturnValue);
  end;

  for I := 1 to 5 do
    Threads[I].Free;

  WriteLn;

  WriteLn;
  WriteLn('--- Additional Threading/Prallel Details ---');
  WriteLn('Threading unit provides:');
  WriteLn('  - TThread: base class with status tracking');
  WriteLn('  - TMutex: mutual exclusion for critical sections');
  WriteLn('  - TSemaphore: counting semaphore for resource limiting');
  WriteLn('  - TEvent: event signaling with auto/manual reset');
  WriteLn('  - TAtomic: atomic increment/decrement/exchange');
  WriteLn('  - TThreadPool: pool of reusable worker threads');
  WriteLn('  - TParallel: parallel for/forEach loops');
  WriteLn('  - TTask: simple async task execution');
  WriteLn;
  WriteLn('Parallel unit adds:');
  WriteLn('  - TThreadPool: configurable with min/max threads');
  WriteLn('  - TFuture: async result with wait capability');
  WriteLn('  - Barriers, spinlocks, RW locks');
  WriteLn('  - Parallel sort algorithms');
  WriteLn('  - Atomic operations with memory ordering');
  WriteLn('  - Work stealing and load balancing');
end.
