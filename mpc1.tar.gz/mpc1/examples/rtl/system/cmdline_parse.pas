{
  Matrix Pascal - RTL Example
  cmdline_parse.pas — Command line parsing
}
{$mode objfpc}{$H+}
program cmdline_parse;

uses
  System, Classes, SysUtils, SysUtils.CmdLine;

var
  Cmd: TCmdLine;
  I: integer;
  Opts: TStringList;
begin
  WriteLn('Command Line Parsing Example');
  WriteLn('=============================');
  WriteLn;

  Cmd := TCmdLine.Create;
  Opts := TStringList.Create;
  try
    WriteLn('Created TCmdLine parser.');
    WriteLn;

    WriteLn('Argument count: ', Cmd.ArgumentCount);
    WriteLn;
    WriteLn('Arguments:');
    for I := 0 to Cmd.ArgumentCount - 1 do
      WriteLn('  Arg[', I, '] = ', Cmd.GetArgument(I));
    WriteLn;

    WriteLn('Options:');
    if Cmd.HasOption('help') then
      WriteLn('  --help is present');
    if Cmd.HasOption('v') then
      WriteLn('  -v is present');

    WriteLn;
    WriteLn('Option values:');
    WriteLn('  config: ', Cmd.GetOptionValue('config', '(default: config.ini)'));
    WriteLn('  output: ', Cmd.GetOptionValue('output', '(default: stdout)'));
    WriteLn('  level: ', Cmd.GetOptionValue('level', 'info'));
    WriteLn;

    WriteLn('All parsed options:');
    Opts := Cmd.GetOptions;
    for I := 0 to Opts.Count - 1 do
      WriteLn('  ', Opts[I]);
    WriteLn;

    WriteLn('Available query methods:');
    WriteLn('  HasOption: Check if option exists');
    WriteLn('  GetOptionValue: Get option value with default');
    WriteLn('  GetArgument: Access positional arguments');
    WriteLn('  ArgumentCount: Number of positional args');
    WriteLn('  GetOptions: Get all options as string list');
    WriteLn('  PrintHelp: Display formatted help');
  finally
    Opts.Free;
    Cmd.Free;
  end;

  WriteLn;

  WriteLn;
  WriteLn('--- Additional Details ---');
  WriteLn('Command line parsing with TCmdLine:');
  WriteLn('  - Automatic option parsing from ParamStr');
  WriteLn('  - Named option support (--name value)');
  WriteLn('  - boolean flag detection (--flag)');
  WriteLn('  - default values for optional options');
  WriteLn('  - Positional argument access by index');
  WriteLn('  - Help text generation via PrintHelp');
  WriteLn;
  WriteLn('Configuration management:');
  WriteLn('  - TConfig: key-value configuration store');
  WriteLn('  - TIniFile: Windows-compatible INI file format');
  WriteLn('  - TRegistry: registry-like key/value store');
  WriteLn('  - LoadFromFile/SaveToFile for persistence');
  WriteLn('  - type-safe getters: GetString, GetInteger, GetBool');
  WriteLn('  - Section-based organization (INI)');
  WriteLn('  - Key enumeration and deletion');
  WriteLn('  - Works on Linux with simulated registry');
end.
