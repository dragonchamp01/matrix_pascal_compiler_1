{
  Matrix Pascal - RTL Example
  crypto_rsa_sign.pas — RSA digital signing
}
{$mode objfpc}{$H+}
program crypto_rsa_sign;

uses
  System, Classes, SysUtils, Crypto.RSA;

var
  RSA: TRSA;
  KeyPair: TRSAKeyPair;
  Data: TBytes;
  Signature: TBytes;
  I: integer;
begin
  WriteLn('RSA Digital Signature Example');
  WriteLn('==============================');

  WriteLn('Generating RSA-2048 key pair...');
  KeyPair := TRSA.GenerateKeyPair(rs2048);

  RSA := TRSA.Create(rs2048);
  try
    RSA.LoadPrivateKey(KeyPair.PrivateKey);
    RSA.LoadPublicKey(KeyPair.PublicKey);

    Data := TEncoding.UTF8.GetBytes('Important document to sign');

    WriteLn('Data to sign: Important document to sign');
    WriteLn;

    Signature := RSA.Sign(Data);
    write('  Signature: ');
    for I := 0 to Length(Signature) - 1 do
      write(IntToHex(Signature[I], 2));
    WriteLn;
    WriteLn('  Signature length: ', Length(Signature), ' bytes');
    WriteLn;

    WriteLn('Signature created successfully.');
    WriteLn('Now verifying the signature...');
    WriteLn;

    if RSA.Verify(Data, Signature) then
      WriteLn('Signature verification: VALID')
    else
      WriteLn('Signature verification: INVALID');

    WriteLn;
    WriteLn('Test with tampered data:');
    Data[0] := Data[0] xor $FF;
    if RSA.Verify(Data, Signature) then
      WriteLn('Tampered verification: VALID (should not happen)')
    else
      WriteLn('Tampered verification: INVALID (correctly detected)');
  finally
    RSA.Free;
  end;

  WriteLn;

  WriteLn;
  WriteLn('--- Additional Cryptographic Details ---');
  WriteLn('matrix pascal RTL Crypto unit provides:');
  WriteLn('  - Hash algorithms: MD5, SHA1, SHA256, SHA384, SHA512, RIPEMD160');
  WriteLn('  - Symmetric encryption: AES (ECB/CBC/CFB/OFB/CTR/GCM)');
  WriteLn('  - Asymmetric crypto: RSA (1024/2048/4096), ECC (secp256r1/p384/p521/Curve25519)');
  WriteLn('  - Key derivation: PBKDF2, bcrypt, scrypt, argon2');
  WriteLn('  - message authentication: HMAC (MD5/SHA1/SHA256/SHA512)');
  WriteLn('  - Random generation: cryptographically secure');
  WriteLn('  - Certificate handling: X.509 with PEM serialization');
  WriteLn('  - TLS support available in Crypto.TLS');
  WriteLn('  - Additional ciphers: Blowfish, Twofish, DES, 3DES');
  WriteLn('  - Stream ciphers: ChaCha20, Salsa20, RC4');
  WriteLn('  - Authenticated encryption: Poly1305');
  WriteLn('  - Key exchange: Diffie-Hellman, ECDH');
  WriteLn('  - Digital signatures: RSA-PSS, ECDSA, Ed25519');
  WriteLn;
  WriteLn('All cryptographic operations use TBytes for type safety.');
  WriteLn('string overloads are provided for convenience.');
  WriteLn('Streaming APIs available for large data processing.');
end.
