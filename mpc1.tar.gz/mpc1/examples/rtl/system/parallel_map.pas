{
  Matrix Pascal - RTL Example
  parallel_map.pas — Parallel map operation
}
{$mode objfpc}{$H+}
program parallel_map;

uses
  System, Classes, SysUtils, threading, parallel.thread_pool;

type
  TMapFunc = function(Value: integer): integer;

var
  InputValues, OutputValues: array[1..50] of integer;
  I: integer;
  pool: TThreadPool;

function Square(Value: integer): integer;
begin
  Result := Value * Value;
end;

procedure MapTask(Data: pointer);
var
  Idx: integer;
begin
  Idx := PInteger(Data)^;
  OutputValues[Idx] := Square(InputValues[Idx]);
  WriteLn('  Mapped index ', Idx, ': ', InputValues[Idx], ' -> ', OutputValues[Idx]);
end;

begin
  WriteLn('Parallel Map Operation');
  WriteLn('======================');

  for I := 1 to 50 do
    InputValues[I] := I;

  pool := TThreadPool.Create;
  try
    WriteLn('Mapping square function over 50 elements...');
    WriteLn;

    for I := 1 to 50 do
      pool.QueueTask(@MapTask, @I);

    pool.Start;
    pool.WaitForAll;

    WriteLn;
    WriteLn('Results:');
    WriteLn('  Input[1] = 1, Output[1] = ', OutputValues[1]);
    WriteLn('  Input[10] = 10, Output[10] = ', OutputValues[10]);
    WriteLn('  Input[50] = 50, Output[50] = ', OutputValues[50]);
  finally
    pool.Free;
  end;


  WriteLn;
  WriteLn('--- Additional Threading/Prallel Details ---');
  WriteLn('Threading unit provides:');
  WriteLn('  - TThread: base class with status tracking');
  WriteLn('  - TMutex: mutual exclusion for critical sections');
  WriteLn('  - TSemaphore: counting semaphore for resource limiting');
  WriteLn('  - TEvent: event signaling with auto/manual reset');
  WriteLn('  - TAtomic: atomic increment/decrement/exchange');
  WriteLn('  - TThreadPool: pool of reusable worker threads');
  WriteLn('  - TParallel: parallel for/forEach loops');
  WriteLn('  - TTask: simple async task execution');
  WriteLn;
  WriteLn('Parallel unit adds:');
  WriteLn('  - TThreadPool: configurable with min/max threads');
  WriteLn('  - TFuture: async result with wait capability');
  WriteLn('  - Barriers, spinlocks, RW locks');
  WriteLn('  - Parallel sort algorithms');
  WriteLn('  - Atomic operations with memory ordering');
  WriteLn('  - Work stealing and load balancing');
end.
