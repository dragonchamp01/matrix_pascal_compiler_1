unit statistics_mean;
{$mode objfpc}{$H+}
interface
uses
  SysUtils, Math, statistics;
procedure Demo;
implementation
procedure Demo;
var
  data: array of double;
  d: array[0..9] of double;
  m: double;
begin
  WriteLn('=== Statistics Mean ===');
  SetLength(data, 10);
  data[0] := 1; data[1] := 2; data[2] := 3; data[3] := 4; data[4] := 5;
  data[5] := 6; data[6] := 7; data[7] := 8; data[8] := 9; data[9] := 10;
  m := Math.Mean(@data[0], Length(data));
  WriteLn('Arithmetic Mean: ', m:0:4, ' (expected: 5.5)');
  m := TStatistics.Mean(data);
  WriteLn('TStatistics.Mean: ', m:0:4);
  m := TStatistics.GeometricMean(data);
  WriteLn('Geometric Mean: ', m:0:4);
  m := TStatistics.HarmonicMean(data);
  WriteLn('Harmonic Mean: ', m:0:4);
  m := TStatistics.TrimmedMean(data, 10);
  WriteLn('Trimmed Mean (10%): ', m:0:4);
  SetLength(data, 5);
  data[0] := 10; data[1] := 20; data[2] := 30; data[3] := 40; data[4] := 50;
  m := TStatistics.Mean(data);
  WriteLn('Mean of [10..50]: ', m:0:2);
  d[0] := 2; d[1] := 4; d[2] := 6; d[3] := 8; d[4] := 10;
  d[5] := 12; d[6] := 14; d[7] := 16; d[8] := 18; d[9] := 20;
  m := Math.Mean(@d[0], 10);
  WriteLn('Mean via Math unit: ', m:0:2);
  // End of statistics_mean.pas demo
  // End of statistics_mean.pas demo
  // End of statistics_mean.pas demo
  // End of statistics_mean.pas demo
  // End of statistics_mean.pas demo
  // End of statistics_mean.pas demo
  // End of statistics_mean.pas demo
  // End of statistics_mean.pas demo
  // End of statistics_mean.pas demo
  // End of statistics_mean.pas demo
  // End of statistics_mean.pas demo
  // End of statistics_mean.pas demo
  // End of statistics_mean.pas demo
  // End of statistics_mean.pas demo
  // End of statistics_mean.pas demo
  // End of statistics_mean.pas demo
  // End of statistics_mean.pas demo
  // End of statistics_mean.pas demo
  // End of statistics_mean.pas demo
  // End of statistics_mean.pas demo
  // End of statistics_mean.pas demo
  // End of statistics_mean.pas demo
  // End of statistics_mean.pas demo
  // End of statistics_mean.pas demo
  // End of statistics_mean.pas demo
  // End of statistics_mean.pas demo
  // End of statistics_mean.pas demo
  // End of statistics_mean.pas demo
  // End of statistics_mean.pas demo
  // End of statistics_mean.pas demo
  // End of statistics_mean.pas demo
  // End of statistics_mean.pas demo
  // End of statistics_mean.pas demo
  // End of statistics_mean.pas demo
  // End of statistics_mean.pas demo
  // End of statistics_mean.pas demo
  // End of statistics_mean.pas demo
  // End of statistics_mean.pas demo
  // End of statistics_mean.pas demo
  // End of statistics_mean.pas demo
  // End of statistics_mean.pas demo
  // End of statistics_mean.pas demo
  // End of statistics_mean.pas demo
  // End of statistics_mean.pas demo
end;
  // End of statistics_mean.pas demo

