unit linalg_matrix_inverse;
{$mode objfpc}{$H+}
interface
uses
  SysUtils, Math;
procedure Demo;
implementation
procedure PrintMat3(const M: TTMatrix3; const name: string);
begin
  WriteLn(name, ':');
  WriteLn(Math.Mat3Get(M,0,0):0:4, ' ', Math.Mat3Get(M,0,1):0:4, ' ', Math.Mat3Get(M,0,2):0:4);
  WriteLn(Math.Mat3Get(M,1,0):0:4, ' ', Math.Mat3Get(M,1,1):0:4, ' ', Math.Mat3Get(M,1,2):0:4);
  WriteLn(Math.Mat3Get(M,2,0):0:4, ' ', Math.Mat3Get(M,2,1):0:4, ' ', Math.Mat3Get(M,2,2):0:4);
end;
procedure PrintMat4(const M: TTMatrix4; const name: string);
begin
  WriteLn(name, ':');
  WriteLn(Math.Mat4Get(M,0,0):0:4, ' ', Math.Mat4Get(M,0,1):0:4, ' ', Math.Mat4Get(M,0,2):0:4, ' ', Math.Mat4Get(M,0,3):0:4);
  WriteLn(Math.Mat4Get(M,1,0):0:4, ' ', Math.Mat4Get(M,1,1):0:4, ' ', Math.Mat4Get(M,1,2):0:4, ' ', Math.Mat4Get(M,1,3):0:4);
  WriteLn(Math.Mat4Get(M,2,0):0:4, ' ', Math.Mat4Get(M,2,1):0:4, ' ', Math.Mat4Get(M,2,2):0:4, ' ', Math.Mat4Get(M,2,3):0:4);
  WriteLn(Math.Mat4Get(M,3,0):0:4, ' ', Math.Mat4Get(M,3,1):0:4, ' ', Math.Mat4Get(M,3,2):0:4, ' ', Math.Mat4Get(M,3,3):0:4);
end;
procedure Demo;
var
  M, Inv: TTMatrix3;
  M4, Inv4, Check: TTMatrix4;
begin
  WriteLn('=== matrix Inverse ===');
  M.Col0 := Math.Vec3(4, 3, 2);
  M.Col1 := Math.Vec3(3, 4, 3);
  M.Col2 := Math.Vec3(2, 3, 4);
  PrintMat3(M, 'matrix M');
  WriteLn('Det(M): ', Math.Mat3Det(M):0:4);
  Inv := Math.Mat3Inverse(M);
  PrintMat3(Inv, 'Inverse');
  WriteLn('M * Inv should be I:');
  PrintMat3(Math.Mat3Mul(M, Inv), 'Check');
  M4 := Math.Mat4Identity;
  M4.Col0 := Math.Vec4(1, 0, 0, 0);
  M4.Col1 := Math.Vec4(0, 2, 0, 0);
  M4.Col2 := Math.Vec4(0, 0, 3, 0);
  M4.Col3 := Math.Vec4(0, 0, 0, 4);
  Inv4 := Math.Mat4Inverse(M4);
  PrintMat4(Inv4, 'Inverse of diag(1,2,3,4)');
  Check := Math.Mat4Mul(M4, Inv4);
  PrintMat4(Check, 'Should be Identity');
  // End of linalg_matrix_inverse.pas demo
  // End of linalg_matrix_inverse.pas demo
  // End of linalg_matrix_inverse.pas demo
  // End of linalg_matrix_inverse.pas demo
  // End of linalg_matrix_inverse.pas demo
  // End of linalg_matrix_inverse.pas demo
  // End of linalg_matrix_inverse.pas demo
  // End of linalg_matrix_inverse.pas demo
  // End of linalg_matrix_inverse.pas demo
  // End of linalg_matrix_inverse.pas demo
  // End of linalg_matrix_inverse.pas demo
  // End of linalg_matrix_inverse.pas demo
  // End of linalg_matrix_inverse.pas demo
  // End of linalg_matrix_inverse.pas demo
  // End of linalg_matrix_inverse.pas demo
  // End of linalg_matrix_inverse.pas demo
  // End of linalg_matrix_inverse.pas demo
  // End of linalg_matrix_inverse.pas demo
  // End of linalg_matrix_inverse.pas demo
  // End of linalg_matrix_inverse.pas demo
  // End of linalg_matrix_inverse.pas demo
  // End of linalg_matrix_inverse.pas demo
  // End of linalg_matrix_inverse.pas demo
  // End of linalg_matrix_inverse.pas demo
  // End of linalg_matrix_inverse.pas demo
  // End of linalg_matrix_inverse.pas demo
  // End of linalg_matrix_inverse.pas demo
  // End of linalg_matrix_inverse.pas demo
  // End of linalg_matrix_inverse.pas demo
  // End of linalg_matrix_inverse.pas demo
  // End of linalg_matrix_inverse.pas demo
  // End of linalg_matrix_inverse.pas demo
  // End of linalg_matrix_inverse.pas demo
end;
  // End of linalg_matrix_inverse.pas demo

