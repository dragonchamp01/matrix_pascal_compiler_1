unit linalg_matrix_create;
{$mode objfpc}{$H+}
interface
uses
  SysUtils, Math;
procedure Demo;
implementation
procedure PrintMat3(const M: TTMatrix3; const name: string);
begin
  WriteLn(name, ':');
  WriteLn(Math.Mat3Get(M,0,0):0:2, ' ', Math.Mat3Get(M,0,1):0:2, ' ', Math.Mat3Get(M,0,2):0:2);
  WriteLn(Math.Mat3Get(M,1,0):0:2, ' ', Math.Mat3Get(M,1,1):0:2, ' ', Math.Mat3Get(M,1,2):0:2);
  WriteLn(Math.Mat3Get(M,2,0):0:2, ' ', Math.Mat3Get(M,2,1):0:2, ' ', Math.Mat3Get(M,2,2):0:2);
end;
procedure PrintMat4(const M: TTMatrix4; const name: string);
begin
  WriteLn(name, ':');
  WriteLn(Math.Mat4Get(M,0,0):0:2, ' ', Math.Mat4Get(M,0,1):0:2, ' ', Math.Mat4Get(M,0,2):0:2, ' ', Math.Mat4Get(M,0,3):0:2);
  WriteLn(Math.Mat4Get(M,1,0):0:2, ' ', Math.Mat4Get(M,1,1):0:2, ' ', Math.Mat4Get(M,1,2):0:2, ' ', Math.Mat4Get(M,1,3):0:2);
  WriteLn(Math.Mat4Get(M,2,0):0:2, ' ', Math.Mat4Get(M,2,1):0:2, ' ', Math.Mat4Get(M,2,2):0:2, ' ', Math.Mat4Get(M,2,3):0:2);
  WriteLn(Math.Mat4Get(M,3,0):0:2, ' ', Math.Mat4Get(M,3,1):0:2, ' ', Math.Mat4Get(M,3,2):0:2, ' ', Math.Mat4Get(M,3,3):0:2);
end;
procedure Demo;
var
  M3: TTMatrix3;
  M4: TTMatrix4;
begin
  WriteLn('=== matrix Creation ===');
  M3 := Math.Mat3Identity;
  PrintMat3(M3, '3x3 Identity');
  M4 := Math.Mat4Identity;
  PrintMat4(M4, '4x4 Identity');
  M3.Col0 := Math.Vec3(1, 2, 3);
  M3.Col1 := Math.Vec3(4, 5, 6);
  M3.Col2 := Math.Vec3(7, 8, 9);
  PrintMat3(M3, '3x3 Custom');
  M4.Col0 := Math.Vec4(1, 0, 0, 0);
  M4.Col1 := Math.Vec4(0, 2, 0, 0);
  M4.Col2 := Math.Vec4(0, 0, 3, 0);
  M4.Col3 := Math.Vec4(0, 0, 0, 4);
  PrintMat4(M4, '4x4 Diagonal');
  // End of linalg_matrix_create.pas demo
  // End of linalg_matrix_create.pas demo
  // End of linalg_matrix_create.pas demo
  // End of linalg_matrix_create.pas demo
  // End of linalg_matrix_create.pas demo
  // End of linalg_matrix_create.pas demo
  // End of linalg_matrix_create.pas demo
  // End of linalg_matrix_create.pas demo
  // End of linalg_matrix_create.pas demo
  // End of linalg_matrix_create.pas demo
  // End of linalg_matrix_create.pas demo
  // End of linalg_matrix_create.pas demo
  // End of linalg_matrix_create.pas demo
  // End of linalg_matrix_create.pas demo
  // End of linalg_matrix_create.pas demo
  // End of linalg_matrix_create.pas demo
  // End of linalg_matrix_create.pas demo
  // End of linalg_matrix_create.pas demo
  // End of linalg_matrix_create.pas demo
  // End of linalg_matrix_create.pas demo
  // End of linalg_matrix_create.pas demo
  // End of linalg_matrix_create.pas demo
  // End of linalg_matrix_create.pas demo
  // End of linalg_matrix_create.pas demo
  // End of linalg_matrix_create.pas demo
  // End of linalg_matrix_create.pas demo
  // End of linalg_matrix_create.pas demo
  // End of linalg_matrix_create.pas demo
  // End of linalg_matrix_create.pas demo
  // End of linalg_matrix_create.pas demo
  // End of linalg_matrix_create.pas demo
  // End of linalg_matrix_create.pas demo
  // End of linalg_matrix_create.pas demo
  // End of linalg_matrix_create.pas demo
  // End of linalg_matrix_create.pas demo
  // End of linalg_matrix_create.pas demo
  // End of linalg_matrix_create.pas demo
  // End of linalg_matrix_create.pas demo
end;
  // End of linalg_matrix_create.pas demo

