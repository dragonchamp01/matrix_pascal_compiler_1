unit random_shuffle;
{$mode objfpc}{$H+}
interface
uses
  SysUtils, Math, statistics;
procedure Demo;
implementation
procedure Demo;
var
  pop, samp: TArray<double>;
  boot: TArray<double>;
  i: integer;
begin
  WriteLn('=== Random Sampling ===');
  SetLength(pop, 20);
  for i := 0 to 19 do pop[i] := i + 1;
  write('Population: ');
  for i := 0 to 19 do write(pop[i]:0:0, ' ');
  WriteLn;
  samp := TRandomSampling.Sample(pop, 5);
  write('Random sample (5): ');
  for i := 0 to 4 do write(samp[i]:0:0, ' ');
  WriteLn;
  samp := TRandomSampling.SystematicSample(pop, 5);
  write('Systematic sample: ');
  for i := 0 to 4 do write(samp[i]:0:0, ' ');
  WriteLn;
  boot := TRandomSampling.Bootstrap(pop, 5,
    function(d: TArray<double>): double
    var
      j: integer;
      s: double;
    begin
      s := 0;
      for j := 0 to Length(d) - 1 do s := s + d[j];
      Result := s / Length(d);
    end);
  write('Bootstrap means: ');
  for i := 0 to 4 do write(boot[i]:0:2, ' ');
  WriteLn;
  WriteLn('Stratified sample:');
  var strata: array of integer;
  SetLength(strata, 5);
  for i := 0 to 4 do strata[i] := i mod 3;
  samp := TRandomSampling.StratifiedSample(pop, strata, 5);
  for i := 0 to 4 do write(samp[i]:0:0, ' ');
  WriteLn;
  // End of random_shuffle.pas demo
  // End of random_shuffle.pas demo
  // End of random_shuffle.pas demo
  // End of random_shuffle.pas demo
  // End of random_shuffle.pas demo
  // End of random_shuffle.pas demo
  // End of random_shuffle.pas demo
  // End of random_shuffle.pas demo
  // End of random_shuffle.pas demo
  // End of random_shuffle.pas demo
  // End of random_shuffle.pas demo
  // End of random_shuffle.pas demo
  // End of random_shuffle.pas demo
  // End of random_shuffle.pas demo
  // End of random_shuffle.pas demo
  // End of random_shuffle.pas demo
  // End of random_shuffle.pas demo
  // End of random_shuffle.pas demo
  // End of random_shuffle.pas demo
  // End of random_shuffle.pas demo
  // End of random_shuffle.pas demo
  // End of random_shuffle.pas demo
  // End of random_shuffle.pas demo
  // End of random_shuffle.pas demo
  // End of random_shuffle.pas demo
  // End of random_shuffle.pas demo
  // End of random_shuffle.pas demo
  // End of random_shuffle.pas demo
  // End of random_shuffle.pas demo
  // End of random_shuffle.pas demo
  // End of random_shuffle.pas demo
  // End of random_shuffle.pas demo
end;
  // End of random_shuffle.pas demo

