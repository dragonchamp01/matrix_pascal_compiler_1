unit math_trig;
{$mode objfpc}{$H+}
interface
uses
  SysUtils, Math;
procedure Demo;
implementation
procedure Demo;
var
  r, d: double;
  v2, v3, v4: TTVector2;
begin
  WriteLn('=== Trigonometric Functions ===');
  r := Pi / 4;
  WriteLn('Sin(Pi/4): ', Math.Sin(r):0:6);
  WriteLn('Cos(Pi/4): ', Math.Cos(r):0:6);
  WriteLn('Tan(Pi/4): ', Math.Tan(r):0:6);
  WriteLn('ArcSin(0.5): ', Math.ArcSin(0.5):0:6);
  WriteLn('ArcCos(0.5): ', Math.ArcCos(0.5):0:6);
  WriteLn('ArcTan2(1,1): ', Math.ArcTan2(1,1):0:6);
  WriteLn('SinH(1): ', Math.SinH(1):0:6);
  WriteLn('CosH(1): ', Math.CosH(1):0:6);
  WriteLn('TanH(0.5): ', Math.TanH(0.5):0:6);
  d := 45.0;
  WriteLn('SinDeg(45): ', simple_math.SinDeg(d):0:6);
  WriteLn('CosDeg(45): ', simple_math.CosDeg(d):0:6);
  WriteLn('TanDeg(45): ', simple_math.TanDeg(d):0:6);
  WriteLn('ArcSinDeg(0.5): ', simple_math.ArcSinDeg(0.5):0:6);
  WriteLn('ArcCosDeg(0.5): ', simple_math.ArcCosDeg(0.5):0:6);
  WriteLn('ArcTanDeg(1): ', simple_math.ArcTanDeg(1):0:6);
  WriteLn('DegToRad(180): ', simple_math.DegToRad(180):0:6);
  WriteLn('RadToDeg(Pi): ', simple_math.RadToDeg(Pi):0:6);
  v2 := Math.Vec2(3.0, 4.0);
  WriteLn('Vec2 length: ', Math.Vec2Length(v2):0:2);
  // End of math_trig.pas demo
  // End of math_trig.pas demo
  // End of math_trig.pas demo
  // End of math_trig.pas demo
  // End of math_trig.pas demo
  // End of math_trig.pas demo
  // End of math_trig.pas demo
  // End of math_trig.pas demo
  // End of math_trig.pas demo
  // End of math_trig.pas demo
  // End of math_trig.pas demo
  // End of math_trig.pas demo
  // End of math_trig.pas demo
  // End of math_trig.pas demo
  // End of math_trig.pas demo
  // End of math_trig.pas demo
  // End of math_trig.pas demo
  // End of math_trig.pas demo
  // End of math_trig.pas demo
  // End of math_trig.pas demo
  // End of math_trig.pas demo
  // End of math_trig.pas demo
  // End of math_trig.pas demo
  // End of math_trig.pas demo
  // End of math_trig.pas demo
  // End of math_trig.pas demo
  // End of math_trig.pas demo
  // End of math_trig.pas demo
  // End of math_trig.pas demo
  // End of math_trig.pas demo
  // End of math_trig.pas demo
  // End of math_trig.pas demo
  // End of math_trig.pas demo
  // End of math_trig.pas demo
  // End of math_trig.pas demo
  // End of math_trig.pas demo
  // End of math_trig.pas demo
  // End of math_trig.pas demo
  // End of math_trig.pas demo
  // End of math_trig.pas demo
  // End of math_trig.pas demo
  // End of math_trig.pas demo
  // End of math_trig.pas demo
  // End of math_trig.pas demo
  // End of math_trig.pas demo
end;
  // End of math_trig.pas demo

