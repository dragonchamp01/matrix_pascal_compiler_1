unit linalg_vector_dot;
{$mode objfpc}{$H+}
interface
uses
  SysUtils, Math;
procedure Demo;
implementation
procedure Demo;
var
  v2a, v2b: TTVector2;
  v3a, v3b: TTVector3;
  v4a, v4b: TTVector4;
  va, vb, vr: TVector;
  d: double;
begin
  WriteLn('=== Dot Product Operations ===');
  v2a := Math.Vec2(1.0, 2.0);
  v2b := Math.Vec2(3.0, 4.0);
  WriteLn('Vec2Dot: ', Math.Vec2Dot(v2a, v2b):0:2);
  v3a := Math.Vec3(1.0, 0.0, 0.0);
  v3b := Math.Vec3(0.0, 1.0, 0.0);
  WriteLn('Vec3Dot(orthogonal): ', Math.Vec3Dot(v3a, v3b):0:2);
  v3a := Math.Vec3(1.0, 2.0, 3.0);
  v3b := Math.Vec3(4.0, 5.0, 6.0);
  WriteLn('Vec3Dot: ', Math.Vec3Dot(v3a, v3b):0:2);
  v4a := Math.Vec4(1.0, 2.0, 3.0, 4.0);
  v4b := Math.Vec4(5.0, 6.0, 7.0, 8.0);
  WriteLn('Vec4Dot: ', Math.Vec4Dot(v4a, v4b):0:2);
  va := nil; vb := nil;
  va := Math.VecAdd(va, vb, 3); // will allocate
  WriteLn('TVector dot product:');
  va := Math.VecAdd(nil, nil, 0); // skip, use direct
  GetMem(va, 3 * SizeOf(Double));
  GetMem(vb, 3 * SizeOf(Double));
  va[0] := 1; va[1] := 2; va[2] := 3;
  vb[0] := 4; vb[1] := 5; vb[2] := 6;
  d := Math.VecDot(va, vb, 3);
  WriteLn('VecDot(3): ', d:0:2);
  d := Math.VecLength(va, 3);
  WriteLn('VecLength: ', d:0:4);
  vr := Math.VecNormalize(va, 3);
  WriteLn('VecNormalize[0]: ', vr[0]:0:4);
  FreeMem(va); FreeMem(vb); FreeMem(vr);
  // End of linalg_vector_dot.pas demo
  // End of linalg_vector_dot.pas demo
  // End of linalg_vector_dot.pas demo
  // End of linalg_vector_dot.pas demo
  // End of linalg_vector_dot.pas demo
  // End of linalg_vector_dot.pas demo
  // End of linalg_vector_dot.pas demo
  // End of linalg_vector_dot.pas demo
  // End of linalg_vector_dot.pas demo
  // End of linalg_vector_dot.pas demo
  // End of linalg_vector_dot.pas demo
  // End of linalg_vector_dot.pas demo
  // End of linalg_vector_dot.pas demo
  // End of linalg_vector_dot.pas demo
  // End of linalg_vector_dot.pas demo
  // End of linalg_vector_dot.pas demo
  // End of linalg_vector_dot.pas demo
  // End of linalg_vector_dot.pas demo
  // End of linalg_vector_dot.pas demo
  // End of linalg_vector_dot.pas demo
  // End of linalg_vector_dot.pas demo
  // End of linalg_vector_dot.pas demo
  // End of linalg_vector_dot.pas demo
  // End of linalg_vector_dot.pas demo
  // End of linalg_vector_dot.pas demo
  // End of linalg_vector_dot.pas demo
  // End of linalg_vector_dot.pas demo
  // End of linalg_vector_dot.pas demo
  // End of linalg_vector_dot.pas demo
  // End of linalg_vector_dot.pas demo
  // End of linalg_vector_dot.pas demo
  // End of linalg_vector_dot.pas demo
  // End of linalg_vector_dot.pas demo
  // End of linalg_vector_dot.pas demo
  // End of linalg_vector_dot.pas demo
  // End of linalg_vector_dot.pas demo
end;
  // End of linalg_vector_dot.pas demo

