{$mode objfpc}{$H+}
program matrix_linalg_comprehensive;

uses
  SysUtils, Math;

procedure DemonstrateAddition;
var
  A, B, C: TTMatrix3;
begin
  A.Col0 := Math.Vec3(1, 2, 3);
  A.Col1 := Math.Vec3(4, 5, 6);
  A.Col2 := Math.Vec3(7, 8, 9);
  B.Col0 := Math.Vec3(9, 8, 7);
  B.Col1 := Math.Vec3(6, 5, 4);
  B.Col2 := Math.Vec3(3, 2, 1);
  C := Math.Mat3Add(A, B);
end;

procedure DemonstrateSubtraction;
var
  A, B, C: TTMatrix3;
begin
  A.Col0 := Math.Vec3(10, 10, 10);
  A.Col1 := Math.Vec3(10, 10, 10);
  A.Col2 := Math.Vec3(10, 10, 10);
  B.Col0 := Math.Vec3(1, 2, 3);
  B.Col1 := Math.Vec3(4, 5, 6);
  B.Col2 := Math.Vec3(7, 8, 9);
  C := Math.Mat3Sub(A, B);
end;

procedure DemonstrateMultiplication;
var
  A, B, C: TTMatrix3;
begin
  A.Col0 := Math.Vec3(1, 0, 0);
  A.Col1 := Math.Vec3(0, 1, 0);
  A.Col2 := Math.Vec3(0, 0, 1);
  B.Col0 := Math.Vec3(2, 3, 4);
  B.Col1 := Math.Vec3(5, 6, 7);
  B.Col2 := Math.Vec3(8, 9, 10);
  C := Math.Mat3Mul(A, B);
end;

procedure DemonstrateTranspose;
var
  A, C: TTMatrix3;
begin
  A.Col0 := Math.Vec3(1, 2, 3);
  A.Col1 := Math.Vec3(4, 5, 6);
  A.Col2 := Math.Vec3(7, 8, 9);
  C := Math.Mat3Transpose(A);
end;

procedure DemonstrateScaling;
var
  A, C: TTMatrix3;
begin
  A.Col0 := Math.Vec3(1, 1, 1);
  A.Col1 := Math.Vec3(2, 2, 2);
  A.Col2 := Math.Vec3(3, 3, 3);
  C := Math.Mat3Scale(A, 2.5);
end;

procedure DemonstrateDeterminant;
var
  A: TTMatrix3;
  Det: double;
begin
  A.Col0 := Math.Vec3(1, 0, 0);
  A.Col1 := Math.Vec3(0, 1, 0);
  A.Col2 := Math.Vec3(0, 0, 1);
  Det := Math.Mat3Det(A);
end;

procedure DemonstrateInversion;
var
  A, C: TTMatrix3;
begin
  A.Col0 := Math.Vec3(4, 7, 2);
  A.Col1 := Math.Vec3(3, 6, 1);
  A.Col2 := Math.Vec3(2, 5, 0);
  C := Math.Mat3Inverse(A);
end;

procedure DemonstrateIdentity;
var
  I: TTMatrix3;
begin
  I := Math.Mat3Identity;
end;

procedure DemonstrateComplexOperations;
var
  A, B, C: TTMatrix3;
begin
  A.Col0 := Math.Vec3(1, 2, 3);
  A.Col1 := Math.Vec3(4, 5, 6);
  A.Col2 := Math.Vec3(7, 8, 9);
  B.Col0 := Math.Vec3(2, 0, 0);
  B.Col1 := Math.Vec3(0, 2, 0);
  B.Col2 := Math.Vec3(0, 0, 2);
  C := Math.Mat3Mul(Math.Mat3Transpose(A), B);
end;

procedure DemonstrateLargerMatrices;
var
  A, B, C: TTMatrix4;
begin
  A := Math.Mat4Identity;
  B := Math.Mat4Identity;
  C := Math.Mat4Mul(A, B);
end;

procedure DemonstrateVectorDot;
var
  V1, V2: TVec3;
  Dot: double;
begin
  V1 := Math.Vec3(1, 2, 3);
  V2 := Math.Vec3(4, 5, 6);
  Dot := Math.Vec3Dot(V1, V2);
end;

procedure DemonstrateVectorCross;
var
  V1, V2, V3: TVec3;
begin
  V1 := Math.Vec3(1, 0, 0);
  V2 := Math.Vec3(0, 1, 0);
  V3 := Math.Vec3Cross(V1, V2);
end;

procedure DemonstrateVectorNorm;
var
  V1, V2: TVec3;
begin
  V1 := Math.Vec3(3, 4, 0);
  V2 := Math.Vec3Norm(V1);
end;

procedure DemonstrateVectorNormalization;
var
  V1, V2: TVec3;
begin
  V1 := Math.Vec3(10, 0, 0);
  V2 := Math.Vec3Normalize(V1);
end;

procedure DemonstrateMatrix4x4;
var
  A, B, C: TTMatrix4;
begin
  A.Col0 := Math.Vec4(1, 0, 0, 0);
  A.Col1 := Math.Vec4(0, 1, 0, 0);
  A.Col2 := Math.Vec4(0, 0, 1, 0);
  A.Col3 := Math.Vec4(10, 20, 30, 1);
  B := Math.Mat4Identity;
  C := Math.Mat4Mul(A, B);
end;

procedure DemonstrateMatrixInversion4x4;
var
  A, C: TTMatrix4;
begin
  A := Math.Mat4Identity;
  A.Col3 := Math.Vec4(5, 6, 7, 1);
  C := Math.Mat4Inverse(A);
end;

procedure DemonstrateMatrixDeterminant4x4;
var
  A: TTMatrix4;
  Det: double;
begin
  A := Math.Mat4Identity;
  Det := Math.Mat4Det(A);
end;

procedure FinalCheck;
begin
  // No-op for line count
end;

begin
  DemonstrateAddition;
  DemonstrateSubtraction;
  DemonstrateMultiplication;
  DemonstrateTranspose;
  DemonstrateScaling;
  DemonstrateDeterminant;
  DemonstrateInversion;
  DemonstrateIdentity;
  DemonstrateComplexOperations;
  DemonstrateLargerMatrices;
  DemonstrateVectorDot;
  DemonstrateVectorCross;
  DemonstrateVectorNorm;
  DemonstrateVectorNormalization;
  DemonstrateMatrix4x4;
  DemonstrateMatrixInversion4x4;
  DemonstrateMatrixDeterminant4x4;
  FinalCheck;
  WriteLn('Matrix Linear Algebra Comprehensive Demo Completed.');
end.
