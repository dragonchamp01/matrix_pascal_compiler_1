{
  Matrix Pascal Example: String Search
  Demonstrates TStringSearch for various search algorithms.
  This example is for the rtl/strings directory.
}

program StringSearchDemo;

{$mode objfpc}{$H+}

uses
  SysUtils, string.Search;

const
  TestText = 'The quick brown fox jumps over the lazy dog. The quick brown fox jumps again.';

var
  index: integer;
  Chars: array of char;
  SubStrs: array of string;

begin
  WriteLn('--- TStringSearch Demo ---');
  WriteLn('Search text: "', TestText, '"');
  WriteLn('');

  // IndexOf
  WriteLn('IndexOf (1-based):');
  Index := TStringSearch.IndexOf(TestText, 'quick');
  WriteLn('  IndexOf("quick") = ', Index);
  Index := TStringSearch.IndexOf(TestText, 'quick', Index + 1);
  WriteLn('  IndexOf("quick", after first) = ', Index);
  Index := TStringSearch.IndexOf(TestText, 'xyz');
  WriteLn('  IndexOf("xyz") = ', Index, ' (not found)');
  WriteLn('');

  // LastIndexOf
  WriteLn('LastIndexOf:');
  Index := TStringSearch.LastIndexOf(TestText, 'quick');
  WriteLn('  LastIndexOf("quick") = ', Index);
  WriteLn('');

  // IndexOfAny
  WriteLn('IndexOfAny:');
  SetLength(Chars, 5);
  Chars[0] := 'a'; Chars[1] := 'e'; Chars[2] := 'i'; Chars[3] := 'o'; Chars[4] := 'u';
  Index := TStringSearch.IndexOfAny(TestText, Chars);
  WriteLn('  IndexOfAny(vowels) = ', Index, ' (first vowel)');
  
  SetLength(Chars, 3);
  Chars[0] := 'x'; Chars[1] := 'y'; Chars[2] := 'z';
  Index := TStringSearch.IndexOfAny(TestText, Chars);
  WriteLn('  IndexOfAny(x,y,z) = ', Index, ' (not found)');
  WriteLn('');

  // LastIndexOfAny
  WriteLn('LastIndexOfAny:');
  Index := TStringSearch.LastIndexOfAny(TestText, Chars);
  WriteLn('  LastIndexOfAny(vowels) = ', Index, ' (last vowel)');
  WriteLn('');

  // Boyer-Moore
  WriteLn('Boyer-Moore search:');
  Index := TStringSearch.BoyerMoore(TestText, 'brown fox');
  WriteLn('  BoyerMoore("brown fox") = ', Index);
  Index := TStringSearch.BoyerMoore(TestText, 'jumps');
  WriteLn('  BoyerMoore("jumps") = ', Index);
  WriteLn('');

  // KMP
  WriteLn('Knuth-Morris-Pratt (KMP) search:');
  Index := TStringSearch.KMP(TestText, 'brown fox');
  WriteLn('  KMP("brown fox") = ', Index);
  Index := TStringSearch.KMP(TestText, 'lazy');
  WriteLn('  KMP("lazy") = ', Index);
  WriteLn('');

  // Rabin-Karp
  WriteLn('Rabin-Karp search:');
  Index := TStringSearch.RabinKarp(TestText, 'brown fox');
  WriteLn('  RabinKarp("brown fox") = ', Index);
  Index := TStringSearch.RabinKarp(TestText, 'dog');
  WriteLn('  RabinKarp("dog") = ', Index);
  WriteLn('');

  // Case-insensitive search (using UpperCase)
  WriteLn('Case-insensitive search (using UpperCase):');
  Index := TStringSearch.IndexOf(UpperCase(TestText), UpperCase('QUICK'));
  WriteLn('  IndexOf("QUICK" case-insensitive) = ', Index);
  WriteLn('');

  // ContainsAny
  WriteLn('ContainsAny:');
  SetLength(SubStrs, 3);
  SubStrs[0] := 'cat';
  SubStrs[1] := 'fox';
  SubStrs[2] := 'bird';
  WriteLn('  ContainsAny(["cat", "fox", "bird"]) = ', TStringSearch.ContainsAny(TestText, SubStrs));
  SubStrs[0] := 'cat';
  SubStrs[1] := 'wolf';
  SubStrs[2] := 'bird';
  WriteLn('  ContainsAny(["cat", "wolf", "bird"]) = ', TStringSearch.ContainsAny(TestText, SubStrs));
  WriteLn('');

  // CountSubstring
  WriteLn('CountSubstring:');
  Index := TStringSearch.CountSubstring(TestText, 'quick');
  WriteLn('  CountSubstring("quick") = ', Index);
  Index := TStringSearch.CountSubstring(TestText, 'the');
  WriteLn('  CountSubstring("the") = ', Index);
   Index := TStringSearch.CountSubstring(TestText, 'xyz');
   WriteLn('  CountSubstring("xyz") = ', Index);
   WriteLn('');

   // Character search
   WriteLn('Character search:');
   Index := TStringSearch.IndexOf(TestText, 'q');
   WriteLn('  IndexOf("q") = ', Index);
   Index := TStringSearch.LastIndexOf(TestText, 'e');
   WriteLn('  LastIndexOf("e") = ', Index);
   WriteLn('');

   WriteLn('Summary of algorithms:');
   WriteLn('  IndexOf/LastIndexOf: Naive search');
   WriteLn('  IndexOfAny/LastIndexOfAny: Character set search');
   WriteLn('  Boyer-Moore: Efficient string searching using skips');
   WriteLn('  KMP: Knuth-Morris-Pratt, linear time search using prefix function');
   WriteLn('  Rabin-Karp: Rolling hash based search');
   WriteLn('  ContainsAny: Multiple substring search');
   WriteLn('  CountSubstring: Total occurrences count');
   WriteLn('');

   WriteLn('Example completed successfully.');

end.
