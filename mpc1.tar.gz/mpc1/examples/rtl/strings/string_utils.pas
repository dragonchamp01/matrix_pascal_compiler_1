{
  Matrix Pascal Example: String Utils
  Demonstrates TStringUtils for common string operations.
  This example is for the rtl/strings directory.
}

program StringUtilsDemo;

{$mode objfpc}{$H+}

 uses
  SysUtils, string.Utils, StrUtils;

var
  S, Result: string;
  i: integer;
  Words: TStringDynArray;

begin
  WriteLn('--- TStringUtils Demo ---');

  // IsEmpty / IsBlank
  WriteLn('IsEmpty/IsBlank tests:');
  WriteLn('  IsEmpty(""): ', TStringUtils.IsEmpty(''));
  WriteLn('  IsEmpty("hello"): ', TStringUtils.IsEmpty('hello'));
  WriteLn('  IsBlank(""): ', TStringUtils.IsBlank(''));
  WriteLn('  IsBlank("   "): ', TStringUtils.IsBlank('   '));
  WriteLn('  IsBlank(" hello "): ', TStringUtils.IsBlank(' hello '));
  WriteLn('');

  // Reverse
  S := 'Matrix Pascal';
  WriteLn('Reverse("', S, '") = "', TStringUtils.Reverse(S), '"');
  WriteLn('');

  // Repeat
  S := 'Abc';
  WriteLn('Repeat("', S, '", 3) = "', TStringUtils.Repeat(S, 3), '"');
  WriteLn('');

  // Replace
  S := 'Hello World World';
  WriteLn('Replace("', S, '", "World", "Pascal") = "', TStringUtils.Replace(S, 'World', 'Pascal'), '"');
  WriteLn('');

  // Remove
  S := 'Hello World';
  WriteLn('Remove("', S, '", 5, 6) = "', TStringUtils.Remove(S, 5, 6), '"');
  WriteLn('');

  // Insert
  S := 'HelloWorld';
  WriteLn('Insert("', S, '", 5, " ") = "', TStringUtils.Insert(S, 5, ' '), '"');
  WriteLn('');

  // Left / Right
  S := 'Matrix Pascal';
  WriteLn('Left("', S, '", 6) = "', TStringUtils.Left(S, 6), '"');
  WriteLn('Right("', S, '", 6) = "', TStringUtils.Right(S, 6), '"');
  WriteLn('');

  // Contains
  S := 'The quick brown fox';
  WriteLn('Contains("', S, '", "quick") = ', TStringUtils.Contains(S, 'quick'));
  WriteLn('Contains("', S, '", "slow") = ', TStringUtils.Contains(S, 'slow'));
  WriteLn('');

  // Count
  S := 'ababa';
  WriteLn('Count("', S, '", "aba") = ', TStringUtils.Count(S, 'aba'));
  WriteLn('');

  // EqualsIgnoreCase
  WriteLn('EqualsIgnoreCase("Hello", "HELLO") = ', TStringUtils.EqualsIgnoreCase('Hello', 'HELLO'));
  WriteLn('EqualsIgnoreCase("Hello", "World") = ', TStringUtils.EqualsIgnoreCase('Hello', 'World'));
  WriteLn('');

  // ChangeCase
  S := 'Hello World';
  WriteLn('ChangeCase("', S, '", True) = "', TStringUtils.ChangeCase(S, True), '"');
  WriteLn('ChangeCase("', S, '", False) = "', TStringUtils.ChangeCase(S, False), '"');
  WriteLn('');

  // Using StrUtils for more operations
  WriteLn('Additional operations from StrUtils:');
  
  // Trim
  S := '   Trim Me   ';
  WriteLn('  Trim("', S, '") = "', Trim(S), '"');
  
  // Substring (Copy)
  S := 'Matrix Pascal';
  WriteLn('  Copy("', S, '", 7, 6) = "', Copy(S, 7, 6), '"');
  
  // Split
  S := 'apple,banana,cherry';
  Words := SplitString(S, ',');
  Write('  Split("', S, '") = [');
  for i := 0 to High(Words) do
  begin
    Write(Words[i]);
    if i < High(Words) then Write(', ');
  end;
  WriteLn(']');
  
   // Join
   WriteLn('  Join(["apple", "banana", "cherry"], " | ") = "', JoinStrings(Words, ' | '), '"');

   // Pad
   S := '123';
   WriteLn('  PadLeft("', S, '", 5, "0") = "', PadLeft(S, 5, '0'), '"');
   WriteLn('  PadRight("', S, '", 5, "*") = "', PadRight(S, 5, '*'), '"');

   // More StrUtils
   WriteLn('Additional StrUtils:');
   WriteLn('  LowerCase("MixedCase") = "', LowerCase('MixedCase'), '"');
   WriteLn('  UpperCase("MixedCase") = "', UpperCase('MixedCase'), '"');
   WriteLn('  ContainsText("Hello World", "hello") = ', ContainsText('Hello World', 'hello'));
   WriteLn('  ReplaceText("Hello World", "World", "Pascal") = "', ReplaceText('Hello World', 'World', 'Pascal'), '"');

   WriteLn('');
   WriteLn('Example completed successfully.');

end.
