{
  Matrix Pascal Example: MM.MemoryPool Low-Level Memory Pool
  Demonstrates MM.MemoryPool for chunk-based allocation.
  This example is for the rtl/memory directory.
}

program MMMemoryPoolDemo;

{$mode objfpc}{$H+}

uses
  SysUtils, MM.MemoryPool;

var
  pool: TMemoryPool;
  ptr: pointer;
  Pointers: array[0..99] of pointer;
  I: integer;

begin
  WriteLn('--- MM.MemoryPool Low-Level pool Demo ---');

  // Create pool with 128-byte chunks
  Pool := TMemoryPool.Create(128);
  try
    WriteLn('Created pool with chunk size: ', Pool.ChunkSize, ' bytes');
    WriteLn('');

    // Allocate multiple chunks
    WriteLn('Allocating 100 chunks...');
    for I := 0 to 99 do
    begin
      Ptr := Pool.Alloc;
      if Ptr = nil then
      begin
        WriteLn('ERROR: Allocation failed at index ', I);
        Break;
      end;
      Pointers[I] := Ptr;
      // Write pattern to verify
      PByte(Ptr)^ := I mod 256;
    end;
    WriteLn('Allocated ', I, ' chunks successfully');
    WriteLn('');

    // Verify data
    WriteLn('Verifying chunk data...');
    for I := 0 to 99 do
    begin
      if PByte(Pointers[I])^ <> (I mod 256) then
      begin
        WriteLn('ERROR: Data mismatch at index ', I);
        Break;
      end;
    end;
    WriteLn('All 100 chunks verified correctly');
    WriteLn('');

    // Free all chunks
    WriteLn('Freeing all chunks...');
    for I := 0 to 99 do
      Pool.Free(Pointers[I]);
    WriteLn('All chunks freed');
    WriteLn('');

    // Test clear
    WriteLn('Testing Clear...');
    for I := 0 to 10 do
      Pointers[I] := Pool.Alloc;
    Pool.Clear;
    WriteLn('Pool cleared, all chunks returned to free list');

  finally
    Pool.Free;
    WriteLn('Pool destroyed.');
  end;

  WriteLn('');
  WriteLn('Example completed successfully.');
end.