{
  Matrix Pascal Example: MM.Heap Low-Level Heap Operations
  Demonstrates MM.Heap class for direct heap management.
  This example is for the rtl/memory directory.
}

program MMHeapDemo;

{$mode objfpc}{$H+}

uses
  SysUtils, MM.Heap;

var
  Ptr1, Ptr2, Ptr3: pointer;
  HeapSize, FreeSpace: nativeuint;

begin
  WriteLn('--- MM.Heap Low-Level Heap Demo ---');

  // Get initial heap stats
  HeapSize := THeap.GetHeapSize;
  FreeSpace := THeap.GetFreeSpace;
  WriteLn('Initial heap: Size=', HeapSize, ' Free=', FreeSpace);
  WriteLn('');

  // Allocate memory
  WriteLn('Allocating 1KB...');
  Ptr1 := THeap.Alloc(1024);
  WriteLn('  Ptr1 = ', HexStr(PtrUInt(Ptr1)));

  WriteLn('Allocating 4KB...');
  Ptr2 := THeap.Alloc(4096);
  WriteLn('  Ptr2 = ', HexStr(PtrUInt(Ptr2)));

  WriteLn('Allocating 16KB...');
  Ptr3 := THeap.Alloc(16384);
  WriteLn('  Ptr3 = ', HexStr(PtrUInt(Ptr3)));
  WriteLn('');

  // Check heap stats after allocations
  HeapSize := THeap.GetHeapSize;
  FreeSpace := THeap.GetFreeSpace;
  WriteLn('After allocations: Size=', HeapSize, ' Free=', FreeSpace);
  WriteLn('');

  // Reallocate
  WriteLn('Reallocating Ptr1 from 1KB to 8KB...');
  Ptr1 := THeap.Realloc(Ptr1, 8192);
  WriteLn('  New Ptr1 = ', HexStr(PtrUInt(Ptr1)));
  WriteLn('');

  // Check heap stats after realloc
  HeapSize := THeap.GetHeapSize;
  FreeSpace := THeap.GetFreeSpace;
  WriteLn('After realloc: Size=', HeapSize, ' Free=', FreeSpace);
  WriteLn('');

  // Compact heap
  WriteLn('Compacting heap...');
  THeap.Compact;
  HeapSize := THeap.GetHeapSize;
  FreeSpace := THeap.GetFreeSpace;
  WriteLn('After compact: Size=', HeapSize, ' Free=', FreeSpace);
  WriteLn('');

  // Free memory
  WriteLn('Freeing all allocations...');
  THeap.Free(Ptr1);
  THeap.Free(Ptr2);
  THeap.Free(Ptr3);
  WriteLn('All freed.');
  WriteLn('');

  // Final stats
  HeapSize := THeap.GetHeapSize;
  FreeSpace := THeap.GetFreeSpace;
  WriteLn('Final heap: Size=', HeapSize, ' Free=', FreeSpace);

  WriteLn('');
  WriteLn('Example completed successfully.');
end.