{$mode objfpc}{$H+}

program PrctlDemo;

uses
  SysUtils, linux.syscalls, linux.types;

var
  name: array[0..15] of char;
  res: cint;
  pd: linux.types.prctl_mm_map;
  dumpable: cint;

begin
  WriteLn('=== Prctl Demo ===');
  
  WriteLn('Current process name: ', GetProcessName);
  
  StrPCopy(name, 'my_custom_name');
  res := linux.syscalls.prctl(linux.syscalls.PR_SET_NAME, ptruint(@name[0]), 0, 0, 0);
  if res < 0 then
    WriteLn('PR_SET_NAME failed: ', strerror(-res))
  else
    WriteLn('Process name changed to: my_custom_name');
  
  FillChar(name, SizeOf(name), 0);
  res := linux.syscalls.prctl(linux.syscalls.PR_GET_NAME, ptruint(@name[0]), 0, 0, 0);
  if res = 0 then
    WriteLn('Process name retrieved: ', name)
  else
    WriteLn('PR_GET_NAME failed: ', strerror(-res));
  
  dumpable := linux.syscalls.prctl(linux.syscalls.PR_GET_DUMPABLE, 0, 0, 0, 0);
  WriteLn('Dumpable: ', dumpable);
  
  res := linux.syscalls.prctl(linux.syscalls.PR_SET_DUMPABLE, 1, 0, 0, 0);
  if res < 0 then
    WriteLn('PR_SET_DUMPABLE failed: ', strerror(-res));
  
  dumpable := linux.syscalls.prctl(linux.syscalls.PR_GET_DUMPABLE, 0, 0, 0, 0);
  WriteLn('Dumpable after change: ', dumpable);
  
  res := linux.syscalls.prctl(linux.syscalls.PR_GET_PDEATHSIG, 0, 0, 0, 0);
  WriteLn('Parent death signal: ', res);
  
  res := linux.syscalls.prctl(linux.syscalls.PR_SET_PDEATHSIG, linux.syscalls.SIGTERM, 0, 0, 0);
  if res < 0 then
    WriteLn('PR_SET_PDEATHSIG failed: ', strerror(-res));
  
  res := linux.syscalls.prctl(linux.syscalls.PR_GET_PDEATHSIG, 0, 0, 0, 0);
  WriteLn('Parent death signal after change: ', res);
  
  res := linux.syscalls.prctl(linux.syscalls.PR_GET_TIMERSLACK, 0, 0, 0, 0);
  WriteLn('Current timer slack: ', res, ' ns');
  
  res := linux.syscalls.prctl(linux.syscalls.PR_SET_TIMERSLACK, 50000, 0, 0, 0);
  if res < 0 then
    WriteLn('PR_SET_TIMERSLACK failed: ', strerror(-res));
  
  res := linux.syscalls.prctl(linux.syscalls.PR_GET_TIMERSLACK, 0, 0, 0, 0);
  WriteLn('Timer slack after change: ', res, ' ns');
  
  WriteLn('Done');
end.