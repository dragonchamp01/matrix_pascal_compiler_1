unit db_group_by;
{$mode objfpc}{$H+}
interface
uses
  System, Classes, SysUtils, DB.Connection, DB.Query, DB.SQLite;
type
  TGroupByDemo = class
  private
    FConnection: TDBConnection;
  public
    constructor Create(Conn: TDBConnection);
    procedure SetupData;
    procedure SimpleGroupBy;
    procedure GroupByMultiple;
    procedure GroupByWithCount;
    procedure GroupByWithAggregates;
  end;
implementation
constructor TGroupByDemo.Create(Conn: TDBConnection);
begin
  FConnection := Conn;
end;
procedure TGroupByDemo.SetupData;
begin
  FConnection.Execute('CREATE TABLE if not EXISTS sales (' +
    'id integer, product text, category text, region text, amount real, qty integer)');
  FConnection.Execute('INSERT INTO sales VALUES (1, ''Laptop'', ''Electronics'', ''North'', 1200, 2)');
  FConnection.Execute('INSERT INTO sales VALUES (2, ''Mouse'', ''Electronics'', ''North'', 25, 10)');
  FConnection.Execute('INSERT INTO sales VALUES (3, ''Desk'', ''Furniture'', ''South'', 350, 1)');
  FConnection.Execute('INSERT INTO sales VALUES (4, ''Chair'', ''Furniture'', ''South'', 200, 4)');
  FConnection.Execute('INSERT INTO sales VALUES (5, ''Laptop'', ''Electronics'', ''South'', 1100, 1)');
  FConnection.Execute('INSERT INTO sales VALUES (6, ''Monitor'', ''Electronics'', ''North'', 450, 3)');
  FConnection.Execute('INSERT INTO sales VALUES (7, ''Desk'', ''Furniture'', ''North'', 350, 2)');
  FConnection.Execute('INSERT INTO sales VALUES (8, ''Mouse'', ''Electronics'', ''South'', 25, 5)');
end;
procedure TGroupByDemo.SimpleGroupBy;
var
  Results: TList;
begin
  WriteLn('=== Simple GROUP BY ===');
  Results := FConnection.Query(
    'SELECT category, SUM(amount) as total_sales ' +
    'FROM sales GROUP BY category');
  try
    WriteLn('Total sales by category:');
  finally
    Results.Free;
  end;
end;
procedure TGroupByDemo.GroupByMultiple;
var
  Results: TList;
begin
  Results := FConnection.Query(
    'SELECT category, region, SUM(amount) as total, AVG(amount) as avg_sale ' +
    'FROM sales GROUP BY category, region');
  try
    WriteLn('Sales by category and region:');
  finally
    Results.Free;
  end;
end;
procedure TGroupByDemo.GroupByWithCount;
var
  Results: TList;
begin
  Results := FConnection.Query(
    'SELECT product, COUNT(*) as sale_count, SUM(qty) as total_units ' +
    'FROM sales GROUP BY product ORDER BY sale_count DESC');
  try
    WriteLn('Product sales frequency:');
  finally
    Results.Free;
  end;
end;
procedure TGroupByDemo.GroupByWithAggregates;
var
  Results: TList;
begin
  Results := FConnection.Query(
    'SELECT category, ' +
    'SUM(amount) as total, AVG(amount) as avg_value, ' +
    'MIN(amount) as min_sale, MAX(amount) as max_sale, ' +
    'COUNT(*) as transactions ' +
    'FROM sales GROUP BY category');
  try
    WriteLn('Category sales statistics:');
  finally
    Results.Free;
  end;
end;
procedure DemoGroupBy;
var
  Conn: TSQLiteConnection;
  Demo: TGroupByDemo;
begin
  Conn := TSQLiteConnection.Create('groupby_demo.db');
  try
    Conn.Connect;
    Demo := TGroupByDemo.Create(Conn);
    try
      Demo.SetupData;
      Demo.SimpleGroupBy;
      Demo.GroupByMultiple;
      Demo.GroupByWithCount;
      Demo.GroupByWithAggregates;
    finally
      Demo.Free;
    end;
  finally
    Conn.Free;
  end;
end;
end.
