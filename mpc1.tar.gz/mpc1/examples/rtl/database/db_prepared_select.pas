unit db_prepared_select;
{$mode objfpc}{$H+}
interface
uses
  System, Classes, SysUtils, dbcore, prepared_stmt, sqlite;
type
  TPreparedSelectDemo = class
  private
    FDatabase: TSQLiteDatabase;
  public
    constructor Create(const DBPath: string);
    destructor Destroy; override;
    procedure Run;
  end;
implementation
constructor TPreparedSelectDemo.Create(const DBPath: string);
begin
  FDatabase := TSQLiteDatabase.Create(DBPath);
  FDatabase.Connect;
  FDatabase.Execute('CREATE TABLE if not EXISTS products (' +
    'id integer PRIMARY KEY, ' +
    'name text, ' +
    'category text, ' +
    'price real, ' +
    'stock integer)');
  FDatabase.Execute('INSERT INTO products VALUES (1, ''Laptop'', ''Electronics'', 999.99, 10)');
  FDatabase.Execute('INSERT INTO products VALUES (2, ''Mouse'', ''Electronics'', 29.99, 100)');
  FDatabase.Execute('INSERT INTO products VALUES (3, ''Desk'', ''Furniture'', 349.99, 5)');
  FDatabase.Execute('INSERT INTO products VALUES (4, ''Chair'', ''Furniture'', 199.99, 20)');
  FDatabase.Execute('INSERT INTO products VALUES (5, ''Monitor'', ''Electronics'', 449.99, 15)');
end;
destructor TPreparedSelectDemo.Destroy;
begin
  FDatabase.Free;
  inherited;
end;
procedure TPreparedSelectDemo.Run;
var
  Stmt: TPreparedStatement;
  Rows: TDBRows;
  I, J: integer;
begin
  WriteLn('=== Prepared Select Demo ===');
  Stmt := TPreparedStatement.Create(FDatabase);
  try
    Stmt.Prepare('SELECT name, price, stock FROM products WHERE category = ? and price > ?');
    Stmt.SetString(0, 'Electronics');
    Stmt.SetFloat(1, 100.0);
    Rows := Stmt.ExecuteQuery;
    WriteLn('Electronics with price > 100:');
    for I := 0 to Length(Rows) - 1 do
    begin
      write('  Row ', I + 1, ': ');
      for J := 0 to Length(Rows[I].Values) - 1 do
        write(VarToStr(Rows[I].Values[J]), ' ');
      WriteLn;
    end;
    Stmt.ClearParams;
    Stmt.SetString(0, 'Furniture');
    Stmt.SetFloat(1, 0.0);
    Rows := Stmt.ExecuteQuery;
    WriteLn('All Furniture items:');
    for I := 0 to Length(Rows) - 1 do
    begin
      write('  Row ', I + 1, ': ');
      for J := 0 to Length(Rows[I].Values) - 1 do
        write(VarToStr(Rows[I].Values[J]), ' ');
      WriteLn;
    end;
  finally
    Stmt.Free;
  end;
end;
end.
