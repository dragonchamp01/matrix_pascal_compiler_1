unit db_pool_config;
{$mode objfpc}{$H+}
interface
uses
  System, Classes, SysUtils, dbcore, connection_pool;
type
  TPoolConfiguration = record
    MinSize: integer;
    MaxSize: integer;
    Timeout: integer;
    MaxIdleTime: integer;
    ConnectionLifetime: integer;
    ValidationQuery: string;
    TestOnBorrow: boolean;
    TestOnReturn: boolean;
  end;
  TPoolConfigurator = class
  private
    FPool: TConnectionPool;
    FConfig: TPoolConfiguration;
  public
    constructor Create(pool: TConnectionPool);
    procedure LoadDefaultConfig;
    procedure ApplyConfig;
    procedure DisplayConfig;
    procedure ValidateConfig;
    function GetConfig: TPoolConfiguration;
    procedure SetConfig(const Config: TPoolConfiguration);
  end;
implementation
constructor TPoolConfigurator.Create(pool: TConnectionPool);
begin
  FPool := pool;
  LoadDefaultConfig;
end;
procedure TPoolConfigurator.LoadDefaultConfig;
begin
  FConfig.MinSize := 2;
  FConfig.MaxSize := 20;
  FConfig.Timeout := 30;
  FConfig.MaxIdleTime := 300;
  FConfig.ConnectionLifetime := 3600;
  FConfig.ValidationQuery := 'SELECT 1';
  FConfig.TestOnBorrow := true;
  FConfig.TestOnReturn := false;
  WriteLn('=== pool Configuration Demo ===');
  WriteLn('default configuration loaded');
end;
procedure TPoolConfigurator.ApplyConfig;
begin
  FPool.MinConnections := FConfig.MinSize;
  FPool.MaxConnections := FConfig.MaxSize;
  FPool.Timeout := FConfig.Timeout;
  WriteLn('Configuration applied to pool');
end;
procedure TPoolConfigurator.DisplayConfig;
begin
  WriteLn('Current pool configuration:');
  WriteLn('  Min size: ', FConfig.MinSize);
  WriteLn('  Max size: ', FConfig.MaxSize);
  WriteLn('  Timeout: ', FConfig.Timeout, 's');
  WriteLn('  Max idle: ', FConfig.MaxIdleTime, 's');
  WriteLn('  Connection lifetime: ', FConfig.ConnectionLifetime, 's');
  WriteLn('  Validation query: ', FConfig.ValidationQuery);
  WriteLn('  Test on borrow: ', FConfig.TestOnBorrow);
  WriteLn('  Test on return: ', FConfig.TestOnReturn);
  WriteLn('pool state:');
  WriteLn('  Total: ', FPool.TotalConnections);
  WriteLn('  Available: ', FPool.AvailableConnections);
end;
procedure TPoolConfigurator.ValidateConfig;
begin
  WriteLn('Validating pool configuration...');
  if FConfig.MinSize < 1 then WriteLn('  WARNING: MinSize should be >= 1');
  if FConfig.MaxSize < FConfig.MinSize then WriteLn('  WARNING: MaxSize < MinSize');
  if FConfig.Timeout < 1 then WriteLn('  WARNING: Timeout should be > 0');
  if FConfig.MaxIdleTime < 1 then WriteLn('  WARNING: MaxIdleTime should be > 0');
  WriteLn('  Validation complete');
end;
function TPoolConfigurator.GetConfig: TPoolConfiguration;
begin
  Result := FConfig;
end;
procedure TPoolConfigurator.SetConfig(const Config: TPoolConfiguration);
begin
  FConfig := Config;
  ApplyConfig;
end;
procedure DemoPoolConfig;
var
  pool: TConnectionPool;
  Config: TPoolConfigurator;
  CustomConfig: TPoolConfiguration;
begin
  pool := TConnectionPool.Create(TSQLiteDatabase, 'sqlite://pool_config.db');
  try
    Config := TPoolConfigurator.Create(Pool);
    try
      Config.DisplayConfig;
      CustomConfig.MinSize := 5;
      CustomConfig.MaxSize := 50;
      CustomConfig.Timeout := 60;
      CustomConfig.MaxIdleTime := 600;
      CustomConfig.ConnectionLifetime := 7200;
      CustomConfig.ValidationQuery := 'SELECT 1';
      CustomConfig.TestOnBorrow := True;
      CustomConfig.TestOnReturn := True;
      Config.SetConfig(CustomConfig);
      Config.ValidateConfig;
      Config.DisplayConfig;
    finally
      Config.Free;
    end;
  finally
    Pool.Free;
  end;
end;
end.
