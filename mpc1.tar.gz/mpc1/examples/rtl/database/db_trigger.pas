unit db_trigger;
{$mode objfpc}{$H+}
interface
uses
  System, Classes, SysUtils, sqlite3;
type
  TTriggerDemo = class
  private
    FDB: TSQLite3Connection;
  public
    constructor Create(const DBPath: string);
    destructor Destroy; override;
    procedure CreateTables;
    procedure CreateAuditTrigger;
    procedure CreateValidationTrigger;
    procedure CreateUpdateTimestampTrigger;
    procedure TestTriggers;
    procedure DropTriggers;
    procedure ListTriggers;
  end;
implementation
constructor TTriggerDemo.Create(const DBPath: string);
begin
  FDB := TSQLite3Connection.Create(DBPath);
end;
destructor TTriggerDemo.Destroy;
begin
  FDB.Free;
  inherited;
end;
procedure TTriggerDemo.CreateTables;
begin
  WriteLn('=== Trigger Demo ===');
  FDB.Execute('CREATE TABLE if not EXISTS employees (' +
    'id integer PRIMARY KEY, ' +
    'name text, ' +
    'salary real, ' +
    'department text, ' +
    'updated_at TIMESTAMP)');
  FDB.Execute('CREATE TABLE if not EXISTS audit_log (' +
    'id integer PRIMARY KEY AUTOINCREMENT, ' +
    'table_name text, ' +
    'action text, ' +
    'old_data text, ' +
    'new_data text, ' +
    'changed_at TIMESTAMP default CURRENT_TIMESTAMP, ' +
    'changed_by text)');
  WriteLn('Created employees and audit_log tables');
end;
procedure TTriggerDemo.CreateAuditTrigger;
begin
  FDB.Execute('CREATE TRIGGER if not EXISTS trg_employees_audit_insert ' +
    'AFTER INSERT ON employees ' +
    'begin ' +
    '  INSERT INTO audit_log (table_name, action, new_data, changed_by) ' +
    '  VALUES (''employees'', ''INSERT'', new.name, ''system''); ' +
    'end');
  WriteLn('Created audit trigger for INSERT on employees');
end;
procedure TTriggerDemo.CreateValidationTrigger;
begin
  FDB.Execute('CREATE TRIGGER if not EXISTS trg_employees_salary_check ' +
    'BEFORE INSERT ON employees ' +
    'begin ' +
    '  SELECT case ' +
    '    WHEN new.salary < 0 then ' +
    '      raise(abort, ''Salary cannot be negative'') ' +
    '  end; ' +
    'end');
  WriteLn('Created validation trigger for salary check');
end;
procedure TTriggerDemo.CreateUpdateTimestampTrigger;
begin
  FDB.Execute('CREATE TRIGGER if not EXISTS trg_employees_timestamp ' +
    'AFTER UPDATE ON employees ' +
    'begin ' +
    '  UPDATE employees set updated_at = datetime(''now'') WHERE id = new.id; ' +
    'end');
  WriteLn('Created trigger to auto-update timestamp');
end;
procedure TTriggerDemo.TestTriggers;
begin
  WriteLn('Testing triggers:');
  FDB.Execute('INSERT INTO employees VALUES (1, ''Alice'', 75000, ''Engineering'', NULL)');
  WriteLn('  Insert triggered audit log entry');
  FDB.Execute('UPDATE employees set salary = 80000 WHERE id = 1');
  WriteLn('  Update triggered timestamp update');
  try
    FDB.Execute('INSERT INTO employees VALUES (2, ''Bob'', -100, ''Sales'', NULL)');
  except
    on E: Exception do
      WriteLn('  Validation trigger caught: ', E.message);
  end;
end;
procedure TTriggerDemo.DropTriggers;
begin
  WriteLn('Dropping triggers:');
  FDB.Execute('DROP TRIGGER if EXISTS trg_employees_audit_insert');
  FDB.Execute('DROP TRIGGER if EXISTS trg_employees_salary_check');
  FDB.Execute('DROP TRIGGER if EXISTS trg_employees_timestamp');
  WriteLn('  All triggers dropped');
end;
procedure TTriggerDemo.ListTriggers;
var
  Stmt: TSQLite3Statement;
begin
  WriteLn('Listing triggers:');
  Stmt := FDB.Prepare('SELECT name, sql FROM sqlite_master WHERE type=''trigger''');
  try
    while Stmt.Step = 5 do
      WriteLn('  Trigger: ', Stmt[0]);
  finally
    Stmt.Free;
  end;
end;
procedure DemoTrigger;
var
  Demo: TTriggerDemo;
begin
  Demo := TTriggerDemo.Create('trigger_demo.db');
  try
    Demo.CreateTables;
    Demo.CreateAuditTrigger;
    Demo.CreateValidationTrigger;
    Demo.CreateUpdateTimestampTrigger;
    Demo.TestTriggers;
    Demo.ListTriggers;
    Demo.DropTriggers;
  finally
    Demo.Free;
  end;
end;
end.
