unit db_multi_tenant;
{$mode objfpc}{$H+}
interface
uses
  System, Classes, SysUtils, DB.Connection, DB.SQLite, sqlite3;
type
  TTenantStrategy = (tsSeparateDatabase, tsSeparateSchema, tsSharedTable);
  TTenantContext = class
  private
    FCurrentTenantID: string;
    FStrategy: TTenantStrategy;
  public
    constructor Create(const TenantID: string; Strategy: TTenantStrategy);
    property CurrentTenantID: string read FCurrentTenantID;
    property Strategy: TTenantStrategy read FStrategy;
  end;
  TMultiTenantManager = class
  private
    FConnections: TStringList;
    FBasePath: string;
  public
    constructor Create(const BasePath: string);
    destructor Destroy; override;
    function GetTenantConnection(const TenantID: string): TSQLiteConnection;
    function CreateTenantDatabase(const TenantID: string): boolean;
    procedure ExecuteForAllTenants(const SQL: string);
    procedure ListTenants;
  end;
implementation
constructor TTenantContext.Create(const TenantID: string; Strategy: TTenantStrategy);
begin
  FCurrentTenantID := TenantID;
  FStrategy := Strategy;
end;
constructor TMultiTenantManager.Create(const BasePath: string);
begin
  FConnections := TStringList.Create;
  FBasePath := BasePath;
end;
destructor TMultiTenantManager.Destroy;
var
  I: integer;
begin
  for I := 0 to FConnections.Count - 1 do
    TObject(FConnections.Objects[I]).Free;
  FConnections.Free;
  inherited;
end;
function TMultiTenantManager.GetTenantConnection(const TenantID: string): TSQLiteConnection;
var
  Idx: integer;
  Conn: TSQLiteConnection;
begin
  Idx := FConnections.IndexOf(TenantID);
  if Idx >= 0 then
    Result := TSQLiteConnection(FConnections.Objects[Idx])
  else
  begin
    Conn := TSQLiteConnection.Create(FBasePath + '/' + TenantID + '.db');
    Conn.Connect;
    FConnections.AddObject(TenantID, Conn);
    Result := Conn;
  end;
end;
function TMultiTenantManager.CreateTenantDatabase(const TenantID: string): boolean;
var
  Conn: TSQLiteConnection;
begin
  WriteLn('Creating tenant database for: ', TenantID);
  Conn := GetTenantConnection(TenantID);
  Conn.Execute('CREATE TABLE if not EXISTS tenant_data (id integer, value text)');
  WriteLn('  Tenant ', TenantID, ' ready');
  Result := true;
end;
procedure TMultiTenantManager.ExecuteForAllTenants(const SQL: string);
var
  I: integer;
  Conn: TSQLiteConnection;
begin
  WriteLn('Executing for all tenants: ', Copy(SQL, 1, 60));
  for I := 0 to FConnections.Count - 1 do
  begin
    Conn := TSQLiteConnection(FConnections.Objects[I]);
    if Conn.IsConnected then
    begin
      Conn.Execute(SQL);
      WriteLn('  Executed on tenant: ', FConnections[I]);
    end;
  end;
end;
procedure TMultiTenantManager.ListTenants;
var
  I: integer;
begin
  WriteLn('Active tenants (', FConnections.Count, '):');
  for I := 0 to FConnections.Count - 1 do
    WriteLn('  - ', FConnections[I]);
end;
procedure DemoMultiTenant;
var
  Mgr: TMultiTenantManager;
begin
  WriteLn('=== Multi-Tenant Demo ===');
  Mgr := TMultiTenantManager.Create('/tmp/tenants');
  try
    Mgr.CreateTenantDatabase('acme_corp');
    Mgr.CreateTenantDatabase('globex_inc');
    Mgr.CreateTenantDatabase('initech');
    Mgr.ListTenants;
    Mgr.ExecuteForAllTenants('INSERT INTO tenant_data VALUES (1, ''initialized'')');
  finally
    Mgr.Free;
  end;
end;
end.
