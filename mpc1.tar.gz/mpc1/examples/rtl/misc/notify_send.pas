program NotifySendExample;
{$mode objfpc}{$H+}
uses
  System, Classes, SysUtils, notify;

begin
  WriteLn('Desktop Notification Example');
  WriteLn('============================');
  WriteLn;

  if not Assigned(libnotify) then
  begin
    WriteLn('libnotify is not available on this system.');
    WriteLn('The notify unit provides desktop notification bindings.');
    WriteLn;
    WriteLn('Expected usage:');
    WriteLn('  1. Call notify_init("AppName")');
    WriteLn('  2. Create a NotifyNotification');
    WriteLn('  3. set title, body, and icon');
    WriteLn('  4. Call Show to display');
    WriteLn('  5. Free the notification');
    WriteLn;
    WriteLn('Features supported:');
    WriteLn('  - Summary and body text');
    WriteLn('  - Icon and urgency levels');
    WriteLn('  - Action buttons and callbacks');
    WriteLn('  - Notification timeout');
    WriteLn('  - Notification categories');
    WriteLn;
    WriteLn('Example notification would show:');
    WriteLn('  Title: matrix pascal');
    WriteLn('  Body: Hello from Notification System!');
    WriteLn('  Icon: dialog-information');
    WriteLn('  Urgency: Normal');
  end
  else
  begin
    WriteLn('libnotify detected.');
    WriteLn('Sending real notifications...');
  end;

  WriteLn;
  WriteLn('Desktop notification capabilities:');
  WriteLn('  - notify_init: initialize notification library');
  WriteLn('  - NotifyNotification: create notification objects');
  WriteLn('  - set summary, body, and icon');
  WriteLn('  - Urgency levels: low, normal, critical');
  WriteLn('  - Action buttons with callback handlers');
  WriteLn('  - Notification timeouts and categories');
  WriteLn;
  WriteLn('Expected notification flow:');
  WriteLn('  1. notify_init("AppName")');
  WriteLn('  2. notification := NotifyNotification.New');
  WriteLn('  3. notification.SetSummary("Title")');
  WriteLn('  4. notification.SetBody("Message")');
  WriteLn('  5. notification.SetUrgency(NOTIFY_URGENCY_NORMAL)');
  WriteLn('  6. notification.Show');
  WriteLn('  7. notification.Free');
  WriteLn;
  WriteLn('The notify unit wraps libnotify for Linux desktop');
  WriteLn('notifications. requires a notification daemon like');
  WriteLn('GNOME Shell, KDE, or notify-osd to be running.');
  WriteLn;
  WriteLn('Notifications can include action buttons that trigger');
  WriteLn('callbacks, icon images, and custom sound effects.');
  WriteLn;
  WriteLn('libnotify supports notification categories for');
  WriteLn('grouping similar notifications (email, im, etc).');
  WriteLn('Different urgency levels affect display behavior:');
  WriteLn('  - LOW: normal timeout');
  WriteLn('  - NORMAL: stays longer, may have sound');
  WriteLn('  - CRITICAL: stays until dismissed');
  WriteLn;
  WriteLn('Note: The notify unit is a stub and needs');
  WriteLn('libnotify development library to function.');
  WriteLn('Cross-platform notifications require separate');
  WriteLn('implementations per operating system.');
  WriteLn("This example demonstrates the notify send RTL API.");
  WriteLn('Done.');
end.
