program ContnrsQueueExample;
{$mode objfpc}{$H+}
uses
  System, Classes, SysUtils, Contnrs, Generics.Collections;

var
  Queue: TQueue<string>;
  S: string;
  I: integer;
begin
  WriteLn('Generics TQueue<string> (Contnrs compatible)');
  WriteLn('=============================================');
  WriteLn;

  Queue := TQueue<string>.Create;
  try
    Queue.Enqueue('First in line');
    Queue.Enqueue('Second');
    Queue.Enqueue('Third');
    Queue.Enqueue('Fourth');
    Queue.Enqueue('Last in line');

    WriteLn('Count after enqueues: ', Queue.Count);
    WriteLn('Peek front: ', Queue.Peek);

    WriteLn('Dequeue all (FIFO order):');
    while Queue.Count > 0 do
    begin
      S := Queue.Dequeue;
      WriteLn('  ', S);
    end;

    WriteLn('Count after dequeues: ', Queue.Count);

    for I := 1 to 5 do
      Queue.Enqueue('Item ' + IntToStr(I));

    WriteLn('After re-adding, count: ', Queue.Count);
    WriteLn('Peek: ', Queue.Peek);

    Queue.Clear;
    WriteLn('Count after clear: ', Queue.Count);
  finally
    Queue.Destroy;
  end;

  WriteLn;
  WriteLn('TQueue<T> (FIFO) from Generics.Collections:');
  WriteLn('  - First-In-First-out data structure');
  WriteLn('  - Enqueue: add item to tail');
  WriteLn('  - Dequeue: remove and return head item');
  WriteLn('  - Peek: return head without removal');
  WriteLn('  - Circular buffer implementation');
  WriteLn('  - Clear: remove all items');
  WriteLn;
  WriteLn('Use cases in Contnrs compatible manner:');
  WriteLn('  - Job/task scheduling');
  WriteLn('  - message passing systems');
  WriteLn('  - BFS graph traversal');
  WriteLn('  - Print spooler buffers');
  WriteLn('  - Stream processing pipelines');
  WriteLn;
  WriteLn('The circular buffer provides O(1) enqueue/dequeue');
  WriteLn('without shifting elements like a linear array would.');
  WriteLn;
  WriteLn('Queue operations from Generics.Collections:');
  WriteLn('  - Enqueue: add to tail (FIFO order)');
  WriteLn('  - Dequeue: remove and return from head');
  WriteLn('  - Peek: return head without removal');
  WriteLn('  - Count: number of elements in queue');
  WriteLn('  - Clear: remove all elements');
  WriteLn;
  WriteLn('The circular buffer grows by doubling when full.');
  WriteLn('Elements are stored contiguously for cache efficiency.');
  WriteLn;
  WriteLn('Use Contnrs.TQueue for non-generic object queues,');
  WriteLn('or Generics.Collections.TQueue<T> for typed queues.');
  WriteLn("This example demonstrates the contnrs queue RTL API.");
  WriteLn('Done.');
end.
