program Example_363;
uses Xorg;

var
  display: PDisplay;
  window: PWindow;
  screen: integer;
  root: integer;
  white_pixel: uint32;
  black_pixel: uint32;

begin
  display := XOpenDisplay(nil);
  if display = nil then
  begin
    WriteLn('Error: Cannot open X display.');
    exit;
  end;

  screen := XDefaultScreen(display);
  root := XDefaultRootWindow(display);
  white_pixel := XDefaultWhitePixel(display, screen);
  black_pixel := XDefaultBlackPixel(display, screen);

  window := XCreateSimpleWindow(display, root, 100, 100, 400, 300, 1, black_pixel, white_pixel);
  XMapWindow(display, window);

  WriteLn('Running Example 363. Press Enter to exit...');
  
  XDestroyWindow(display, window);
  XCloseDisplay(display);
end.