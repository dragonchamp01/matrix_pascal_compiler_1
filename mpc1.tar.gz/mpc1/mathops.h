#ifndef MATHOPS_H
#define MATHOPS_H
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

extern int mul_nums(int, int);
extern int add_nums(int, int);

void mathops_init(void);
void mathops_final(void);

#ifdef __cplusplus
}
#endif

#endif /* MATHOPS_H */
