#ifndef STACK_H
#define STACK_H

#define MAX_REGS 8
#define MAX_XMM_REGS 8
#define MAX_TEMPS 100

/* STRUCTURES */
typedef struct stack_s {
	int reg[MAX_REGS];
	int temp[MAX_TEMPS];
	int top_idx;
	int reg_top_idx;
	int xmm_reg[MAX_XMM_REGS];
	int xmm_temp[MAX_TEMPS];
	int xmm_top_idx;
} stack_t;


/* GLOBALS */
extern stack_t* rstack;

/* FUNCTIONS */
#ifdef __cplusplus
extern "C" {
#endif
int top(stack_t* stack);
int pop(stack_t* stack);
void swap(stack_t* stack);
void push(int reg, stack_t* stack);

int xmm_top(stack_t* stack);
int xmm_pop(stack_t* stack);
void xmm_swap(stack_t* stack);
void xmm_push(int reg, stack_t* stack);

char* reg_string(int reg);
char* xmm_string(int reg);
void print_regs(stack_t* stack);
void reset_reg_stack(stack_t* stack);
void init_reg_stack();
#ifdef __cplusplus
}
#endif

#endif
